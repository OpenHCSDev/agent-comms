"""ACP session publication consumes the shared configuration catalogs."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Iterable
from contextlib import aclosing, asynccontextmanager
from functools import partial

from acp.schema import (
    ConfigOptionUpdate,
    SessionConfigOptionBoolean,
    SessionConfigOptionSelect,
    SessionConfigSelectOption,
    SetSessionConfigOptionResponse,
)

from agent_comms.comms import Comms
from agent_comms.config_options import (
    CatalogConfigOption,
    ConfigOptions,
    ConfigurationChanges,
    InvalidConfigChoice,
)
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.errors import Refused
from agent_comms.execution.child_process import join_retirement
from agent_comms.execution.controller import SessionUpdateSink
from agent_comms.execution.native_failures import NativePiUnavailable
from agent_comms.execution.owner_protocol import IncompatibleOwner
from agent_comms.execution.pi_commands import SettingCommand
from agent_comms.execution.runtime import RuntimeProxy
from agent_comms.execution.session_effects import SessionEffects
from agent_comms.execution.turn_inbox import UseSettings
from agent_comms.messaging.bus import Bus
from agent_comms.messaging.watched import FileSource
from agent_comms.nominal.field_codec import AcpSessionId, FieldCodec
from agent_comms.registry.thread_model import CatalogSelection
from agent_comms.registry.threads import ChosenModel, NextTurnConfiguration, Thread
from agent_comms.session_reads import OwnedObservation, SessionConfigurationSource
from agent_comms.transport.runtime_server import RuntimeServer


class SessionConfigOptions(ConfigurationChanges[ConfigOptions]):
    """Publish and persist each executing session's original configuration."""

    def __init__(
        self,
        comms: Comms,
        runtime: RuntimeServer,
        sessions: SessionConfigurationSource[RuntimeProxy | IncompatibleOwner],
        effects: SessionEffects,
    ):
        self.comms, self.runtime, self.sessions, self.effects = comms, runtime, sessions, effects
        self.catalog_publish_lock = asyncio.Lock()
        self.publications: dict[AcpSessionId, ConfigOptionUpdate] = {}
        self._observed_owners: dict[AcpSessionId, OwnedObservation] = {}
        self._tasks: set[asyncio.Task[None]] = set()
        self.observer = self.runtime.background(self._observe_configuration())
        # The stored settings each session's owner last saw, to notice a change.
        # The model and thinking level each running turn currently uses.
        self.settings_in_use: dict[AcpSessionId, UseSettings] = {}

    async def describe(self, option: CatalogConfigOption, thread: CatalogSelection) -> SessionConfigOptionSelect:
        choices = await option.display_choices(thread)
        configured = option.current_value(thread)
        try:
            option.require_value(configured, choices)
        except InvalidConfigChoice as error:
            raise NativePiUnavailable(str(error)) from error
        return SessionConfigOptionSelect(
            id=FieldCodec.encode(type(option)), name=option.title,
            description=option.description, category=option.category, type="select",
            current_value=next(choice.editor_value for choice in choices if choice.value == configured),
            options=[SessionConfigSelectOption(name=choice.name, value=choice.editor_value)
                     for choice in choices],
        )

    async def options(
        self, configuration: ConfigOptions, thread: CatalogSelection,
    ) -> list[SessionConfigOptionSelect | SessionConfigOptionBoolean]:
        """Present this executing session's catalogs through the ACP schema."""
        return [await self.describe(configuration.catalog_for(member), thread)
                for member in CatalogConfigOption.members_with(CatalogConfigOption)]

    async def _publish(
        self, session_id: AcpSessionId,
        options: list[SessionConfigOptionSelect | SessionConfigOptionBoolean],
    ) -> None:
        """Publish within the configuration owner's acquisition lifetime."""
        update = ConfigOptionUpdate(
            session_update="config_option_update", config_options=options
        )
        if self.publications.get(session_id) == update:
            return
        if await self.runtime.publish_update(session_id=session_id, update=update):
            # Retain exactly what this send supplied, not a later catalog
            # generation or settings observation acquired during its await.
            self.publications[session_id] = update

    async def set_option(
        self, config_id: str, session_id: AcpSessionId, value: str | bool
    ) -> SetSessionConfigOptionResponse:
        try:
            member = CatalogConfigOption.member_named(config_id)
            value = FieldCodec.decode(str, value)
        except ValueError:
            raise Refused.invalid_params(
                {"reason": f"Unknown session configuration option: {config_id!r}"}
            ) from None
        if session_id in self.sessions.proxies:
            result = await self.sessions.proxies[session_id].request(
                "set_config_option", config_id=config_id, value=value
            )
            return SetSessionConfigOptionResponse.model_validate(result)
        name = await self.sessions.sync_identity(session_id)
        thread = await Coordination.run_worker(partial(self.comms.registry.require, name))
        try:
            await self.effects.inputs.state(session_id).owned().configuration.catalog_for(member).change(self, thread, value)
        except (NativePiUnavailable, InvalidConfigChoice) as error:
            raise Refused.invalid_params({"reason": str(error)}) from error
        await self.effects.turns.close_idle_backend(session_id)
        await self.use_stored_settings(session_id, name)
        return SetSessionConfigOptionResponse(
            config_options=await self.publish_configuration(session_id),
        )

    async def configure_thread(
        self, configuration: ConfigOptions, thread: Thread, command: SettingCommand,
    ) -> None:
        """Store the model and thinking level Pi itself reports for this change."""
        arguments = thread.model.native(configuration.agent_args).with_thinking(
            thread.thinking_level
        )
        state = await command.configure(
            configuration.launch.binary, arguments.argv, package=configuration.package,
            worktree=thread.worktree.path, root=self.comms.root,
            configuration=configuration.launch.configuration,
        )
        model = state.model.thread_model().require_reported()
        level = state.thinking_level.require_reported(
            NativePiUnavailable("Native configuration did not report a thinking level"))
        await self.store_configuration(thread, NextTurnConfiguration(
            model=ChosenModel(model.text), thinking_level=level,
        ))

    async def store_configuration(
        self, thread: Thread, change: NextTurnConfiguration,
    ) -> None:
        await Coordination.run_worker(partial(
            self.comms.threads.set_thread_configuration, thread, change,
        ))

    @staticmethod
    def stored_settings(thread: Thread) -> UseSettings:
        return UseSettings(thread.model, thread.thinking_level)

    def turn_started(self, session_id: AcpSessionId, thread: Thread) -> None:
        self.settings_in_use.setdefault(session_id, self.stored_settings(thread))

    async def use_stored_settings(self, session_id: AcpSessionId, name: str) -> None:
        """A running turn switches at its next model call, whichever process stored the change."""
        thread = await Coordination.run_worker(partial(self.comms.registry.require, name))
        settings = self.stored_settings(thread)
        if self.settings_in_use.get(session_id, settings) == settings:
            return
        turn = await self.effects.turns.active_backend_turn(session_id)
        if turn.is_open:
            self.settings_in_use[session_id] = settings
            turn.send(settings)

    async def apply_stored_settings(self, session_id: AcpSessionId) -> None:
        """Apply execution state without discovering presentation catalogs."""
        name = await self.sessions.sync_identity(session_id)
        await self.effects.turns.goals.sync_goal_execution(session_id)
        await self.use_stored_settings(session_id, name)

    def start_menu(self, session_id: AcpSessionId, client: SessionUpdateSink) -> asyncio.Task[None]:
        """Retain initial publication until it finishes or its consumer retires."""
        owner = self.effects.inputs.state(session_id).owned()
        self._observed_owners[session_id] = owner
        task = self.runtime.background(owner.observe_live(partial(self.send_menu, client, session_id)))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        return task

    @asynccontextmanager
    async def observe_configuration(
        self, session_id: AcpSessionId, client: SessionUpdateSink,
    ) -> AsyncIterator[None]:
        """An attached socket owns its initial catalog wait through disconnect."""
        task = self.start_menu(session_id, client)
        try:
            yield
        finally:
            await self.retire_observations((task,))

    async def retire_observations(self, tasks: Iterable[asyncio.Task[None]]) -> None:
        pending = tuple(tasks)
        for task in pending:
            task.cancel()
        await join_retirement(asyncio.gather(*pending, return_exceptions=True))

    async def send_menu(self, client: SessionUpdateSink, session_id: AcpSessionId) -> None:
        options = await self.options_for_session(session_id)
        async with self.catalog_publish_lock:
            update = ConfigOptionUpdate(
                session_update="config_option_update", config_options=options,
            )
            if await client.publish_update(session_id=session_id, update=update):
                self.publications[session_id] = update

    async def options_for_session(
        self, session_id: AcpSessionId,
    ) -> list[SessionConfigOptionSelect | SessionConfigOptionBoolean]:
        name = self.sessions.require(session_id)
        return await self.options(
            self.effects.inputs.state(session_id).owned().configuration,
            await Coordination.run_worker(partial(self.comms.threads.running_selection, name)),
        )

    def stop_observing_configuration(self, session_id: AcpSessionId) -> None:
        self._observed_owners.pop(session_id, None)
        self.publications.pop(session_id, None)

    async def _observe_configuration(self) -> None:
        async with aclosing(Bus.watch_sources(FileSource(self.comms.registry.store.path))) as observations:
            async for _ in observations:
                for owner in tuple(self._observed_owners.values()):
                    await owner.observe_live(partial(self.refresh_configuration, owner.identifier))

    async def refresh_configuration(self, session_id: AcpSessionId) -> None:
        """Refresh within the original owner's admitted observation lifetime."""
        await self.sessions.sync_identity(session_id)
        await self.publish_configuration(session_id)

    async def close(self) -> None:
        await self.retire_observations((*self._tasks, self.observer))
        self._observed_owners.clear()

    async def publish_configuration(
        self, session_id: AcpSessionId,
    ) -> list[SessionConfigOptionSelect | SessionConfigOptionBoolean]:
        options = await self.options_for_session(session_id)
        async with self.catalog_publish_lock:
            await self._publish(session_id, options)
            return options
