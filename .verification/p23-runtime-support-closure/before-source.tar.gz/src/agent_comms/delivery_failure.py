"""Decode actual send exceptions once into the shared delivery failure family."""

from metaclass_registry.mro_dispatch import (
    MroDispatch,
    handles,
)

from agent_comms.acp_extension import BackendDeliveryFailure, ClaimBlockedFailure
from agent_comms.errors import HumanClaimBlockedError


class FailureDecoder(MroDispatch):
    def __init__(self):
        self.failure = None

    @handles(HumanClaimBlockedError)
    def blocked(self, error):
        self.failure = ClaimBlockedFailure(str(error))

    @handles(Exception)
    def refused(self, error):
        if self.failure is None:
            self.failure = BackendDeliveryFailure(str(error))


def delivery_failure(error: Exception):
    decoder = FailureDecoder()
    decoder.dispatch_sync(error)
    return decoder.failure
