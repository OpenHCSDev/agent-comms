"""Declared Comms facts carried by the external ACP metadata envelope.

These records are shared with the paired Toad client. They describe observations;
they never authorize a native send, restore a queue, or replay an UNKNOWN input.
"""

from __future__ import annotations

from abc import abstractmethod
from dataclasses import dataclass, field, replace
from typing import Annotated, Callable, ClassVar, Self

from acp.schema import AgentMessageChunk, TextContentBlock

from agent_comms.acp_failure import (
    ACPFailure,
    BackendDeliveryFailure,
    DeliveryFailure,
    FailureSource,
    UnrecordedFailureSource,
)
from agent_comms.agent_events import CompactionEvent
from agent_comms.context_reading import ContextReading
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.execution.native_output import NativeOutputScope
from agent_comms.execution.native_runtime_input import CurrentNativeCursor
from agent_comms.execution.turn_context import ContextManifest
from agent_comms.execution.turn_inbox import SendNow, TurnInbox
from agent_comms.execution.turn_lease import TurnState
from agent_comms.external_transcript import DraftRow
from agent_comms.input_attempt import InputAttempt
from agent_comms.input_origin import InputOrigin, UnattributedInputOrigin
from agent_comms.nominal.declared_family import DeclaredFamily
from agent_comms.nominal.field_codec import (
    AcceptsNull,
    AcpSessionId,
    AssignmentId,
    ClaimId,
    ExternalJsonShape,
    FieldCodec,
    InputId,
    MalformedRecord,
    MessageId,
    RootId,
    TurnId,
    WireName,
    WireOmitDefault,
    WireValue,
)
from agent_comms.owner_protocol import IncompatibleOwner
from agent_comms.pi_wire import McpLiveAcknowledgement
from agent_comms.planning.goal_presentation import GoalExecutionControls, GoalSnapshot
from agent_comms.projects.checkouts import Checkout
from agent_comms.queue_publication import QueuePublication
from agent_comms.registry.thread_identity import ClaimedIdentity, ClaimScoped, ThreadIncarnation
from agent_comms.reported_turn import ReportedTurn, ReportedTurnState
from agent_comms.routing import MessageRoute, NoMessageRoute
from agent_comms.tool_result import ToolResult
from agent_comms.transcript_sources import NoDraft
from agent_comms.transcripts import (
    LivePageSource,
    NativeCommittedPrefix,
    PageSource,
    TranscriptCursor,
    TranscriptPage,
    TranscriptRead,
    TranscriptReadIdentity,
)
from agent_comms.working_memory_labels import ModelLabel


class AgentCommsUpdate(DeclaredFamily, affix="Update"):
    """One declared fact; member identity supplies its wire discriminator."""

    def for_session(self, session_id: AcpSessionId) -> AgentCommsUpdate:
        return self

    def matches_turn(self, turn: ReportedTurnState) -> bool:
        return True

    def acp_chunk(self) -> AgentMessageChunk:
        """Carry this declared observation in its original empty ACP envelope."""
        return AgentMessageChunk(
            session_update="agent_message_chunk",
            content=TextContentBlock(type="text", text=""),
            field_meta=encode_updates(self),
        )


@dataclass(frozen=True)
class ContextAnnotatedUpdate(AgentCommsUpdate):
    context: ContextManifest
    labels: tuple[ModelLabel, ...]


@dataclass(frozen=True)
class TurnChangedUpdate(AgentCommsUpdate):
    state: TurnState


@dataclass(frozen=True)
class TextRouteUpdate(AgentCommsUpdate):
    route: MessageRoute | NoMessageRoute = NoMessageRoute()


@dataclass(frozen=True)
class TextNoticeUpdate(AgentCommsUpdate):
    """The accompanying ACP text is one complete standalone notice."""


@dataclass(frozen=True)
class TranscriptChangedUpdate(AgentCommsUpdate):
    cursor: TranscriptCursor


class ClaimBlockedFailure(BackendDeliveryFailure):
    """A human claim held the input; presented as every delivery failure is, a refusal that
    restores the draft. Toad's 62e938ce deleted delivery_blocked: a lock no state leaves."""


@dataclass(frozen=True)
class InputFailedUpdate(AgentCommsUpdate):
    text: str
    failure: DeliveryFailure


@dataclass(frozen=True)
class UpdateBatch:
    updates: tuple[AgentCommsUpdate, ...]


@dataclass(frozen=True)
class UpdateMetadata:
    """An ACP ``_meta`` object carrying one batch of Comms updates."""

    batch: Annotated[UpdateBatch, WireName("agentComms")]

    @classmethod
    def of(cls, *updates: AgentCommsUpdate) -> UpdateMetadata:
        return cls(UpdateBatch(updates))


@dataclass(frozen=True)
class GoalSnapshotReply(ToolResult, GoalSnapshot):
    """A goal request's reply: the owner's goal snapshot and its turn state."""

    execution: Annotated[GoalExecutionControls, WireName("goalExecution")]
    meta: Annotated[UpdateMetadata, WireName("_meta")]


def encode_updates(*updates: AgentCommsUpdate) -> dict:
    return {"agentComms": FieldCodec.encode(UpdateBatch(updates))}


def decode_updates(metadata: object) -> tuple[AgentCommsUpdate, ...]:
    """Decode facts once at ACP ingress, rejecting unknown kinds and fields."""
    if metadata is None:
        return ()
    if not isinstance(metadata, dict):
        raise MalformedRecord("ACP metadata must be an object")
    if "agentComms" not in metadata:
        return ()
    extension = metadata["agentComms"]
    if not isinstance(extension, dict):
        raise ValueError("Comms metadata must be an object")
    return FieldCodec.decode(UpdateBatch, extension).updates


class AttachmentScope(AcceptsNull, ExternalJsonShape, WireValue):
    """One decoded attachment; JSON null is an absent attachment, not Python None."""

    @classmethod
    def from_wire(cls, data):
        return cls.empty_scope() if data is None else FieldCodec.decode_record(cls.record_type(), data)

    @classmethod
    @abstractmethod
    def empty_scope(cls): ...

    @classmethod
    @abstractmethod
    def record_type(cls): ...

    @classmethod
    def schema(cls):
        return {"anyOf": [{"type": "null"}, FieldCodec.record_schema(cls.record_type())]}

    def to_wire(self):
        return None

    def for_session(self, session_id: AcpSessionId):
        return self

    def matches_session(self, session_id: AcpSessionId) -> bool:
        return False

    def foreign_session(self, session_id: AcpSessionId) -> bool:
        return False

    def relation(self, other: AttachmentScope) -> AttachmentRelation:
        return AttachmentRelation()

    def relation_from(self, original: LiveAttachmentScope) -> AttachmentRelation:
        return AttachmentRelation()

    def current_for(self, other: AttachmentScope) -> bool:
        return self.relation(other).current

    def same_request(self, other: AttachmentScope) -> bool:
        return self == other or self.current_for(other)

    def require_live(self):
        raise ValueError('Attachment has no live local owner scope.')


class LiveAttachmentScope(AttachmentScope, ClaimScoped):
    """Logical ACP attachment and executor evidence have separate identities."""
    session_id: AcpSessionId
    owner: ProcessIdentity

    @property
    @abstractmethod
    def logical_key(self) -> tuple[str, ...]: ...

    @property
    def owner_created_at(self):
        return self.claimed_identity.incarnation.require_recorded().created_at

    @property
    def claimed_generation(self):
        return self.claimed_identity.claimed_generation

    def to_wire(self):
        return FieldCodec.encode_record(self)

    def for_session(self, session_id: AcpSessionId):
        return replace(self, session_id=session_id)

    def matches_session(self, session_id: AcpSessionId) -> bool:
        return self.session_id == session_id

    def foreign_session(self, session_id: AcpSessionId) -> bool:
        return self.session_id != session_id

    def require_live(self):
        return self

    def relation(self, other: AttachmentScope) -> AttachmentRelation:
        return other.relation_from(self)

    def relation_from(self, original: LiveAttachmentScope) -> AttachmentRelation:
        return ObservedAttachmentRelation(original, self)


class AttachmentRelation:
    """Absent evidence cannot identify a common live attachment."""
    foreign = True
    same_incarnation = False
    ambiguous = True
    newer = False
    older = False
    current = False


@dataclass(frozen=True)
class ObservedAttachmentRelation(AttachmentRelation):
    """Compare original scope witnesses once; no state or alias registry."""
    original: AttachmentScope
    received: AttachmentScope

    @property
    def foreign(self):
        return self.original.logical_key != self.received.logical_key

    @property
    def same_incarnation(self):
        return (not self.foreign and self.original.owner_created_at == self.received.owner_created_at)

    @property
    def ambiguous(self):
        return (not self.same_incarnation or
                (self.original.claimed_generation == self.received.claimed_generation
                 and self.original.owner != self.received.owner))

    @property
    def newer(self):
        return self.same_incarnation and self.received.claimed_generation > self.original.claimed_generation

    @property
    def older(self):
        return self.same_incarnation and self.received.claimed_generation < self.original.claimed_generation

    @property
    def current(self):
        return (self.same_incarnation
                and self.original.claimed_generation == self.received.claimed_generation
                and self.original.owner == self.received.owner)


class CursorScope(AttachmentScope):
    @classmethod
    def empty_scope(cls):
        return NoCursorScope()

    @classmethod
    def record_type(cls):
        return LiveCursorScope


@dataclass(frozen=True)
class NoCursorScope(CursorScope):
    pass


@dataclass(frozen=True)
class LiveCursorScope(CursorScope, LiveAttachmentScope):
    session_id: AcpSessionId
    wire_root_id: RootId
    owner: ProcessIdentity

    def __post_init__(self):
        self.claimed_identity.incarnation.require_recorded()
        if (
            not self.session_id
            or self.claimed_identity.claimed_generation <= 0
        ):
            raise ValueError("Invalid native cursor scope")

    @property
    def logical_key(self):
        return self.session_id, self.wire_root_id


class CursorObservation(DeclaredFamily, affix="CursorObservation"):
    """Read-only history evidence, never an input/send capability."""

    @property
    @abstractmethod
    def status(self) -> str: ...

    def validate_scope(self, scope: CursorScope) -> None:
        pass

    @property
    def needs_refresh(self) -> bool:
        return False


@dataclass(frozen=True)
class UnavailableCursorObservation(CursorObservation):
    @property
    def needs_refresh(self) -> bool:
        return True

    @property
    def status(self) -> str:
        return "unavailable"


@dataclass(frozen=True)
class EmptyCursorObservation(CursorObservation):
    @property
    def needs_refresh(self) -> bool:
        # Absence of a durable projection does not settle an original proof.
        return True

    @property
    def status(self) -> str:
        return "none"


@dataclass(frozen=True)
class VerifiedCursorObservation(CursorObservation):
    cursor: CurrentNativeCursor

    @property
    def status(self) -> str:
        return "proven" if self.cursor.injected_seq else "coverage_only"

    def validate_scope(self, scope: CursorScope) -> None:
        scope = scope.require_live()
        cursor = self.cursor
        if (
            cursor.wire_root_id != scope.wire_root_id
            or cursor.recipient_lookup != scope.claimed_identity.incarnation.lookup
            or cursor.owner_claimed_generation != scope.claimed_generation
            or not 0 <= cursor.injected_seq <= cursor.covered_seq
        ):
            raise ValueError("Cursor observation does not belong to its scope")


@dataclass(frozen=True)
class CursorEnvelope:
    scope: CursorScope
    revision: int
    observation: CursorObservation

    def __post_init__(self):
        if self.revision <= 0:
            raise ValueError("A cursor observation requires a positive revision")
        self.observation.validate_scope(self.scope)

    @property
    def status(self) -> str:
        return self.observation.status

    def same_observation(self, other: CursorEnvelope) -> bool:
        """Publication equality excludes only the local observation revision."""
        return self.scope == other.scope and self.observation == other.observation

    @property
    def digest(self) -> str:
        return FieldCodec.digest(self)


@dataclass(frozen=True)
class CursorAdvancedUpdate(AgentCommsUpdate):
    envelope: CursorEnvelope
    selected_status: str | None = None

    def for_session(self, session_id: AcpSessionId) -> CursorAdvancedUpdate:
        return replace(self, envelope=replace(
            self.envelope, scope=self.envelope.scope.for_session(session_id)))


class QueueScope(AttachmentScope):
    @classmethod
    def empty_scope(cls):
        return NoQueueScope()

    @classmethod
    def record_type(cls):
        return LiveQueueScope

    def projection(self, queued, restored) -> QueueProjection:
        return UnavailableQueueProjection()

    def validate_scope(self, projection: QueueProjection) -> None:
        projection.without_scope()

    def start_revision(self, inputs: QueuePublication, session_id: AcpSessionId) -> int | None:
        return None

    def accepts_request(self, projection: QueueProjection) -> bool:
        return True

    def when_unidentified(self, action: Callable[[], None]) -> None:
        """A start with no live queue is posted as an unidentified input."""
        action()


@dataclass(frozen=True)
class NoQueueScope(QueueScope):
    pass


@dataclass(frozen=True)
class LiveQueueScope(QueueScope, LiveAttachmentScope):
    session_id: AcpSessionId
    owner: ProcessIdentity

    @property
    def logical_key(self):
        return (self.session_id,)

    def projection(self, queued, restored) -> QueueProjection:
        items = tuple(row for item in queued for row in item.queue_items(self))
        previous = tuple(row for item in restored for row in item.queue_items(self))
        rows = items + previous
        try:
            for row in rows:
                row.preview.encode("utf-8")
        except UnicodeError:
            return UnavailableQueueProjection()
        return AvailableQueueProjection(items, previous)

    def validate_scope(self, projection: QueueProjection) -> None:
        pass

    def start_revision(self, inputs: QueuePublication, session_id: AcpSessionId) -> int:
        return inputs.next_revision(session_id)

    def accepts_request(self, projection: QueueProjection) -> bool:
        return projection.status == 'available'

    def when_unidentified(self, action: Callable[[], None]) -> None:
        pass


@dataclass(frozen=True)
class QueueItem:
    """Exact accepted identity with display-only text, never a resubmission body."""

    input_id: InputId
    preview: str

    @staticmethod
    def summarize(text: str) -> str:
        """The queue summary's single-line preview; original content stays with its input."""
        return " ".join(text.split())[:100]

    @classmethod
    def from_input(cls, input_id: InputId, text: str) -> QueueItem:
        return cls(input_id, cls.summarize(text))


class QueueProjection(DeclaredFamily, affix="QueueProjection"):
    items: ClassVar[tuple[QueueItem, ...]] = ()
    restored: ClassVar[tuple[QueueItem, ...]] = ()

    @property
    @abstractmethod
    def status(self) -> str | None: ...

    @abstractmethod
    def feedback(self, supported: bool) -> str: ...

    def without_scope(self) -> None:
        """Do not offer queue access while its state is missing or still loading."""

    def input_identity(self, acquire_scope: Callable[[], LiveAttachmentScope]) -> ClaimedIdentity:
        """Refuse input until the queue's current state has been read."""
        raise ValueError(self.feedback(True))


@dataclass(frozen=True)
class PendingQueueProjection(QueueProjection):
    @property
    def status(self) -> None:
        return None

    def feedback(self, supported: bool) -> str:
        return "Checking input queue…" if supported else ""


@dataclass(frozen=True)
class UnavailableQueueProjection(QueueProjection):
    @property
    def status(self) -> str:
        return "unavailable"

    def feedback(self, supported: bool) -> str:
        return "Remote queue unavailable (input status unchanged)"


@dataclass(frozen=True)
class HistoryOnlyQueueProjection(UnavailableQueueProjection):
    """The owner runs another Core, so this client cannot queue its input."""

    owner: IncompatibleOwner

    def feedback(self, supported: bool) -> str:
        return self.owner.line()


@dataclass(frozen=True)
class AvailableQueueProjection(QueueProjection):
    items: tuple[QueueItem, ...] = ()
    restored: tuple[QueueItem, ...] = ()

    @property
    def status(self) -> str:
        return "available"

    def feedback(self, supported: bool) -> str:
        return ""

    def without_scope(self) -> None:
        raise ValueError('Available input queue has no original attachment scope.')

    def input_identity(self, acquire_scope: Callable[[], LiveAttachmentScope]) -> ClaimedIdentity:
        return acquire_scope().claimed_identity


@dataclass(frozen=True)
class QueueChangedUpdate(AgentCommsUpdate):
    scope: QueueScope
    revision: int
    projection: QueueProjection

    def __post_init__(self):
        self.scope.validate_scope(self.projection)

    def for_session(self, session_id: AcpSessionId) -> QueueChangedUpdate:
        return replace(self, scope=self.scope.for_session(session_id))

    @property
    def status(self) -> str | None:
        return self.projection.status

    @property
    def digest(self) -> str:
        return FieldCodec.digest(self)


@dataclass(frozen=True)
class InputStartedUpdate(AgentCommsUpdate, declared_name=None):
    text: str | None
    scope: QueueScope
    revision: int | None
    native_id: InputId

    def queue_started(
        self, receive: Callable[[IdentifiedInputStarted], tuple[IdentifiedInputStarted, ...]],
    ) -> tuple[IdentifiedInputStarted, ...]:
        return ()

    def identified(self, input_id: InputId) -> IdentifiedInputStarted:
        return IdentifiedInputStarted(
            self.text, self.scope, self.revision, self.native_id, input_id,
        )

    def started_request(self, input_id: InputId) -> bool:
        return False

    def when_unidentified(self, action: Callable[[], None]) -> None:
        pass

    def for_session(self, session_id: AcpSessionId) -> InputStartedUpdate:
        return replace(self, scope=self.scope.for_session(session_id))


@dataclass(frozen=True)
class IdentifiedInputStarted(InputStartedUpdate):
    input_id: InputId

    def queue_started(
        self, receive: Callable[[IdentifiedInputStarted], tuple[IdentifiedInputStarted, ...]],
    ) -> tuple[IdentifiedInputStarted, ...]:
        return receive(self)

    def started_request(self, input_id: InputId) -> bool:
        return self.input_id == input_id


@dataclass(frozen=True)
class UnidentifiedInputStarted(InputStartedUpdate):
    def when_unidentified(self, action: Callable[[], None]) -> None:
        self.scope.when_unidentified(action)


@dataclass(frozen=True)
class CoordinationChangedUpdate(AgentCommsUpdate, ToolResult):
    thread: ThreadIncarnation
    wire_root: str
    owner: ProcessIdentity
    worktree: Checkout
    model: str
    thinking_level: str | None
    title: str
    context_usage: ContextReading

    @property
    def status_label(self) -> str:
        return " · ".join((self.model, *self.context_usage.label_parts()))

    @property
    def persistence(self) -> str:
        return "shared on-disk wire"

    @property
    def transport(self) -> str:
        return "per-session stdio ACP"


@dataclass(frozen=True)
class GoalChangedUpdate(GoalSnapshot, AgentCommsUpdate):
    """The goal snapshot after a change, announced to the session."""


@dataclass(frozen=True)
class CompactionChangedUpdate(AgentCommsUpdate):
    event: CompactionEvent


@dataclass(frozen=True)
class CompactionCommittedUpdate(AgentCommsUpdate):
    """The /compact reply: the runtime placed this summary."""

    summary: str


@dataclass(frozen=True)
class NativeRoundCommittedUpdate(AgentCommsUpdate):
    identity: NativeCommittedPrefix


@dataclass(frozen=True)
class NativeOutputCommittedUpdate(AgentCommsUpdate):
    identity: NativeCommittedPrefix
    output: NativeOutputScope


@dataclass(frozen=True)
class TranscriptDraftUpdate(AgentCommsUpdate):
    """Current draft beside an unchanged, already published transcript page."""

    identity: TranscriptReadIdentity
    draft: DraftRow | NoDraft


@dataclass(frozen=True)
class TranscriptSnapshotUpdate(AgentCommsUpdate, ToolResult):
    page: TranscriptPage
    identity: TranscriptReadIdentity
    draft: DraftRow | NoDraft = NoDraft()

    @classmethod
    def from_read(cls, read: TranscriptRead) -> Self:
        page, draft = read.read_snapshot()
        return cls(page, read.identity, draft)

    @classmethod
    def capture(cls, transcripts, name, *, page_source: PageSource = LivePageSource()):
        """Publish the page together with the source witness that read it."""
        read = transcripts.capture_page_read(name, page_source=page_source)
        return cls.from_read(read)


@dataclass(frozen=True)
class InputDeliveryChangedUpdate(AgentCommsUpdate):
    pass


@dataclass(frozen=True)
class McpClientAcknowledgementUpdate(AgentCommsUpdate, declared_name="mcp_client_receipt"):
    turn_id: TurnId
    acknowledgement: Annotated[McpLiveAcknowledgement, WireName("receipt")]

    def matches_turn(self, turn: ReportedTurnState) -> bool:
        return ReportedTurn(self.turn_id).reports(turn)


class CommsRequest(DeclaredFamily, affix="Request"):
    """One owner command decoded at ACP ingress, never a bag of control flags."""

    @property
    def draft_text(self) -> str | None:
        return None


@dataclass(frozen=True)
class PromptRequest(CommsRequest):
    user_text: str | None = None
    defer_display: bool = False
    input_id: InputId = field(default_factory=InputId.mint)
    origin: Annotated[InputOrigin, WireOmitDefault()] = field(
        default_factory=UnattributedInputOrigin, kw_only=True
    )

    @property
    def draft_text(self) -> str | None:
        return self.user_text

    @abstractmethod
    def enqueue_control(self, inbox: TurnInbox, input_id: InputId) -> None: ...

    async def publish_acceptance(self, inputs: QueuePublication, session_id: AcpSessionId) -> None:
        await inputs.emit_queue_state(session_id)


class QueuePromptRequest(PromptRequest):
    def enqueue_control(self, inbox: TurnInbox, input_id: InputId) -> None:
        pass


class SteerPromptRequest(PromptRequest):
    def enqueue_control(self, inbox: TurnInbox, input_id: InputId) -> None:
        inbox.put_nowait(SendNow((input_id,)))


@dataclass(frozen=True)
class ClearQueueRequest(CommsRequest):
    pass


@dataclass(frozen=True)
class SendNowRequest(CommsRequest):
    pass


@dataclass(frozen=True)
class CompactRequest(CommsRequest):
    instructions: str | None = None

    def __post_init__(self):
        if self.instructions is not None and len(self.instructions.strip()) > 2000:
            raise ValueError("Compaction instructions are too long")


@dataclass(frozen=True)
class SelectedWriteRequest(CommsRequest):
    source_seq: int
    source_message_id: MessageId
    resource: str
    contents: str

    def __post_init__(self):
        if self.source_seq <= 0 or not self.resource:
            raise ValueError("Selected write requires actual source and resource identity")


@dataclass(frozen=True)
class SelectedWriteAcceptedUpdate(AgentCommsUpdate):
    operation_id: ClaimId
    source_seq: int
    claim_id: AssignmentId


def encode_request(request: CommsRequest) -> dict:
    return {"agentComms": {"request": FieldCodec.encode(request)}}


def decode_request(metadata: object = None, **expanded) -> CommsRequest:
    """ACP SDK keyword expansion is normalized here, once, before dispatch."""
    if metadata is None:
        metadata = {}
    if not isinstance(metadata, dict):
        raise MalformedRecord("ACP metadata must be an object")
    extension = expanded.get("agentComms", metadata.get("agentComms"))
    if extension is None:
        return QueuePromptRequest()
    if not isinstance(extension, dict) or set(extension) != {"request"}:
        raise MalformedRecord("Comms metadata requires one declared request")
    return FieldCodec.decode(CommsRequest, extension["request"])


@dataclass(frozen=True)
class RequestFailedUpdate(AgentCommsUpdate):
    failure: ACPFailure
    source: FailureSource = UnrecordedFailureSource()


@dataclass(frozen=True)
class PromptCancelledUpdate(AgentCommsUpdate):
    input_state: type[InputAttempt] | None

    @property
    def feedback(self):
        return InputAttempt.reported(self.input_state).cancellation_feedback
