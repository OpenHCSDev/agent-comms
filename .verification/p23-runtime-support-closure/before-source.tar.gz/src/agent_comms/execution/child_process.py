"""Identity-bound child ownership, process-group retirement and bounded runs.

Linux pidfd operations are lifted from compaction_child_watchdog. Process
identity is captured before releasing the exec gate, including for short jobs.
"""

from __future__ import annotations

import asyncio
import ctypes
import fcntl
import json
import math
import multiprocessing
import os
import pwd
import re
import select
import shutil
import signal
import stat
import subprocess
import sys
import termios
import threading
import time
from abc import (
    ABC,
    abstractmethod,
)
from collections.abc import (
    Callable,
    Generator,
    Iterable,
    Iterator,
    Mapping,
)
from concurrent.futures import (
    Future,
    ProcessPoolExecutor,
    wait,
)
from contextlib import (
    AbstractContextManager,
    ExitStack,
    asynccontextmanager,
    contextmanager,
    nullcontext,
    suppress,
)
from contextvars import copy_context
from dataclasses import dataclass
from functools import (
    cache,
    cached_property,
    partial,
)
from io import BufferedReader
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import (
    IO,
    Annotated,
    Any,
    ClassVar,
    NoReturn,
    Self,
)

from agent_comms.errors import RelationViolationError
from agent_comms.installer.native_build_inputs import (
    AsyncStdioOptions,
    ChildStdio,
    ConfiguredChildStdio,
    DetachedChildStdio,
    GitAcquisitionCancelled,
    GitLaunch,
    GitOpening,
    StdioOptions,
)
from agent_comms.launch_runtime import INHERITED_ENVIRONMENT, LaunchRuntime, RestoredRuntime
from agent_comms.nominal.declared_family import DeclaredFamily
from agent_comms.nominal.field_codec import (
    DisclosedRecord,
    FieldCodec,
    FieldDirective,
    Id128,
    NullMember,
    RecordMember,
    SubclassUnion,
    WireRequired,
)
from agent_comms.nominal.sealed import Sealed
from agent_comms.registry.thread_identity import ThreadIncarnation, ThreadRole
from agent_comms.systemd_unit import AgentsSlice, SystemdUnit

STOP_GRACE_SECONDS = 2.0


@dataclass(frozen=True)
class ProcfsColumn(FieldDirective):
    key: str
    scale: int = 1024

    def value(self, tokens: list[str]) -> int:
        return int(tokens[0]) * self.scale


class ProcfsRecord:
    """Procfs owns the text; field declarations own selection, units and requiredness."""

    filename: ClassVar[str]

    @classmethod
    def read(cls, directory: Path) -> Self:
        fields = {key: value.split()
                  for line in (directory / cls.filename).read_text().splitlines()
                  for key, _, value in (line.partition(":"),)}
        return FieldCodec.decode(cls, {
            plan.key: column.value(fields[column.key])
            for plan in FieldCodec.field_plans(cls)
            for column in ProcfsColumn.single(plan.annotation)
            if column.key in fields
        })


@dataclass(frozen=True)
class ProportionalMemory(ProcfsRecord):
    filename = "smaps_rollup"
    bytes: Annotated[int, ProcfsColumn("Pss"), WireRequired()]


@dataclass(frozen=True)
class ResidentMemory(ProcfsRecord):
    """One procfs status sample, in bytes; kernel threads have no resident pages."""

    filename = "status"
    parent: Annotated[int, ProcfsColumn("PPid", 1), WireRequired()]
    resident: Annotated[int, ProcfsColumn("VmRSS")] = 0
    peak: Annotated[int, ProcfsColumn("VmHWM")] = 0

    @classmethod
    def tree(cls, process: ProcessIdentity, proc: Path) -> dict[int, ResidentMemory]:
        """A sampled descendant set, guarded by the root's exact process birth. The kernel lists
        each task's children, so only the subtree's status files are read."""
        if not process.alive():
            return {}
        rows: dict[int, ResidentMemory] = {}
        pending = [process.pid]
        while pending:
            pid = pending.pop()
            directory = proc / str(pid)
            try:
                rows[pid] = cls.read(directory)
            except (FileNotFoundError, ProcessLookupError):
                continue
            pending.extend(child for child in cls.children(directory) if child not in rows)
        return rows if process.alive() else {}

    @staticmethod
    def children(directory: Path) -> Iterator[int]:
        """Every task's children: a child forked by a non-leader thread is listed only there."""
        for listing in directory.glob("task/*/children"):
            try:
                yield from map(int, listing.read_text().split())
            except (FileNotFoundError, ProcessLookupError):
                continue


class IdentityMismatchError(ProcessLookupError):
    """A recorded process incarnation is absent or has been replaced."""


class ChildRetirementError(BaseException):
    """The child owner's cleanup acknowledgement failed independently of cancellation."""


class ChildRetirementFailed(RuntimeError, ChildRetirementError):
    """An ordinary retirement failure; never a cancellation."""


class ChildRetirementCancelled(asyncio.CancelledError, ChildRetirementError):
    """Preserve cancellation and an independently failed retirement acknowledgement."""


class ProcessSighting[Status](ABC):
    """A thread's live presence, answering for the process state its owner has."""

    __slots__ = ()

    @abstractmethod
    def heartbeat_seen(self, last_seen: float) -> Status:
        """The presence when no process is recorded: the heartbeat is the evidence."""

    @abstractmethod
    def process_seen(self, process: ProcessState) -> Status:
        """The presence when a process is recorded for it."""


class ProcessFence[Status](ABC):
    """A stored stop, answering for whether a process still binds it."""

    __slots__ = ()

    @abstractmethod
    def unbound(self) -> Status:
        """The stop when no process binds it."""

    @abstractmethod
    def fenced(self) -> Status:
        """The stop while its process still binds it."""


class NativeBinding[Presentation](ABC):
    """A registry lease that presents its thread natively once a process holds it."""

    __slots__ = ()

    @abstractmethod
    def native_presentation(self, ordinary: Presentation) -> Presentation: ...


class ProcessRestart[Change](ABC):
    """A registration change over a prior incarnation, kept or restarted by its processes."""

    __slots__ = ()

    @property
    @abstractmethod
    def previous_incarnation(self) -> ThreadIncarnation: ...

    @abstractmethod
    def kept(self) -> Change:
        """The change as requested: no process restarts it."""

    @abstractmethod
    def restarted(self) -> Change:
        """The change once a process replaces the prior incarnation's."""


class ProcessState(SubclassUnion, affix=""):
    """An exact recorded process or a worker which has never started."""

    @abstractmethod
    def allows_owner_start(self) -> bool: ...
    @abstractmethod
    def allows_inactive_stop(self) -> bool: ...

    @abstractmethod
    def require_held_by(self, role: type[ThreadRole]) -> None: ...
    @abstractmethod
    def conflicts_with(self, previous: ProcessState) -> bool: ...

    @abstractmethod
    def registration_change[Change](
        self, previous: ProcessState, change: ProcessRestart[Change], incarnation: ThreadIncarnation,
    ) -> Change: ...

    @abstractmethod
    def restarted_registration[Change](
        self, change: ProcessRestart[Change], incarnation: ThreadIncarnation,
    ) -> Change: ...

    @abstractmethod
    def native_presentation[Presentation](
        self, ordinary: Presentation, binding: NativeBinding[Presentation],
    ) -> Presentation: ...

    @abstractmethod
    def applied(self, previous: ProcessState) -> ProcessState: ...

    @abstractmethod
    def offline(self) -> bool: ...

    @abstractmethod
    def require(self, message: str = "No worker process has started") -> ProcessIdentity: ...

    @abstractmethod
    def alive(self) -> bool: ...

    @abstractmethod
    def thread_status[Status](self, presence: ProcessSighting[Status], last_seen: float) -> Status: ...

    @abstractmethod
    def stopped_seen[Status](self, stopped: ProcessFence[Status]) -> Status:
        """A stored stop with no process is stopped; one still bound is a fence."""

    @abstractmethod
    def runs_here(self) -> bool: ...

    @abstractmethod
    def signal(self, signum: int) -> None: ...

    @abstractmethod
    def require_release_by(self, process: ProcessIdentity) -> None: ...

    @abstractmethod
    def held_external_stop(self, release: Callable[[], None], name: str) -> tuple[str, ...]:
        """Stop a CLI endpoint this process holds: the names still for the ordinary stop."""


@dataclass(frozen=True)
class NoProcess(NullMember, ProcessState):
    def allows_owner_start(self) -> bool:
        return True

    def allows_inactive_stop(self) -> bool:
        return True

    def require_held_by(self, role: type[ThreadRole]) -> None:
        """No process is held, so any role may declare it."""

    def conflicts_with(self, previous: ProcessState) -> bool:
        return False

    def registration_change[Change](
        self, previous: ProcessState, change: ProcessRestart[Change], incarnation: ThreadIncarnation,
    ) -> Change:
        return change.kept()

    def restarted_registration[Change](
        self, change: ProcessRestart[Change], incarnation: ThreadIncarnation,
    ) -> Change:
        return change.kept()

    def native_presentation[Presentation](
        self, ordinary: Presentation, binding: NativeBinding[Presentation],
    ) -> Presentation:
        return ordinary

    def applied(self, previous: ProcessState) -> ProcessState:
        return previous

    def offline(self) -> bool:
        return False

    def require(self, message: str = "No worker process has started") -> ProcessIdentity:
        raise RelationViolationError(message)

    def alive(self) -> bool:
        return False

    def thread_status[Status](self, presence: ProcessSighting[Status], last_seen: float) -> Status:
        return presence.heartbeat_seen(last_seen)

    def stopped_seen[Status](self, stopped: ProcessFence[Status]) -> Status:
        return stopped.unbound()

    def runs_here(self) -> bool:
        return False

    def signal(self, signum: int) -> None:
        pass

    def require_release_by(self, process: ProcessIdentity) -> None:
        # Stopping before the first start still produces a valid release.
        pass

    def held_external_stop(self, release: Callable[[], None], name: str) -> tuple[str, ...]:
        """Nothing holds the endpoint, so the ordinary stop finishes it on the bus."""
        return (name,)


@dataclass(frozen=True)
class ProcessIdentity(RecordMember, ProcessState):
    pid: int
    start_time: int

    def __post_init__(self) -> None:
        if self.pid <= 0 or self.start_time <= 0:
            raise ValueError("A positive PID and platform start time are required")

    def memory(self, proc: Path = Path("/proc")) -> ResidentMemory:
        platform = Platform.current()
        platform.require(self)
        result = ResidentMemory.read(proc / str(self.pid))
        platform.require(self)
        return result

    @classmethod
    def pid_argument(cls, value: str) -> dict[str, object]:
        return FieldCodec.encode_record(cls.capture(int(value)))

    @classmethod
    def capture(cls, pid: int) -> ProcessIdentity:
        return cls.current() if pid == os.getpid() else Platform.current().identity(pid)

    @classmethod
    def current(cls) -> ProcessIdentity:
        """The caller's immutable birth; a fork selects its own PID, not its parent's."""
        return cls._current(os.getpid())

    @staticmethod
    @cache
    def _current(pid: int) -> ProcessIdentity:
        return Platform.current().identity(pid)

    def allows_owner_start(self) -> bool:
        return False

    def allows_inactive_stop(self) -> bool:
        return self.runs_here()

    def require_held_by(self, role: type[ThreadRole]) -> None:
        role.require_executable(
            RelationViolationError("A human thread cannot hold an owner process")
        )

    def conflicts_with(self, previous: ProcessState) -> bool:
        return self != previous

    def offline(self) -> bool:
        return not self.alive()

    def native_presentation[Presentation](
        self, ordinary: Presentation, binding: NativeBinding[Presentation],
    ) -> Presentation:
        return binding.native_presentation(ordinary)

    def applied(self, previous: ProcessState) -> ProcessState:
        return self

    def require(self, message: str = "No worker process has started") -> ProcessIdentity:
        return self

    @staticmethod
    def in_group(pid: int, start_time: int, pgid: int) -> ProcessIdentity:
        return GroupLeader(pid, start_time) if pgid == pid else GroupMember(pid, start_time)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ProcessIdentity):
            return NotImplemented
        return (self.pid, self.start_time) == (other.pid, other.start_time)

    def alive(self) -> bool:
        return Platform.current().matches(self)

    def arguments(self) -> tuple[str, ...]:
        return Platform.current().arguments(self)

    def environment(self) -> dict[str, str]:
        return Platform.current().environment(self)

    def require_alive(self) -> ProcessIdentity:
        """Validate this recorded PID and start time against the live process."""
        return Platform.current().require(self)

    def runs_here(self) -> bool:
        return os.getpid() == self.pid

    def signal(self, signum: int) -> None:
        Platform.current().send(self, signum)

    def lineage(self) -> Iterator[ProcessIdentity]:
        """This incarnation and its exact ancestors, ending at PID 1."""
        platform = Platform.current()
        current = self
        while True:
            yield current
            if current.pid == 1:
                return
            current = platform.parent_identity(current.pid)

    def require_ancestor_of(self, pid: int) -> None:
        """A supplied process is authority only for its actual descendant."""
        platform = Platform.current()
        platform.require(self)
        if self in platform.identity(pid).lineage():
            return
        raise IdentityMismatchError('The declared process is not an ancestor of this hook')

    async def wait_exited(self) -> None:
        await Platform.current().wait_exited(self)

    def require_release_by(self, process: ProcessIdentity) -> None:
        if self != process:
            raise RelationViolationError("Only the registered owner may release itself.")

    def held_external_stop(self, release: Callable[[], None], name: str) -> tuple[str, ...]:
        """A live holder (a CLI bridge or the connector's inbox watch) serves no owner runtime to
        retire, so its binding is released for it. A dead holder left a binding the ordinary stop
        finishes."""
        if not self.alive():
            return (name,)
        release()
        return ()

    def thread_status[Status](self, presence: ProcessSighting[Status], last_seen: float) -> Status:
        return presence.process_seen(self)

    def stopped_seen[Status](self, stopped: ProcessFence[Status]) -> Status:
        return stopped.fenced()

    def registration_change[Change](
        self, previous: ProcessState, change: ProcessRestart[Change], incarnation: ThreadIncarnation,
    ) -> Change:
        return previous.restarted_registration(change, incarnation)

    def restarted_registration[Change](
        self, change: ProcessRestart[Change], incarnation: ThreadIncarnation,
    ) -> Change:
        return change.restarted() if incarnation != change.previous_incarnation else change.kept()

    def members(self, platform: Platform) -> tuple[ProcessIdentity, ...]:
        return ()  # A stored, exited identity cannot grant group ownership.


NO_PROCESS = NoProcess()


class GroupLeader(ProcessIdentity, declared_name=None):
    def members(self, platform: Platform) -> tuple[ProcessIdentity, ...]:
        return tuple(member for member in platform.members_of_group(self.pid)
                     if member.start_time >= self.start_time)


class GroupMember(ProcessIdentity, declared_name=None):
    def members(self, platform: Platform) -> tuple[ProcessIdentity, ...]:
        return (self,) if platform.matches(self) else ()


class LockHolder(DeclaredFamily, affix="LockHolder"):
    """An observed flock owner; diagnosis, not authority to signal it."""

    @abstractmethod
    def describe(self) -> str: ...

    @staticmethod
    def described(holders: tuple[LockHolder, ...]) -> str:
        return "held by " + "; ".join(holder.describe() for holder in holders)


@dataclass(frozen=True, slots=True)
class IdentifiedLockHolder(LockHolder):
    pid: int

    def describe(self) -> str:
        return f"PID {self.pid}: {self.detail()}"

    @abstractmethod
    def detail(self) -> str: ...


@dataclass(frozen=True, slots=True)
class RunningLockHolder(IdentifiedLockHolder):
    command: str

    def detail(self) -> str:
        return self.command


class ExitedLockHolder(IdentifiedLockHolder):
    def detail(self) -> str:
        return "process exited"


class UnidentifiedLockHolder(LockHolder):
    def describe(self) -> str:
        return "kernel did not identify the owner"


class PidfdHandles:
    @staticmethod
    def open_pidfd(pid: int) -> int:
        """Use libc when a portable Python build omitted Linux wrappers."""
        if hasattr(os, "pidfd_open"):
            return os.pidfd_open(pid)
        libc = ctypes.CDLL(None, use_errno=True)
        function = getattr(libc, "pidfd_open", None)
        if function is None:
            raise NotImplementedError("Linux libc pidfd_open unavailable")
        function.argtypes = (ctypes.c_int, ctypes.c_uint)
        function.restype = ctypes.c_int
        descriptor = function(pid, 0)
        if descriptor < 0:
            code = ctypes.get_errno()
            raise OSError(code, os.strerror(code))
        return int(descriptor)

    @staticmethod
    def signal_pidfd(pidfd: int, sig: int) -> None:
        if hasattr(signal, "pidfd_send_signal"):
            signal.pidfd_send_signal(pidfd, sig)
            return
        libc = ctypes.CDLL(None, use_errno=True)
        function = getattr(libc, "pidfd_send_signal", None)
        if function is None:
            raise NotImplementedError("Linux libc pidfd_send_signal unavailable")
        function.argtypes = (ctypes.c_int, ctypes.c_int, ctypes.c_void_p, ctypes.c_uint)
        function.restype = ctypes.c_int
        if function(pidfd, sig, None, 0) < 0:
            code = ctypes.get_errno()
            raise OSError(code, os.strerror(code))


class Platform(DeclaredFamily, affix="Platform"):
    store_lock_interval = 0.025

    @classmethod
    def current(cls) -> Platform:
        return cls.member_named(sys.platform)()

    def sync_file(self, path: Path) -> None:
        descriptor = os.open(path, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    def sync_directory(self, path: Path) -> None:
        descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    class NativeImage(ctypes.Structure):
        """The POSIX loader's native symbol-image ABI."""

        _fields_ = (
            ("filename", ctypes.c_char_p),
            ("base", ctypes.c_void_p),
            ("symbol", ctypes.c_char_p),
            ("address", ctypes.c_void_p),
        )

    @contextmanager
    def native_image(self, address: ctypes.c_void_p) -> Generator[BufferedReader]:
        """Open the native file providing a symbol; the caller consumes this handle."""
        lookup = ctypes.CDLL(None).dladdr
        lookup.argtypes = (ctypes.c_void_p, ctypes.POINTER(self.NativeImage))
        lookup.restype = ctypes.c_int
        image = self.NativeImage()
        if not lookup(address, ctypes.byref(image)) or not image.filename:
            raise ValueError("The loader did not identify the native symbol image")
        with Path(os.fsdecode(image.filename)).resolve(strict=True).open("rb") as stream:
            yield stream

    @abstractmethod
    def require_watched_procfs(self, refusal: Exception) -> None: ...

    def is_private(self, info: os.stat_result, permissions: int) -> bool:
        return stat.S_IMODE(info.st_mode) == permissions and self.is_owned(info)

    def is_owned(self, info: os.stat_result) -> bool:
        return info.st_uid == os.geteuid()

    def trusted_ancestor_owner(self, uid: int) -> bool:
        return uid in (0, os.geteuid())

    def ancestor_write_bits(self, info: os.stat_result) -> int:
        """Directory write permissions granted outside the owner's trusted principals."""
        return info.st_mode & 0o022

    def publish_new_file(
        self, staged: str | Path, destination: str | Path, *,
        src_dir_fd: int | None = None, dst_dir_fd: int | None = None,
    ) -> None:
        """Publish a closed stage without replacing a winner; the stage may be consumed."""
        os.link(staged, destination, src_dir_fd=src_dir_fd, dst_dir_fd=dst_dir_fd,
                follow_symlinks=False)

    def snapshot_file(
        self, source: str | Path, destination: str | Path, *,
        src_dir_fd: int | None = None, dst_dir_fd: int | None = None,
    ) -> None:
        """Retain an immutable file's bytes and mode under a new, exclusive name."""
        os.link(source, destination, src_dir_fd=src_dir_fd, dst_dir_fd=dst_dir_fd,
                follow_symlinks=False)

    def share_file(self, source: Path, destination: Path) -> bool:
        """Share an immutable artifact's inode, or report that no sharing occurred."""
        os.link(source, destination, follow_symlinks=False)
        return True

    def make_private(self, path: Path, permissions: int) -> None:
        with suppress(FileNotFoundError):
            if stat.S_IMODE(path.lstat().st_mode) != permissions:
                os.chmod(path, permissions, follow_symlinks=False)

    def make_private_descriptor(self, descriptor: int, permissions: int) -> None:
        if stat.S_IMODE(os.fstat(descriptor).st_mode) != permissions:
            os.fchmod(descriptor, permissions)

    @contextmanager
    def socket_address(self, path: Path, descriptor: int) -> Generator[Path]:
        with TemporaryDirectory(prefix="ac-socket-", dir="/tmp") as directory:
            parent = Path(directory) / "d"
            parent.symlink_to(path.parent, target_is_directory=True)
            if not os.path.samestat(os.stat(parent), os.fstat(descriptor)):
                raise ValueError("Socket directory changed during address acquisition")
            yield parent / path.name

    def launch(
        self, command: tuple[str, ...], pass_fds: tuple[int, ...], runtime: LaunchRuntime,
        lifetime: type[ChildLifetime],
    ) -> ChildLaunch:
        return ChildLaunch(self, command, pass_fds, runtime, lifetime)

    def terminate_group(self, identity: ProcessIdentity) -> None:
        self.signal_group(identity, signal.SIGTERM)

    def force_group(self, identity: ProcessIdentity) -> None:
        self.signal_group(identity, signal.SIGKILL)

    @abstractmethod
    def identity(self, pid: int) -> ProcessIdentity: ...

    def started_at(self, identity: ProcessIdentity) -> float:
        """This recorded process's birth on the monotonic clock."""
        raise NotImplementedError("This platform does not expose process elapsed time")

    @abstractmethod
    def arguments(self, process: ProcessIdentity) -> tuple[str, ...]: ...

    @abstractmethod
    def environment(self, process: ProcessIdentity) -> dict[str, str]: ...

    @abstractmethod
    def process_name(self, pid: int) -> str: ...

    def lock_holders(self, descriptor: int) -> tuple[LockHolder, ...]:
        return (UnidentifiedLockHolder(),)

    def parent_identity(self, pid: int) -> ProcessIdentity:
        raise NotImplementedError('This platform does not expose exact parent identities')

    async def wait_exited(self, identity: ProcessIdentity) -> None:
        """Wait for one incarnation's exit; members with a loop-readable handle override this."""
        await asyncio.to_thread(self.wait_any_exited, (identity,), math.inf)

    @abstractmethod
    def wait_any_exited(
        self, identities: tuple[ProcessIdentity, ...], timeout: float,
    ) -> None:
        """Wait for a member's exit or the caller's remaining deadline."""

    def matches(self, identity: ProcessIdentity) -> bool:
        if identity.runs_here():
            return identity == ProcessIdentity.current()
        try:
            return self.identity(identity.pid) == identity
        except ProcessLookupError:
            return False

    def require(self, identity: ProcessIdentity) -> ProcessIdentity:
        with suppress(ProcessLookupError):
            current = self.identity(identity.pid)
            if current == identity:
                return current
        raise IdentityMismatchError(f"Process incarnation changed: {identity.pid}")

    def send(self, identity: ProcessIdentity, signum: int) -> None:
        self.require(identity)
        os.kill(identity.pid, signum)

    def group_members(self, leader: ProcessIdentity) -> tuple[ProcessIdentity, ...]:
        try:
            current = self.identity(leader.pid)
        except ProcessLookupError:
            return leader.members(self)
        if current != leader:
            raise IdentityMismatchError(f"Process incarnation changed: {leader.pid}")
        return current.members(self)

    def signal_group(self, leader: ProcessIdentity, signum: int) -> None:
        # Snapshot identities, then signal each exact member. Never signal a
        # numeric group after its leader may have been reaped and reused.
        signalled = 0
        for member in self.group_members(leader):
            try:
                self.send(member, signum)
            except ProcessLookupError:
                continue
            signalled += 1
        if not signalled and self.matches(leader):
            raise RuntimeError(f"Live process {leader.pid} was not signalled")

    def parent_death_binding(self) -> int:
        """Darwin has no parent-death signal: its exec gate binds no launcher."""
        return 0

    @abstractmethod
    def members_of_group(self, pgid: int) -> tuple[ProcessIdentity, ...]: ...


@dataclass(frozen=True)
class LinuxProcessRecord:
    identity: ProcessIdentity
    group: int
    parent: int


class LinuxPlatform(PidfdHandles, Platform):
    @contextmanager
    def native_image(self, address: ctypes.c_void_p) -> Generator[BufferedReader]:
        # glibc's main-image filename aliases argv[0]; setproctitle changes it.
        # Resolve the actual symbol mapping instead, including shared libpython.
        # ctypes represents C null as None; kernel mapping addresses are integers.
        pointer = address.value or 0
        if pointer == 0:
            raise ValueError("A null address has no native image")
        with Path("/proc/self/maps").open() as mappings:
            for line in mappings:
                extent, _permissions, _offset, device, inode, *_name = line.split(maxsplit=5)
                first, stop = (int(value, 16) for value in extent.split("-"))
                if first <= pointer < stop:
                    link = Path("/proc/self/map_files") / f"{first:x}-{stop:x}"
                    with link.resolve(strict=True).open("rb") as stream:
                        observed = os.fstat(stream.fileno())
                        major, minor = (int(value, 16) for value in device.split(":"))
                        # Decode kernel metadata once at this native boundary.
                        if (observed.st_dev, observed.st_ino) != (os.makedev(major, minor), int(inode)):
                            raise ValueError("The native image file no longer matches its mapping")
                        yield stream
                    return
        raise ValueError("The kernel did not identify the native symbol image")

    def require_watched_procfs(self, refusal: Exception) -> None:
        return None

    @contextmanager
    def socket_address(self, path: Path, descriptor: int) -> Generator[Path]:
        yield Path(f"/proc/{os.getpid()}/fd/{descriptor}") / path.name

    def parent_death_binding(self) -> int:
        """The exec gate arms PR_SET_PDEATHSIG and binds to this launcher's PID."""
        return os.getpid()

    @staticmethod
    def _stat(pid: int) -> LinuxProcessRecord:
        try:
            # comm can contain whitespace and ')'; fields after its final ')'
            # start at field 3. Kernel starttime is field 22, pgrp is field 5.
            fields = Path(f"/proc/{pid}/stat").read_text().rsplit(") ", 1)[1].split()
        except FileNotFoundError:
            raise ProcessLookupError(pid) from None
        if fields[0] in {"Z", "X"}:
            raise ProcessLookupError(pid)
        group = int(fields[2])
        return LinuxProcessRecord(
            ProcessIdentity.in_group(pid, int(fields[19]), group), group, int(fields[1]))

    def identity(self, pid: int) -> ProcessIdentity:
        return self._stat(pid).identity

    def started_at(self, identity: ProcessIdentity) -> float:
        started = identity.start_time / os.sysconf("SC_CLK_TCK")
        age = time.clock_gettime(time.CLOCK_BOOTTIME) - started
        return time.monotonic() - age

    def arguments(self, process: ProcessIdentity) -> tuple[str, ...]:
        try:
            raw = Path(f"/proc/{process.pid}/cmdline").read_bytes()
        except FileNotFoundError:
            raise ProcessLookupError(process.pid) from None
        if not raw:
            raise ProcessLookupError(process.pid)
        return tuple(os.fsdecode(word) for word in raw.split(b"\0")[:-1])

    def environment(self, process: ProcessIdentity) -> dict[str, str]:
        try:
            raw = Path(f"/proc/{process.pid}/environ").read_bytes()
        except FileNotFoundError:
            raise ProcessLookupError(process.pid) from None
        values = (item.split(b"=", 1) for item in raw.split(b"\0") if b"=" in item)
        return {os.fsdecode(key): os.fsdecode(value) for key, value in values}

    def process_name(self, pid: int) -> str:
        try:
            return Path(f"/proc/{pid}/comm").read_text().strip()
        except FileNotFoundError:
            raise ProcessLookupError(pid) from None

    def lock_holders(self, descriptor: int) -> tuple[LockHolder, ...]:
        """Identify actual flock owners of this opened file, not merely open FDs.

        An OFD lock with no reported PID, inaccessible /proc, or a concurrent exit
        is unknown; absence never proves sole ownership of the lock.
        """
        info = os.fstat(descriptor)
        identity = f"{os.major(info.st_dev):02x}:{os.minor(info.st_dev):02x}:{info.st_ino}"
        holders = []
        with open('/proc/locks', encoding='ascii') as locks:
            for line in locks:
                fields = line.split()
                if len(fields) < 8 or fields[1] != 'FLOCK' or fields[5] != identity:
                    continue
                pid = int(fields[4])
                if pid < 0:
                    holders.append(UnidentifiedLockHolder())
                    continue
                try:
                    command = " ".join(self.arguments(self.identity(pid)))
                except ProcessLookupError:
                    holders.append(ExitedLockHolder(pid))
                else:
                    holders.append(RunningLockHolder(pid, command))
        return tuple(holders)

    def parent_identity(self, pid: int) -> ProcessIdentity:
        return self.identity(self._stat(pid).parent)

    async def wait_exited(self, identity: ProcessIdentity) -> None:
        try:
            descriptor = self.open_pidfd(identity.pid)
        except ProcessLookupError:
            return
        try:
            self.require(identity)
            loop = asyncio.get_running_loop()
            exited = loop.create_future()
            def observe() -> None:
                if not exited.done():
                    exited.set_result(None)
            loop.add_reader(descriptor, observe)
            try:
                await exited
            finally:
                loop.remove_reader(descriptor)
        except ProcessLookupError:
            return
        finally:
            os.close(descriptor)

    def wait_any_exited(
        self, identities: tuple[ProcessIdentity, ...], timeout: float,
    ) -> None:
        descriptors: list[int] = []
        try:
            pending = select.poll()
            for identity in identities:
                try:
                    descriptor = self.open_pidfd(identity.pid)
                    descriptors.append(descriptor)
                    current = self.identity(identity.pid)
                except ProcessLookupError:
                    return
                if current != identity:
                    return  # Another incarnation holds the pid: this member exited.
                pending.register(descriptor, select.POLLIN)
            pending.poll(None if math.isinf(timeout) else max(0, math.ceil(timeout * 1000)))
        finally:
            for descriptor in descriptors:
                os.close(descriptor)

    def members_of_group(self, pgid: int) -> tuple[ProcessIdentity, ...]:
        """The kernel answers an empty group in one call; only a live one walks /proc."""
        try:
            os.killpg(pgid, 0)
        except ProcessLookupError:
            return ()
        except PermissionError:
            pass
        members = []
        for entry in Path("/proc").iterdir():
            if entry.name.isdecimal():
                with suppress(ProcessLookupError):
                    record = self._stat(int(entry.name))
                    if record.group == pgid:
                        members.append(record.identity)
        return tuple(members)

    def send(self, identity: ProcessIdentity, signum: int) -> None:
        # Bind first; recheck start time against the pidfd-bound incarnation
        # before signaling. A concurrent exit can never target a reused PID.
        descriptor = self.open_pidfd(identity.pid)
        try:
            self.require(identity)
            self.signal_pidfd(descriptor, signum)
        finally:
            os.close(descriptor)


class AndroidPlatform(LinuxPlatform):
    """Termux's Python names Android; its process and file operations use the Linux kernel."""

    # AOSP's AID_SYSTEM owns /data; app UID/GID pairs own their isolated sandboxes.
    system_identity = 1000

    def trusted_ancestor_owner(self, uid: int) -> bool:
        return uid == self.system_identity or super().trusted_ancestor_owner(uid)

    def ancestor_write_bits(self, info: os.stat_result) -> int:
        writes = super().ancestor_write_bits(info)
        if info.st_gid in (0, self.system_identity, os.getegid()):
            writes &= ~0o020
        return writes

    def publish_new_file(
        self, staged: str | Path, destination: str | Path, *,
        src_dir_fd: int | None = None, dst_dir_fd: int | None = None,
    ) -> None:
        # Android forbids hard links. renameat2 supplies the same no-replace decision
        # without opening the published SQLite inode and releasing another fd's locks.
        function = ctypes.CDLL(None, use_errno=True).renameat2
        function.argtypes = (ctypes.c_int, ctypes.c_char_p, ctypes.c_int,
                             ctypes.c_char_p, ctypes.c_uint)
        function.restype = ctypes.c_int
        if function(-100 if src_dir_fd is None else src_dir_fd, os.fsencode(staged),
                    -100 if dst_dir_fd is None else dst_dir_fd, os.fsencode(destination), 1) < 0:
            code = ctypes.get_errno()
            raise OSError(code, os.strerror(code), os.fspath(destination))

    def snapshot_file(
        self, source: str | Path, destination: str | Path, *,
        src_dir_fd: int | None = None, dst_dir_fd: int | None = None,
    ) -> None:
        with os.fdopen(os.open(source, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=src_dir_fd), 'rb') as original:
            observed = os.fstat(original.fileno())
            if not stat.S_ISREG(observed.st_mode):
                raise ValueError('A retained snapshot requires a regular source file')
            descriptor = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                                 0o600, dir_fd=dst_dir_fd)
            try:
                with os.fdopen(descriptor, 'wb') as retained:
                    shutil.copyfileobj(original, retained)
                    self.make_private_descriptor(retained.fileno(), stat.S_IMODE(observed.st_mode))
                    retained.flush()
                    os.fsync(retained.fileno())
            except BaseException:
                os.unlink(destination, dir_fd=dst_dir_fd)
                raise

    def share_file(self, source: Path, destination: Path) -> bool:
        return False  # A byte copy would not deliver the inode sharing this operation promises.


class DarwinPlatform(Platform):
    """libproc exposes microsecond birth times, unlike formatted ps output."""

    def require_watched_procfs(self, refusal: Exception) -> None:
        raise refusal

    class ProcessInfo(ctypes.Structure):
        # External Darwin proc_bsdinfo ABI, from xnu/bsd/sys/proc_info.h.
        _fields_ = [
            (name, ctypes.c_uint32)
            for name in (
                "flags",
                "status",
                "xstatus",
                "pid",
                "ppid",
                "uid",
                "gid",
                "ruid",
                "rgid",
                "svuid",
                "svgid",
                "reserved",
            )
        ] + [
            ("comm", ctypes.c_char * 16),
            ("name", ctypes.c_char * 32),
            ("nfiles", ctypes.c_uint32),
            ("pgid", ctypes.c_uint32),
            ("pjobc", ctypes.c_uint32),
            ("tdev", ctypes.c_uint32),
            ("tpgid", ctypes.c_uint32),
            ("nice", ctypes.c_int32),
            ("start_seconds", ctypes.c_uint64),
            ("start_microseconds", ctypes.c_uint64),
        ]

    def __init__(self):
        self.libproc = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
        self.libproc.proc_pidinfo.argtypes = (
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_uint64,
            ctypes.c_void_p,
            ctypes.c_int,
        )
        self.libproc.proc_pidinfo.restype = ctypes.c_int
        self.libproc.proc_listpids.argtypes = (
            ctypes.c_uint32,
            ctypes.c_uint32,
            ctypes.c_void_p,
            ctypes.c_int,
        )
        self.libproc.proc_listpids.restype = ctypes.c_int

    def identity(self, pid: int) -> ProcessIdentity:
        info = self.ProcessInfo()
        size = self.libproc.proc_pidinfo(pid, 3, 0, ctypes.byref(info), ctypes.sizeof(info))
        if size != ctypes.sizeof(info):
            code = ctypes.get_errno()
            if code == 3:  # ESRCH, the actual OS absence result.
                raise ProcessLookupError(pid)
            raise OSError(code, os.strerror(code))
        if info.status == 5:  # SZOMB: exited, awaiting reap.
            raise ProcessLookupError(pid)
        return ProcessIdentity.in_group(
            pid, info.start_seconds * 1_000_000 + info.start_microseconds, info.pgid,
        )

    def started_at(self, identity: ProcessIdentity) -> float:
        return time.monotonic() - (time.time() - identity.start_time / 1_000_000)

    def arguments(self, process: ProcessIdentity) -> tuple[str, ...]:
        raise NotImplementedError(f"{type(self).__name__} does not read process arguments")

    def environment(self, process: ProcessIdentity) -> dict[str, str]:
        raise NotImplementedError(f"{type(self).__name__} does not read process environment")

    def process_name(self, pid: int) -> str:
        raise NotImplementedError(f"{type(self).__name__} does not read process names")

    def members_of_group(self, pgid: int) -> tuple[ProcessIdentity, ...]:
        # proc_listpids returns bytes. Grow until one query fits; never mistake
        # a full buffer for a complete process-group observation.
        capacity = 16
        while True:
            buffer = (ctypes.c_int * capacity)()
            size = self.libproc.proc_listpids(2, pgid, buffer, ctypes.sizeof(buffer))
            if size < 0:
                code = ctypes.get_errno()
                raise OSError(code, os.strerror(code))
            if size < ctypes.sizeof(buffer):
                break
            capacity *= 2
        members = []
        for pid in buffer[: size // ctypes.sizeof(ctypes.c_int)]:
            if pid > 0:
                with suppress(ProcessLookupError):
                    members.append(self.identity(pid))
        return tuple(members)

    def wait_any_exited(
        self, identities: tuple[ProcessIdentity, ...], timeout: float,
    ) -> None:
        with select.kqueue() as pending:
            events = [
                select.kevent(
                    identity.pid, filter=select.KQ_FILTER_PROC,
                    flags=select.KQ_EV_ADD | select.KQ_EV_ONESHOT,
                    fflags=select.KQ_NOTE_EXIT,
                )
                for identity in identities
            ]
            for identity in identities:
                try:
                    current = self.identity(identity.pid)
                except ProcessLookupError:
                    return
                if current != identity:
                    return  # Another incarnation holds the pid: this member exited.
            try:
                returned = pending.control(
                    events, 1, None if math.isinf(timeout) else max(0, timeout),
                )
                for event in returned:
                    if event.flags & select.KQ_EV_ERROR:
                        raise OSError(event.data, os.strerror(event.data))
            except ProcessLookupError:
                return


class UnitActivity(DeclaredFamily, affix="Unit"):
    """systemd's ActiveState of a unit, an external contract decoded once by its spelling."""

    @classmethod
    def ended(cls) -> bool:
        """Whether the unit has stopped running, cleanly or not."""
        return False

    @classmethod
    def serving(cls) -> bool:
        """Whether ``systemctl is-active`` counts the unit as running."""
        return False


class EndedUnit(UnitActivity, declared_name=None):
    @classmethod
    def ended(cls) -> bool:
        return True


class ServingUnit(UnitActivity, declared_name=None):
    @classmethod
    def serving(cls) -> bool:
        return True


class ActiveUnit(ServingUnit): ...


class ReloadingUnit(ServingUnit): ...


class RefreshingUnit(ServingUnit): ...


class ActivatingUnit(UnitActivity): ...


class DeactivatingUnit(UnitActivity): ...


class MaintenanceUnit(UnitActivity): ...


class InactiveUnit(EndedUnit): ...


class FailedUnit(EndedUnit): ...


class UnmanagedHomeError(RelationViolationError):
    """A home no user manager belongs to asked to change the manager's units."""


class ResidentManager(DeclaredFamily, affix="Manager"):
    """What owns this home's units, and a handed-off resident once its launcher is gone: a
    host fact, decoded once, and the only caller of ``systemctl`` and ``systemd-run``.

    Leaving the launcher's process tree is not enough when the launcher is itself a systemd
    unit: ending that unit signals its whole cgroup, setsid and the reparent to init included.
    """

    @staticmethod
    def current(environment: Mapping[str, str] = os.environ) -> ResidentManager:
        """Admit the UID's own home before discovering its manager. Explicit runtime
        directories are never replaced; only an absent address uses the UID's standard
        directory. Both the directory and manager socket must belong to that UID."""
        uid = os.getuid()
        home = Path(pwd.getpwuid(uid).pw_dir).resolve()
        if Path(environment.get("HOME", str(home))).resolve() != home:
            return NoResidentManager()
        runtime = Path(environment.get("XDG_RUNTIME_DIR", f"/run/user/{uid}"))
        if not runtime.is_absolute():
            return NoResidentManager()
        runtime = runtime.resolve()
        try:
            directory = runtime.stat()
            socket = (runtime / "systemd/private").stat()
        except (FileNotFoundError, NotADirectoryError, PermissionError):
            return NoResidentManager()
        if directory.st_uid == uid and socket.st_uid == uid and stat.S_ISSOCK(socket.st_mode):
            return SystemdUserManager(runtime)
        return NoResidentManager()

    def command(self, command: tuple[str, ...]) -> tuple[str, ...]:
        """A host with no manager owns the resident only through its process tree."""
        return command

    def handoff_environment(self, environment: Mapping[str, str]) -> dict[str, str]:
        """Keep the environment required to reach the selected resident manager."""
        return dict(environment)

    def activity(self, unit: str) -> type[UnitActivity]:
        """No manager runs a unit for this home."""
        return InactiveUnit

    def loads(self, unit: str, definition: Path) -> bool:
        """Whether the manager runs ``unit`` from this home's own ``definition``."""
        return False

    def main_pid(self, unit: str, definition: Path) -> int:
        """The process of the unit loaded from ``definition``; zero for any other."""
        return 0

    def listed(self, pattern: str) -> tuple[str, ...]:
        """The names of the active units matching ``pattern``."""
        return ()

    def reload(self) -> None:
        """Load this home's unit definitions; no manager reads a home it does not serve."""

    def install(self, unit: type[SystemdUnit], arguments: tuple[str, ...] = (), *,
                home: Path) -> None:
        """Publish a unit and its declared prerequisites, then load them together."""
        if self.write_unit(unit, arguments, home=home):
            self.reload()

    def required_units(self) -> tuple[type[SystemdUnit], ...]:
        return ()

    def prepare_units(self, *, home: Path) -> None:
        """Install the manager's declared launch prerequisites before releasing a child."""
        for required in self.required_units():
            self.install(required, home=home)

    def write_unit(self, unit: type[SystemdUnit], arguments: tuple[str, ...] = (), *,
                   home: Path) -> bool:
        changed = False
        for required in unit.required_units():
            changed |= self.write_unit(required, home=home)
        destination = unit.unit_file(home)
        definition = unit.unit_text(arguments)
        if not destination.is_file() or destination.read_text(encoding="utf-8") != definition:
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(definition, encoding="utf-8")
            changed = True
        return changed

    def control(self, *arguments: str) -> None:
        """Start, stop, enable or disable the manager's units."""
        raise UnmanagedHomeError(
            f"{Path.home()} is not the user's own home, so no user manager belongs to it; "
            f"refused systemctl {' '.join(arguments)}")

    def transient(self, unit: str, command: tuple[str, ...], *, cwd: Path, stdin: Path,
                  stdout: Path, stderr: Path, inherited: tuple[str, ...],
                  assigned: Mapping[str, str], wait: bool) -> None:
        """Run ``command`` as ``unit``, so stopping its caller cannot cut it short; ``wait``
        follows it to its end and raises on its failure. Without a manager only a caller
        that waits can own it."""
        if not wait:
            raise UnmanagedHomeError(
                f"{Path.home()} has no user manager to keep {unit} past its caller")
        environment = {name: os.environ[name] for name in inherited if name in os.environ}
        # As under systemd-run, the unit gets exactly these variables, its import path included.
        with (stdin.open("rb") as given, stdout.open("wb") as answer, stderr.open("wb") as errors,
              SpawnedProcess.launch(command, cwd=cwd, env={**environment, **assigned},
                                    stdio=ConfiguredChildStdio(stdin=given, stdout=answer, stderr=errors),
                                    runtime=RestoredRuntime(Path(command[0]))) as child):
            returncode = child.process.wait()
        if returncode:
            raise subprocess.CalledProcessError(returncode, command)


@dataclass(frozen=True)
class NoResidentManager(ResidentManager): ...


@dataclass(frozen=True)
class SystemdUserManager(ResidentManager):
    """The admitted connection, retained for every command and resident handoff. The user
    manager owns each resident in its own scope; ``systemd-run --scope`` execs in place."""

    runtime_directory: Path

    def command(self, command: tuple[str, ...]) -> tuple[str, ...]:
        return (*AgentsSlice.run_prefix(), "--scope",
                f"--unit=agent-comms-resident-{Id128.mint()}", "--", *command)

    def handoff_environment(self, environment: Mapping[str, str]) -> dict[str, str]:
        return {**environment, "XDG_RUNTIME_DIR": str(self.runtime_directory),
                "DBUS_SESSION_BUS_ADDRESS": f"unix:path={self.runtime_directory}/bus"}

    def required_units(self) -> tuple[type[SystemdUnit], ...]:
        return (AgentsSlice,)

    def shown(self, unit: str, name: str) -> str:
        return subprocess.check_output(
            ("systemctl", "--user", "show", "-p", name, "--value", unit), text=True,
            env=self.handoff_environment(os.environ),
        ).strip()

    def activity(self, unit: str) -> type[UnitActivity]:
        return UnitActivity.member_named(self.shown(unit, "ActiveState"))

    def loads(self, unit: str, definition: Path) -> bool:
        """The manager belongs to the UID, not HOME; the same name loaded from another
        directory is not this home's unit."""
        return (definition.is_file()
                and Path(self.shown(unit, "FragmentPath")).resolve() == definition.resolve())

    def main_pid(self, unit: str, definition: Path) -> int:
        return int(self.shown(unit, "MainPID")) if self.loads(unit, definition) else 0

    def listed(self, pattern: str) -> tuple[str, ...]:
        listed = subprocess.check_output(
            ("systemctl", "--user", "list-units", pattern, "--state=active", "--plain",
             "--no-legend"), text=True, env=self.handoff_environment(os.environ))
        return tuple(line.split()[0] for line in listed.splitlines() if line.strip())

    def reload(self) -> None:
        self.control("daemon-reload")

    def control(self, *arguments: str) -> None:
        subprocess.run(("systemctl", "--user", *arguments), check=True,
                       env=self.handoff_environment(os.environ))

    def transient(self, unit: str, command: tuple[str, ...], *, cwd: Path, stdin: Path,
                  stdout: Path, stderr: Path, inherited: tuple[str, ...],
                  assigned: Mapping[str, str], wait: bool) -> None:
        """systemd-run copies each inherited value from this connection's environment,
        including a runtime directory discovered without an ambient XDG value."""
        self.prepare_units(home=Path.home())
        subprocess.run(
            (*AgentsSlice.run_prefix(), *(("--wait",) if wait else ()),
             f"--unit={unit}", f"--working-directory={cwd}",
             f"--property=StandardInput=file:{stdin}",
             f"--property=StandardOutput=file:{stdout}",
             f"--property=StandardError=file:{stderr}",
             *(f"--setenv={name}" for name in inherited),
             *(f"--setenv={name}={value}" for name, value in assigned.items()), *command),
            check=True, env=self.handoff_environment(os.environ),
        )


class ChildLifetime(DeclaredFamily, affix="Lifetime"):
    """Whether a launched child may outlive the process that launched it."""

    handoff: ClassVar[bool] = False

    @classmethod
    def environment(cls, environment: Mapping[str, str]) -> Mapping[str, str]:
        return environment

    @classmethod
    def command(cls, command: tuple[str, ...]) -> tuple[str, ...]:
        """The command the exec gate executes; a child bound to its launcher runs it as given."""
        return command

    @classmethod
    def spawned(cls, process: subprocess.Popen[bytes], descriptor: int) -> SpawnedProcess:
        return SpawnedProcess(process, Platform.current().identity(process.pid))

    @classmethod
    async def spawned_async(cls, process: asyncio.subprocess.Process, descriptor: int) -> AttachedChild:
        return AttachedChild(process, Platform.current().identity(process.pid))

    @classmethod
    @abstractmethod
    def launcher(cls, platform: Platform) -> int:
        """The PID the exec gate binds the child's life to; zero binds none."""


class DiesWithLauncherLifetime(ChildLifetime):
    """Every child by default: a killed launcher cannot leave it running under init.

    The kernel signal follows the launching thread, so the thread that launches
    the child must outlive it, as the event loop and a pool worker's task do.
    """

    @classmethod
    def launcher(cls, platform: Platform) -> int:
        return platform.parent_death_binding()


class OutlivesLauncherLifetime(ChildLifetime):
    """A resident the launcher hands off, such as a worker, a watcher or a bridge."""

    handoff: ClassVar[bool] = True

    @classmethod
    def environment(cls, environment: Mapping[str, str]) -> Mapping[str, str]:
        return ResidentManager.current().handoff_environment(environment)

    @classmethod
    def command(cls, command: tuple[str, ...]) -> tuple[str, ...]:
        manager = ResidentManager.current()
        manager.prepare_units(home=Path.home())
        return manager.command(command)

    @staticmethod
    def resident(descriptor: int) -> ProcessIdentity:
        encoded = os.read(descriptor, 64)
        if not encoded:
            raise ChildProcessError("Exec gate exited without handing off its resident")
        return Platform.current().identity(int(encoded))

    @classmethod
    def spawned(cls, process: subprocess.Popen[bytes], descriptor: int) -> SpawnedProcess:
        try:
            identity = cls.resident(descriptor)
        finally:
            returncode = process.wait()
        if returncode != 0:
            raise ChildProcessError("Resident handoff failed")
        return HandedOffProcess(process, identity)

    @classmethod
    async def spawned_async(cls, process: asyncio.subprocess.Process, descriptor: int) -> AttachedChild:
        try:
            identity = await asyncio.to_thread(cls.resident, descriptor)
        finally:
            returncode = await process.wait()
        if returncode != 0:
            raise ChildProcessError("Resident handoff failed")
        return HandedOffAttachedChild(process, identity)

    @classmethod
    def launcher(cls, platform: Platform) -> int:
        return 0


class ChildLaunch:
    def __init__(self, platform: Platform, command: tuple[str, ...],
                 pass_fds: tuple[int, ...], runtime: LaunchRuntime,
                 lifetime: type[ChildLifetime]):
        self.runtime = runtime
        self.platform = platform
        self.command = command
        self.pass_fds = pass_fds
        self.lifetime = lifetime
        self.read_fd, self.write_fd = os.pipe()
        self.error_r, error_w = os.pipe()
        self.error_writer = os.fdopen(error_w, "wb", buffering=0)
        self.identity_r, identity_w = os.pipe()
        self.identity_writer = os.fdopen(identity_w, "wb", buffering=0)

    @property
    def argv(self) -> tuple[str, ...]:
        # The exec gate runs this decoder's code before exec of the selected command.
        return (
            str(LaunchRuntime.running().interpreter),
            "-c",
            _EXEC_GATE,
            str(self.read_fd),
            str(self.error_writer.fileno()),
            str(self.lifetime.launcher(self.platform)),
            str(int(self.lifetime.handoff)),
            str(self.identity_writer.fileno()),
            *self.lifetime.command(self.command),
        )

    @property
    def options(self) -> dict:
        return {
            "start_new_session": True,
            "pass_fds": (self.read_fd, self.error_writer.fileno(),
                         self.identity_writer.fileno(), *self.pass_fds),
        }

    def spawned(self, process: subprocess.Popen[bytes]) -> SpawnedProcess:
        self.identity_writer.close()
        return self.lifetime.spawned(process, self.identity_r)

    async def spawned_async(self, process: asyncio.subprocess.Process) -> AttachedChild:
        self.identity_writer.close()
        return await self.lifetime.spawned_async(process, self.identity_r)

    def spawn(
        self,
        *,
        cwd=None,
        env: Mapping[str, str] = INHERITED_ENVIRONMENT,
        stdio: ChildStdio,
    ) -> SpawnedProcess:
        """Hand back the launch handle before the platform allows exec."""
        process = subprocess.Popen(
            self.argv, cwd=cwd,
            env=self.lifetime.environment(self.runtime.child_environment(env)),
            **stdio.streams, **self.options,
        )
        return self.spawned(process)

    async def spawn_async(self, *, cwd, env, stdio: ChildStdio) -> AttachedChild:
        process = await asyncio.create_subprocess_exec(
            self.argv[0], *self.argv[1:], cwd=cwd,
            env=self.lifetime.environment(self.runtime.child_environment(env)),
            **stdio.options, **self.options,
        )
        child = await self.spawned_async(process)
        child._stderr_task = asyncio.create_task(child._drain_stderr())
        return child

    def release(self, identity: ProcessIdentity) -> None:
        self.error_writer.close()
        os.write(self.write_fd, b"G")

    def cancel_before_release(self, identity: ProcessIdentity) -> None:
        # The exec gate has not released user code or spawned descendants.
        with suppress(ProcessLookupError):
            self.platform.send(identity, signal.SIGKILL)

    def verify(self) -> None:
        error = os.read(self.error_r, 64)
        if error:
            code = int(error)
            raise OSError(code, os.strerror(code), self.command[0])

    async def verify_async(self) -> None:
        await _exec_error(self.error_r, self.command[0])

    def close(self) -> None:
        self.error_writer.close()
        self.identity_writer.close()
        for fd in (self.read_fd, self.write_fd, self.error_r, self.identity_r):
            os.close(fd)

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


class OrderCheckFailedError(ValueError):
    """A completed order check did not prove its expected result."""


class CheckPrinted(DisclosedRecord, DeclaredFamily, affix="Printed"):
    """The count printed by a child, or the absence of an integer."""

    @staticmethod
    def decoded(stdout: bytes) -> CheckPrinted:
        counts = re.findall(r"\d+", stdout.decode(errors="replace"))
        return CountPrinted(int(counts[-1])) if counts else NoIntegerPrinted()

    @abstractmethod
    def unproven(self, command: str, expected: int) -> tuple[str, ...]: ...

    @abstractmethod
    def distance(self, expected: int) -> CheckPrinted: ...

    @abstractmethod
    def plus(self, amount: int) -> CheckPrinted: ...

    @abstractmethod
    def require(self, expected: object) -> None: ...

    @abstractmethod
    def project[T](self, counted: Callable[[int], T],
                   uncounted: Callable[[NoIntegerPrinted], T]) -> T: ...


@dataclass(frozen=True)
class CountPrinted(CheckPrinted):
    count: int

    def distance(self, expected: int) -> CheckPrinted:
        return CountPrinted(abs(self.count - expected))

    def plus(self, amount: int) -> CheckPrinted:
        return CountPrinted(self.count + amount)

    def require(self, expected: object) -> None:
        if self.count:
            raise OrderCheckFailedError(f"The order check is {self.count} away from {expected}.")

    def project[T](self, counted: Callable[[int], T],
                   uncounted: Callable[[NoIntegerPrinted], T]) -> T:
        return counted(self.count)

    def unproven(self, command: str, expected: int) -> tuple[str, ...]:
        return ((f"Check already prints {self.count} before any work: `{command}` proves nothing; "
                 "write a check that fails now",) if self.count == expected else ())


@dataclass(frozen=True)
class NoIntegerPrinted(CheckPrinted):
    def distance(self, expected: int) -> CheckPrinted:
        return self

    def plus(self, amount: int) -> CheckPrinted:
        return self

    def require(self, expected: object) -> None:
        raise OrderCheckFailedError(
            f"The order check cannot prove {expected}: it printed no integer.")

    def project[T](self, counted: Callable[[int], T],
                   uncounted: Callable[[NoIntegerPrinted], T]) -> T:
        return uncounted(self)

    def progress(self, command: str) -> str:
        return f"; check prints no integer: {command}"

    def unproven(self, command: str, expected: int) -> tuple[str, ...]:
        return ("the check printed no integer; use grep -c PATTERN FILE or ... | wc -l",)


class NoCountYetPrinted(NoIntegerPrinted):
    """An unfinished child contributes no count, including digits in partial stdout."""

    def require(self, expected: object) -> None:
        raise ValueError(f"The order check has no count yet; cannot prove {expected}.")

    def unproven(self, command: str, expected: int) -> tuple[str, ...]:
        return (f"the check has no count yet: `{command}` did not finish",)

    def progress(self, command: str) -> str:
        return "; no count yet"


class ChildOutcome(DeclaredFamily, affix="Outcome"):
    interrupted: ClassVar[bool] = False

    def report_shutdown(self, report_timeout: Callable[[], None]) -> None:
        pass

    def report_forced(self, report: Callable[[str], None]) -> None:
        pass

    def report_stopped(self, report: Callable[[], None], stop_exits: frozenset[int]) -> None:
        """Only a signal, or a program's declared stop exit, ends a child as stopped."""

    def fork_failure(self, interrupted_consequence: Callable[[], str]) -> str:
        return ""

    def printed_count(self, stdout: bytes) -> CheckPrinted:
        return NoCountYetPrinted()

    @property
    @abstractmethod
    def summary(self) -> str: ...

    @property
    @abstractmethod
    def successful(self) -> bool: ...

    @classmethod
    def from_returncode(cls, code: int) -> ChildOutcome:
        return SignaledOutcome(-code) if code < 0 else ExitedOutcome(code)


@dataclass(frozen=True)
class ExitedOutcome(ChildOutcome):
    code: int

    def printed_count(self, stdout: bytes) -> CheckPrinted:
        return CheckPrinted.decoded(stdout)

    def report_stopped(self, report: Callable[[], None], stop_exits: frozenset[int]) -> None:
        if self.code in stop_exits:
            report()

    @property
    def summary(self) -> str:
        return f"exited with code {self.code}"

    @property
    def successful(self) -> bool:
        return self.code == 0


class InterruptedForkOutcome(ChildOutcome):
    """A killed helper may leave its native writer locks behind."""

    def fork_failure(self, interrupted_consequence: Callable[[], str]) -> str:
        return interrupted_consequence()


@dataclass(frozen=True)
class SignaledOutcome(InterruptedForkOutcome):
    interrupted: ClassVar[bool] = True
    signal_number: int

    def report_stopped(self, report: Callable[[], None], stop_exits: frozenset[int]) -> None:
        report()

    @property
    def summary(self) -> str:
        return f"stopped by {signal.Signals(self.signal_number).name}"

    @property
    def successful(self) -> bool:
        return False


@dataclass(frozen=True)
class TimedOutOutcome(InterruptedForkOutcome):
    termination: ChildOutcome

    def report_shutdown(self, report_timeout: Callable[[], None]) -> None:
        report_timeout()

    @property
    def summary(self) -> str:
        return f"timed out; {self.termination.summary}"

    @property
    def successful(self) -> bool:
        return False


@dataclass(frozen=True)
class GracefulStopOutcome(ChildOutcome):
    termination: ChildOutcome

    @property
    def summary(self) -> str:
        return self.termination.summary

    @property
    def successful(self) -> bool:
        return self.termination.successful


@dataclass(frozen=True)
class ForcedStopOutcome(GracefulStopOutcome):
    """At least one member required the forced stage, even if leader exited."""

    def report_forced(self, report: Callable[[str], None]) -> None:
        report(self.summary)


@dataclass(frozen=True)
class FailedToStartOutcome(ChildOutcome):
    error: str

    @property
    def summary(self) -> str:
        return f"failed to start: {self.error}"

    @property
    def successful(self) -> bool:
        return False


@dataclass(frozen=True)
class ChildResult:
    outcome: ChildOutcome
    stdout: bytes = b""
    stderr: bytes = b""


# The gate establishes identity before even an instantaneous executable can
# exit. It owns no business logic or stored state and preserves exec PID/group.
_EXEC_GATE = """import os,sys
fd=int(sys.argv[1]); error_fd=int(sys.argv[2]); launcher=int(sys.argv[3])
handoff=int(sys.argv[4]); identity_fd=int(sys.argv[5])
if handoff:
    ready_r, ready_w = os.pipe()
    resident = os.fork()
    if resident:
        os.close(ready_w)
        ready = os.read(ready_r, 1); os.close(ready_r)
        if ready != b'R': os._exit(126)
        os.write(identity_fd, str(resident).encode()); os.close(identity_fd)
        os._exit(0)
    os.close(ready_r)
    os.setsid()
    os.write(ready_w, b'R'); os.close(ready_w)
os.close(identity_fd)
if launcher:
    import ctypes
    # PR_SET_PDEATHSIG (1) survives exec: the kernel kills this child with its launcher.
    if ctypes.CDLL(None, use_errno=True).prctl(1, 9):
        os.write(error_fd, str(ctypes.get_errno()).encode()); os._exit(126)
    if os.getppid() != launcher: os._exit(126)
go=os.read(fd,1); os.close(fd)
if go != b'G': sys.exit(126)
os.set_inheritable(error_fd, False)
try: os.execvpe(sys.argv[6], sys.argv[6:], os.environ)
except OSError as error:
    os.write(error_fd, str(error.errno).encode()); os._exit(126)
"""


async def _exec_error(fd: int, command: str) -> None:
    os.set_blocking(fd, False)
    loop = asyncio.get_running_loop()
    ready: asyncio.Future[bytes] = loop.create_future()

    def receive() -> None:
        if not ready.done():
            ready.set_result(os.read(fd, 64))

    loop.add_reader(fd, receive)
    try:
        data = await ready
        if data:
            code = int(data)
            raise OSError(code, os.strerror(code), command)
    finally:
        loop.remove_reader(fd)


class DroppableRead[Result](Future[Result], threading.Thread):
    """Read-only work may leave with its process instead of holding its shutdown.

    Unlike the default executor, a daemon reader is not joined by asyncio.run or
    Python's executor shutdown. Its future still receives completion safely if the
    loop has already closed. Only a declared read capability may use this owner.
    """

    def __init__(self, operation: Callable[[], Result]) -> None:
        Future.__init__(self)
        threading.Thread.__init__(self, daemon=True, name="droppable-read")
        self.operation = operation

    def run(self) -> None:
        if not self.set_running_or_notify_cancel():
            return
        try:
            result = self.operation()
        except BaseException as error:
            self.set_exception(error)
        else:
            self.set_result(result)

    async def answer(self) -> Result:
        self.start()
        return await asyncio.wrap_future(self)


class AsyncWork:
    """Accepted work finishes before its caller releases the operation's resources."""

    @classmethod
    async def run_async[Result](cls, operation: Callable[[], Result]) -> Result:
        return await join_retirement(asyncio.create_task(asyncio.to_thread(operation)))

    @classmethod
    def cancel_on_shutdown[Result](cls, pending: asyncio.Future[Result]) -> None:
        """A mutation must finish, even if its worker has not started yet."""


class ReadWork(AsyncWork):
    """Declared read-only work can leave with its process without joining its thread."""

    @classmethod
    async def run_async[Result](cls, operation: Callable[[], Result]) -> Result:
        context = copy_context()

        def observe() -> Result:
            with GitLaunch.acquiring():
                return operation()

        return await DroppableRead(lambda: context.run(observe)).answer()

    @classmethod
    def cancel_on_shutdown[Result](cls, pending: asyncio.Future[Result]) -> None:
        pending.cancel()


class HelperStart(ABC):
    """How a helper interpreter that runs the application's own code starts: a route
    observer, a render worker. Each owner that starts one declares its member.

    The application spawns a fresh interpreter: it leaves through normal finalisation, so its
    atexit hooks (the exit heap freeze, launch_root.started) run. A test runner that already
    holds the application imported declares an owner whose member forks from that warm
    interpreter instead.
    """

    @abstractmethod
    def context(self) -> multiprocessing.context.SpawnContext:
        """Every member speaks spawn's protocol (a pickled process object on a pipe); a
        member decides only what interpreter receives it."""


class SpawnedHelper(HelperStart):
    """A fresh interpreter per helper, importing what it runs."""

    def context(self) -> multiprocessing.context.SpawnContext:
        return multiprocessing.get_context("spawn")


async def join_retirement[Result](task: asyncio.Future[Result]) -> Result:
    """Join owned cleanup through repeated cancellation, then propagate it."""
    interrupted = None
    try:
        while not task.done():
            try:
                # wait does not cancel the original future or replace its own
                # typed cancellation with shield's synthetic CancelledError.
                await asyncio.wait((task,))
            except asyncio.CancelledError as error:
                interrupted = error
        result = task.result()
    except ChildRetirementError:
        raise  # Cancellation cannot turn an unattested physical stop into success.
    except BaseException as error:
        # A failed joined operation has still finished. Its error must
        # not consume the caller's cancellation and restart an observer loop.
        if interrupted is not None:
            raise interrupted from error
        raise
    if interrupted is not None:
        raise interrupted
    return result


class ChildProcess(Sealed, ABC):
    """The sole stop algorithm; cancellation retains the cleanup task."""

    def __init__(self, identity: ProcessIdentity):
        self.identity = identity
        self.platform = Platform.current()
        self._stop_task: asyncio.Task[ChildOutcome] | None = None

    @property
    def pid(self) -> int:
        return self.identity.pid

    def alive(self) -> bool:
        return self.platform.matches(self.identity)

    def force(self) -> None:
        """Signal the original owned group, including an exited leader's members."""
        self.platform.force_group(self.identity)

    @property
    def retired(self) -> bool:
        """Exact child and its owned group are gone, independent of pipe callbacks."""
        return not self.alive() and not self.platform.group_members(self.identity)

    @abstractmethod
    async def wait(self) -> ChildOutcome: ...

    def _stop_plan(
        self, guard: Callable[[], AbstractContextManager[None]], deadline: float = math.inf,
    ) -> Generator[tuple[tuple[ProcessIdentity, ...], float], None, type[GracefulStopOutcome]]:
        with guard():
            self.platform.terminate_group(self.identity)
        grace_deadline = min(time.monotonic() + STOP_GRACE_SECONDS, deadline)
        stage = GracefulStopOutcome
        while members := self.platform.group_members(self.identity):
            now = time.monotonic()
            if stage is GracefulStopOutcome and now >= grace_deadline:
                stage = ForcedStopOutcome
                with guard():
                    self.platform.force_group(self.identity)
                continue
            if stage is ForcedStopOutcome:
                if now >= deadline:
                    raise ChildRetirementFailed(f"Process group still alive: {members}")
                with guard():
                    self.platform.force_group(self.identity)
            # Re-enumerate after a member exits: a surviving member may have forked.
            until = grace_deadline if stage is GracefulStopOutcome else deadline
            yield members, max(0, until - now)
        return stage

    def _retire_group(self, guard, deadline=math.inf):
        """Use the same guarded stop plan for synchronous and asynchronous cleanup."""
        plan = self._stop_plan(guard, deadline)
        while True:
            try:
                members, timeout = next(plan)
            except StopIteration as done:
                return done.value
            self.platform.wait_any_exited(members, timeout)

    async def _stop(self) -> ChildOutcome:
        pending = asyncio.get_running_loop().run_in_executor(
            None, self._retire_group, nullcontext
        )
        stage = await join_retirement(pending)
        self._release_retired_io()
        async with asyncio.timeout(STOP_GRACE_SECONDS):
            return stage(await self.wait())

    def _release_retired_io(self) -> None:
        """Release owned IO after the identity-bound process group has retired."""
        return None

    async def stop(self) -> ChildOutcome:
        if self._stop_task is None:
            self._stop_task = asyncio.create_task(self._stop())
        try:
            return await join_retirement(self._stop_task)
        except asyncio.CancelledError:
            # join_retirement completed the owned task before propagating cancellation.
            # Its original result, not the caller's exception, owns cleanup certainty.
            try:
                self._stop_task.result()
            except BaseException as error:
                raise ChildRetirementCancelled("Child retirement was not attested") from error
            raise
        except (OSError, RuntimeError) as error:
            raise ChildRetirementFailed("Child retirement was not attested") from error


@dataclass(frozen=True)
class StreamingChildStdio(ChildStdio):
    input_enabled: bool = True
    limit: int = 65536
    stderr: int | IO[bytes] | IO[str] = subprocess.PIPE

    @property
    def streams(self) -> StdioOptions:
        return {
            "stdin": subprocess.PIPE if self.input_enabled else subprocess.DEVNULL,
            "stdout": subprocess.PIPE,
            "stderr": self.stderr,
        }

    @property
    def options(self) -> AsyncStdioOptions:
        return {**self.streams, "limit": self.limit}


@dataclass(frozen=True)
class TerminalChildStdio(ChildStdio):
    terminal: IO[bytes] | IO[str]

    @property
    def streams(self) -> StdioOptions:
        return {"stdin": self.terminal, "stdout": self.terminal, "stderr": self.terminal}


class AttachedChild(ChildProcess):
    stderr_limit: ClassVar[int] = 16000

    def __init__(self, process: asyncio.subprocess.Process, identity: ProcessIdentity):
        super().__init__(identity)
        self.process = process
        self.stdin = process.stdin
        self.stdout = process.stdout
        self.stderr = process.stderr
        self._stderr_task: asyncio.Task[bytes]

    @classmethod
    async def start(
        cls,
        command: tuple[str, ...],
        *,
        cwd: str | Path | None = None,
        env: Mapping[str, str] = INHERITED_ENVIRONMENT,
        pass_fds: tuple[int, ...] = (),
        stdio: ChildStdio = StreamingChildStdio(),
        runtime: LaunchRuntime = LaunchRuntime.running(),
        lifetime: type[ChildLifetime] = DiesWithLauncherLifetime,
    ) -> AttachedChild:
        if not command:
            raise ValueError("A child command is required")
        platform = Platform.current()
        with platform.launch(command, pass_fds, runtime, lifetime) as launch:
            child = await launch.spawn_async(cwd=cwd, env=env, stdio=stdio)
            try:
                launch.release(child.identity)
                await launch.verify_async()
            except BaseException:
                await child.stop()
                raise
        return child

    def send(self, data: bytes) -> None:
        """Write synchronously while this child's input still exists and it runs."""
        if self.stdin is None or self.returncode is not None:
            raise BrokenPipeError
        self.stdin.write(data)

    async def drain(self) -> None:
        await self.stdin.drain()

    async def write(self, data: bytes) -> None:
        """Write to this still-running child's input and observe transport backpressure."""
        self.send(data)
        await self.drain()

    @property
    def returncode(self) -> int | None:
        return self.process.returncode

    async def wait(self) -> ChildOutcome:
        outcome = ChildOutcome.from_returncode(await self.process.wait())
        await asyncio.shield(self._stderr_task)
        return outcome

    def _release_retired_io(self) -> None:
        # asyncio's wait also waits for pipe disconnects. A cancelled reader
        # can leave a full pipe paused forever, even after process exit. Close
        # the owned subprocess transport only after the group has retired;
        # don't decode, accumulate, or replay abandoned output to unblock wait.
        self.process._transport.close()

    async def _drain_stderr(self) -> bytes:
        """The one pipe reader, started before releasing the child's exec gate."""
        tail = b""
        if self.stderr is not None:
            while chunk := await self.stderr.read(4096):
                tail = (tail + chunk)[-self.stderr_limit:]
        return tail

    async def stderr_tail(self, max_bytes: int = stderr_limit) -> str:
        return (
            (await asyncio.shield(self._stderr_task))[-max_bytes:].decode(errors="replace").strip()
        )

    async def _collect_stdout(self) -> bytes:
        output = bytearray()
        if self.stdout is not None:
            while chunk := await self.stdout.read(65536):
                output.extend(chunk)
        return bytes(output)

    async def communicate(self, data: bytes | None) -> tuple[bytes, bytes]:
        """Collect stdout without competing with the owned bounded stderr reader."""
        output = asyncio.create_task(self._collect_stdout())
        try:
            try:
                if data:
                    await self.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass  # A command may finish before consuming all supplied input.
            finally:
                self.close_input()
            return await output, await asyncio.shield(self._stderr_task)
        finally:
            if not output.done():
                output.cancel()
            await asyncio.gather(output, return_exceptions=True)

    def close_input(self) -> None:
        if self.stdin is not None:
            self.stdin.close()

    async def finish(self) -> ChildOutcome:
        """Allow a completed streaming protocol to flush and exit after EOF."""
        self.close_input()
        try:
            async with asyncio.timeout(STOP_GRACE_SECONDS):
                outcome = await self.wait()
            await self.stop()  # Also retire descendants of an exited leader.
            return outcome
        except TimeoutError:
            return TimedOutOutcome(await self.stop())


class HandedOffAttachedChild(AttachedChild):
    """The gate was reaped; resident completion has no parent exit status."""

    @property
    def returncode(self) -> None:
        return None

    async def wait(self) -> ChildOutcome:
        await self.identity.wait_exited()
        await asyncio.shield(self._stderr_task)
        return DetachedExitOutcome()


class ParentLifeline:
    """Inherited pipe for a Python child which must die with its launcher.

    Lifted from the recovery reader's parent watchdog. The child enters guard()
    before calling the blocking operation; EOF releases OS-owned locks even
    when the operation is stuck on another Python thread.
    """

    variable = "AGENT_COMMS_PARENT_LIFELINE_FD"

    def __enter__(self):
        self.read_fd, self.write_fd = os.pipe()
        return self

    def __exit__(self, *_):
        os.close(self.read_fd)
        os.close(self.write_fd)

    @property
    def environment(self) -> dict[str, str]:
        return {**os.environ, self.variable: str(self.read_fd)}

    @staticmethod
    def watch(descriptor: int, lost: Callable[[], None]) -> None:
        os.fstat(descriptor)

        def parent_watchdog() -> None:
            try:
                os.read(descriptor, 1)
            finally:
                lost()

        threading.Thread(target=parent_watchdog, daemon=True).start()

    @classmethod
    def guard(cls) -> None:
        cls.watch(int(os.environ.pop(cls.variable)), partial(os._exit, 1))


class BoundedRun:
    @classmethod
    @asynccontextmanager
    async def session(cls, command: tuple[str, ...], *, timeout: float, **options):
        """One bounded request/response exchange; caller owns its protocol."""
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("A positive finite timeout is required")
        child = None
        try:
            async with asyncio.timeout(timeout):
                child = await AttachedChild.start(command, **options)
                yield child
        finally:
            if child is not None:
                await child.stop()

    @classmethod
    async def run(cls, command: tuple[str, ...], *, timeout: float, **options) -> ChildResult:
        """Collect a result and join retirement before returning it."""
        async with cls.exchange(command, timeout=timeout, **options) as result:
            return result

    @classmethod
    @asynccontextmanager
    async def exchange(
        cls,
        command: tuple[str, ...],
        *,
        timeout: float,
        input: bytes | None = None,
        cwd: str | Path | None = None,
        env: Mapping[str, str] = INHERITED_ENVIRONMENT,
        pass_fds: tuple[int, ...] = (),
        runtime: LaunchRuntime = LaunchRuntime.running(),
    ):
        """Borrow a collected result; this scope still owns child retirement.

        Launch and collection consume one absolute deadline. Consumers may deliver
        a verified response before group cleanup completes. Leaving the scope always
        joins that cleanup, including under cancellation.
        """
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("A positive finite timeout is required")
        deadline = asyncio.get_running_loop().time() + timeout
        try:
            async with asyncio.timeout_at(deadline):
                child = await AttachedChild.start(
                    command, cwd=cwd, env=env, pass_fds=pass_fds, runtime=runtime
                )
        except TimeoutError:
            raise  # A launch expiry is not evidence that user code never started.
        except FileNotFoundError as error:
            yield ChildResult(FailedToStartOutcome(str(error)))
            return
        exchange = asyncio.create_task(child.communicate(input))
        try:
            try:
                async with asyncio.timeout_at(deadline):
                    stdout, stderr = await asyncio.shield(exchange)
                    outcome = await child.wait()
            except TimeoutError:
                outcome = TimedOutOutcome(await child.stop())
                stdout, stderr = await exchange
            yield ChildResult(outcome, stdout, stderr)
        finally:
            try:
                await child.stop()
            finally:
                await join_retirement(exchange)


class SynchronousProcess(ChildProcess):
    """Identity-checked process control; each subclass supplies synchronous reaping."""

    def __init__(self, identity: ProcessIdentity):
        super().__init__(identity)
        self._retirement_lock = threading.Lock()
        self._retirement: Future[ChildOutcome] = Future()

    def require_stop_authority(self) -> None:
        """A retained parent handle already establishes stop/reap authority."""

    def force(self) -> None:
        self.platform.require(self.identity)
        super().force()

    async def stop(self) -> ChildOutcome:
        if self._stop_task is None:
            self.require_stop_authority()
        return await super().stop()

    async def _stop(self) -> ChildOutcome:
        return await join_retirement(asyncio.create_task(asyncio.to_thread(self.stop_sync)))

    @abstractmethod
    def reap(self) -> ChildOutcome: ...

    def stop_sync(self, *, guard=nullcontext, deadline=math.inf) -> ChildOutcome:
        return SynchronousProcess.stop_together(((self, guard),), deadline=deadline)[0]

    @staticmethod
    def stop_together(
        stops: Iterable[tuple[SynchronousProcess, Callable[[], AbstractContextManager[None]]]],
        *, deadline: float = math.inf,
    ) -> tuple[ChildOutcome, ...]:
        """Concurrent cleanup callers share each actual process's one retirement."""
        owned = []
        pending: list[Future[ChildOutcome]] = []
        for process, guard in stops:
            with process._retirement_lock:
                retirement = process._retirement
                if not retirement.running() and not retirement.done():
                    retirement.set_running_or_notify_cancel()
                    owned.append((process, guard, retirement))
                pending.append(retirement)
        if owned:
            try:
                outcomes = SynchronousProcess._stop_together(
                    tuple((process, guard) for process, guard, _future in owned), deadline=deadline)
            except BaseException as error:
                for _process, _guard, future in owned:
                    future.set_exception(error)
                raise
            else:
                for (_process, _guard, future), outcome in zip(owned, outcomes, strict=True):
                    future.set_result(outcome)
        collected: list[ChildOutcome] = []
        for retirement in pending:
            # A waiter borrows the original stop, not its owner's deadline.
            # wait distinguishes wait expiry from an exception stored by that owner.
            remaining = None if deadline == math.inf else max(0, deadline - time.monotonic())
            _done, unattested = wait((retirement,), timeout=remaining)
            if unattested:
                raise ChildRetirementFailed("Child retirement was not attested before deadline") from (
                    TimeoutError("The original stop owner has not completed retirement"))
            collected.append(retirement.result())
        return tuple(collected)

    @staticmethod
    def _stop_together(stops, *, deadline=math.inf) -> tuple[ChildOutcome, ...]:
        """Step every member's stop plan together: one signal pass, one shared grace, one force pass.

        Each member still runs the sole stop plan under its own guard. Expected
        identity and retirement failures are raised once every other plan has
        finished; storage, ownership and programming faults propagate immediately.
        """
        errors: list[Exception] = []
        plans = {}
        for index, (process, guard) in enumerate(stops):
            try:
                process.require_stop_authority()
            except ProcessLookupError as error:
                errors.append(error)
                continue
            plans[index] = process._stop_plan(guard, deadline)
        stages = {}
        while plans:
            waits = []
            for index, plan in tuple(plans.items()):
                try:
                    waits.append(next(plan))
                except StopIteration as done:
                    stages[index] = done.value
                    del plans[index]
                except (ProcessLookupError, ChildRetirementFailed) as error:
                    errors.append(error)
                    del plans[index]
            if waits:
                members = tuple(dict.fromkeys(
                    member for identities, _timeout in waits for member in identities
                ))
                Platform.current().wait_any_exited(
                    members, min(timeout for _identities, timeout in waits),
                )
        if errors:
            cause = errors[0] if len(errors) == 1 else ExceptionGroup("Process retirement failed", errors)
            raise ChildRetirementFailed("Child retirement was not attested") from cause
        return tuple(stages[index](process.reap()) for index, (process, _) in enumerate(stops))


class ObservedProcess(SynchronousProcess):
    """A recorded incarnation: may signal it, cannot claim a parent's exit code."""

    def require_stop_authority(self) -> None:
        self.identity = self.platform.require(self.identity)

    def reap(self) -> ChildOutcome:
        return DetachedExitOutcome()

    async def wait(self) -> ChildOutcome:
        await self.platform.wait_exited(self.identity)
        return self.reap()


class SpawnedProcess(SynchronousProcess):
    """A launched process handle; surviving the launcher does not preserve its parent."""

    def __init__(self, process: subprocess.Popen[bytes], identity: ProcessIdentity):
        super().__init__(identity)
        self.process = process

    @classmethod
    @contextmanager
    def launching(
        cls,
        command: tuple[str, ...],
        *,
        cwd: str | Path | None = None,
        env: Mapping[str, str] = INHERITED_ENVIRONMENT,
        stdio: ChildStdio = DetachedChildStdio(),
        pass_fds: tuple[int, ...] = (),
        runtime: LaunchRuntime = LaunchRuntime.running(),
        lifetime: type[ChildLifetime] = DiesWithLauncherLifetime,
    ) -> Generator[SpawnedProcess]:
        """Yield the child before it executes; leaving the body releases it, raising reaps it."""
        if not command:
            raise ValueError("A child command is required")
        with Platform.current().launch(command, pass_fds, runtime, lifetime) as launch:
            child = launch.spawn(cwd=cwd, env=env, stdio=stdio)
            try:
                yield child
            except BaseException:
                launch.cancel_before_release(child.identity)
                child.reap()
                child.close_streams()
                raise
            try:
                launch.release(child.identity)
                launch.verify()
            except BaseException:
                child.close()
                raise

    @classmethod
    def launch(cls, command: tuple[str, ...], **options: Any) -> SpawnedProcess:
        """Launch with nothing to reserve before the child executes."""
        with cls.launching(command, **options) as child:
            return child

    def collect(self, *, timeout: float) -> subprocess.CompletedProcess[bytes]:
        """Collect within the caller's owned context; its exit retires descendants."""
        stdout, stderr = self.process.communicate(timeout=timeout)
        return subprocess.CompletedProcess(self.process.args, self.process.wait(), stdout, stderr)

    @classmethod
    def run(
        cls,
        command: tuple[str, ...],
        *,
        timeout: float,
        cwd: str | Path,
        env: dict[str, str],
        runtime: LaunchRuntime = LaunchRuntime.running(),
    ) -> subprocess.CompletedProcess[bytes]:
        """A one-shot interpreter exchange, including forced descendant retirement.

        Containers use launch/collect instead: their graceful scope exit lets
        nested owners retire their own groups before the outer force pass.
        """
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("A positive finite timeout is required")
        deadline = time.monotonic() + timeout
        with cls.launch(
            command,
            cwd=cwd,
            env=env,
            runtime=runtime,
            stdio=DetachedChildStdio(stdout=subprocess.PIPE, stderr=subprocess.PIPE),
        ) as child:
            try:
                return child.collect(timeout=max(0, deadline - time.monotonic()))
            finally:
                child.platform.force_group(child.identity)

    def reap(self) -> ChildOutcome:
        """Collect the owned child's actual exit; stop grace belongs to its stop plan."""
        return ChildOutcome.from_returncode(self.process.wait())

    async def wait(self) -> ChildOutcome:
        await self.platform.wait_exited(self.identity)
        return self.reap()

    def close_streams(self) -> None:
        for stream in (self.process.stdin, self.process.stdout, self.process.stderr):
            if stream is not None:
                stream.close()

    def close(self) -> None:
        try:
            self.stop_sync()
        finally:
            self.close_streams()

    def __enter__(self) -> SpawnedProcess:
        return self

    def __exit__(self, *_):
        self.close()


class GitChildPermission:
    """An entered business operation retains its child launches through shutdown."""

    def require_open(self, closing: threading.Event) -> None:
        pass

    def stopping(self, child: SpawnedProcess) -> tuple[SpawnedProcess, ...]:
        return ()

    def completed(self) -> None:
        pass


class CancellableGitChild(GitChildPermission):
    """This exchange belongs to a declared observation or publication acquisition."""

    def __init__(self) -> None:
        self.cancelled = threading.Event()

    def require_open(self, closing: threading.Event) -> None:
        if closing.is_set():
            raise GitAcquisitionCancelled("Connector closed acquisition launches")

    def stopping(self, child: SpawnedProcess) -> tuple[SpawnedProcess, ...]:
        self.cancelled.set()
        return (child,)

    def completed(self) -> None:
        if self.cancelled.is_set():
            raise GitAcquisitionCancelled("Connector stopped this acquisition")


class GitChildren:
    """One connector's actual gated children, registered with their operation's permission."""

    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.closing = threading.Event()
        self.active: dict[SpawnedProcess, GitChildPermission] = {}

    def enter_phase(self) -> None:
        with self.lock:
            if self.closing.is_set():
                raise GitAcquisitionCancelled("Connector closed new phases")

    def register(self, child: SpawnedProcess, permission: GitChildPermission) -> None:
        with self.lock:
            permission.require_open(self.closing)
            self.active[child] = permission

    def retire(self, child: SpawnedProcess) -> None:
        # Never hold the launch lock while signalling, waiting, draining or closing streams.
        child.stop_sync(deadline=time.monotonic() + 2 * STOP_GRACE_SECONDS)
        child.close_streams()
        with self.lock:
            del self.active[child]

    @cached_property
    def _shutdown_task(self) -> asyncio.Task[tuple[ChildOutcome, ...]]:
        with self.lock:
            self.closing.set()
            stops = tuple((permitted, nullcontext)
                          for child, permission in self.active.items()
                          for permitted in permission.stopping(child))
        return asyncio.create_task(asyncio.to_thread(
            SynchronousProcess.stop_together, stops,
            deadline=time.monotonic() + 2 * STOP_GRACE_SECONDS))

    def start_shutdown(self) -> asyncio.Task[tuple[ChildOutcome, ...]]:
        return self._shutdown_task


class OwnedGitOpening(GitOpening):
    """Core's constructor capability; permission stays with the entered operation."""

    permission: type[GitChildPermission] = GitChildPermission

    def __init__(self, children: GitChildren) -> None:
        self.children = children

    def enter_phase(self) -> None:
        self.children.enter_phase()

    @contextmanager
    def acquiring(self) -> Iterator[None]:
        self.children.enter_phase()
        with AcquisitionGitOpening(self.children).bound():
            yield
            self.children.enter_phase()

    @contextmanager
    def opening(
        self, command: tuple[str, ...], *, env: Mapping[str, str], stdio: ChildStdio,
    ) -> Iterator[subprocess.Popen[bytes]]:
        permission = self.permission()
        try:
            with self.children.lock:
                permission.require_open(self.children.closing)
            with ExitStack() as cleanup:
                with SpawnedProcess.launching(
                    command, env=env, stdio=stdio,
                ) as child:
                    self.children.register(child, permission)
                    cleanup.callback(self.children.retire, child)
                yield child.process
        except ChildRetirementError:
            raise  # Failed physical retirement must never be relabelled cancellation.
        except BaseException:
            permission.completed()
            raise
        permission.completed()


class AcquisitionGitOpening(OwnedGitOpening):
    permission = CancellableGitChild


class HandedOffProcess(ObservedProcess, SpawnedProcess):
    """Keep launch streams, while observed-process behavior owns resident retirement."""

    def collect(self, *, timeout: float) -> subprocess.CompletedProcess[bytes]:
        raise ChildProcessError("A handed-off resident has no parent exit status to collect")


class PoolWorkerStopped(BaseException):
    """A pool's parent stopped; unwind owned work before the worker exits."""


class ForkedProcessPool(ExitStack, ProcessPoolExecutor, ParentLifeline):
    """Parallel work whose workers and nested child owners cannot outlive its parent."""

    def __init__(self, workers: int) -> None:
        """The caller declares the width; no default multiplies it under a parallel runner."""
        if workers < 1:
            raise ValueError("A pool needs at least one worker")
        ExitStack.__init__(self)
        ParentLifeline.__enter__(self)
        self.callback(ParentLifeline.__exit__, self)
        try:
            ProcessPoolExecutor.__init__(
                self, max_workers=workers, mp_context=multiprocessing.get_context("fork"),
                initializer=self._initialize, initargs=(self.read_fd, self.write_fd),
            )
        except BaseException:
            self.close()
            raise
        self.callback(ProcessPoolExecutor.shutdown, self)

    @staticmethod
    def _stopped(signum: int, frame: object) -> NoReturn:
        # A second notification must not interrupt the current child's retirement.
        signal.signal(signum, signal.SIG_IGN)
        raise PoolWorkerStopped()

    @classmethod
    def _initialize(cls, read_fd: int, write_fd: int) -> None:
        signal.signal(signal.SIGTERM, cls._stopped)
        os.close(write_fd)
        cls.watch(read_fd, partial(os.kill, os.getpid(), signal.SIGTERM))

    @staticmethod
    def _work[T](work: Callable[[], T]) -> T:
        try:
            return work()
        except PoolWorkerStopped:
            # ProcessPoolExecutor otherwise catches BaseException and waits for
            # another task from the dead parent. Owned scopes have now unwound.
            os._exit(1)

    def submit[T, **P](
        self, fn: Callable[P, T], /, *args: P.args, **kwargs: P.kwargs,
    ) -> Future[T]:
        return super().submit(self._work, partial(fn, *args, **kwargs))


@dataclass(frozen=True)
class DetachedExitOutcome(ChildOutcome):
    """Exit observed; a non-parent cannot claim an exit code."""

    @property
    def summary(self) -> str:
        return "exited; status unavailable"

    @property
    def successful(self) -> bool:
        return False


class ChildCommand(DeclaredFamily, affix="Command"):
    """Internal child entrypoints decode once through their declaration owner."""

    def argv(self) -> tuple[str, ...]:
        # Decode this process's private command with the same declarations that encoded it.
        return (
            str(LaunchRuntime.running().interpreter),
            "-c",
            "from agent_comms.execution.child_process import ChildCommand; ChildCommand.main()",
            json.dumps(FieldCodec.encode(self)),
        )

    @classmethod
    def main(cls) -> None:
        FieldCodec.decode(cls, json.loads(sys.argv[1])).run()

    @abstractmethod
    def run(self) -> None: ...


@dataclass(frozen=True)
class ControllingTerminalCommand(ChildCommand):
    """Acquire stdin's PTY after exec, inside the acquired child's new session."""

    command: tuple[str, ...]

    def run(self) -> None:
        fcntl.ioctl(0, termios.TIOCSCTTY, 0)
        os.execvpe(self.command[0], self.command, os.environ)
