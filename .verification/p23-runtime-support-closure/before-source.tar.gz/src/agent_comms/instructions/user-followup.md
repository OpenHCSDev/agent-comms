User follow-up:
{content}