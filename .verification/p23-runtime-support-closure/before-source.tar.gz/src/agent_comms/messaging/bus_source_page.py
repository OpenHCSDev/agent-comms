from __future__ import annotations

from dataclasses import dataclass
from typing import Self

from agent_comms.coordination.errors import IdentityConflict
from agent_comms.nominal.field_codec import FieldCodec, ThreadLookup


@dataclass(frozen=True, kw_only=True)
class SourcePage:
    after_seq: int = 0
    limit: int = 100

    def __post_init__(self) -> None:
        if self.after_seq < 0:
            raise ValueError("Source page sequence must be nonnegative")
        if not 1 <= self.limit <= 100:
            raise ValueError("Source page limit must be between 1 and 100")

    @classmethod
    def capture(cls, **values) -> Self:
        return FieldCodec.decode(cls, values)


@dataclass(frozen=True, kw_only=True)
class AddressedPage(SourcePage):
    lookup: ThreadLookup


@dataclass(frozen=True, kw_only=True)
class CoveragePage(AddressedPage):
    partial: bool = False

    def __post_init__(self) -> None:
        super().__post_init__()
        if self.after_seq and not self.partial:
            raise ValueError("Noninitial coverage page must declare partial coverage")

    def require_exhausted(self, has_more: bool) -> None:
        """An unqualified coverage request cannot accept a truncated prefix."""
        if has_more and not self.partial:
            raise IdentityConflict("source coverage exceeded its bounded private initial scan")


@dataclass(frozen=True, kw_only=True)
class CandidateQuery(SourcePage):
    recipient_lookup: ThreadLookup
    required_through_seq: int

    def __post_init__(self) -> None:
        super().__post_init__()
        if self.required_through_seq < 0:
            raise ValueError("Candidate query high-water must be nonnegative")
