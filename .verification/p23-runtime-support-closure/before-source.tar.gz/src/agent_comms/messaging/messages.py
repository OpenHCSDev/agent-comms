"""Messages: declaration and persistence owners."""

from __future__ import annotations

from agent_comms.display_references import NO_HISTORY_SOURCE, MessageHistory
from agent_comms.message_reads import MessageDeliveryRead

from agent_comms.message_send_reads import MessageReferenceRead

import builtins
import re
import sqlite3
import time
from abc import ABC, abstractmethod
from collections.abc import Callable, Iterable, Iterator, Mapping, Sequence
from contextlib import closing, contextmanager
from dataclasses import Field, dataclass, field, fields, make_dataclass, replace
from functools import cache
from inspect import get_annotations
from itertools import accumulate, batched
from typing import (
    Annotated,
    ClassVar,
    Self,
    Type,
    cast,
    dataclass_transform,
    get_origin,
)

from agent_comms.change_report import NoChangeReport, ReportEvidence, SourceRoots
from agent_comms.class_fact import ClassFact
from agent_comms.coordination.errors import IdentityConflict
from agent_comms.envelope_claim_transitions import (
    ClaimOwner,
    ClaimProducer,
    ClaimProjection,
    ClaimTransition,
    ClaimTransitionError,
    ResourceClaim,
    UnclaimedResource,
)
from agent_comms.errors import RelationViolationError
from agent_comms.execution.turn_origin import TurnOrigin
from agent_comms.input_key import InputKey
from agent_comms.mentions import ThreadMention
from agent_comms.message_clock_source import MessageClockSource
from agent_comms.message_sender import PublicSender
from agent_comms.messaging.channel_targets import CommandTarget, ThreadTarget
from agent_comms.messaging.message_reference import MessageReference
from agent_comms.nominal.declared_family import DeclaredFamily
from agent_comms.nominal.field_codec import (
    ClaimId,
    FieldCodec,
    InlineRecord,
    MessageId,
    NullMember,
    PublicationExclude,
    ThreadLookup,
    WireExclude,
    WireName,
    WireOmitDefault,
    WireOrder,
    compile_decoder,
    projected,
)
from agent_comms.page_traversal import LiveCursor, PageCursor
from agent_comms.projection_source import ProducedRow, ProjectionOutputs, ProjectionSource
from agent_comms.registry.thread_creation import ThreadCreationSource
from agent_comms.registry.thread_identity import AgentThreadRole, ThreadRole
from agent_comms.response_message_source import ResponseMessageSource
from agent_comms.response_policy import (
    NO_ALIASES,
    InformationalPolicy,
    ResponseEligibility,
    ResponsePolicy,
)
from agent_comms.storage.typed_table import (
    LOCAL_TABLE_SOURCE,
    AppendOnlyTables,
    Column,
    DerivedTables,
    DurableTables,
    ForeignKey,
    Index,
    ProducedTable,
    SharedFileTables,
    TableReference,
    TableSource,
    TypedRow,
    TypedTable,
)
from agent_comms.task_sources import (
    NoTaskAttachment,
    TaskAttachment,
)
from agent_comms.thread_identity_source import ThreadIdentitySource
from agent_comms.transport.progress import InterruptibleRead
from agent_comms.ui_model.message_category import InboundCategory, MessageCategory, OtherCategory
from agent_comms.wake_policy import BoundedTriageWake, PassiveWake



class BusTables(TypedTable, AppendOnlyTables, SharedFileTables, DurableTables, declared_name=None):
    """Bus history cannot be rebuilt from another source."""


class BusProjectionTables(ProducedTable, SharedFileTables, DerivedTables, declared_name=None):
    """Reverse lookups are derived from the record, in its append transaction."""

    @classmethod
    def changed_rows(
        cls, db: sqlite3.Connection, sharing: tuple[type[TypedTable], ...] = (),
    ) -> tuple[type[TypedTable], ...]:
        changed = set(super().changed_rows(db, sharing))
        coupled = frozenset(row for row in cls.projection_rows() if row in ClaimTransition.writes)
        if changed.intersection(coupled):
            changed.update(coupled)
        return tuple(row for row in cls.schema_rows() if row in changed)

    @classmethod
    def rebuild_rows(cls, db: sqlite3.Connection, rows: tuple[type[TypedTable], ...]) -> None:
        """Rebuild from history after the schema creates the selected empty tables."""
        ReplayedHolders(tables=frozenset(rows)).replay(db)

    @classmethod
    def replay(
        cls, db: sqlite3.Connection, rows: tuple[type[TypedTable], ...], *, after: int,
    ) -> None:
        StoredHolders(tables=frozenset(rows)).replay(db, after=after)


@dataclass(frozen=True)
class BusRow(BusTables):
    seq: Annotated[int, Column(primary_key=True, auto_increment=True)]
    kind: type[BusRecord]
    at: float

    @classmethod
    def last_seq(cls, db: sqlite3.Connection, *,
                 table_source: TableSource = LOCAL_TABLE_SOURCE) -> int:
        return FieldCodec.decode(int, db.execute(
            cls._sql(f'SELECT COALESCE(MAX({{seq}}), 0) FROM {table_source.qualified(cls.declared_name)}')
        ).fetchone()[0])

    @classmethod
    def next_seq(cls, db: sqlite3.Connection) -> int:
        return FieldCodec.decode(int, db.execute(
            "SELECT COALESCE((SELECT seq FROM sqlite_sequence WHERE name=?), 0) + 1",
            (cls.declared_name,),
        ).fetchone()[0])


@dataclass(frozen=True)
class TeamUpdatePosition(BusProjectionTables, declared_name="team_update_position"):
    """Where each typed teammate packet sits, by the teammate birth it addresses. A rebuildable
    search projection: the packet's content stays on its original message's task."""

    seq: Annotated[int, Column(primary_key=True, references=TableReference(BusRow, ("seq",)))]
    teammate_lookup: ThreadLookup
    indexes = (Index(("teammate_lookup", "seq")),)

    @classmethod
    def latest(cls, db: sqlite3.Connection, recipient: ThreadLookup) -> tuple[BusRecord, ...]:
        """The newest packet for that teammate through the covering index, decoded from its one
        original record; a teammate with no packet has none."""
        positions = db.execute(
            cls._sql(f'SELECT {{seq}} FROM "{cls.declared_name}" WHERE {{teammate_lookup}}=? '
                     'ORDER BY {seq} DESC LIMIT 1'),
            (FieldCodec.encode(recipient),))
        headers = (BusRow.require(db, seq=FieldCodec.decode(int, seq)) for seq, in positions)
        return tuple(header.kind.read_from(db, header.seq) for header in headers)


@dataclass(frozen=True)
class EscalationPosition(BusProjectionTables):
    """Where each escalation line sits, by the teammate birth it addresses and when it was sent.
    It shares the owner's thread with every message he types, so this rebuildable projection, not
    the sender, finds a burst; which burst a line belongs to stays on its original message's task."""

    seq: Annotated[int, Column(primary_key=True, references=TableReference(BusRow, ("seq",)))]
    teammate_lookup: ThreadLookup
    at: float
    indexes = (Index(("teammate_lookup", "at")),)

    @classmethod
    def sent(cls, db: sqlite3.Connection, recipient: ThreadLookup, since: float,
             before: float) -> tuple[BusRecord, ...]:
        """Every escalation line to that teammate birth in [since, before], newest first."""
        positions = db.execute(
            cls._sql(f'SELECT {{seq}} FROM "{cls.declared_name}" WHERE {{teammate_lookup}}=? '
                     'AND {at} >= ? AND {at} <= ? ORDER BY {seq} DESC'),
            (FieldCodec.encode(recipient), since, before))
        headers = (BusRow.require(db, seq=FieldCodec.decode(int, seq)) for seq, in positions)
        return tuple(header.kind.read_from(db, header.seq) for header in headers)


@dataclass(frozen=True)
class ClaimOperations(BusProjectionTables):
    """An acquisition's consumed operation refers to its original claim row."""

    operation_id: Annotated[ClaimId, Column(primary_key=True)]
    seq: int

    @classmethod
    def references(cls) -> tuple[ForeignKey, ...]:
        return (ForeignKey(columns=("seq",), target=Claimed.table, target_columns=("seq",)),)

    @classmethod
    def used(cls, db: sqlite3.Connection, operation_id: ClaimId) -> bool:
        return cls.exists(db, where="{operation_id} = ?", parameters=(operation_id,))


@dataclass(frozen=True)
class HeldResources(ClaimProducer, BusProjectionTables):
    """Current membership references the canonical transition, never a copy."""

    resource: Annotated[str, Column(primary_key=True)]
    claim_seq: int

    @classmethod
    def references(cls) -> tuple[ForeignKey, ...]:
        return (ForeignKey(columns=("claim_seq",), target=Claimed.table, target_columns=("seq",)),)

    @classmethod
    def owner_for(cls, db: sqlite3.Connection, resource: str) -> ResourceClaim:
        originals = Claimed.table.select(
            db, where=f'{{seq}}=(SELECT claim_seq FROM "{cls.declared_name}" WHERE resource=?)',
            parameters=(resource,), row_type=Claimed,
        )
        return next((row.claim_transition.claimed(resource) for row in originals), UnclaimedResource())

    @classmethod
    def all_claims(cls, db: sqlite3.Connection) -> ClaimProjection:
        return cls._project(db, cls.select(db), BusRow.last_seq(db))

    @classmethod
    def claims_for(
        cls, db: sqlite3.Connection, resources: tuple[str, ...], through: int,
    ) -> ClaimProjection:
        marks = ",".join("?" for _ in resources)
        return cls._project(db, cls.select(
            db, where=f'{{resource}} IN ({marks})', parameters=resources,
        ), through)

    @classmethod
    def _project(
        cls, db: sqlite3.Connection, current: list[HeldResources], through: int,
    ) -> ClaimProjection:
        claim_table = Claimed.table
        last_seq = FieldCodec.decode(int, db.execute(claim_table._sql(
            f'SELECT COALESCE(MAX({{seq}}), 0) FROM "{claim_table.declared_name}" WHERE {{seq}} <= ?'
        ), (through,)).fetchone()[0])
        sequences = tuple({row.claim_seq for row in current})
        marks = ",".join("?" for _ in sequences)
        transitions = {row.claim_transition.seq: row.claim_transition for row in claim_table.select(
            db, where=f'{{seq}} IN ({marks})', parameters=sequences, row_type=Claimed,
        )}
        return ClaimProjection(last_seq, {
            row.resource: transitions[row.claim_seq].claimed(row.resource) for row in current
        })

    @classmethod
    def project(
        cls, db: sqlite3.Connection, transition: ClaimTransition, holders: ClaimHolders,
    ) -> ClaimProjection:
        """Validate before the original is inserted; the caller retains the writer."""
        try:
            transition.require_new_operation(lambda operation: holders.operation_used(db, operation))
            return transition.project(holders.before(db, transition))
        except (ClaimTransitionError, IdentityConflict) as error:
            raise RelationViolationError("Committed claim transition is inconsistent.") from error


@dataclass
class ProjectionPass(ABC, ProjectionSource):
    """A projection pass writes only its selected tables."""

    tables: frozenset[type[TypedTable]] = field(
        default_factory=lambda: frozenset(BusProjectionTables.schema_rows()))

    @ClassFact
    def writes(cls) -> tuple[type[ProducedRow], ...]:
        return BusProjectionTables.projection_rows()

    def write(self, db: sqlite3.Connection, row: TypedTable) -> None:
        if type(row) in self.tables:
            self.store(db, row)

    def store(self, db: sqlite3.Connection, row: TypedTable) -> None:
        row.insert(db)

    def flush(self, db: sqlite3.Connection) -> None:
        """Rows written at once leave nothing to flush."""


class ClaimHolders(ProjectionPass):
    """The current holders a claim transition projects from, before it is applied."""

    def replay(self, db: sqlite3.Connection, *, after: int = 0) -> None:
        projections = tuple(row for row in BusProjectionTables.projection_rows()
                            if row in self.tables)
        writers = {writer for row in projections for writer in ProjectionSource.writers_for(row)}
        kinds = tuple(kind for kind in BusRecord.members_with(BusRecord) if kind in writers)
        for record in BusCapability.history(db, kinds, after=after):
            record.project_into(db, self)
        self.flush(db)

    def project(self, db: sqlite3.Connection, transition: ClaimTransition) -> None:
        if self.tables.intersection(ClaimTransition.writes):
            projected = HeldResources.project(db, transition, self)
            self.apply(db, transition, projected)

    @abstractmethod
    def before(self, db: sqlite3.Connection, transition: ClaimTransition) -> ClaimProjection: ...

    def operation_used(self, db: sqlite3.Connection, operation: ClaimId) -> bool:
        return ClaimOperations.used(db, operation)

    def apply(
        self, db: sqlite3.Connection, transition: ClaimTransition, projected: ClaimProjection,
    ) -> None:
        removed = transition.resources + transition.expired
        marks = ",".join("?" for _ in removed)
        HeldResources.delete(db, where=f'{{resource}} IN ({marks})', parameters=removed)
        for owner in projected.values():
            self.write(db, HeldResources(owner.resource, owner.seq))
        for operation_id in transition.operation_ids:
            self.write(db, ClaimOperations(operation_id, transition.seq))
        self.advance(removed, projected)

    def advance(self, removed: tuple[str, ...], projected: ClaimProjection) -> None:
        """Held rows already record the applied transition."""


class StoredHolders(ClaimHolders):
    """One append reads the holders of its resources from their table."""

    def before(self, db: sqlite3.Connection, transition: ClaimTransition) -> ClaimProjection:
        return HeldResources.claims_for(db, transition.resources, transition.seq - 1)


@dataclass
class ReplayedHolders(ClaimHolders):
    """An in-order rebuild carries the holders it already projected; it never rereads them.

    Each owner was validated in the projection that produced it; only the subset a
    transition projects from is validated again, as one ``ClaimProjection``.
    """

    last_seq: int = 0
    owners: dict[str, ClaimOwner] = field(default_factory=dict)
    operations: set[ClaimId] = field(default_factory=set)
    rows: dict[str, list[tuple]] = field(default_factory=dict)
    """Derived rows by insert statement; nothing in the rebuild reads them back before
    ``flush``, which inserts each statement's rows with one ``executemany``."""

    def store(self, db: sqlite3.Connection, row: TypedTable) -> None:
        statement, values = row.insertion()
        self.rows.setdefault(statement, []).append(values)

    def apply(
        self, db: sqlite3.Connection, transition: ClaimTransition, projected: ClaimProjection,
    ) -> None:
        for operation_id in transition.operation_ids:
            self.write(db, ClaimOperations(operation_id, transition.seq))
        self.operations.update(transition.operation_ids)
        self.advance(transition.resources + transition.expired, projected)

    def operation_used(self, db: sqlite3.Connection, operation: ClaimId) -> bool:
        return operation in self.operations

    def flush(self, db: sqlite3.Connection) -> None:
        for owner in self.owners.values():
            self.write(db, HeldResources(owner.resource, owner.seq))
        for statement, values in self.rows.items():
            db.executemany(statement, values)
        self.rows.clear()

    def before(self, db: sqlite3.Connection, transition: ClaimTransition) -> ClaimProjection:
        return ClaimProjection(self.last_seq, {
            resource: self.owners[resource]
            for resource in transition.resources if resource in self.owners})

    def advance(self, removed: tuple[str, ...], projected: ClaimProjection) -> None:
        for resource in removed:
            self.owners.pop(resource, None)
        self.owners.update(projected)
        self.last_seq = projected.last_seq


@dataclass(frozen=True)
class CapabilityRow(BusTables, declared_name=None):
    """Every generated capability row belongs to one original bus sequence."""

    seq: Annotated[int, Column(primary_key=True, references=TableReference(BusRow, ("seq",)))]


class _CapabilityTable(ProjectionSource):
    """A class's table is derived once, after its dataclass decorator has run."""

    def __get__(self, instance: BusCapability | None, owner: type[BusCapability]) -> type[CapabilityRow]:
        return self.for_class(owner)

    @cache
    def for_class(self, owner: type[BusCapability]) -> type[CapabilityRow]:
        hints = FieldCodec._types(owner)
        return make_dataclass(
            BusTables.__name__.removesuffix("Tables") + owner.__name__ + "Row",
            [*((item.name, hints[item.name], item) for item in BusCapability.declared_fields(owner)),
             *((name, hints[name], vars(owner)[name]) for name in get_annotations(owner)
               if get_origin(hints[name]) is ClassVar and name in vars(owner))],
            bases=(CapabilityRow,),
            namespace={"__module__": owner.__module__},
            frozen=True,
        )


@dataclass(frozen=True)
class BusCapability(TypedRow, ProjectionSource):
    """The hierarchy and each dataclass declaration own their table union."""

    table = _CapabilityTable()

    def deliveries(self) -> tuple[MessageDeliveryRead[Message], ...]:
        return ()

    @classmethod
    def declared_fields(cls, owner: type[BusCapability]) -> tuple[Field, ...]:
        own = get_annotations(owner)
        header_fields = {item.name for item in fields(BusRow)}
        return tuple(item for item in fields(owner)
                     if item.name in own and item.name not in header_fields)

    @classmethod
    @cache
    def tables(cls) -> tuple[type[CapabilityRow], ...]:
        return tuple(base.table for base in cls.__mro__
                     if issubclass(base, BusCapability) and BusCapability.declared_fields(base))

    @classmethod
    def render(cls, expression: str) -> str:
        """Render {field} selectors through every capability table this declaration inherits,
        so a field moved between capabilities never edits the statements that select it. A
        selector no table declares is refused, never sent to SQLite as text."""
        for table in cls.tables():
            expression = table._sql(expression)
        if unresolved := re.findall(r"\{(\w+)\}", expression):
            raise ValueError(f"{cls.__name__} declares no field {sorted(set(unresolved))}")
        return expression

    def rows(self) -> tuple[CapabilityRow, ...]:
        """Project declared Python fields without flattening their wire representations."""
        return tuple(
            FieldCodec.construct(table, {
                item.name: getattr(self, item.name) for item in fields(table)
            })
            for table in self.tables())

    @classmethod
    def read_from(cls, db: sqlite3.Connection, seq: int) -> Self:
        """Reconstruct this declared value from its own capability tables."""
        rows = []
        for table in cls.tables():
            stored = table.select(db, seq=seq)
            if not stored:
                raise RelationViolationError(f"Bus row {seq} lacks {table.declared_name}")
            rows.append(stored[0])
        return cls.assembled(rows)

    @classmethod
    def assembled(cls, rows: Iterable[CapabilityRow]) -> Self:
        """This declared value from one stored row of each of its capability tables."""
        return FieldCodec.construct(cls, {
            item.name: getattr(row, item.name) for row in rows for item in type(row)._fields})

    @staticmethod
    def history(
        db: sqlite3.Connection, kinds: tuple[type[BusRecord], ...] | None = None,
        *, after: int = 0,
    ) -> Iterator[BusCapability]:
        """Records after one sequence, using the same joined cursor for full and tail replay."""
        header = BusRow.qualified("seq")
        predicate, parameters = ("", ()) if kinds is None else (
            f' AND {BusRow.qualified("kind")} IN ({", ".join("?" for _ in kinds)})',
            tuple(BusRow._fields_named(("kind",))[0].encode(kind) for kind in kinds),
        )
        return (record for _, record in BusCapability.stored_records(
            db, f"{header}>?" + predicate + f" ORDER BY {header}", (after, *parameters)))

    @staticmethod
    def public_messages(
        db: sqlite3.Connection, sequences: Iterable[int], page: int = 100,
    ) -> Iterator[Message]:
        """The public messages of these ascending records, assembled one joined page at a time."""
        for chunk in batched(sequences, page):
            for record in BusCapability.at_sequences(db, chunk):
                for message in record.messages():
                    yield Message.from_message(message)

    @staticmethod
    def at_sequences(db: sqlite3.Connection, sequences: tuple[int, ...]) -> tuple[BusRecord, ...]:
        """Exactly these records, in the given order, from one joined read; a sequence with no
        stored row is refused, as a single lookup refuses it."""
        if not sequences:
            return ()
        header = BusRow.qualified("seq")
        found = {row.seq: record for row, record in BusCapability.stored_records(
            db, f"{header} IN ({','.join('?' for _ in sequences)})", sequences)}
        if missing := [seq for seq in sequences if seq not in found]:
            raise RelationViolationError(f"Unknown bus sequences: {missing}")
        return tuple(found[seq] for seq in sequences)

    @staticmethod
    def stored_records(
        db: sqlite3.Connection, where: str, parameters: tuple[object, ...],
    ) -> Iterator[tuple[BusRow, BusRecord]]:
        """Each selected header with the record its capability rows assemble, decoded once."""
        tables = TypedTable.members_with(CapabilityRow)
        offsets = dict(zip(tables, accumulate(
            (len(BusRow.columns()), *(len(table.columns()) for table in tables)))))
        header = BusRow.qualified("seq")
        columns = [BusRow.qualified(*BusRow.column_projection())]
        columns.extend(table.qualified(*table.column_projection()) for table in tables)
        with closing(db.execute(
            f"SELECT {', '.join(columns)} "
            f'FROM "{BusRow.declared_name}" '
            + " ".join(f'LEFT JOIN "{table.declared_name}" ON {table.qualified("seq")} = {header}'
                       for table in tables)
            + f" WHERE {where}",
            parameters,
        )) as cursor:
            for stored in cursor:
                row = BusRow.decode_at(stored, 0)
                yield row, row.kind.assembled(
                    table.decode_at(stored, offsets[table]) for table in row.kind.tables())

    def projections(self) -> Iterator[TypedTable]:
        return iter(())

    def project_into(self, db: sqlite3.Connection, holders: ClaimHolders) -> None:
        for row in self.projections():
            holders.write(db, row)


@dataclass(frozen=True)
class Addressed(BusCapability):
    sender: Annotated[str, WireName("from"), WireOrder(2)]
    target: Annotated[str, WireName("to"), WireOrder(3), Column(index=True)]
    indexes: ClassVar[tuple[Index, ...]] = (Index(("sender", "target", "seq")),)


class MessageRoutes(ProjectionOutputs):
    """The rows a message kind routes; send-time validation produces none."""

    __slots__ = ()

    @ClassFact
    def writes(cls) -> tuple[type[ProducedRow], ...]:
        from agent_comms.bus_tables import AwaitingAnswerSource
        from agent_comms.messaging.bus_route_counts import BusRouteCounts, BusRouteKeys
        return (BusRouteCounts, BusRouteKeys, AwaitingAnswerSource)

    conversation_message: ClassVar[bool] = True

    @classmethod
    def route_rows(cls, message):
        from agent_comms.messaging.bus_route_counts import BusRouteCounts, BusRouteKeys

        return (BusRouteCounts.from_message(message), BusRouteKeys.from_message(message))


class MessageKind(DeclaredFamily, MessageRoutes, ProjectionSource, affix="Kind"):
    """A declared message kind; each member owns the validation it requires.

    Members are the kind themselves, never instances: the wire carries the
    plain declared name (``"type": "info"``), exactly as the previous enum
    stored it. Publication-time checks run once, from the single commit path.
    """

    @classmethod
    def decode_message(cls, data: Mapping) -> Message:
        return FieldCodec.decode(Message, data)

    @classmethod
    def require_sendable(cls) -> None:
        if not issubclass(cls, SendableMessageKind):
            raise ValueError(f"Message kind {cls.declared_name!r} is not generically sendable")

    @classmethod
    def require_publishable(cls, message: Message, roots: SourceRoots) -> None:
        """Checks a send must pass before publication; base kinds declare none."""

    @classmethod
    def allows_automatic_reply(cls, message: Message) -> bool:
        """Human inputs need a reply even when their committed kind is informational."""
        return message.sender_role.allows_automatic_reply()


class SendableMessageKind(MessageKind, declared_name=None):
    """The declared kinds accepted by generic message commands."""


class ClaimNoticeKind(MessageKind, declared_name="claim-notice"):
    """A claim-owner record, not a delivery to a reader."""

    conversation_message = False

    @classmethod
    def route_rows(cls, message):
        return ()

    @classmethod
    def decode_message(cls, data: Mapping) -> Message:
        return FieldCodec.decode(ClaimMessage, data)

    @classmethod
    def claimed(cls, owner: ThreadIdentitySource) -> Message:
        return Message(
            owner.name, owner.name, "Claimed", cls,
        )


class ClaimHistoryKind(ClaimNoticeKind, declared_name="claim-history"):
    """A copied claim notice has display facts, not a live claim envelope."""

    @classmethod
    def decode_message(cls, data: Mapping) -> Message:
        return FieldCodec.decode(Message, data)


class InfoKind(SendableMessageKind):
    @classmethod
    def decode_message(cls, data: Mapping) -> Message:
        """Committed info rows include the original claim-bearing envelopes."""
        return cast(Message, compile_decoder(Message | ClaimMessage).decode(data))


class NeedsAnswerKind(SendableMessageKind, declared_name=None):
    """Questions, alerts and handoffs ask their recipient to act."""

    @classmethod
    def allows_automatic_reply(cls, message: Message) -> bool:
        return True


class QuestionKind(NeedsAnswerKind):
    pass


class AckKind(SendableMessageKind):
    pass


class HandoffKind(NeedsAnswerKind):
    """Ask the recipient to act; typed goal and order actions own completion."""


class AlertKind(NeedsAnswerKind):
    pass


class ChangeReportKind(SendableMessageKind, declared_name="change-report"):
    """A review request declares each touched fact with its single owner."""

    @classmethod
    def require_publishable(cls, message: Message, roots: SourceRoots) -> None:
        message.report.require_references_exist(roots)


class RoleActivitySource(ProjectionSource):
    """A message's role and membership write its sender's activity and its awaited answers."""

    __slots__ = ()

    @ClassFact
    def writes(cls) -> tuple[type[ProducedRow], ...]:
        from agent_comms.bus_activity_index import SentActivity
        from agent_comms.bus_tables import AwaitingAnswerSource
        return (SentActivity, AwaitingAnswerSource)


class MembershipTransition(DeclaredFamily, RoleActivitySource, affix="Membership"):
    @classmethod
    def conversation_role(cls) -> MembershipConversationRole:
        return MembershipConversationRole(cls)

    @classmethod
    def between(cls, previous: bool, current: bool) -> tuple[type[MembershipTransition], ...]:
        return tuple(member for member in cls.members_with(cls) if member.applies(previous, current))

    @staticmethod
    @abstractmethod
    def applies(previous: bool, current: bool) -> bool: ...


class JoinedMembership(MembershipTransition):
    @staticmethod
    def applies(previous: bool, current: bool) -> bool:
        return not previous and current


class LeftMembership(MembershipTransition):
    @staticmethod
    def applies(previous: bool, current: bool) -> bool:
        return previous and not current


@dataclass(frozen=True, slots=True)
class NoMembershipChange(NullMember, RoleActivitySource):

    def conversation_role(self):
        return ConversationRole()


@dataclass(frozen=True, slots=True)
class MessageRoleWire(RoleActivitySource):
    """The unchanged external fields, decoded once into a message role."""

    change: Annotated[
        type[MembershipTransition] | NoMembershipChange,
        WireName("membership"),
        WireOmitDefault(),
    ] = field(default_factory=NoMembershipChange)
    notice: Annotated[bool, WireOmitDefault()] = False

    def role(self):
        role = self.change.conversation_role()
        return role.as_notice() if self.notice else role

    @classmethod
    def notice_key(cls) -> str:
        """The stored key of the notice flag, read from the field that declares it."""
        declared, = (field for field in fields(cls) if field.name == "notice")
        return WireName.read(declared.type, declared.name)


class MessageRole(InlineRecord, RoleActivitySource):

    category: ClassVar[type[MessageCategory]]

    @classmethod
    def stored_conversations(cls) -> str:
        """Selects stored rows whose role counts as a conversation, over a `{role}` selector.

        A role is stored as the wire object `MessageRoleWire` writes, so the notice flag it
        records is what separates a conversation from a notice; a membership change keeps
        counting as one. A reader that wants only conversations asks for this instead of
        decoding every row to call `counts_as_conversation`.
        """
        return (f"COALESCE(json_extract({{role}}, "
                f"'$.{MessageRoleWire.notice_key()}'), 0) = 0")

    @abstractmethod
    def response_policy(self, message: MessageInput) -> ResponsePolicy: ...

    @abstractmethod
    def as_historical(self) -> MessageRole: ...

    @classmethod
    def wire_record(cls):
        return MessageRoleWire

    @classmethod
    def from_wire(cls, data):
        return FieldCodec.decode(MessageRoleWire, data).role()

    def to_wire(self):
        return FieldCodec.encode_record(self.wire_fields())

    def notification_references(self, message):
        return ()

    def response_wake_mode(self):
        return BoundedTriageWake()

    def as_notice(self):
        return NoticeRole()

    def require_recipients(self, target, audience):
        if len(audience.recipients) != len(target.direct_names):
            raise ValueError("a direct message must have exactly one frozen eligible recipient.")
        if tuple(member.canonical_thread for member in audience.recipients) != target.direct_names:
            raise ValueError("direct frozen recipient must match the exact stored target.")


class SendableRole(MessageRole, DeclaredFamily, affix="Role"):
    pass


class InformationalMessage(RoleActivitySource):

    def response_policy(self, message: MessageInput) -> ResponsePolicy:
        return InformationalPolicy.instance()

    def counts_as_conversation(self):
        return False

    def activity_rows(self, message):
        return ()

    def wake_mode(self, target, recipient, mentions, control):
        return PassiveWake()


class ConversationActivity(ProjectionSource):
    """Conversation activity owns its rows independently of reply eligibility."""

    @ClassFact
    def writes(cls) -> tuple[type[ProducedRow], ...]:
        from agent_comms.bus_activity_index import SentActivity
        return (SentActivity,)

    def activity_rows(self, message: Message) -> tuple[TypedTable, ...]:
        from agent_comms.bus_activity_index import SentActivity

        return (SentActivity(message.sender, message.timestamp),)


@dataclass(frozen=True, slots=True)
class ConversationRole(ConversationActivity, SendableRole):

    category = InboundCategory

    def wire_fields(self):
        return MessageRoleWire()

    def export_attributes(self):
        return ()

    def counts_as_conversation(self):
        return True

    def as_historical(self):
        return HistoricalConversationRole()

    def response_policy(self, message: MessageInput) -> ResponsePolicy:
        return (CommandTarget.named(message.target).response_policy(message)
                if message.type.conversation_message else InformationalPolicy.instance())

    def notification_references(self, message):
        return (message.reference,) if message.type.conversation_message else ()

    def wake_mode(self, target, recipient, mentions, control):
        return control.wake_mode(target, recipient, mentions)


@dataclass(frozen=True, slots=True)
class NoticeRole(InformationalMessage, SendableRole):
    category = OtherCategory

    def wire_fields(self):
        return MessageRoleWire(notice=True)

    def export_attributes(self):
        return ("notice=true",)

    def as_historical(self):
        return HistoricalNoticeRole()

    def response_wake_mode(self):
        return PassiveWake()

    def require_recipients(self, target, audience):
        if audience.recipients:
            super(NoticeRole, self).require_recipients(target, audience)


@dataclass(frozen=True)
class Membership(InformationalMessage):
    change: type[MembershipTransition]

    def wire_fields(self):
        return replace(super().wire_fields(), change=self.change)

    def export_attributes(self):
        return (*super().export_attributes(), f"membership={self.change.declared_name}")

    def as_notice(self):
        return MembershipNoticeRole(self.change)


@dataclass(frozen=True, slots=True)
class MembershipConversationRole(Membership, ConversationRole, declared_name=None):
    def as_historical(self):
        return HistoricalMembershipConversationRole(self.change)


@dataclass(frozen=True, slots=True)
class MembershipNoticeRole(Membership, NoticeRole, declared_name=None):
    def as_historical(self):
        return HistoricalMembershipNoticeRole(self.change)


class HistoricalRole:
    """Historical rows cannot create current reply or notification work."""

    def notification_references(self, message):
        return ()

    def response_policy(self, message: MessageInput) -> ResponsePolicy:
        return InformationalPolicy.instance()

    def as_historical(self):
        return self

    def as_notice(self):
        return super().as_notice().as_historical()


class HistoricalConversationRole(HistoricalRole, ConversationRole, declared_name=None):
    pass


class HistoricalNoticeRole(HistoricalRole, NoticeRole, declared_name=None):
    pass


class HistoricalMembershipConversationRole(
    HistoricalRole, MembershipConversationRole, declared_name=None):
    pass


class HistoricalMembershipNoticeRole(HistoricalRole, MembershipNoticeRole, declared_name=None):
    pass


@dataclass(frozen=True, slots=True)
class MessageInput(MessageClockSource, Addressed, BusCapability, ResponseMessageSource):
    """The facts an input is keyed and written from: who, where, what text, which role.

    Attachments, reports and answers belong to Message; this is never a whole message
    and carries no content identity.
    """

    body: Annotated[str, WireName("text"), WireOrder(6)]
    type: Annotated[builtins.type[MessageKind], WireOrder(5)]
    timestamp: Annotated[float, WireName("ts"), WireOrder(4), Column(index=True)] = (
        field(default_factory=time.time)
    )
    seq: Annotated[int, WireOrder(0), PublicationExclude()] = (
        0
    )
    sender_role: Annotated[
        Type[ThreadRole], WireOrder(7), PublicationExclude()
    ] = AgentThreadRole
    role: Annotated[MessageRole, WireOrder(8)] = field(
        default_factory=ConversationRole
    )
    mentions: Annotated[
        tuple[ThreadMention, ...],
        WireOmitDefault(),
        WireOrder(10),
        PublicationExclude(),
    ] = ()

    def bus_key(self, owner: ThreadCreationSource) -> InputKey:
        return self.role.response_policy(self).disposition_key(self, owner)

    @property
    def sender_label(self) -> str:
        """Who sent this as its reader sees it: the thread and what kind of sender it is."""
        return f"{self.sender} ({self.sender_role.origin_label})"


@dataclass(frozen=True, slots=True)
class Message(MessageInput, TurnOrigin['Message'], MessageReferenceRead):
    """Declares one inter-thread message.

    The bus assigns ``seq`` (a monotonically increasing log position) at send
    time; the hash-derived ``message_id`` is identity only and is not ordered.
    """

    task: Annotated[
        TaskAttachment, WireOmitDefault(), WireOrder(12)
    ] = field(default_factory=NoTaskAttachment)
    report: Annotated[
        ReportEvidence, WireOmitDefault(), WireOrder(13), Column(nullable=True)
    ] = NoChangeReport()
    answers: Annotated[
        tuple[MessageReference, ...], WireOmitDefault(), WireOrder(14)
    ] = ()

    def require_answers(self, db: sqlite3.Connection) -> None:
        """Validate public references once, before appending their sequence-only projection."""
        from agent_comms.bus_tables import MessageIdentitySource

        MessageIdentitySource.require_references(db, self.answers)

    @classmethod
    def from_message(cls, message: Message, **capabilities: object) -> Self:
        return FieldCodec.construct(cls, {
            **{item.name: getattr(message, item.name) for item in fields(message)
               if item.name in {target.name for target in fields(cls)}},
            **capabilities,
        })

    @property
    def message(self) -> Self:
        return self

    @classmethod
    def envelope_type(cls) -> builtins.type[Message]:
        """The public message declaration this class's values carry."""
        return Message

    @property
    def envelope(self) -> Message:
        return self

    def require_envelope(self) -> None:
        pass

    def messages(self) -> tuple[Self, ...]:
        return (self,)

    @property
    def text_size(self) -> int:
        return len(self.body)

    @property
    def publication_snapshot(self) -> Message:
        """Frozen publication content before independently owned delivery enrichment.

        Sequence, role, resolved mentions and claim evidence are assigned by the
        bus. Their declarations exclude them from publication content identity;
        all other declared fields participate in the Message value comparison.
        This is an in-memory snapshot, never a different wire representation.
        """
        return replace(
            self,
            **{
                plan.name: plan.declared.default
                for plan in FieldCodec.field_plans(type(self))
                if plan.setting(PublicationExclude, False)
            },
        )

    @property
    def reference(self) -> MessageReference:
        return MessageReference(self.seq, self.message_id)

    @property
    def category(self) -> type[MessageCategory]:
        """The filter category this message files under, answered by what it carries."""
        return self.task.category(self.role.category)

    def require_task_publication(self, sender, snapshot, original_source) -> None:
        self.task.require_target(self.target, snapshot)
        self.task.require_publication(sender, snapshot, original_source)

    @property
    def history_snapshot(self) -> Message:
        """Retain display facts, never another root's resource-claim authority."""
        return self

    def require_claim_transition(self) -> ClaimTransition:
        raise RelationViolationError("Message has no claim transition")

    def retained_task_facts(self):
        source = Message.from_message(self)
        yield from self.sender_role.user_task_facts(source)
        yield from self.task.retained_task_facts(source)

    def __post_init__(self) -> None:
        if not self.sender:
            raise RelationViolationError("Message sender cannot be empty.")
        if not self.target:
            raise RelationViolationError("Message target cannot be empty.")
        if not self.body:
            raise ValueError("Message body cannot be empty.")
        self.task.require_sender(self.sender)
        if any(
            not (0 <= mention.start < mention.end <= len(self.body))
            or self.body[mention.start] != "@"
            for mention in self.mentions
        ):
            raise ValueError("Mention ranges must identify text in the message body.")
        CommandTarget.named(self.target).validate(self)

    @property
    def view_cursor(self) -> PageCursor:
        return LiveCursor(self.seq)

    @property
    def view_key(self) -> tuple[str, int]:
        return "", self.seq

    @property
    def view_order(self) -> tuple[int, int, int]:
        return 1, 0, self.seq

    @projected(view=WireExclude, name="id")
    def message_id(self) -> MessageId:
        return MessageId.mint(f"{self.sender}:{self.target}:{self.timestamp}:{self.body}")

    @property
    def history_source(self) -> MessageHistory:
        """A live message was recorded by no attached history."""
        return NO_HISTORY_SOURCE

    @property
    def display_metadata(self) -> dict:
        """Live messages carry no historical provenance decoration."""
        return {}

    @classmethod
    def stored_wire_query(cls, db: sqlite3.Connection, identity: type[TypedTable]) -> str:
        """Project the public envelope from its declared stored fields, not domain objects."""
        tables = cls.tables()
        stored = {name: table for table in tables for name in table.column_projection()}
        pieces = [stored[plan.name].wire_record(db, plan)
                  for plan in FieldCodec.field_plans(cls) if plan.records]
        identity_key = cls.message_id.wire_name
        pieces.append("json_object('" + identity_key + "', " + identity.qualified("message_id") + ")")
        fragments = " UNION ALL ".join(f"SELECT substr(({piece}), 2, length(({piece})) - 2) AS body"
                                       for piece in pieces)
        wire = "'{' || COALESCE((SELECT group_concat(NULLIF(body, ''), ',') FROM (" + fragments + ")), '') || '}'"
        columns = ", ".join(f'{table.qualified(name)} AS "{name}"'
                            for name, table in stored.items())
        joins = " ".join(table.join_to(BusRow) for table in (*tables, identity))
        extra = tuple(name for name in identity.column_projection() if name not in stored)
        identity_columns = ', '.join(f'{identity.qualified(name)} AS "{name}"' for name in extra)
        return (f'SELECT {columns}, {identity_columns}, {wire} AS wire '
                f'FROM "{BusRow.declared_name}" {joins}')

    def to_wire(self) -> dict:
        return {"seq": self.seq, "id": self.message_id, **FieldCodec.encode(self.envelope)}

    @classmethod
    def from_wire(cls, data: object) -> Message:
        # Content identity is derived from the declared message fields.
        plan = FieldCodec.field_plan(Message, 'type')
        kind = cast(builtins.type[MessageKind], plan.value.decode(plan.raw(data)))
        # The field decoder has already required a record; do not validate/copy it again.
        return kind.decode_message({"ts": 0.0, **cast(Mapping[str, object], data)})

    def awaits_answer_from(self, recipient: ThreadTarget) -> bool:
        """The original message owns whether this named recipient owes its sender an answer."""
        return (self.sender == recipient.name or self.target == recipient.name
                or bool(self.response_eligibility((recipient.name,)).required_responders))

    def response_eligibility(
        self, audience: Sequence[str], *, aliases: Mapping[str, str] = NO_ALIASES
    ) -> ResponseEligibility:
        """Resolve channel responders from canonical audience identities.

        Mention identities were canonicalized when the message was committed.
        The audience remains authoritative for membership, so a valid mention
        outside the channel cannot acquire delivery by being named.
        """
        policy = self.role.response_policy(self)
        return ResponseEligibility(
            policy, policy.recipients(self, audience, aliases=aliases),
            policy.required_responders(self, audience, aliases=aliases),
        )

    @property
    def exact_reply_target(self) -> str:
        """The exact response destination owned by this opening message."""
        return CommandTarget.named(self.target).reply_target(self.sender)

    def automatic_reply_targets(self) -> tuple[str, ...]:
        """An owed answer uses the destination's existing automatic-reply route."""
        if not self.type.allows_automatic_reply(self):
            return ()
        return CommandTarget.named(self.target).automatic_reply_targets(self.sender)

    def opening_references(self, recipient: str) -> tuple[MessageReference, ...]:
        """A confirmed delivery may open its intended reader's turn without owing a reply."""
        return ((self.reference,)
                if self.role.response_policy(self).starts_turn_for(self, recipient) else ())

    autonomous: ClassVar[bool] = False

    @property
    def separate_turn(self) -> bool:
        return self.role.response_policy(self).separate_turn

    @property
    def batch_target(self) -> str:
        return self.exact_reply_target

    def bus_keys(self, owner: ThreadCreationSource) -> tuple[InputKey, ...]:
        return (self.bus_key(owner),)

    @property
    def reply_target(self) -> str | None:
        """An external sender may receive an automatic live reply."""
        return self.sender_role.reply_target(self)


class CarriesEnvelope(Message):
    """A message carrying extra capabilities exposes only its declared public envelope."""

    @property
    def envelope(self) -> Message:
        return self.envelope_type().from_message(self)

    def require_envelope(self) -> None:
        raise TypeError(f"{type(self).__name__} is a record; pass its envelope")


@dataclass_transform(frozen_default=True, kw_only_default=True)
class BusRecord(CarriesEnvelope, Message, DeclaredFamily, affix="Record"):
    """Every record declaration owns its frozen value and derived tables."""

    @ClassFact
    def writes(cls) -> tuple[type[ProducedRow], ...]:
        from agent_comms.bus_activity_index import BusActivityIndex, SentActivity
        from agent_comms.bus_tables import AnsweredSource, MessageIdentitySource
        from agent_comms.messaging.bus_display_index import BusDisplayIndex
        from agent_comms.messaging.bus_route_counts import BusRouteCounts, BusRouteKeys
        # Task rows are written by the record that carries the task, so the record kinds own
        # them too: that is what lets a carry replay old records into a new task row.
        return tuple(dict.fromkeys((
            BusActivityIndex, SentActivity, BusDisplayIndex, BusRouteCounts, BusRouteKeys,
            MessageIdentitySource, AnsweredSource,
            *(row for task in TaskAttachment.members_with(TaskAttachment)
              for owner in task.writer_declarations() for row in owner.writes),
        )))

    def projections(self):
        from agent_comms.bus_activity_index import BusActivityIndex
        from agent_comms.bus_tables import AnsweredSource, MessageIdentitySource
        from agent_comms.messaging.bus_display_index import BusDisplayIndex

        yield from super().projections()
        yield BusActivityIndex.from_message(self, target=self.target)
        participants = {self.sender, *CommandTarget.named(self.target).direct_names,
                        *(mention.thread for mention in self.mentions)}
        for participant in participants:
            yield BusDisplayIndex.from_message(self, participant=participant)
        yield from self.role.activity_rows(self)
        yield from self.type.route_rows(self)
        yield MessageIdentitySource(self.seq, self.message_id, self.sender)
        for original in self.answers:
            yield AnsweredSource(original.seq, self.seq)
        yield from self.task.projections(self)


    @property
    def history_record(self) -> BusRecord:
        """What a copied history appends: display facts, never another root's claims."""
        return PublicRecord.from_message(self.history_snapshot)

    def append_to(self, db: sqlite3.Connection, seq: int) -> int:
        """The caller's transaction owns the sequence, including preserved history."""
        self.require_answers(db)
        BusRow.insert_values(db, seq=seq, kind=type(self), at=time.time())
        stored = replace(self, seq=seq)
        for row in stored.rows():
            row.insert(db)
        stored.project_into(db, StoredHolders())
        return stored.seq

    @property
    def publication_snapshot(self) -> Message:
        """Delivery capabilities are not message content in a publication intent."""
        return Message.from_message(self).publication_snapshot

    @classmethod
    def envelope_type(cls) -> builtins.type[Message]:
        """A record carries the envelope of the message declaration after it in the MRO."""
        return super().envelope_type()

    def __init_subclass__(cls) -> None:
        super().__init_subclass__()
        dataclass(cls, frozen=True, kw_only=True)
        cls.tables()


@dataclass(frozen=True)
class StoredWireMessage:
    """One public envelope as its stored wire text, read on a held SQLite snapshot."""

    seq: int
    timestamp: float
    wire: str


@dataclass(frozen=True)
class StoredWireHistory(InterruptibleRead):
    """A captured public-envelope query; cursors stream and retire with the read."""

    db: sqlite3.Connection
    query: str
    parameters: tuple[object, ...]

    @contextmanager
    def interruptible(self, stopped: Callable[[], bool]) -> Iterator[None]:
        """SQLite checks `stopped` every thousand steps of this read's query."""
        self.db.set_progress_handler(stopped, 1000)
        try:
            yield
        finally:
            self.db.set_progress_handler(None, 0)

    def rows(self) -> Iterator[StoredWireMessage]:
        with closing(self.db.execute(
            f"SELECT seq, timestamp, wire FROM ({self.query}) ORDER BY seq", self.parameters,
        )) as cursor:
            for row in cursor:
                yield StoredWireMessage(*row)

    def messages(self) -> Iterator[Message]:
        """The selected rows' public messages, decoded once from their capability tables."""
        with closing(self.db.execute(
            f"SELECT seq FROM ({self.query}) ORDER BY seq", self.parameters,
        )) as cursor:
            yield from BusCapability.public_messages(
                self.db, (FieldCodec.decode(int, seq) for seq, in cursor))


class PublicRecord(BusRecord):
    sender_lookup: ClassVar[PublicSender] = PublicSender()


@dataclass(frozen=True, kw_only=True)
class Claimed(ClaimProducer, BusCapability):
    """The transition attesting this row, stored in its append transaction."""

    claim_transition: Annotated[ClaimTransition, WireOrder(11)]

    def require_claim_transition(self) -> ClaimTransition:
        return self.claim_transition

    def project_into(self, db: sqlite3.Connection, holders: ClaimHolders) -> None:
        """Append and the shared derived rebuild replay this same original transition."""
        super().project_into(db, holders)
        holders.project(db, self.claim_transition)


@dataclass(frozen=True, kw_only=True)
class ClaimMessage(Claimed, Message):
    """A claimed message binds its transition to its public envelope identity."""

    @classmethod
    def envelope_type(cls) -> builtins.type[Message]:
        return ClaimMessage

    @classmethod
    def of(cls, message: Message, transition: ClaimTransition) -> Self:
        return cls.from_message(message, claim_transition=transition)

    def __post_init__(self) -> None:
        super().__post_init__()
        transition = self.claim_transition
        if (transition.owner != self.sender or transition.seq != self.seq
                or transition.message_id != self.message_id):
            raise RelationViolationError('Claim transition does not bind this message.')

    @property
    def history_snapshot(self) -> Message:
        """A copied history keeps the envelope's display facts and drops its claim."""
        return Message.from_message(self, type=ClaimHistoryKind)

    def retained_task_facts(self) -> Iterator[task_facts.ExactTaskFact]:
        yield from super().retained_task_facts()
        yield task_facts.ClaimTaskFact(ClaimMessage.of(self, self.claim_transition))

from agent_comms import retained_task_facts as task_facts
