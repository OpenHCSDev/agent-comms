"""A9: immutable evidence for exactly the messages a client displays.

This is a value contract, not an assertion that fetching a page paints it. A
client acknowledges it only after paint. DM participant identity deliberately
uses ThreadIncarnation; process and turn generations do not alter provenance.
"""

from __future__ import annotations

import asyncio
import json
from abc import ABC, abstractmethod
from bisect import bisect_left, bisect_right
from collections.abc import Collection, Iterable, Mapping
from dataclasses import dataclass, field, replace
from itertools import product
from pathlib import Path
from typing import Annotated, ClassVar, NoReturn, Self, TYPE_CHECKING, TextIO

from agent_comms.activity_clocks import ChannelActivity
from agent_comms.channel_sources import ChannelHistorySource
from agent_comms.messaging.channel_targets import CommandTarget, ThreadTarget
from agent_comms.coordination.errors import DMPaintedBoundChanged, DMScopeChanged
from agent_comms.errors import RelationViolationError, UnregisteredThreadError
from agent_comms.launch_runtime import CallingThreadUnavailable
from agent_comms.mentions import ThreadMention
from agent_comms.messaging.message_reference import MessageReference
from agent_comms.messaging.messages import MessageInput
from agent_comms.nominal.declared_family import DeclaredFamily
from agent_comms.nominal.field_codec import (
    CapabilityUnion,
    FieldCodec,
    NullMember,
    PathText,
    SingleFieldValue,
    SubclassUnion,
    TaggedRecordMember,
    TaggedUnion,
)
from agent_comms.notification_evidence import AllOutcomes, DisplayOutcomes, OutcomeViewer
from agent_comms.projection_source import ProjectionSource
from agent_comms.projects.checkouts import Checkout
from agent_comms.recorded_bus import RecordedBus, RecordedBusIdentity
from agent_comms.registry.thread_identity import RecordedThreadIncarnation, ThreadIncarnation
from agent_comms.registry_names import RegistryNames
from agent_comms.storage.bound_set import BoundSet
from agent_comms.storage.private_path import FileObservation, MissingFile
from agent_comms.tagged_thread_source import TaggedThreadSource

if TYPE_CHECKING:
    import sqlite3

    from agent_comms.bus import Bus, BusReader, BusSnapshot
    from agent_comms.historical_views import DMHistory, HistoricalSelection, HistorySource
    from agent_comms.history_views import HistoryViews
    from agent_comms.messaging.messages import Message, MessageKind
    from agent_comms.messaging.message_bus import MessageBus
    from agent_comms.messaging.message_page import MessagePage, PageBounds
    from agent_comms.messaging.read_ledger import ReadDocument, ReadLedger
    from agent_comms.messaging.read_selection import CapturedSelection
    from agent_comms.presentation import BusPresentation
    from agent_comms.private_registry_guard import RegistryPrivacy
    from agent_comms.registry.registration import Registration
    from agent_comms.registry.registry_document import RegistrySnapshot
    from agent_comms.registry.threads import Thread
    from agent_comms.registry.user_thread_lookup import UserThreadLookup
    from agent_comms.registry_provenance import RegistryProvenance


class DisplayViewer(SubclassUnion, affix="Viewer"):
    """The reader owns read evidence, aliases and cursor selection."""

    @abstractmethod
    def direct_history(self, direct: type[DMHistory], peer: ThreadTarget) -> DMHistory: ...

    @abstractmethod
    def resolve(self, snapshot: RegistryProvenance) -> DisplayViewer: ...

    @abstractmethod
    def historical_selection(self, page: MessagePage, presentation: BusPresentation, historical: HistorySource, source: Bus, document: ReadDocument, snapshot: RegistrySnapshot) -> SelectedDisplay: ...

    @abstractmethod
    def cursor(self, reads: ReadLedger, snapshot: RegistrySnapshot, document: ReadDocument, source: BusSnapshot) -> ReadCursor: ...

    @abstractmethod
    def aliases(self, snapshot: RegistrySnapshot) -> frozenset[str]: ...

    @abstractmethod
    def require_name(self, snapshot: RegistrySnapshot) -> str: ...

    @abstractmethod
    def read_page(
        self,
        scope: ChannelDisplayScope,
        bounds: PageBounds,
        basis: CapturedSelection,
        source: BusSnapshot,
    ) -> MessagePage: ...


@dataclass(frozen=True, slots=True)
class AnonymousViewer(NullMember, DisplayViewer):
    def resolve(self, snapshot: RegistryProvenance) -> AnonymousViewer:
        return self

    def direct_history(self, direct: type[DMHistory], peer: ThreadTarget) -> DMHistory:
        raise ValueError("DM history requires --as <participant>.")

    def historical_selection(self, page: MessagePage, presentation: BusPresentation, historical: HistorySource, source: Bus, document: ReadDocument, snapshot: RegistrySnapshot) -> NoDisplaySelection:
        return NoDisplaySelection()

    def cursor(self, reads: ReadLedger, snapshot: RegistrySnapshot, document: ReadDocument, source: BusSnapshot) -> ReadCursor:
        return ReadCursor()

    def aliases(self, snapshot: RegistrySnapshot) -> frozenset[str]:
        return frozenset()

    def require_name(self, snapshot: RegistrySnapshot) -> str:
        raise ValueError("Viewer metrics require a named viewer")

    def read_page(
        self,
        scope: ChannelDisplayScope,
        bounds: PageBounds,
        basis: CapturedSelection,
        source: BusSnapshot,
    ) -> MessagePage:
        return bounds.conversation(scope).read_opened(source)


@dataclass(frozen=True, slots=True)
class NamedViewer(SingleFieldValue, DisplayViewer):
    name: str

    def resolve(self, snapshot: RegistryProvenance) -> NamedViewer:
        return type(self)(snapshot.canonical_name(self.name))

    def direct_history(self, direct: type[DMHistory], peer: ThreadTarget) -> DMHistory:
        return direct(self.name, peer)

    def historical_selection(self, page: MessagePage, presentation: BusPresentation, historical: HistorySource, source: Bus, document: ReadDocument, snapshot: RegistrySnapshot) -> HistoricalSelection:
        historical.validate()
        return historical.selection(presentation.bus.reads.capture(
            self.resolve(snapshot).name, page.messages, snapshot, source,
            conversation_snapshot=historical.provenance, document=document))

    def cursor(self, reads: ReadLedger, snapshot: RegistrySnapshot, document: ReadDocument, source: BusSnapshot) -> ReadCursor:
        return document.cursor(self.name, snapshot, source)

    def aliases(self, snapshot: RegistrySnapshot) -> frozenset[str]:
        return snapshot.names_for(self.name)

    def require_name(self, snapshot: RegistrySnapshot) -> str:
        return snapshot.canonical_name(self.name)

    def read_page(
        self,
        scope: ChannelDisplayScope,
        bounds: PageBounds,
        basis: CapturedSelection,
        source: BusSnapshot,
    ) -> MessagePage:
        result = bounds.conversation(scope).displayed(
            basis.reads, basis.document, self.name, basis.registry, basis.registry, source,
        )
        return replace(result.page, selection=ChannelSelection(
            replace(scope, displayed=result.displayed)))


class ReadAuthority(ABC):
    """Whose read this is; distinct from the SQL reader that acquires its rows."""

    @abstractmethod
    def outcome_viewer(self, registry: Registration) -> OutcomeViewer: ...

    def subject(self, named: str) -> str:
        return named or self.own_thread()

    def history_viewer(self, named: str) -> DisplayViewer:
        """A thread reader defaults to itself; unscoped callers own their default."""
        return NamedViewer(self.subject(named))

    def own_thread(self) -> str:
        return self.refuse_thread()

    def refuse_thread(self) -> NoReturn:
        raise CallingThreadUnavailable("This tool requires a thread caller.")


class OperatorOutcomes(ReadAuthority):
    """An unscoped operator reader sees every recipient outcome."""

    __slots__ = ()

    def outcome_viewer(self, registry: Registration) -> OutcomeViewer:
        return AllOutcomes()


class DisplayCut(OperatorOutcomes, CapabilityUnion, ABC):
    """The selected display cut, including the absence of a painted display."""

    __slots__ = ()

    @classmethod
    def capability_families(cls) -> tuple[type[DeclaredFamily], ...]:
        return (DisplayIdentity, SelectedDisplay)

    @property
    @abstractmethod
    def notification_identity(self) -> DisplayCut: ...


@dataclass(frozen=True, slots=True, kw_only=True)
class DisplayIdentity(TaggedUnion, DisplayCut, affix="DisplayIdentity"):
    """The scope observation compared between pages, independent of paint evidence. A
    revision carries it to a remote UI and back, and the members share their common
    fields, so each record carries its kind."""

    viewer: ThreadIncarnation
    history_revision: FileObservation
    bus_identity: RecordedBusIdentity


    @property
    def notification_identity(self) -> SourceDisplayIdentity:
        """The captured viewer/source cut, without an unrelated channel/DM payload."""
        return SourceDisplayIdentity(
            viewer=self.viewer,
            history_revision=self.history_revision,
            bus_identity=self.bus_identity,
        )

    def outcome_viewer(self, registry: Registration) -> OutcomeViewer:
        return DisplayOutcomes(self.viewer, self.bus_identity)


@dataclass(frozen=True, slots=True, kw_only=True)
class SourceDisplayIdentity(TaggedRecordMember, DisplayIdentity):
    """The viewer and source cut alone: a notification's or a historical display's."""


@dataclass(frozen=True, slots=True)
class ChannelDisplayIdentity(TaggedRecordMember, DisplayIdentity):
    scope: ChannelDisplayScope


@dataclass(frozen=True, slots=True)
class DMDisplayIdentity(TaggedRecordMember, DisplayIdentity):
    root_identity: tuple[int, int]
    project_path: Annotated[Path, PathText]
    requested_peer: str
    peer: ThreadIncarnation
    scope: DMDisplayScope


@dataclass(frozen=True, slots=True, kw_only=True)
class SelectedDisplay(TaggedUnion, affix="Selection"):
    """The builder's declared read proof; never recovered from a page's fields. It travels
    with its page to a remote UI and back with the read mark, so each record carries its kind."""


    history_revision: FileObservation = MissingFile()
    has_evidence: ClassVar[bool] = True

    @property
    @abstractmethod
    def identity(self) -> DisplayCut: ...

    @property
    def notification_identity(self) -> DisplayCut:
        return self.identity.notification_identity

    @abstractmethod
    def acknowledge(
        self, views: HistoryViews, page: MessagePage, *, worktree: Checkout
    ) -> None: ...

    def select(self, page: MessagePage, sequences: Collection[int]) -> MessagePage:
        selected = frozenset(sequences)
        return replace(page,
            messages=tuple(message for message in page.messages if message.seq in selected),
            source_pages=tuple(source.select(selected) for source in page.source_pages),
            selection=self.select_evidence(selected))

    @abstractmethod
    def select_evidence(self, selected: frozenset[int]) -> SelectedDisplay: ...


@dataclass(frozen=True, slots=True)
class NoDisplaySelection(TaggedRecordMember, SelectedDisplay, DisplayCut):
    has_evidence: ClassVar[bool] = False

    @property
    def identity(self):
        return self

    @property
    def notification_identity(self) -> NoDisplaySelection:
        return self

    def acknowledge(self, views: HistoryViews, page: MessagePage, *, worktree: Checkout) -> None:
        raise DMPaintedBoundChanged()

    def select_evidence(self, selected: frozenset[int]) -> Self:
        return self


@dataclass(frozen=True, slots=True)
class ChannelSelection(TaggedRecordMember, SelectedDisplay):
    scope: ChannelDisplayScope

    @property
    def identity(self):
        return self.scope.identity(self.history_revision)

    def acknowledge(self, views: HistoryViews, page: MessagePage, *, worktree: Checkout) -> None:
        from agent_comms.presentation import ReadThrough

        views.presentation.mark_channel_read(
            self.scope.channel, viewer=views.messaging.user_identity(worktree).name,
            mark=ReadThrough(page.newest_seq, self.scope),
        )

    def select_evidence(self, selected: frozenset[int]) -> Self:
        return replace(self, scope=replace(self.scope,
            displayed=self.scope.require_displayed().select(selected)))


@dataclass(frozen=True, slots=True)
class DMSelection(TaggedRecordMember, SelectedDisplay):
    basis: DMDisplayBasis

    @property
    def identity(self):
        return self.basis.identity(self.history_revision)

    def acknowledge(self, views: HistoryViews, page: MessagePage, *, worktree: Checkout) -> None:
        self.basis.acknowledge(
            views.bus, views.registry, views.root, self.basis.requested_peer,
            worktree=worktree, through=page.newest_seq,
        )

    def select_evidence(self, selected: frozenset[int]) -> Self:
        return replace(self, basis=replace(self.basis,
            displayed=self.basis.displayed.select(selected)))


class LineOutput:
    """Flush once per event-loop pass."""

    def __init__(self, stream: TextIO) -> None:
        self.stream = stream
        self.pending: asyncio.Handle | None = None

    def write(self, line: str) -> None:
        self.stream.write(line + '\n')
        if self.pending is None:
            self.pending = asyncio.get_running_loop().call_soon(self.flush)

    def flush(self) -> None:
        self.pending = None
        self.stream.flush()


@dataclass(frozen=True, slots=True)
class CursorRow:
    """One actor's cursor on one (target, sender) key: the row `read_cursors` reads."""

    actor: str
    target: str
    sender: str
    cursor: ConversationCursor

    @property
    def key(self) -> tuple[str, str, str]:
        return self.actor, self.target, self.sender

    @property
    def whole_bus(self) -> bool:
        """The explicit whole-bus read: moving it may change every row's state."""
        return self.target == ""

    @staticmethod
    def binding(rows: Iterable[CursorRow]) -> str:
        """The `read_cursors` SQL parameter, in the column order ReadCursor.sql reads."""
        return json.dumps([(row.actor, row.target, row.sender, row.cursor.high_water,
                            row.cursor.exceptions) for row in rows])


@dataclass(frozen=True, slots=True)
class ConversationCursor:
    """One conversation's proved prefix and ordered out-of-order reads."""

    high_water: int = 0
    exceptions: tuple[int, ...] = ()

    @classmethod
    def union(cls, cursors: Iterable[ConversationCursor]) -> ConversationCursor:
        cursors = tuple(cursors)
        through = max((cursor.high_water for cursor in cursors), default=0)
        return cls(through, tuple(sorted({sequence for cursor in cursors
                                          for sequence in cursor.exceptions if sequence > through})))

    def add(self, sequences: tuple[int, ...]) -> ConversationCursor:
        exceptions = list(self.exceptions)
        for sequence in sequences:
            if sequence > self.high_water:
                index = bisect_left(exceptions, sequence)
                if index == len(exceptions) or exceptions[index] != sequence:
                    exceptions.insert(index, sequence)
        high_water = self.high_water
        prefix = 0
        while prefix < len(exceptions) and exceptions[prefix] == high_water + 1:
            high_water += 1
            prefix += 1
        return type(self)(high_water, tuple(exceptions[prefix:]))

    def agrees_through(self, other: ConversationCursor) -> int:
        """The highest sequence at or below which both cursors read every row alike. Both read
        all of the lower high water's prefix; with equal high waters, they first differ at the
        lowest sequence only one of them read out of order."""
        if self.high_water != other.high_water:
            return min(self.high_water, other.high_water)
        return min(set(self.exceptions) ^ set(other.exceptions), default=self.high_water + 1) - 1

    def through(self, sequence: int) -> ConversationCursor:
        sequence = max(sequence, self.high_water)
        return type(self)(sequence, self.exceptions[bisect_right(self.exceptions, sequence):])

    def __contains__(self, sequence: int) -> bool:
        index = bisect_left(self.exceptions, sequence)
        return 0 < sequence <= self.high_water or (index < len(self.exceptions) and self.exceptions[index] == sequence)


@dataclass(frozen=True, slots=True)
class ReadCursor:
    """Read evidence stays keyed by conversation even when viewer aliases join."""

    conversations: dict[Conversation, ConversationCursor] = field(default_factory=dict)

    def lower_bound(self, scope: ChannelDisplayScope, snapshot: RegistryProvenance) -> int:
        return scope.lower_bound(self, snapshot)

    @staticmethod
    def sql(parameter: str) -> str:
        return f"""read_cursors AS MATERIALIZED (
        SELECT CAST(json_extract(value,'$[0]') AS TEXT) AS actor,
               CAST(json_extract(value,'$[1]') AS TEXT) AS target,
               CAST(json_extract(value,'$[2]') AS TEXT) AS sender,
               json_extract(value,'$[3]') AS high_water,
               json_extract(value,'$[4]') AS exceptions
        FROM json_each({parameter}))"""

    unread_sql = "seq > high_water AND seq NOT IN (SELECT value FROM json_each(exceptions))"

    def unread_rule(self) -> str:
        """Which joined request rows this cursor still counts; a human read is the whole rule."""
        return self.unread_sql

    @staticmethod
    def rule_of(cursors: Iterable[ReadCursor]) -> str:
        """One route query applies one cursor rule to every actor it reads."""
        rule, = {cursor.unread_rule() for cursor in cursors}
        return rule

    def attached(self, db: sqlite3.Connection, root: Path, privacy: RegistryPrivacy) -> ReadCursor:
        """A human read needs no store beyond the bus snapshot it is read from."""
        return self

    floor_sql = """actor_floor AS MATERIALIZED (
        SELECT actor,target,max(high_water) AS high_water
        FROM read_cursors WHERE sender='' GROUP BY actor,target
    )"""
    """The broad-cursor part of joined_sql's rule, grouped by actor and target."""

    @staticmethod
    def above_floor(seq: str, actor: str, target: str) -> str:
        """Apply the broad-cursor part of joined_sql's rule to a candidate row."""
        return (
            f"{seq}>coalesce((SELECT max(high_water) FROM actor_floor AS floor "
            f"WHERE floor.actor={actor} AND floor.target IN ({target},'')),0)"
        )

    joined_sql = """cursors AS NOT MATERIALIZED (
        SELECT row.*,max(coalesce(read.high_water,0),coalesce(all_read.high_water,0)) AS high_water,
            coalesce(read.exceptions,'[]') AS exceptions FROM requests AS row
        LEFT JOIN read_cursors AS read ON read.actor=row.actor AND read.target=row.target
            AND (read.sender='' OR read.sender=row.sender)
        LEFT JOIN read_cursors AS all_read ON all_read.actor=row.actor
            AND all_read.target='' AND all_read.sender=''
    )"""

    def counted(self, scope: MessageDisplayScope, snapshot: RegistryProvenance
                ) -> Iterable[tuple[Conversation, ConversationCursor]]:
        return scope.counted(self, snapshot)

    @staticmethod
    def rows(snapshot: RegistryProvenance,
             cursors: Mapping[str, Iterable[tuple[Conversation, ConversationCursor]]]
             ) -> tuple[CursorRow, ...]:
        """Each actor's cursor on every (target, sender) key its conversations resolve to."""
        return tuple(
            CursorRow(actor, target, sender, cursor)
            for actor, selected in cursors.items() for conversation, cursor in selected
            for target, sender in conversation.sql_keys(snapshot)
        )

    @staticmethod
    def sql_bindings(snapshot: RegistryProvenance,
                     cursors: Mapping[str, Iterable[tuple[Conversation, ConversationCursor]]]
                     ) -> dict[str, str]:
        return {"read_cursors": CursorRow.binding(ReadCursor.rows(snapshot, cursors))}

    @classmethod
    def union(cls, cursors: Iterable[ReadCursor]) -> ReadCursor:
        grouped: dict[Conversation, list[ConversationCursor]] = {}
        for cursor in cursors:
            for conversation, value in cursor.conversations.items():
                grouped.setdefault(conversation, []).append(value)
        return cls({key: ConversationCursor.union(values) for key, values in grouped.items()})

    def for_conversation(self, conversation: Conversation) -> ConversationCursor:
        return ConversationCursor.union((
            self.conversations.get(AllConversation(), ConversationCursor()),
            self.conversations.get(conversation, ConversationCursor()),
        ))

    def add(self, displayed: Iterable[DisplayedConversation]) -> ReadCursor:
        conversations = dict(self.conversations)
        for item in displayed:
            previous = conversations.get(item.conversation, ConversationCursor())
            conversations[item.conversation] = previous.through(item.prefix_through).add(item.sequences)
        return type(self)(conversations)

    def current(self, snapshot: RegistryProvenance) -> ReadCursor:
        return type(self).union(type(self)({key.resolved(snapshot): value})
            for key, value in self.conversations.items() if key.current(snapshot))


class Conversation(DeclaredFamily, ABC, affix="Conversation"):
    family_discriminator = "kind"
    participants: tuple[ThreadIncarnation, ...] = ()

    def current(self, snapshot: RegistryProvenance) -> bool:
        return all(participant.current(snapshot) for participant in self.participants)

    @abstractmethod
    def resolved(self, snapshot: RegistryProvenance) -> Conversation: ...

    @abstractmethod
    def scope(self, snapshot: RegistryProvenance) -> ChannelDisplayScope | DMDisplayScope: ...

    @abstractmethod
    def sql_keys(self, snapshot: RegistryProvenance) -> Iterable[tuple[str, str]]: ...

    @abstractmethod
    def recorded_keys(self, snapshot: RegistryProvenance) -> Iterable[Conversation]: ...

    @abstractmethod
    def in_targets(self, targets: Collection[str], snapshot: RegistryProvenance) -> bool: ...


@dataclass(frozen=True, slots=True)
class AllConversation(Conversation):
    """An explicit whole-bus read applies to every conversation in this source."""

    def resolved(self, snapshot: RegistryProvenance):
        return self

    def scope(self, snapshot: RegistryProvenance) -> AllChannelDisplayScope:
        from agent_comms.messaging.channels import AnyChannel

        return AllChannelDisplayScope(AnyChannel.address())

    def sql_keys(self, snapshot: RegistryProvenance):
        return (('', ''),)

    def recorded_keys(self, snapshot: RegistryProvenance):
        return (self,)

    def in_targets(self, targets: Collection[str], snapshot: RegistryProvenance) -> bool:
        return True


@dataclass(frozen=True, slots=True)
class ChannelConversation(Conversation):
    target: str

    def resolved(self, snapshot: RegistryProvenance) -> ChannelConversation:
        return self

    def scope(self, snapshot: RegistryProvenance) -> ChannelDisplayScope:
        return ChannelDisplayScope(self.target, frozenset((self.target,)))

    def sql_keys(self, snapshot: RegistryProvenance) -> Iterable[tuple[str, str]]:
        return ((self.target, ""),)

    def recorded_keys(self, snapshot: RegistryProvenance) -> Iterable[Conversation]:
        return (self,)

    def in_targets(self, targets: Collection[str], snapshot: RegistryProvenance) -> bool:
        return self.target in targets


@dataclass(frozen=True, slots=True)
class DMConversation(Conversation):
    participants: tuple[ThreadIncarnation, ...] = ()

    def resolved(self, snapshot: RegistryProvenance) -> DMConversation:
        return type(self)(tuple(sorted(
            (participant.resolved(snapshot) for participant in self.participants),
            key=lambda participant: participant.name,
        )))

    def scope(self, snapshot: RegistryProvenance) -> DMDisplayScope:
        first, second = self.participants[0], self.participants[-1]
        return DMDisplayScope.capture(first.name, second.name, snapshot)

    def recorded_keys(self, snapshot: RegistryProvenance) -> Iterable[Conversation]:
        return (type(self)(tuple(sorted(pair, key=lambda p: p.name)))
                for pair in product(*(p.recorded_names(snapshot) for p in self.participants)))

    def in_targets(self, targets: Collection[str], snapshot: RegistryProvenance) -> bool:
        return any(snapshot.names_for(p.name).intersection(targets) for p in self.participants)

    def sql_keys(self, snapshot: RegistryProvenance) -> Iterable[tuple[str, str]]:
        first, second = self.participants[0], self.participants[-1]
        a, b = snapshot.names_for(first.name), snapshot.names_for(second.name)
        return tuple((target, sender) for senders, targets in ((a, b), (b, a))
                     for sender in senders for target in targets)


@dataclass(frozen=True, slots=True)
class DisplayedConversation:
    conversation: Conversation
    sequences: tuple[int, ...]
    prefix_through: int = 0

    def select(self, selected: Collection[int]) -> DisplayedConversation:
        omitted = min((n for n in self.sequences if n not in selected), default=self.prefix_through + 1)
        return type(self)(self.conversation, tuple(n for n in self.sequences if n in selected),
                          min(self.prefix_through, omitted - 1))

    def through(self, sequence: int) -> DisplayedConversation:
        return type(self)(self.conversation, tuple(n for n in self.sequences if n <= sequence),
                          min(self.prefix_through, sequence))


class DisplayedTail(DeclaredFamily, affix="Tail"):
    """The newest sequence a displayed range vouches for, which bounds a painted read mark."""

    @abstractmethod
    def validate(self, through: int) -> None: ...

    @abstractmethod
    def mark(self, reads: ReadLedger, displayed: DisplayBasis, through: int) -> None: ...


@dataclass(frozen=True, slots=True)
class CoveredTail(DisplayedTail):
    """Only fetched references become read; omitted older messages stay unread."""

    newest: int

    def validate(self, through: int) -> None:
        if through > self.newest:
            raise DMPaintedBoundChanged()

    def mark(self, reads: ReadLedger, displayed: DisplayBasis, through: int) -> None:
        reads.mark_displayed(displayed.viewer, displayed.through(through))


@dataclass(frozen=True, slots=True)
class EmptyTail(DisplayedTail):
    """A range holding no sequences validates its identity but acknowledges nothing."""

    def validate(self, through: int) -> None:
        pass

    def mark(self, reads: ReadLedger, displayed: DisplayBasis, through: int) -> None:
        pass


@dataclass(frozen=True, slots=True)
class DisplayBasis:
    viewer: str
    viewer_created_at: float
    conversations: tuple[DisplayedConversation, ...]
    bus_identity: RecordedBusIdentity

    @property
    def viewer_identity(self) -> RecordedThreadIncarnation:
        return RecordedThreadIncarnation(self.viewer, self.viewer_created_at)

    @property
    def message_count(self) -> int:
        return sum(len(item.sequences) for item in self.conversations)

    def uncovered(self, references: Collection[MessageReference]) -> tuple[MessageReference, ...]:
        """References whose public positions this captured display does not cover."""
        sequences = frozenset(sequence for item in self.conversations for sequence in item.sequences)
        return tuple(reference for reference in references if reference.seq not in sequences)

    @property
    def tail(self) -> DisplayedTail:
        """Derived from the sequences this range holds now: a painted selection of none is empty."""
        newest = sorted(n for item in self.conversations for n in item.sequences)[-1:]
        return CoveredTail(*newest) if newest else EmptyTail()

    def select(self, sequences: Collection[int]) -> DisplayBasis:
        """Retain painted members of this proof; never introduce new sequences."""
        selected = frozenset(sequences)
        return DisplayBasis(
            self.viewer,
            self.viewer_created_at,
            tuple(
                item.select(selected)
                for item in self.conversations
            ),
            self.bus_identity,
        )

    def through(self, sequence: int) -> DisplayBasis:
        if sequence < 0:
            raise ValueError("Display sequence cannot be negative.")
        return DisplayBasis(
            self.viewer,
            self.viewer_created_at,
            tuple(
                item.through(sequence)
                for item in self.conversations
            ),
            self.bus_identity,
        )

    def validate(
        self, viewer: str, snapshot: RegistrySnapshot, bus_identity: RecordedBusIdentity
    ) -> None:
        thread = snapshot.threads.get(viewer)
        if (
            viewer != self.viewer
            or thread is None
            or thread.incarnation != self.viewer_identity
            or not self.bus_identity.matches(bus_identity)
            or any(not item.conversation.current(snapshot) for item in self.conversations)
        ):
            raise DMScopeChanged("Display incarnation changed; refresh the displayed page.")


@dataclass(frozen=True, slots=True)
class DMDisplayBasis:
    """Immutable identity/scope witness for one fetched human DM page.

    A page fetch is not proof that a UI painted it. The client must supply
    separate contiguous painted-tail evidence before requesting a read mark.
    """

    root: str
    root_identity: tuple[int, int]
    project_path: Annotated[Path, PathText]
    requested_peer: str
    viewer_identity: ThreadIncarnation
    viewer_names: frozenset[str]
    peer_identity: ThreadIncarnation
    peer_names: frozenset[str]
    bus_identity: RecordedBusIdentity
    displayed: DisplayBasis
    fetched_through: int

    @classmethod
    def fetch_page(
        cls,
        bus: MessageBus,
        registry: Registration,
        root: Path,
        viewer: Thread,
        peer: ThreadTarget,
        *,
        worktree: Checkout,
        bounds: PageBounds,
    ) -> MessagePage:
        """Fetch a bounded human DM page and its immutable identity/read basis.

        Fetching is not paint proof. A UI may use the basis only after proving
        that the corresponding inbound tail was contiguous and visibly painted.
        """
        snapshot = registry.snapshot()
        viewer_name = snapshot.canonical_name(viewer.name)
        peer_name = peer.selected_name(snapshot)
        scope = DMDisplayScope.capture_human(viewer_name, peer_name, snapshot)
        viewer_thread = snapshot.threads[viewer_name]
        peer_thread = snapshot.participant(peer_name)
        viewer_names, peer_names = scope.first_names, scope.second_names
        document = bus.reads.read_conversation(viewer_name, scope.read_key(viewer_name, peer_name, snapshot), snapshot)
        result = bounds.conversation(scope).displayed(
            bus.reads, document, viewer_name, snapshot, snapshot, bus.bus,
        )
        page, displayed = result.page, result.displayed
        root_info = root.stat()
        basis = cls(
            root=str(root.resolve()),
            root_identity=(root_info.st_dev, root_info.st_ino),
            project_path=worktree.resolved().path,
            requested_peer=peer.name,
            viewer_identity=viewer_thread.incarnation,
            viewer_names=viewer_names,
            peer_identity=peer_thread.incarnation,
            peer_names=peer_names,
            bus_identity=displayed.bus_identity,
            displayed=displayed,
            fetched_through=page.newest_seq or 0,
        )
        current = registry.snapshot()
        basis.validate_identity(
            current, RecordedBusIdentity.capture(bus.bus.path), current.user_thread(),
        )
        return replace(page, selection=DMSelection(basis))

    def identity(self, history_revision: FileObservation) -> DMDisplayIdentity:
        return DMDisplayIdentity(
            root_identity=self.root_identity, bus_identity=self.bus_identity,
            project_path=self.project_path, requested_peer=self.requested_peer,
            viewer=self.viewer_identity, peer=self.peer_identity,
            scope=DMDisplayScope(self.viewer_names, self.peer_names),
            history_revision=history_revision,
        )

    @property
    def viewer(self) -> str:
        return self.viewer_identity.name

    @property
    def peer(self) -> str:
        return self.peer_identity.name

    def acknowledge(
        self,
        bus: MessageBus,
        registry: Registration,
        root: Path,
        peer: str,
        *,
        worktree: Checkout,
        through: int,
    ) -> None:
        """CAS one painted human DM tail, never a global/executor ACK.

        The page must have no omitted unread inbound messages. The caller must
        additionally prove its through-bound was actually and contiguously
        painted; a fetched page alone cannot establish visibility.
        """
        if type(through) is not int:
            raise ValueError("Painted DM read requires a typed page basis and integer bound.")
        user = registry.user_thread()
        with registry.store.current_snapshot() as cut:
            snapshot = cut.snapshot
            self.validate_for(
                root, worktree, peer, through, snapshot,
                RecordedBusIdentity.capture(bus.bus.path), user,
            )
            self.displayed.tail.mark(bus.reads, self.displayed, through)

    def validate_for(
        self,
        root: Path,
        worktree: Checkout,
        peer: str,
        through: int,
        snapshot: RegistrySnapshot,
        bus_identity: RecordedBusIdentity,
        user: UserThreadLookup[Thread],
    ) -> None:
        if (self.root, self.project_path, self.requested_peer) != (
            str(root.resolve()),
            worktree.resolved().path,
            peer,
        ):
            raise DMScopeChanged("Painted DM read belongs to a different root, worktree or peer.")
        self.displayed.tail.validate(through)
        info = root.stat()
        if (info.st_dev, info.st_ino) != self.root_identity:
            raise DMScopeChanged("DM root was replaced; refresh the page.")
        self.validate_identity(snapshot, bus_identity, user)

    def validate_identity(
        self, snapshot: RegistrySnapshot, bus_identity: RecordedBusIdentity,
        user: UserThreadLookup[Thread],
    ) -> None:
        """Fetch and painted acknowledgement share actual identity/scope validation.

        Heartbeat, turn state and another view's read progress are not identity.
        """
        selected = user.require(
            DMScopeChanged("DM viewer/peer incarnation changed; refresh the page."))
        try:
            viewer = snapshot.threads[self.viewer]
            target = snapshot.participant(self.requested_peer)
            scope = DMDisplayScope.capture_human(self.viewer, self.requested_peer, snapshot)
        except (KeyError, UnregisteredThreadError) as error:
            raise DMScopeChanged("DM viewer/peer incarnation changed; refresh the page.") from error
        if (
            selected.incarnation != self.viewer_identity
            or (viewer.incarnation, target.incarnation)
            != (self.viewer_identity, self.peer_identity)
            or scope != DMDisplayScope(self.viewer_names, self.peer_names)
        ):
            raise DMScopeChanged("DM viewer/peer incarnation changed; refresh the page.")
        if not self.bus_identity.matches(bus_identity):
            raise DMScopeChanged("DM bus was replaced; refresh the page.")
        self.displayed.validate(self.viewer, snapshot, bus_identity)


class MessageDisplayScope(DeclaredFamily, ABC, ProjectionSource, affix="DisplayScope"):
    """Captured inclusion and its exact predicate on the bus capability tables."""

    def read_key(self, sender: str, target: str, snapshot: RegistryProvenance) -> Conversation:
        return CommandTarget.named(target).conversation_key(
            sender, snapshot, ChannelConversation, DMConversation
        )

    def records(
        self, source: BusReader, *, lower: int = 0, upper: int | None = None,
        descending: bool = False, limit: int = 100, kinds: tuple[type[MessageKind], ...] = (),
    ) -> tuple[Message, ...]:
        predicate, parameters = self.index_predicate
        return source.scoped_page(predicate, parameters, lower=lower, upper=upper,
                                  descending=descending, limit=limit, kinds=kinds)

    def history(self, source: BusReader, *, limit: int) -> tuple[Message, ...]:
        """A bounded recent selection closed over its answers, without crossing this scope.

        A copied message keeps only the answers this scope discloses: a reference to a message
        outside it would name that message, and its original stays on the source bus."""
        selected: dict[int, Message] = {}
        with source.reading() as reader:
            for message in self.records(reader, descending=True, limit=limit):
                added: dict[int, Message] = {}
                pending = [message]
                while pending and len(selected) + len(added) <= limit:
                    answer = pending.pop()
                    if answer.seq in selected or answer.seq in added:
                        continue
                    disclosed = tuple(original for original in
                                      reader.messages_for_references(answer.answers)
                                      if self.includes(original))
                    added[answer.seq] = replace(
                        answer, answers=tuple(original.reference for original in disclosed))
                    pending.extend(disclosed)
                if len(selected) + len(added) > limit:
                    if not selected:
                        raise RelationViolationError(
                            f"Newest history and its answered originals exceed {limit} records"
                        )
                    break
                selected.update(added)
        return tuple(selected[seq] for seq in sorted(selected))

    def capture_all(self, reads: ReadLedger, viewer: str, snapshot: RegistrySnapshot,
                    source: BusSnapshot, *, document: ReadDocument, through: int) -> DisplayBasis:
        return self.capture_deliveries(reads, viewer, snapshot, source,
                                       document=document, audience=self, through=through)

    def capture_deliveries(self, reads: ReadLedger, viewer: str, snapshot: RegistrySnapshot,
                           source: BusSnapshot, *, document: ReadDocument,
                           audience: MessageDisplayScope, through: int) -> DisplayBasis:
        prefixes: dict[Conversation, int] = {}
        predicate, parameters = self.intersection(audience)
        for row in source.latest_conversations(predicate, parameters, through):
            conversation = self.read_key(row.sender, row.target, snapshot)
            prefixes[conversation] = max(prefixes.get(conversation, 0), row.seq)
        return DisplayBasis(viewer, snapshot.require(viewer).incarnation.wire_birth,
            tuple(DisplayedConversation(conversation, (), sequence)
                  for conversation, sequence in prefixes.items()), RecordedBus(source.identity))

    def intersection(
        self, other: MessageDisplayScope,
    ) -> tuple[str, tuple[object, ...]]:
        predicate, parameters = self.index_predicate
        other_predicate, other_parameters = other.index_predicate
        return f"({predicate}) AND ({other_predicate})", (*parameters, *other_parameters)

    @property
    def index_predicate(self) -> tuple[str, tuple]:
        """Select this scope's members before applying the sequence limit, its field selectors
        rendered through the message input's declared tables."""
        condition, parameters = self.condition
        return MessageInput.render(condition), parameters

    @property
    @abstractmethod
    def condition(self) -> tuple[str, tuple]:
        """This scope's membership over {field} selectors, with its parameters in order."""

    @property
    @abstractmethod
    def index_targets(self) -> frozenset[str]:
        """The explicitly addressed targets included by this scope."""

    def counted(self, cursor: ReadCursor, snapshot: RegistryProvenance
                ) -> Iterable[tuple[Conversation, ConversationCursor]]:
        targets = self.index_targets
        return ((key, value) for key, value in cursor.conversations.items()
                if key.in_targets(targets, snapshot))

    @abstractmethod
    def includes(self, message: Message) -> bool:
        """Apply the captured predicate to a validated authoritative message."""


class AnyTargetDisplayScope(MessageDisplayScope, declared_name=None):
    """A scope matching arbitrary targets cannot trim by named conversations."""

    def target_values[V](self, values: Mapping[str, V]) -> Iterable[V]:
        return values.values()

    def counted(self, cursor: ReadCursor, snapshot: RegistryProvenance
                ) -> Iterable[tuple[Conversation, ConversationCursor]]:
        return cursor.conversations.items()

    def lower_bound(self, cursor: ReadCursor, snapshot: RegistryProvenance) -> int:
        return cursor.for_conversation(AllConversation()).high_water


@dataclass(frozen=True, slots=True)
class DMDisplayScope(MessageDisplayScope):
    first_names: frozenset[str]
    second_names: frozenset[str]

    @classmethod
    def capture(cls, a: str, b: str, snapshot: RegistryProvenance) -> DMDisplayScope:
        return cls(snapshot.names_for(a), snapshot.names_for(b))

    @classmethod
    def capture_human(cls, viewer: str, peer: str, snapshot: RegistrySnapshot) -> DMDisplayScope:
        try:
            first = snapshot.threads[snapshot.canonical_name(viewer)]
            second = snapshot.participant(peer)
        except (KeyError, UnregisteredThreadError) as error:
            raise DMScopeChanged("DM display identity changed; refresh the page.") from error
        first.role.require_user(DMScopeChanged("DM display identity changed; refresh the page."))
        if first.incarnation == second.incarnation:
            raise DMScopeChanged("DM display identity changed; refresh the page.")
        return cls.capture(first.name, second.name, snapshot)

    @property
    def condition(self) -> tuple[str, tuple]:
        return self.address_predicate("{sender}", "{target}")

    def address_predicate(self, sender: str, target: str) -> tuple[str, tuple]:
        first, second = BoundSet(self.first_names), BoundSet(self.second_names)
        return (f"(({first.within(sender)} AND {second.within(target)}) OR "
                f"({second.within(sender)} AND {first.within(target)}))",
                (*first.parameters, *second.parameters, *second.parameters, *first.parameters))

    @property
    def index_targets(self) -> frozenset[str]:
        return self.first_names | self.second_names

    def includes(self, message: Message) -> bool:
        return (message.sender in self.first_names and message.target in self.second_names) or (
            message.sender in self.second_names and message.target in self.first_names
        )


@dataclass(frozen=True)
class RepliesDisplayScope(AnyTargetDisplayScope, DMDisplayScope):
    """Peer requests, direct or channel-addressed, and every reply by the first participant."""

    @property
    def condition(self) -> tuple[str, tuple]:
        names = BoundSet(self.first_names | self.second_names)
        return names.within("{sender}"), names.parameters

    def includes(self, message: Message) -> bool:
        return message.sender in self.first_names or (
            message.sender in self.second_names
            and any(message.awaits_answer_from(ThreadTarget(name)) for name in self.first_names)
        )


@dataclass(frozen=True, slots=True)
class ListedDeliveries(MessageDisplayScope):
    """The messages of another scope whose sequences the route index listed."""

    scope: MessageDisplayScope
    sequences: frozenset[int]
    targets: frozenset[str]

    @property
    def index_targets(self) -> frozenset[str]:
        return self.targets

    @property
    def condition(self) -> tuple[str, tuple]:
        sequences = BoundSet(self.sequences)
        return sequences.within("{seq}"), sequences.parameters

    def includes(self, message: Message) -> bool:
        return message.seq in self.sequences and self.scope.includes(message)


@dataclass(frozen=True, slots=True)
class ChannelDisplayScope(MessageDisplayScope):
    """One captured local display predicate; it never changes delivery or history ownership."""

    channel: str
    targets: frozenset[str]
    displayed: DisplayBasis | None = field(default=None, compare=False)

    def target_values[V](self, values: Mapping[str, V]) -> Iterable[V]:
        return (values[target] for target in self.targets if target in values)

    def activity(self, source: BusReader):
        return source.target_activity(*self.index_predicate)

    @property
    def index_targets(self) -> frozenset[str]:
        return self.targets

    def lower_bound(self, cursor: ReadCursor, snapshot: RegistryProvenance) -> int:
        return min((cursor.for_conversation(ChannelConversation(target)).high_water
                    for target in self.index_targets), default=0)

    @property
    def condition(self) -> tuple[str, tuple]:
        targets = BoundSet(self.index_targets)
        return targets.within("{target}"), targets.parameters

    def identity(self, history_revision: FileObservation) -> ChannelDisplayIdentity:
        displayed = self.require_displayed()
        return ChannelDisplayIdentity(
            viewer=displayed.viewer_identity, bus_identity=displayed.bus_identity,
            scope=self, history_revision=history_revision,
        )

    def require_displayed(self) -> DisplayBasis:
        if self.displayed is None:
            raise DMPaintedBoundChanged()
        return self.displayed

    def includes(self, message: Message) -> bool:
        return message.target in self.targets


@dataclass(frozen=True, slots=True)
class AllTargetsDisplayScope(AnyTargetDisplayScope, ChannelDisplayScope, declared_name=None):
    """The complete wire or a participant's activity across arbitrary targets."""

    targets: frozenset[str] = frozenset()

    @property
    def condition(self) -> tuple[str, tuple]:
        return "1", ()

    def includes(self, message: Message) -> bool:
        return True


@dataclass(frozen=True, slots=True)
class AllChannelDisplayScope(AllTargetsDisplayScope):
    """Only the complete wire view can acknowledge every conversation at once."""

    def capture_all(self, reads: ReadLedger, viewer: str, snapshot: RegistrySnapshot,
                    source: BusSnapshot, *, document: ReadDocument, through: int) -> DisplayBasis:
        return DisplayBasis(viewer, snapshot.require(viewer).incarnation.wire_birth,
            (DisplayedConversation(AllConversation(), (), through),),
            RecordedBus(source.identity))


@dataclass(frozen=True, slots=True)
class MemberActivityDisplayScope(AllTargetsDisplayScope):
    """Member activity may match a sender, DM peer or mention on any target."""

    participant_names: frozenset[str] = frozenset()

    def capture_deliveries(self, reads: ReadLedger, viewer: str, snapshot: RegistrySnapshot,
                           source: BusSnapshot, *, document: ReadDocument,
                           audience: MessageDisplayScope, through: int) -> DisplayBasis:
        # Partial channel selections acknowledge exact rows, never unseen prefixes.
        rows = source.selected_sequences(*self.intersection(audience), through)
        return reads.capture(viewer, rows, snapshot, source, document=document)

    @classmethod
    def capture(cls, channel: ChannelHistorySource, snapshot: RegistryNames[TaggedThreadSource]) -> MemberActivityDisplayScope:
        members = frozenset(name for name, thread in snapshot.threads.items()
                            if channel.tags <= thread.tags)
        names = members | frozenset(alias for alias, owner in snapshot.aliases.items()
                                    if owner in members)
        return cls(channel.name, channel.history_targets, participant_names=names)

    @property
    def condition(self) -> tuple[str, tuple]:
        targets, names = BoundSet(self.targets), BoundSet(self.participant_names)
        mention_key = FieldCodec.field_plan(ThreadMention, "thread").key
        return (f"{targets.within('{target}')} OR {names.within('{sender}')} OR "
                f"({{target}} NOT LIKE '#%' AND {names.within('{target}')}) OR "
                f"EXISTS (SELECT 1 FROM json_each({{mentions}}) "
                f"WHERE {names.within('json_extract(value,?)')})",
                (*targets.parameters, *names.parameters, *names.parameters, f"$.{mention_key}",
                 *names.parameters))

    def includes(self, message: Message) -> bool:
        return self._includes(message.sender, message.target,
                              (mention.thread for mention in message.mentions))

    def activity(self, source: BusReader):

        return ChannelActivity.combine((
            ChannelDisplayScope(self.channel, self.targets).activity(source),
            source.participant_activity(self.participant_names),
        ))

    def _includes(self, sender: str, target: str, mentions: Iterable[str]) -> bool:
        return (target in self.targets or sender in self.participant_names
                or not self.participant_names.isdisjoint(CommandTarget.named(target).direct_names)
                or any(name in self.participant_names for name in mentions))


@dataclass(frozen=True, slots=True)
class UnreadQuery:
    """Every value one channel's unread count reads. Equal queries count the same rows, so
    only the rows appended since an earlier count of an equal query need counting; the
    registry revision they were resolved from is not one of them. A query whose read cursor
    moved for some conversations differs from its earlier count only in those
    conversations' rows above the lower of their two high waters."""

    channel: str
    cursors: tuple[CursorRow, ...]
    lower_bound: int
    predicate: str
    parameters: tuple
    viewer_names: str

    @property
    def counting(self) -> UnreadQuery:
        """The same rows and rule with no read cursor: what stays fixed while reading. The
        lower bound is the cursor's own floor over the scope's targets, so it moves with it."""
        return replace(self, cursors=(), lower_bound=0)

    def moved(self, earlier: UnreadQuery) -> tuple[UnreadQuery, ...]:
        """The earlier and current counts over only the conversations whose cursor moved;
        none when a whole-bus read moved and every row may have changed."""
        before = {row.key: row for row in earlier.cursors}
        after = {row.key: row for row in self.cursors}
        changed = {key for key in before.keys() | after.keys() if before.get(key) != after.get(key)}
        rows = tuple(side[key] for side in (before, after) for key in changed if key in side)
        if any(row.whole_bus for row in rows):
            return ()
        # A key with no cursor on one side has read nothing there. A read of the newest rows
        # leaves the high water where it was and adds exceptions above it, so the floor is the
        # first sequence the two cursors read differently, not the high water.
        cursors = [{key: row.cursor for key, row in side.items()} for side in (before, after)]
        floor = min(cursors[0].get(key, ConversationCursor()).agrees_through(
            cursors[1].get(key, ConversationCursor())) for key in changed)
        targets = BoundSet(frozenset(row.target for row in rows))
        return earlier.within(targets, floor), self.within(targets, floor)

    def within(self, targets: BoundSet[str], floor: int) -> UnreadQuery:
        """This query over only these targets' rows above floor; every row at or below a
        moved conversation's lower high water is read under both cursors."""
        return replace(self, lower_bound=max(self.lower_bound, floor),
                       predicate=f"({self.predicate}) AND {targets.within('target')}",
                       parameters=(*self.parameters, *targets.parameters))
