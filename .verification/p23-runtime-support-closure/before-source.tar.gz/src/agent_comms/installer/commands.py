"""Process execution, diagnostics and timing for one installation."""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from collections.abc import Iterator, Mapping
from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack, contextmanager, nullcontext
from dataclasses import dataclass, field
from pathlib import Path
from threading import Lock
from typing import BinaryIO

from agent_comms.execution.child_process import SpawnedProcess, SynchronousProcess
from agent_comms.installer.interpreter_operation import (
    CommandPhase,
    GitPhase,
    InstallClock,
    InstalledProgram,
    InstallPhase,
    PhaseTiming,
    ProbeProgram,
    ProbeReply,
    ProbeRequest,
    RuntimeProbe,
    RuntimeWorkerClosePhase,
    WorkerClosePhase,
)
from agent_comms.installer.native_build_inputs import ConfiguredChildStdio
from agent_comms.installer.refusals import InterpreterWorkerDied, UpgradeRefused
from agent_comms.launch_runtime import LaunchRuntime
from agent_comms.nominal.field_codec import FieldCodec
from agent_comms.projects.git_errors import GitCommandError
from agent_comms.projects.repo import Repo
from agent_comms.storage.maintenance_barrier import MaintenanceHolder


@dataclass(frozen=True)
class InterpreterWorkerKey:
    python: Path
    program: ProbeProgram
    cwd: Path
    environment: tuple[tuple[str, str], ...]

    def print_forced(self, summary: str) -> None:
        print(
            f"Interpreter worker {self.python} {self.program} required force: {summary}",
            file=sys.stderr, flush=True,
        )



@dataclass
class InterpreterWorker:
    """One interpreter answering requests on its own pipes; stderr is kept for refusals."""

    child: SpawnedProcess
    requests: BinaryIO
    answers: BinaryIO
    diagnostics: BinaryIO
    exchange_lock: Lock = field(default_factory=Lock)

    @classmethod
    def start(cls, key: InterpreterWorkerKey) -> InterpreterWorker:
        with ExitStack() as owned:
            diagnostics = owned.enter_context(tempfile.TemporaryFile())
            request_read, request_write = os.pipe()
            answer_read, answer_write = os.pipe()
            requests = owned.enter_context(os.fdopen(request_write, "wb"))
            answers = owned.enter_context(os.fdopen(answer_read, "rb"))
            try:
                child = SpawnedProcess.launch(
                    (str(key.python), "-P", *map(str, key.program.entry())), cwd=key.cwd,
                    env=dict(key.environment), runtime=LaunchRuntime(key.python),
                    pass_fds=key.program.descriptors,
                    stdio=ConfiguredChildStdio(
                        stdin=request_read, stdout=answer_write, stderr=diagnostics),
                )
            finally:
                os.close(request_read)
                os.close(answer_write)
            worker = cls(child, requests, answers, diagnostics)
            owned.pop_all()
        return worker

    def errors(self) -> str:
        self.diagnostics.seek(0)
        return self.diagnostics.read().decode(errors="replace").strip()

    def exchange(self, encoded: str) -> str:
        with self.exchange_lock:
            self.requests.write((encoded + "\n").encode())
            self.requests.flush()
            answer = self.answers.readline()
            if not answer:
                raise InterpreterWorkerDied(self.child.reap(), self.errors())
            return answer.decode()

    def finish(self) -> None:
        """Closing its requests ends the worker's loop, so its interpreter starts exiting."""
        self.requests.close()

    def close(self) -> None:
        """Close a retired worker's streams; the batch owns its process retirement."""
        with ExitStack() as closing:
            closing.callback(self.diagnostics.close)
            closing.callback(self.answers.close)
            closing.callback(self.child.close_streams)


@dataclass
class InstallCommands:
    """The commands one install runs. Its stacks and steps run every command through it,
    and the install's log and result both read what it ran."""

    clock: InstallClock = field(default_factory=InstallClock)
    workers: dict[InterpreterWorkerKey, InterpreterWorker] = field(default_factory=dict, init=False)
    worker_lock: Lock = field(default_factory=Lock, init=False)
    launcher: ThreadPoolExecutor = field(
        default_factory=lambda: ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="install-launch"),
        init=False,
    )

    def __enter__(self) -> InstallCommands:
        return self

    def close_workers(self, keys: tuple[InterpreterWorkerKey, ...]) -> None:
        """Finish every worker, retire its children in one batch, then close all streams."""
        with self.worker_lock, ExitStack() as exits:
            closing = tuple((key, self.workers.pop(key)) for key in keys)
            for _, worker in closing:
                exits.callback(worker.close)
            try:
                with ExitStack() as requests:
                    for _, worker in closing:
                        requests.callback(worker.finish)
            finally:
                outcomes = SynchronousProcess.stop_together(tuple(
                    (worker.child, nullcontext) for _, worker in closing
                ))
                for (key, _), outcome in zip(closing, outcomes, strict=True):
                    outcome.report_forced(key.print_forced)

    def close_program(self, python: Path, program: ProbeProgram) -> None:
        """Retire borrowers before the parent releases their inherited file locks."""
        self.close_workers(tuple(key for key in self.workers
                                 if key.python == python and key.program == program))

    def close_runtime(self, python: Path) -> None:
        with RuntimeWorkerClosePhase(python).running(self.clock):
            self.close_workers(tuple(key for key in self.workers if key.python == python))

    def close(self) -> None:
        with WorkerClosePhase().running(self.clock):
            try:
                self.close_workers(tuple(self.workers))
            finally:
                self.launcher.shutdown(wait=True)

    def __exit__(self, *_: object) -> None:
        self.close()

    @contextmanager
    def timing(self, phase: InstallPhase) -> Iterator[PhaseTiming]:
        print("+", phase.label(), file=sys.stderr, flush=True)
        with phase.running(self.clock) as measured:
            yield measured
        print("=", measured.line(), file=sys.stderr, flush=True)

    def run(self, *command: str | Path, cwd: Path = Path(),
            env: Mapping[str, str] = os.environ) -> str:
        argv = tuple(map(str, command))
        with self.timing(CommandPhase(argv)):
            completed = subprocess.run(argv, cwd=cwd, env=env,
                                       capture_output=True, text=True)
        if completed.returncode:
            raise UpgradeRefused(f"{command[0]} failed: {completed.stdout.strip()}\n"
                                 f"{completed.stderr.strip()}")
        return completed.stdout

    def git(self, checkout: Path, *args: str) -> str:
        """Git through the one runner (``Repo.git``), timed like every install command."""
        with self.timing(GitPhase(checkout, args)):
            try:
                return Repo.git(checkout, *args)
            except GitCommandError as error:
                raise UpgradeRefused(str(error)) from error

    def probe[Answer](self, probe: RuntimeProbe[Answer], python: Path, *,
                      cwd: Path = Path(), env: Mapping[str, str] = os.environ,
                      program: ProbeProgram = InstalledProgram()) -> Answer:
        key = InterpreterWorkerKey(python, program, cwd.absolute(),
                                   tuple(sorted(MaintenanceHolder.outside(env).items())))
        with self.timing(probe.install_phase()) as measured:
            with self.worker_lock:
                if key not in self.workers:
                    # Linux binds a child's lifetime to its launching thread. Keep that
                    # thread until all workers close, including calls from short-lived pools.
                    self.workers[key] = self.launcher.submit(InterpreterWorker.start, key).result()
                worker = self.workers[key]
            try:
                answer = worker.exchange(FieldCodec.compact(FieldCodec.encode(
                    ProbeRequest(probe, MaintenanceHolder.current().request_text()))))
            except InterpreterWorkerDied:
                self.close_workers((key,))
                raise
            reply = FieldCodec.decode(ProbeReply, FieldCodec.parse(answer))
            self.clock.include(reply.phases, measured)
            return FieldCodec.decode(probe.answer_type(), reply.answer)

