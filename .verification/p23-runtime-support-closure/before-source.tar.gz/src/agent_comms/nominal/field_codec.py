"""Strict JSON boundary conversion derived from dataclass store_files."""

from __future__ import annotations

import annotationlib
import argparse
import hashlib
import inspect
import json
import math
import os
import re
import sys
import types
from abc import ABC, abstractmethod
from collections.abc import Callable, Collection, Hashable, Iterable, Iterator, Mapping, Sequence
from contextvars import ContextVar
from dataclasses import MISSING, Field, dataclass, field, fields, is_dataclass
from datetime import datetime
from enum import Enum, IntFlag
from functools import cache, cached_property, lru_cache, partial, reduce
from operator import or_
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Annotated,
    ClassVar,
    Literal,
    Never,
    Protocol,
    Self,
    TypeGuard,
    TypeVar,
    Union,
    cast,
    get_args,
    get_origin,
    get_type_hints,
    overload,
)
from urllib.parse import quote
from uuid import uuid4
from weakref import WeakKeyDictionary

from metaclass_registry.mro_dispatch import (
    MroDispatch,
    handles,
)
from pydantic import BaseModel, GetCoreSchemaHandler, JsonValue
from pydantic_core import core_schema
from python_introspect import declared_field_label
from typing_extensions import TypeAliasType, TypeForm

from agent_comms.nominal.declared_family import DeclaredFamily, FamilyMeta
from agent_comms.nominal.json_schema import JsonScalar, JsonSchemaOwner
from agent_comms.nominal.sealed import Sealed

if TYPE_CHECKING:
    from _typeshed import DataclassInstance

    from agent_comms.registration_inheritance import RegistrationInheritance

T = TypeVar("T")



@dataclass
class SchemaDefinition:
    """One declaration's schema inside one document, never an equal-shaped substitute."""

    declaration: object
    name: str
    schema: dict[str, JsonValue] = field(default_factory=dict)
    uses: int = 0

    @property
    def reference(self) -> str:
        return f"#/$defs/{self.name}"

    def worth_sharing(self) -> bool:
        body = len(json.dumps(self.schema, separators=(',', ':')))
        reference = len(json.dumps({'$ref': self.reference}, separators=(',', ':')))
        definition = len(json.dumps(self.encoded(), separators=(',', ':'))) + len(self.name) + 3
        return body * self.uses > definition + reference * self.uses

    def encoded(self) -> dict[str, JsonValue]:
        return {'$comment': str(self.declaration), **self.schema}


@dataclass
class SchemaDefinitions:
    """A schema build owns its declarations and emits repeated ones once through $defs."""

    definitions: dict[object, SchemaDefinition] = field(default_factory=dict)
    current: ClassVar[ContextVar[SchemaDefinitions | None]] = ContextVar('schema_document', default=None)

    @classmethod
    def build(cls, render: Callable[[], dict[str, JsonValue]]) -> dict[str, JsonValue]:
        if cls.current.get() is not None:
            return render()
        document = cls()
        token = cls.current.set(document)
        try:
            return document.finish(render())
        finally:
            cls.current.reset(token)

    @classmethod
    def value(cls, declaration: object, render: Callable[[], dict[str, JsonValue]]) -> dict[str, JsonValue]:
        def reference() -> dict[str, JsonValue]:
            document = cls.current.get()
            assert document is not None  # build owns the synchronous schema scope.
            return document.reference(declaration, render)
        return cls.build(reference)

    def reference(self, declaration: object,
                  render: Callable[[], dict[str, JsonValue]]) -> dict[str, JsonValue]:
        if declaration not in self.definitions:
            definition = SchemaDefinition(declaration, f'd{len(self.definitions)}')
            self.definitions[declaration] = definition
            definition.schema = render()
        definition = self.definitions[declaration]
        definition.uses += 1
        return {'$ref': definition.reference}

    def finish(self, schema: dict[str, JsonValue]) -> dict[str, JsonValue]:
        references = {definition.reference: definition for definition in self.definitions.values()}
        shared = {reference for reference, definition in references.items()
                  if definition.worth_sharing()}

        def resolve(value: JsonValue) -> JsonValue:
            if isinstance(value, list):
                return [resolve(item) for item in value]
            if not isinstance(value, dict):
                return value
            return resolve_record(value)

        def resolve_record(value: dict[str, JsonValue]) -> dict[str, JsonValue]:
            # A represented model owns a separate JSON Schema resource and its references.
            if '$id' in value:
                return value
            reference = value.get('$ref')
            if isinstance(reference, str) and reference in references and reference not in shared:
                definition = references[reference]
                return {**resolve_record(definition.schema),
                        **{key: resolve(item) for key, item in value.items() if key != '$ref'}}
            return {key: resolve(item) for key, item in value.items()}

        result = resolve_record(schema)
        definitions = {definition.name: resolve_record(definition.encoded())
                       for reference, definition in references.items() if reference in shared}
        if definitions:
            if '$defs' in result:
                raise TypeError('A schema document already declares its own $defs')
            result['$defs'] = definitions
        return result


class UnsupportedFieldType(TypeError):
    """A declaration has no codec, distinct from a malformed supported declaration."""


class MalformedRecord(ValueError):  # noqa: N818 - names the refused data
    """Data that does not satisfy its declaration.

    Every data refusal at the JSON and record boundary raises this. A broken
    declaration stays a TypeError and is never caught at a data boundary.
    """

    def located(self, name: str, fix: str) -> dict[str, str]:
        return {name: f"{self}; fix: {fix}"}

    @classmethod
    def refusing(cls, subject: str) -> Refusing:
        return Refusing(subject)

    def known_located(self, name: str, fix: str) -> dict[str, str]:
        return self.located(name, fix)

    def nested_unknown(self, owner: DecoderPlan, prefix: tuple[str, ...]) -> tuple[UnknownField, ...]:
        return ()


def boundary_decoder[D: Callable[..., object]](decoder: D) -> D:
    """Declares a decoder that meets absence from outside, so its None spellings are not debt."""
    return decoder


@dataclass(frozen=True, slots=True)
class RefusalBoundary[Suppressed: bool]:
    """Shared exception handling; each boundary declares whether it can suppress a refusal."""

    subject: str

    def __enter__(self) -> None:
        return None

    @boundary_decoder
    def __exit__(
        self, kind: type[BaseException] | None, error: BaseException | None,
        trace: types.TracebackType | None,
    ) -> Suppressed | Literal[False]:
        """The interpreter passes None for a block that raised nothing."""
        if error is None:
            return False
        try:
            raise error
        except MalformedRecord as refused:
            return self.refused(refused)
        except ValueError as refused:
            malformed = MalformedRecord(f"{self.subject}: {refused}")
            malformed.__cause__ = refused
            return self.refused(malformed)

    @abstractmethod
    def refused(self, error: MalformedRecord) -> Suppressed: ...


class Refusing(RefusalBoundary[Never]):
    """A normal decode never suppresses its error or falls through without a value."""

    def refused(self, error: MalformedRecord) -> Never:
        raise error


@dataclass(frozen=True, slots=True)
class Collecting(RefusalBoundary[Literal[True]]):
    """The same data boundary collects a sibling refusal instead of stopping at it."""

    problems: dict[str, str]
    fix: str

    def refused(self, error: MalformedRecord) -> Literal[True]:
        self.problems.update(error.located(self.subject, self.fix))
        return True


@dataclass(frozen=True)
class UnknownField:
    """An undeclared input's path; its enclosing decoder supplies the declared destinations."""

    owner: DecoderPlan
    path: tuple[str, ...]

    def enclosed(self, owner: DecoderPlan, prefix: tuple[str, ...]) -> UnknownField:
        return type(self)(owner, (*prefix, *self.path))

    def describe(self) -> str:
        name = self.path[-1]
        destinations = sorted(set(self.owner.field_paths(name)) - {self.path})
        if not destinations:
            return 'Unknown fields; fix: remove this field'
        parents = ' or '.join('.'.join(path[:-1]) or 'the top level' for path in destinations)
        paths = ' or '.join('.'.join(path) for path in destinations)
        return f'{name} belongs under {parents}; fix: move {name} to {paths}'


class RecordProblems(MalformedRecord):
    """Sibling failures keep paths and unknown-field identities until their outer declaration."""

    def __init__(self, problems: Mapping[str, str], unknown: tuple[UnknownField, ...] = ()):
        self.known = types.MappingProxyType(dict(problems))
        self.unknown = unknown
        super().__init__()

    def __str__(self) -> str:
        return "\n".join(f"{name}: {problem}" for name, problem in self.problems.items())

    @property
    def problems(self) -> dict[str, str]:
        return {**self.known, **{'.'.join(item.path): item.describe() for item in self.unknown}}

    def located(self, name: str, fix: str) -> dict[str, str]:
        return {f"{name}.{path}": problem for path, problem in self.problems.items()}

    def known_located(self, name: str, fix: str) -> dict[str, str]:
        return {f"{name}.{path}": problem for path, problem in self.known.items()}

    def nested_unknown(self, owner: DecoderPlan, prefix: tuple[str, ...]) -> tuple[UnknownField, ...]:
        return tuple(item.enclosed(owner, prefix) for item in self.unknown)

    @staticmethod
    def collecting(problems: dict[str, str], name: str, fix: str) -> Collecting:
        """Run one check through the existing boundary, preserving nested field paths."""
        return Collecting(name, problems, fix)


class FieldDirective:
    """An annotation owns its instructions by directive type, never a string key."""

    @staticmethod
    @cache
    def _index(annotation: object) -> Mapping[type, tuple[object, ...]]:
        """Compile a declaration's metadata once, indexed by every class of each item's MRO:
        looking up a directive class finds exactly its instances."""
        found: dict[type, list[object]] = {}
        if get_origin(annotation) is Annotated:
            for item in get_args(annotation)[1:]:
                for capability in type(item).__mro__:
                    found.setdefault(capability, []).append(item)
        return types.MappingProxyType({kind: tuple(items) for kind, items in found.items()})

    @classmethod
    def on(cls, annotation: object) -> tuple[Self, ...]:
        return cast(tuple[Self, ...], cls._index(annotation).get(cls, ()))

    @classmethod
    def single(cls, annotation: object) -> tuple[Self, ...]:
        matches = cls.on(annotation)
        if len(matches) > 1:
            raise TypeError(f"A field declares {cls.__name__} more than once")
        return matches


@dataclass(frozen=True, eq=False)
class ValueDirective[V](FieldDirective):
    value: V

    @classmethod
    def read[D](cls, annotation: object, default: D) -> V | D:
        for directive in cls.single(annotation):
            return directive.value
        return default


@dataclass(frozen=True)
class FlagDirective(ValueDirective[bool]):
    value: bool = True


class ViewName(ValueDirective[str], DeclaredFamily, affix="Name"):
    """A field's declared key in one encoded view."""


class ViewExclusion(FlagDirective, DeclaredFamily, affix="Exclude"):
    """The nominal encoded view owns exclusion and optional field naming."""

    @classmethod
    def key_in(cls, annotation: object, default: str) -> str:
        return default


class WireName(ViewName):
    pass


class WireOrder(ValueDirective[int]):
    pass


class WireRequired(FlagDirective):
    pass


class NullPolicy(FieldDirective, ABC):
    @abstractmethod
    def rejects_null(self, declared: Field) -> bool: ...


class WireNonNull(FlagDirective, NullPolicy):
    def rejects_null(self, declared: Field) -> bool:
        return self.value


@boundary_decoder
def default_holds_value(declared: Field) -> bool:
    """A dataclass spells a declared ``= None`` default as None; that, or a declared null
    member, is a default holding no value."""
    return declared.default is not None and NullPresence.holds_value(declared.default)


class DefaultNonNull(NullPolicy):
    def rejects_null(self, declared: Field) -> bool:
        return default_holds_value(declared)


class WireChoices(ValueDirective[Callable[[], Iterable[str]]]):
    pass


class WireOmitDefault(FlagDirective):
    pass


class WireNullDefault(FlagDirective):
    """An explicit external null has the same meaning as an omitted field."""


class WireTransient(FlagDirective):
    pass


class WireAbsentNone(FlagDirective):
    pass


class WireContext(FlagDirective):
    pass


class WireBind(ValueDirective[Mapping[str, str]]):
    pass


class WireInline(FlagDirective):
    pass


class Description(ValueDirective[str]):
    pass


class DisclosureIdentity(FlagDirective):
    """Fields that identify the same entity across read-only disclosure refreshes.

    A marked record field derives its identity through that record's declarations;
    an immutable nominal identity supplies its existing equality and hash contract.
    """


class WireExclude(ViewExclusion):
    pass


class ActivityExclude(ViewExclusion):
    pass


class SnapshotExclude(ViewExclusion):
    @classmethod
    def key_in(cls, annotation: object, default: str) -> str:
        return SnapshotName.read(annotation, default)


class HudExclude(ViewExclusion):
    pass


class StatusExclude(ViewExclusion):
    pass


class ReportExclude(ViewExclusion):
    pass


class ArgumentsExclude(ViewExclusion):
    pass


class ContentExclude(ViewExclusion):
    pass


class PublicationExclude(ViewExclusion):
    pass


class PresenceExclude(ViewExclusion):
    pass


class PublicExclude(ViewExclusion):
    pass


class HistoryExclude(ViewExclusion):
    pass


class ArtifactExclude(ViewExclusion):
    pass


class CatalogExclude(ViewExclusion):
    pass


class SealExclude(ViewExclusion):
    pass


class IdentityExclude(ViewExclusion):
    pass


class SnapshotName(ViewName):
    pass


class Normalize(ValueDirective[Callable[[object], object]]):
    pass


class EditorFormat(ValueDirective[Callable[[object], JsonValue]]):
    pass


class Editor(ValueDirective[type]):
    pass


class Catalog(ValueDirective[type]):
    pass


class Multiline(FlagDirective):
    pass


class TargetBound(FlagDirective):
    pass


type RegistrationPolicyValue = type[RegistrationInheritance]


class RegistrationPolicy(ValueDirective[RegistrationPolicyValue]):
    pass


class SlicePolicy(ValueDirective[type]):
    pass


class NativeContext(ValueDirective[object]):
    pass


class NativeScope(FlagDirective):
    pass


class RuntimeScope(FlagDirective):
    pass


class WatchPaths(ValueDirective[Callable[..., tuple[Path, ...]]]):
    pass


class WatchViews(ValueDirective[tuple[type, ...]]):
    pass


class Differs(ValueDirective[Callable[[object, object], bool]]):
    pass


class ContextSource(ValueDirective[type]):
    pass


class ArgumentDefault(ABC):
    """One declared parser-default policy; constructor defaults stay with the field."""

    @abstractmethod
    def options(self, plan: FieldPlan) -> Mapping[str, object]: ...


@dataclass(frozen=True)
class InferredArgumentDefault(ArgumentDefault):
    """An absent option stays absent. The constructor's declaration, not argparse,
    reports required fields beside every other decoding refusal."""

    def options(self, plan: FieldPlan) -> Mapping[str, object]:
        return {"default": argparse.SUPPRESS}


@dataclass(frozen=True)
class GivenArgumentDefault(ArgumentDefault):
    value: object

    def options(self, plan: FieldPlan) -> Mapping[str, object]:
        return {"default": self.value}


@dataclass(frozen=True)
class FactoryArgumentDefault(ArgumentDefault):
    factory: Callable[[], object]

    def options(self, plan: FieldPlan) -> Mapping[str, object]:
        return {"default": self.factory()}


class ArgumentGroup:
    """Ungrouped arguments belong directly to their parser."""

    def owner(
        self, parser: argparse.ArgumentParser, groups: dict[str, argparse._MutuallyExclusiveGroup]
    ) -> argparse._ActionsContainer:
        return parser


@dataclass(frozen=True)
class NamedArgumentGroup(ArgumentGroup):
    name: str

    def owner(
        self, parser: argparse.ArgumentParser, groups: dict[str, argparse._MutuallyExclusiveGroup]
    ) -> argparse._ActionsContainer:
        if self.name not in groups:
            groups[self.name] = parser.add_mutually_exclusive_group(required=True)
        return groups[self.name]


@dataclass(frozen=True, eq=False)
class Argument(FieldDirective):
    """The CLI's argument declaration, including its external argparse options."""

    flags: tuple[str, ...] = ()
    group: ArgumentGroup = field(default_factory=ArgumentGroup)
    default: ArgumentDefault = field(default_factory=InferredArgumentDefault)
    options: Mapping[str, object] = field(default_factory=dict)

    @classmethod
    def declared(cls, annotation: object) -> Argument:
        for argument in cls.single(annotation):
            return argument
        return cls()

    def description(self, name: str) -> str:
        return FieldCodec.decode(str, self.options.get("help", name.replace("_", " ").capitalize()))

    def flags_for(self, name: str) -> tuple[str, ...]:
        return self.flags or ("--" + name.replace("_", "-"),)

    def words(self, name: str, text: object) -> tuple[str, ...]:
        """The command-line words ``add_to``'s argument reads back as ``text``."""
        flag = self.flags_for(name)[0]
        return (f"{flag}={text}",) if flag.startswith("-") else (str(text),)

    def add_to(
        self,
        parser: argparse.ArgumentParser,
        groups: dict[str, argparse._MutuallyExclusiveGroup],
        plan: FieldPlan,
    ) -> None:
        owner = self.group.owner(parser, groups)
        # argparse actions own an extensible keyword protocol, not a closed Core record.
        options: Mapping[str, object] = {
            **({} if "action" in self.options else plan.value.argument_options(self)),
            **self.options,
            **self.default.options(plan),
        }
        flags = self.flags_for(plan.name)
        if any(flag.startswith("-") for flag in flags):
            options = {**options, "dest": plan.key}
        else:
            options = {key: value for key, value in options.items() if key != "required"}
        owner.add_argument(*flags, **options)


class ViewColumn(ABC):
    """Stored and computed fields expose one read-only presentation contract."""

    @property
    @abstractmethod
    def name(self) -> str: ...

    @property
    @abstractmethod
    def annotation(self) -> object: ...

    @property
    def label(self) -> str:
        return declared_field_label(self.annotation) or self.name.replace("_", " ").title()

    @abstractmethod
    def current(self, record: object) -> object: ...

    def excluded_in(self, view: type[ViewExclusion]) -> bool:
        return view.read(self.annotation, False)

    def minimum_width(self, values: Iterable[str]) -> int:
        """Keep headers and individual words intact while the viewport can afford them."""
        return max(len(self.label), max((len(word) for value in values for word in value.split()), default=0))

    @staticmethod
    def fit_widths(weights: Iterable[int], available: int,
                   minimums: Iterable[int]) -> tuple[int, ...]:
        """Allocate measured content proportionally after retaining readable words."""
        weights = tuple(max(1, weight) for weight in weights)
        available = min(available, sum(weights))
        minimums = tuple(minimums)
        if sum(minimums) > available:
            return minimums
        flexible = max(0, available - sum(minimums))
        demands = tuple(max(0, weight - minimum) for weight, minimum in zip(weights, minimums))
        demands = demands if sum(demands) else weights
        total, used = sum(demands), 0
        widths = []
        for demand, minimum in zip(demands, minimums):
            end = used + demand
            widths.append(minimum + flexible * end // total - flexible * used // total)
            used = end
        return tuple(widths)


@dataclass(frozen=True)
class FieldPlan(ViewColumn):
    """One field's wire keys, checks and compiled value decoder."""

    declared: Field
    _annotation: object
    directives: ClassVar[tuple[type[ValueDirective], ...]] = ()
    records: ClassVar[bool] = True
    _plans: ClassVar[list[type[FieldPlan]]] = []

    def __init_subclass__(cls):
        super().__init_subclass__()
        FieldPlan._plans.append(cls)

    @classmethod
    def claims(cls, declared: Field, annotation: object) -> bool:
        return any(directive.read(annotation, False) for directive in cls.directives)

    @property
    def name(self) -> str:
        return self.declared.name

    @property
    def annotation(self) -> object:
        return self._annotation

    @cached_property
    def key(self) -> str:
        return WireName.read(self.annotation, self.name)

    @property
    def fix(self) -> str:
        return f"supply {self.annotation}"

    def locate(self, problems: dict[str, str], refused: MalformedRecord) -> None:
        """Known problems only; a decoder plan encloses unknown fields itself (unknown_under)."""
        problems.update(refused.known_located(self.key, self.fix))

    def locate_all(self, problems: dict[str, str], refused: MalformedRecord) -> None:
        """Known and unknown problems together, for a decoder with no plan to enclose them."""
        problems.update(refused.located(self.key, self.fix))

    def field_paths(self, key: str, seen: frozenset[type]) -> tuple[tuple[str, ...], ...]:
        direct = ((self.key,),) if self.key == key else ()
        return direct + tuple((self.key, *path) for path in self.value.field_paths(key, seen))

    def unknown_under(self, refused: MalformedRecord, owner: DecoderPlan) -> tuple[UnknownField, ...]:
        return refused.nested_unknown(owner, (self.key,))

    @cached_property
    def required(self) -> bool:
        return WireRequired.read(self.annotation, False)

    @cached_property
    def reject_null(self) -> bool:
        return any(
            policy.rejects_null(self.declared) for policy in NullPolicy.single(self.annotation)
        )

    @cached_property
    def choices(self) -> tuple[str, ...] | None:
        for choices in WireChoices.single(self.annotation):
            return tuple(choices.value())
        return None

    @cached_property
    def omit_default(self) -> bool:
        return WireOmitDefault.read(self.annotation, False)

    def key_in(self, view: type[ViewExclusion]) -> str:
        return view.key_in(self.annotation, self.key)

    @cached_property
    def value(self) -> ValueDecoder[object]:
        return compile_decoder(self.annotation)

    @property
    def constructor_required(self) -> bool:
        return self.declared.default is MISSING and self.declared.default_factory is MISSING

    def setting[V, D](self, directive: type[ValueDirective[V]], default: D) -> V | D:
        return directive.read(self.annotation, default)

    def current(self, record: object) -> object:
        return cast(object, getattr(record, self.name))

    @cached_property
    def argument_normalizer(self) -> Callable[[object], object]:
        return self.setting(Normalize, self.value.argument_payload)

    @cached_property
    def editor_normalizer(self) -> Callable[[object], object]:
        return self.setting(Normalize, self.value.decode_editor)

    @cached_property
    def editor_formatter(self) -> Callable[[object], JsonValue]:
        return self.setting(EditorFormat, self.value.encode_editor)

    def argument_payload(self, value: object) -> object:
        return self.argument_normalizer(value)

    def argument_words(self, encoded: object) -> tuple[str, ...]:
        """The command-line spelling ``argument_payload`` decodes back to ``encoded``."""
        return Argument.declared(self.annotation).words(
            self.name, self.value.argument_text(encoded)
        )

    def editor_payload(self, value: object) -> object:
        return self.editor_normalizer(value)

    def editor_default(self, value: object) -> JsonValue:
        return self.editor_formatter(value)

    @property
    def description(self) -> str:
        return Argument.declared(self.annotation).description(self.name)

    def add_argument(
        self, parser: argparse.ArgumentParser, groups: dict[str, argparse._MutuallyExclusiveGroup]
    ) -> None:
        Argument.declared(self.annotation).add_to(parser, groups, self)

    def contribute(self, fields):
        fields.append(self)
        return (self.key,)

    @property
    def wire_keys(self) -> tuple[str, ...]:
        return (self.key,)

    def encoded(self, value, *, key=None):
        return {key or self.key: value}

    def project_encoded[V](
        self, value: V, record: Callable[[Mapping[str, V]], V],
    ) -> V:
        """Project an already encoded field through its declared record shape."""
        return record({self.key: value})

    def schema_fields(self):
        annotation, declared = self.annotation, self.declared
        base = FieldCodec.representation(annotation)[0]
        if self.reject_null and get_origin(base) in (Union, types.UnionType):
            members = tuple(item for item in get_args(base) if item is not type(None))
            annotation = members[0] if len(members) == 1 else Union[members]  # noqa: UP007 - runtime tuple
        schema = FieldCodec.value_schema(annotation)
        # The declared annotation owns the field's directives; the null-free union rebuilt
        # above carries only its members.
        for description in Description.single(self.annotation):
            schema["description"] = description.value
        for choices in WireChoices.single(self.annotation):
            schema["enum"] = list(choices.value())
        if declared.default is not MISSING and default_holds_value(declared):
            schema["default"] = FieldCodec.encode(declared.default, annotation)
        return {self.key: schema}

    def default(self) -> object:
        declared = self.declared
        return declared.default if declared.default is not MISSING else (
            declared.default_factory() if declared.default_factory is not MISSING else MISSING
        )

    def omitted(self, value: object) -> bool:
        return bool(self.omit_default and value == self.default())

    def captured(self, data: object) -> dict[str, object]:
        if not isinstance(data, dict):
            raise MalformedRecord("Expected a record object.")
        return {self.name: data[self.key]} if self.key in data else {}

    def raw(self, data: object) -> object:
        values = self.captured(data)
        if self.name not in values:
            raise MalformedRecord(f"Missing required field {self.key}")
        return values[self.name]

    @boundary_decoder
    def decoded(self, data: object) -> dict[str, object]:
        return self.decoded_using(data, lambda raw: self.value.decode_bound(raw, {}))

    def decoded_bound(
        self, data: dict[str, object], context: Mapping[str, object]
    ) -> dict[str, object]:
        return self.decoded(data)

    def decoded_external(self, data: dict[str, object]) -> dict[str, object]:
        return self.decoded_using(data, lambda raw: self.value.decode_external(raw, data))

    def decoded_selected(self, data, keys, selections):
        return self.decoded_using(data, lambda value: self.value.decode_keys(value, keys, selections))

    def decoded_using(self, data: object, decode: Callable[[object], object]) -> dict[str, object]:
        captured = self.captured(data)
        if self.name not in captured:
            return {}
        value = captured[self.name]
        if self.reject_null and value is None:
            raise MalformedRecord(f"Null field {self.key}")
        if self.choices is not None and value not in self.choices:
            raise MalformedRecord(
                f"Field {self.key} must be one of: {', '.join(self.choices)}")
        return {self.name: decode(value)}

    def read(self, data: object) -> object:
        values = self.decoded(data)
        if self.name in values:
            return values[self.name]
        default = self.default()
        if default is MISSING:
            raise MalformedRecord(f"Missing required field {self.key}")
        return default


class DeclaredFieldPlan(FieldPlan):
    """The value representation declares its plan; ordinary fields declare this one."""

    @classmethod
    def claims(cls, declared: Field, annotation: object) -> bool:
        _, representation = FieldCodec.representation(annotation)
        return super().claims(declared, annotation) or representation.field_plan is cls


class TransientFieldPlan(DeclaredFieldPlan):
    """A process-local field never enters a record or compiles a wire decoder."""

    directives = (WireTransient,)
    records = False


class NullDefaultFieldPlan(DeclaredFieldPlan):
    directives = (WireNullDefault,)

    def captured(self, data: object) -> dict[str, object]:
        return {name: value for name, value in super().captured(data).items()
                if value is not None}


class NullMemberOmission(DeclaredFieldPlan):
    """A declared null member is absent from the wire, as its key's absence."""

    def omitted(self, value: object) -> bool:
        return not NullPresence.holds_value(value) or super().omitted(value)


class MissingNoneFieldPlan(NullMemberOmission):
    """Wire absence is None or the declared null member, independently of the
    constructor's default factory."""

    directives = (WireAbsentNone,)

    def omitted(self, value: object) -> bool:
        return value is None or super().omitted(value)

    def captured(self, data: object) -> dict[str, object]:
        return {self.name: super().captured(data).get(self.name)}


class ContextFieldPlan(DeclaredFieldPlan):
    """A constructor value supplied by the caller, never by wire data."""

    directives = (WireContext,)

    def contribute(self, fields: list[FieldPlan]) -> tuple[str, ...]:
        return ()

    @property
    def wire_keys(self) -> tuple[str, ...]:
        return ()

    def encoded(self, value: object, *, key: str | None = None) -> dict[str, object]:
        return {}

    def project_encoded[V](
        self, value: V, record: Callable[[Mapping[str, V]], V],
    ) -> V:
        return record({})

    def decoded(self, data: object) -> dict[str, object]:
        raise MalformedRecord(f"Missing decode context: {self.name}")

    def decoded_bound(
        self, data: dict[str, object], context: Mapping[str, object]
    ) -> dict[str, object]:
        if self.name not in context:
            raise MalformedRecord(f"Missing decode context: {self.name}")
        return {self.name: self.value.decode_bound(context[self.name], context)}


class BoundFieldPlan(DeclaredFieldPlan):
    """A nested record receives its context from declared sibling fields."""

    directives = (WireBind,)

    @cached_property
    def bound_sources(self) -> Mapping[str, str]:
        return WireBind.read(self.annotation, {})

    def decoded_bound(
        self, data: dict[str, object], context: Mapping[str, object]
    ) -> dict[str, object]:
        bound = {name: data[source] for name, source in self.bound_sources.items()}
        return self.decoded_using(data, lambda raw: self.value.decode_bound(raw, bound))


class InlineFieldPlan(DeclaredFieldPlan):
    """An InlineRecord type's or WireInline field's keys, written beside its parent's."""

    directives = (WireInline,)

    def field_paths(self, key: str, seen: frozenset[type]) -> tuple[tuple[str, ...], ...]:
        return _RecordDecoder(self.inlined).field_paths(key, seen)

    def unknown_under(self, refused: MalformedRecord, owner: DecoderPlan) -> tuple[UnknownField, ...]:
        return refused.nested_unknown(owner, ())

    @cached_property
    def inlined(self) -> type:
        declared, representation = FieldCodec.representation(self.annotation)
        match representation:
            case type() as inline if issubclass(inline, InlineRecord):
                return inline.wire_record()
        return cast(type, declared)

    @cached_property
    def record(self):
        return FieldCodec._record_plan(self.inlined)

    def contribute(self, fields):
        fields.extend(self.record.fields)
        return self.record.required_keys

    @cached_property
    def wire_keys(self) -> tuple[str, ...]:
        return tuple(entry.key for entry in self.record.fields)

    def encoded(self, value, *, key=None):
        return value

    def project_encoded[V](
        self, value: V, record: Callable[[Mapping[str, V]], V],
    ) -> V:
        return value

    def captured(self, data: object) -> dict[str, object]:
        if not isinstance(data, dict):
            raise MalformedRecord("Expected a record object.")
        return {self.name: {key: data[key] for key in self.wire_keys if key in data}}


class InlineFamilyPlan(InlineFieldPlan):
    """An inlined family member: its tag, then the keys of whichever member it is."""

    @classmethod
    def claims(cls, declared: Field, annotation: object) -> bool:
        value_type = FieldCodec.representation(annotation)[0]
        return (
            super().claims(declared, annotation)
            and isinstance(value_type, type)
            and issubclass(value_type, DeclaredFamily)
        )

    @cached_property
    def family(self) -> type[DeclaredFamily]:
        return cast(type[DeclaredFamily], self.inlined)

    def contribute(self, fields):
        return (self.family.family_discriminator,)

    @cached_property
    def wire_keys(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys((self.family.family_discriminator, *(
            entry.key for member in self.family.members_with(self.family)
            for entry in FieldCodec._record_plan(member).fields))))


type ExternalDecoder = Callable[[object, Mapping[str, object]], object]


class ExternalField(ABC):
    """A declared field type owns its external value and any sibling context it requires."""

    @classmethod
    def decode_external(cls, value: object, record: Mapping[str, object]) -> object:
        return cls.decode_external_value(value, record)

    @classmethod
    @abstractmethod
    def decode_external_value(cls, value: object, record: Mapping[str, object]) -> object: ...


class ExternalNullMember:
    """The family member representing an external null, without changing retained wire form."""


class ExternalNull(ExternalField, MroDispatch):
    """A family's declared null member owns nullable external ingress."""

    @classmethod
    def decode_external(cls, value: object, record: Mapping[str, object]) -> object:
        handler = cls.handler_for(type(value))
        return handler(value, record)

    @handles(type(None))
    @classmethod
    def decode_null(cls, value: object, record: Mapping[str, object]) -> object:
        family = cast(type[DeclaredFamily], cls)
        member, = (member for member in family._member_declarations()
                   if issubclass(member, ExternalNullMember))
        return member()

    @handles(object)
    @classmethod
    def decode_non_null(cls, value: object, record: Mapping[str, object]) -> object:
        return super().decode_external(value, record)

    @classmethod
    def from_wire(cls, value: object) -> Self:
        return FieldCodec.decode_external(cls, value, {})


class SingleExternalMember(ExternalNull):
    """An untagged nullable family has exactly one provided external member."""

    @classmethod
    def wire_member(cls, value: object) -> type[Self]:
        family = cast(type[DeclaredFamily], cls)
        member, = (
            member for member in family.members_with(family)
            if not issubclass(member, ExternalNullMember)
        )
        return cast(type[Self], member)


class DefaultExternalName:
    """The family member selected when an external name is absent or unrecognized."""


class DefaultedName:
    """Precedes a family's base: its recorded names can outlive their declarations (a newer
    build, an older record), so an absent or unrecognized name selects its one
    DefaultExternalName member."""

    @classmethod
    def recorded_member(cls, name: object) -> type[Self]:
        return cast(type[DeclaredFamily], cls).member_or_default(name, DefaultExternalName)


class ExternalName(ExternalField, DefaultedName, DeclaredFamily):
    @classmethod
    @boundary_decoder
    def from_external(cls, value: object) -> type[Self]:
        return cls.recorded_member(FieldCodec.decode(str | None, value))

    @classmethod
    def decode_external_value(cls, value: object, record: Mapping[str, object]) -> object:
        return cls.from_external(value)


@dataclass(frozen=True, slots=True)
class DecoderPlan(ABC):
    """Wire shape and record traversal, independent of the decoded value type."""

    target: object

    def sql_checks(self, column: str, quote: Callable[[object], str]) -> tuple[str, ...]:
        """Stored-value predicates; the SQL owner quotes its column and constants."""
        return ()

    def field_paths(self, key: str, seen: frozenset[type] = frozenset()) -> tuple[tuple[str, ...], ...]:
        """Scalars declare no fields; containers and records own their traversal."""
        return ()

    @property
    def accepts_null(self) -> bool:
        return False

    def fits_wire(self, data: object) -> bool:
        """Check outer wire shape without decoding nested values.

        This may pass a value decoding rejects, but must never reject one decoding accepts.
        """
        return True

    def shape_refusal(self, data: object) -> MalformedRecord:
        """Why fits_wire refused data; it states a refusal and never decides one."""
        return MalformedRecord(f"Expected {self.target}, received {type(data).__name__}")

    def fits_external(self, data: object) -> bool:
        """A sibling-aware external reader may accept more than the stored wire shape."""
        return any(self.external_decoders(data)) or self.fits_wire(data)

    def external_decoders(self, data: object) -> Iterable[ExternalDecoder]:
        return ()


@dataclass(frozen=True, slots=True)
class ValueDecoder[T](DecoderPlan, JsonSchemaOwner):
    """One annotation owns its wire conversion, draft projection and choice domain."""

    _by_origin: ClassVar[dict[object, type[ValueDecoder[object]]]] = {}
    _by_annotation: ClassVar[dict[object, type[ValueDecoder[object]]]] = {}

    def __init_subclass__(cls):
        super(ValueDecoder, cls).__init_subclass__()
        for origin in cls.__dict__.get("origins", ()):
            cls._by_origin[origin] = cls
        for annotation in cls.__dict__.get("annotations", ()):
            cls._by_annotation[annotation] = cls
        # The lookup compiled from these two is only good for the registry it read, and
        # this is the one place either of them changes: a decoder declared after an
        # annotation was first looked up must not stay invisible to it.
        ValueDecoder._forget_registered()

    @classmethod
    def from_annotation(cls, target: object, args: tuple[object, ...]) -> ValueDecoder[T]:
        return cls(target)

    @classmethod
    def _forget_registered(cls) -> None:
        ValueDecoder.__dict__["_registered"].__func__.cache_clear()

    @classmethod
    @cache
    def _registered(cls, annotation: object) -> tuple[type[ValueDecoder[object]], ...]:
        """Which declared decoders claim ``annotation``, compiled once per annotation.

        Walking an annotation's whole MRO and asking `get_origin` of each entry is a pure
        function of the annotation and the registry, and it was being redone for every
        value decoded: on a phone profiled while scrolling, `get_origin` alone accounted
        for 80,808 samples and every one of them came from here.

        Cached, but not frozen. `representation` and `_index` nearby cache annotation
        metadata, which cannot change; this reads `_by_origin` and `_by_annotation`, which
        `__init_subclass__` writes, so the registration that writes them is what drops this.
        """
        matches: list[type[ValueDecoder[object]]] = []
        if annotation in cls._by_annotation:
            matches.append(cls._by_annotation[annotation])
        declarations = annotation.__mro__ if isinstance(annotation, type) else (annotation,)
        for declaration in declarations:
            origin = get_origin(declaration) or declaration
            if origin in cls._by_origin:
                matches.append(cls._by_origin[origin])
        return tuple(matches)

    @classmethod
    def annotation_class(cls, annotation: object) -> type[ValueDecoder[object]]:
        matches = cls._registered(annotation)
        if not matches:
            raise KeyError(annotation)
        return matches[0]

    @classmethod
    def represented_class(cls, annotation: object) -> type[ValueDecoder[object]]:
        """A represented value with no registered decoder is a scalar of its representation;
        a declared record keeps its record fields as comparison content."""
        scalar: type[ValueDecoder[object]] = (
            _OpaqueRecordDecoder if is_dataclass(annotation) else _OpaqueDecoder
        )
        return next(iter(cls._registered(annotation)), scalar)

    def value_schema(self) -> dict[str, JsonValue]:
        """The compiled decoder owns target-dependent schema as well as conversion."""
        return self.schema()

    @classmethod
    def with_representation(
        cls, annotation: object, target: object, args: tuple[object, ...],
        representation: type[FieldRepresentation],
    ) -> ValueDecoder[T]:
        return representation.decoder(
            annotation, representation,
            cast(ValueDecoder[object], cls.representation_plan(target, args, representation)),
        )

    @classmethod
    def representation_plan(
        cls, target: object, args: tuple[object, ...], representation: type[FieldRepresentation],
    ) -> ValueDecoder[T]:
        return cls.from_annotation(target, args)

    @classmethod
    @cache
    def for_members[M](cls, members: tuple[type[M], ...]) -> UnionDecoder[M]:
        return UnionDecoder(
            reduce(or_, members),
            tuple(compile_decoder(member) for member in members),
        )

    @abstractmethod
    def decode(self, data: object) -> T:
        """Decode raw wire input; callers enter through decode_bound."""
        ...

    @abstractmethod
    def encode(self, value: T) -> object: ...

    def comparison(self, value: T) -> object:
        """The nominal value and its declaration-owned comparison content."""
        declaration = type(value)
        return (declaration.__module__, declaration.__qualname__, self.compared(value))

    def compared(self, value: T) -> object:
        return self.encode(value)

    def represented_comparison(self, represented: ValueDecoder[T], value: T) -> object:
        """A structure owns its comparison content; wire spellings do not."""
        return self.compared(value)

    def compile_comparison(self, compiled: set[object]) -> None:
        """Compile every decoder ``compared`` reaches, so a declaration with no codec
        owner refuses when its declarer is prepared, never inside an observation.
        Content compared by its own encoding reaches nothing further."""

    def compile_represented_comparison(self, compiled: set[object]) -> None:
        self.compile_comparison(compiled)

    def decode_external(self, data: object, record: Mapping[str, object]) -> T:
        for decode in self.external_decoders(data):
            return self.decode_resolved(cast(T, decode(data, record)))
        return self.decode_bound(data, record)

    def decode_resolved(self, value: T) -> T:
        if not self.accepts_value(value):
            raise MalformedRecord(f"Resolved value does not match {self.target}")
        return value

    def accepts_value(self, value: object) -> bool:
        """Select an in-process union case using its compiled declaration."""
        return isinstance(value, self.target)

    def accepts_external_value(self, value: object) -> bool:
        """A structural container match does not validate its contents."""
        return False

    def encode_document(self, value: T) -> object:
        return self.encode(value)

    def decode_document(self, data: object) -> T:
        return self.decode_bound(data, {})

    def decode_bound(self, data: object, context: Mapping[str, object]) -> T:
        return self.decode(data)

    @property
    def uses_representation(self) -> bool:
        return False

    def decode_selected(self, data, selections):
        return self.decode_bound(data, {})

    def decode_keys(self, data, keys, selections):
        raise TypeError("Selected keys require a mapping field")

    editor_annotation = str

    def encode_editor(self, value: T) -> str:
        encoded = FieldCodec.encode(value, self.target)
        return json.dumps(encoded)

    @boundary_decoder
    def decode_editor(self, value):
        return None if value is None else json.loads(value)

    def editor_choices(self) -> tuple[tuple[str, object], ...]:
        raise TypeError("The declared decoder does not offer finite choices")

    def argument_options(self, argument: Argument) -> dict[str, object]:
        """argparse options for this annotation's command-line text."""
        return {}

    def argument_text(self, encoded: object) -> object:
        """The command-line spelling of an encoded value."""
        return encoded

    def argument_payload(self, text: object) -> object:
        """The payload value that command-line text spells."""
        return text


@dataclass(frozen=True, slots=True)
class _RepresentedDecoder[T](ValueDecoder[T]):
    """A declared representation capability; null without one decodes structurally."""

    representation: type[FieldRepresentation[T]]
    structural: ValueDecoder[T]

    def sql_checks(self, column: str, quote: Callable[[object], str]) -> tuple[str, ...]:
        return (
            *self.representation.sql_checks(column, quote),
            *self.wire_structure.sql_checks(column, quote),
        )

    @property
    def wire_structure(self) -> DecoderPlan:
        return self.representation.wire_structure(self.structural)

    @property
    def accepts_null(self) -> bool:
        return self.wire_structure.accepts_null

    def field_paths(self, key: str, seen: frozenset[type] = frozenset()) -> tuple[tuple[str, ...], ...]:
        return self.wire_structure.field_paths(key, seen)

    @boundary_decoder
    def fits_wire(self, data: object) -> bool:
        # Null handlers can change the structural null contract; leave that decision to decode.
        return data is None or self.wire_structure.fits_wire(data)

    def fits_external(self, data: object) -> bool:
        # The representation reads through its wire structure, so an external read takes
        # whatever that structure's external reader takes.
        return ValueDecoder.fits_external(self, data) or self.wire_structure.fits_external(data)

    def shape_refusal(self, data: object) -> MalformedRecord:
        return self.wire_structure.shape_refusal(data)

    def external_decoders(self, data: object) -> Iterable[ExternalDecoder]:
        return FieldCodec.external_decoders(self.representation)

    @property
    def uses_representation(self) -> bool:
        return True

    def argument_options(self, argument: Argument) -> dict[str, object]:
        return self.representation.argument_options(argument)

    def encode(self, value: T) -> object:
        return None if value is None else self.representation.encode(value)

    def compared(self, value: T) -> object:
        return self.structural.represented_comparison(self, value)

    def compile_comparison(self, compiled: set[object]) -> None:
        self.structural.compile_represented_comparison(compiled)

    def accepts_value(self, value: object) -> bool:
        return self.structural.accepts_value(value)

    @boundary_decoder
    def decode(self, data: object) -> T:
        return self.representation.decode_field(data, self.structural)


@dataclass(frozen=True, slots=True)
class _NominalTextDecoder[T: str](_RepresentedDecoder[T]):
    """The field owns the decoded kind; its inherited spelling owns wire text."""

    structural: _ScalarDecoder[T, type[T]]

    def decode(self, data: object) -> T:
        return self.structural.target(super().decode(data))

    def encode(self, value: T) -> object:
        encoded = self.representation.encode(value)
        target = self.structural.target
        if not isinstance(value, target):
            raise MalformedRecord(f"Expected {target}, received {type(value).__name__}")
        return encoded

    def compared(self, value: T) -> object:
        return self.encode(value)

    def compile_comparison(self, compiled: set[object]) -> None:
        """Nominal text compares its encoding."""


class FieldRepresentation[T](MroDispatch, ABC, JsonSchemaOwner):
    """A field capability, declared as ``Annotated[ValueType, Representation]``.

    Private transports can declare captures without permitting those objects in
    ordinary JSON. All record structure remains owned by FieldCodec.
    """

    field_plan: ClassVar[type[FieldPlan]] = DeclaredFieldPlan
    decoder: ClassVar[type[_RepresentedDecoder]] = _RepresentedDecoder

    @classmethod
    def sql_checks(cls, column: str, quote: Callable[[object], str]) -> tuple[str, ...]:
        """Constraints on a stored column, already quoted by its SQL owner."""
        return ()

    @classmethod
    def for_value(cls, value: object) -> type[FieldRepresentation]:
        return cls

    @classmethod
    def project_view(cls, value: object, view: type[ViewExclusion], annotation: object) -> JsonValue:
        return RepresentedProjection.of(value, view, annotation)

    @classmethod
    def producer_owners(cls) -> tuple[type[FieldRepresentation], ...]:
        return tuple(parent for parent in cls.__mro__ if issubclass(parent, FieldRepresentation))

    @classmethod
    def decoder_for(cls, annotation: object, target: object) -> ValueDecoder[object]:
        owner = ValueDecoder.represented_class(target)
        return owner.with_representation(annotation, target, get_args(target), cls)

    @classmethod
    def schema_for(cls, annotation: object) -> dict[str, JsonValue]:
        schema = cls.schema()
        if type(None) in get_args(annotation):
            return FieldCodec.alternatives_schema("anyOf", [schema, {"type": "null"}])
        return schema

    @classmethod
    def wire_structure(cls, structural: DecoderPlan) -> DecoderPlan:
        """A custom scalar form stays opaque; declared structural forms supply their plan."""
        return structural

    @classmethod
    def decode_field(cls, data: object, structural: ValueDecoder[T]) -> T:
        handler: Callable[[object, ValueDecoder[T]], T] = cls.handler_for(type(data))
        with MalformedRecord.refusing(f"Invalid {cls.__name__}"):
            return handler(data, structural)

    @handles(type(None))
    @classmethod
    def decode_null(cls, data: object, structural: ValueDecoder[T]) -> T:
        return structural.decode_bound(data, {})

    @handles(object)
    @classmethod
    def decode_value(cls, data: object, structural: ValueDecoder[T]) -> T:
        return cls.decode(data)

    @classmethod
    @abstractmethod
    def encode(cls, value: T) -> object: ...

    @classmethod
    @abstractmethod
    def decode(cls, value: object) -> T: ...

    @classmethod
    def argument_options(cls, argument: Argument) -> dict[str, object]:
        """argparse options for this representation's command-line text."""
        return {}


class StructuralRepresentation(FieldRepresentation):
    """The value has no representation codec, so FieldCodec handles its structure."""

    @classmethod
    def for_value(cls, value: object) -> type[FieldRepresentation]:
        declared: object = type(value)
        return FieldCodec.representation(declared)[1]

    @classmethod
    def project_view(cls, value: object, view: type[ViewExclusion], annotation: object) -> JsonValue:
        return FieldCodec._project_structure(value, view, annotation)

    @classmethod
    def producer_owners(cls) -> tuple[type[FieldRepresentation], ...]:
        return ()

    @classmethod
    def decoder_for(cls, annotation: object, target: object) -> ValueDecoder[object]:
        return _structural_decoder(target)

    @classmethod
    def schema_for(cls, annotation: object) -> dict[str, JsonValue]:
        origin, args = get_origin(annotation), get_args(annotation)
        if origin in (Union, types.UnionType):
            members = list(args)
            if len(members) == 1:
                return FieldCodec.value_schema(members[0])
            return FieldCodec.alternatives_schema(
                "anyOf", [FieldCodec.value_schema(item) for item in members],
            )
        if origin is Literal:
            return {
                **FieldCodec.value_schema(type(args[0])),
                "enum": [value for _, value in compile_decoder(annotation).editor_choices()],
            }
        if origin in (list, tuple, frozenset):
            return {"type": "array", "items": FieldCodec.value_schema(args[0])}
        if origin is type and args and issubclass(args[0], DeclaredFamily):
            return {
                "type": "string",
                "enum": [value for _, value in compile_decoder(annotation).editor_choices()],
            }
        if isinstance(annotation, type) and issubclass(annotation, Enum):
            values = [value for _, value in compile_decoder(annotation).editor_choices()]
            return {**FieldCodec.value_schema(type(values[0])), "enum": values}
        if isinstance(annotation, type) and issubclass(annotation, DeclaredFamily):
            return FieldCodec._family_schema(annotation)
        if isinstance(annotation, type) and is_dataclass(annotation):
            return FieldCodec.record_schema(annotation)
        return compile_decoder(annotation).value_schema()


class AcceptsNull[T](FieldRepresentation[T]):
    """Null is this representation's input, not the structural target's."""

    @handles(type(None))
    @classmethod
    def decode_null(cls, data: object, structural: ValueDecoder[T]) -> T:
        return cls.decode_value(data, structural)


class WiredValue(Protocol):
    def to_wire(self) -> object: ...


class WireForm(FieldRepresentation):
    """A value shown in its own wire form; a read-only result's field is never decoded."""

    @classmethod
    def encode(cls, value: object) -> object:
        return FieldCodec.encode(cast(WiredValue, value).to_wire())

    @classmethod
    def decode(cls, value: object) -> object:
        raise TypeError("A read-only wire form is not decoded")


class WireValue(WireForm):
    """A value supplies its representation to the single field boundary."""

    __slots__ = ()

    @classmethod
    def representation(cls) -> type[FieldRepresentation]:
        return cls

    @abstractmethod
    def to_wire(self) -> JsonValue: ...

    @classmethod
    @abstractmethod
    def from_wire(cls, data: JsonValue) -> Self: ...

    @classmethod
    def decode(cls, value: object) -> Self:
        FieldCodec.encode(value)  # Custom forms still cross the JSON boundary.
        return cls.from_wire(value)


class ExternalJsonShape[T](FieldRepresentation[T]):
    """Decode the external shape directly, without revalidating each subtree."""

    @handles(object)
    @classmethod
    def decode_value(cls, data: object, structural: ValueDecoder[T]) -> T:
        return cls.from_wire(data)

    @classmethod
    @abstractmethod
    def from_wire(cls, data: object) -> T: ...


class SingleValueEncoding(WireValue):
    """Encode one declared field as the whole wire value."""

    @classmethod
    def wire_field(cls):
        entry, = FieldCodec._record_plan(cls).fields
        return entry

    def to_wire(self):
        entry = self.wire_field()
        return FieldCodec.encode_document(getattr(self, entry.name), entry.annotation)


class SingleFieldValue(ExternalJsonShape, SingleValueEncoding):
    """One declared field is the whole wire value, not an object envelope."""

    @classmethod
    def wire_structure(cls, structural: DecoderPlan) -> DecoderPlan:
        return cls.wire_field().value

    @classmethod
    def from_wire(cls, data):
        entry = cls.wire_field()
        return cls(**{entry.name: FieldCodec.decode_document(entry.annotation, data)})

    @classmethod
    def schema(cls):
        return FieldCodec.value_schema(cls.wire_field().annotation)

    @classmethod
    def argument_options(cls, argument: Argument) -> dict[str, object]:
        return compile_decoder(cls.wire_field().annotation).argument_options(argument)


class DeclaredWireType(ExternalJsonShape, WireValue):
    """A member whose whole wire value is one declared JSON type, converted by its own
    from_wire and to_wire. Its shape and schema derive from that type; inherited from a
    union, its shape would be the union holding it, and the shape check would never return."""

    wire_type: ClassVar[object]

    @classmethod
    def wire_structure(cls, structural: DecoderPlan) -> DecoderPlan:
        return compile_decoder(cls.wire_type)

    @classmethod
    def schema(cls) -> dict[str, JsonValue]:
        return FieldCodec.value_schema(cls.wire_type)


class MemberUnion(ExternalJsonShape, WireValue):
    """A wire value that is whichever of its members it holds; the decoder, its decoding and
    its schema all derive from that member set."""

    __slots__ = ()

    @classmethod
    @abstractmethod
    def union_members(cls) -> tuple[type, ...]:
        """The members this union decodes into."""

    @classmethod
    def union_decoder(cls) -> UnionDecoder[object]:
        return ValueDecoder.for_members(cls.union_members())

    @classmethod
    def wire_structure(cls, structural: DecoderPlan) -> DecoderPlan:
        return cls.union_decoder()

    @classmethod
    def from_wire(cls, data: object) -> Self:
        return cast(Self, cls.union_decoder().decode_bound(data, {}))

    @classmethod
    def schema(cls) -> dict[str, JsonValue]:
        return FieldCodec.value_schema(cls.union_decoder().target)


class CapabilityUnion(MemberUnion):
    """A capability shared by members of several declared families. Its wire value is the
    member it holds; it names the families, and each family's members with this
    capability are its members, so no member is listed by hand."""

    __slots__ = ()

    @classmethod
    @abstractmethod
    def capability_families(cls) -> tuple[type[DeclaredFamily], ...]:
        """The declared families whose members can hold this capability."""

    @classmethod
    def union_members(cls) -> tuple[type, ...]:
        return tuple(dict.fromkeys(
            member for family in cls.capability_families() for member in family.members_with(cls)))


class DeclaredError(DeclaredWireType):
    """An error that declares its whole state as its wire form, so it crosses a boundary
    as itself: its class is found by name among declared errors, and it is rebuilt from
    that declared form, never from its args."""

    declared_errors: ClassVar[dict[str, type[DeclaredError]]] = {}

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        DeclaredError.declared_errors[f"{cls.__module__}.{cls.__qualname__}"] = cls

    def to_wire(self) -> JsonValue:
        """Its arguments are its whole state unless a member declares more."""
        return FieldCodec.encode(cast(BaseException, self).args, self.wire_type)

    @classmethod
    def from_wire(cls, data: object) -> Self:
        """Rebuilt from its declared arguments, never through a member's narrowed constructor."""
        error = cls.__new__(cls)
        BaseException.__init__(cast(BaseException, error), *FieldCodec.decode(
            cast(type[tuple[object, ...]], cls.wire_type), data))
        return error


class SubclassUnion(DeclaredFamily, AcceptsNull, MemberUnion):
    """An untagged wire family; each union declares its own root with affix=""."""

    @classmethod
    def decodes_tagged_records(cls) -> bool:
        return False

    @classmethod
    def union_members(cls) -> tuple[type, ...]:
        return cls.members_with(cls)

    @classmethod
    def argument_options(cls, argument: Argument) -> dict[str, object]:
        """The union root offers its members' choices; a member offers only its own."""
        if cls.family_root is not cls:
            return super().argument_options(argument)
        return cls.union_decoder().argument_options(argument)

class TaggedUnion(SubclassUnion):
    """A family whose members cross the wire as tagged records, each carrying its kind."""

    @classmethod
    def decodes_tagged_records(cls) -> bool:
        return True



class PresentMember:
    """A provided member contributes itself to an optional member sequence."""

    def present(self) -> tuple[Self]:
        return (self,)

    def require_present(self) -> Self:
        return self

    def require_absent(self, reason: str = "A value was supplied where absence is required.") -> None:
        raise ValueError(reason)


class NullMember(ExternalField, AcceptsNull, WireValue):
    """One declared empty member owns the JSON null representation."""

    def present(self) -> tuple[()]:
        return ()

    def require_present(self) -> Never:
        raise ValueError("A required value is absent.")

    def require_absent(self, reason: str = "") -> None:
        pass

    @classmethod
    def wire_structure(cls, structural: DecoderPlan) -> DecoderPlan:
        return compile_decoder(type(None))

    @classmethod
    def decode_external_value(cls, value: object, record: Mapping[str, object]) -> object:
        return cls.from_wire(value)

    @classmethod
    def from_wire(cls, data: object) -> Self:
        FieldCodec.decode(type(None), data)
        return cls()

    def to_wire(self) -> None:
        return None

    @classmethod
    def schema(cls) -> dict[str, JsonValue]:
        return FieldCodec.value_schema(type(None))


class NullPresence(MroDispatch):
    """Whether an arbitrary field value is a declared null member."""

    @classmethod
    def holds_value(cls, value: object) -> bool:
        return cls.handler_for(type(value))(value)

    @handles(NullMember)
    @staticmethod
    def null_member(value: NullMember) -> bool:
        return False

    @handles(object)
    @staticmethod
    def ordinary(value: object) -> bool:
        return True


class RecordTag(MroDispatch):
    """The family owns its tag; an ordinary record has none."""

    @classmethod
    def of(cls, value: object) -> dict[str, str]:
        return cls.handler_for(type(value))(value)

    @handles(DeclaredFamily)
    @staticmethod
    def family(value: DeclaredFamily) -> dict[str, str]:
        return value.record_tag()

    @handles(object)
    @staticmethod
    def ordinary(value: object) -> dict[str, str]:
        return {}


class RecordMember(WireValue):
    """A wire union's record case uses the declared record codec."""

    @classmethod
    def wire_structure(cls, structural: DecoderPlan) -> DecoderPlan:
        return _member_decoders[cls]

    @classmethod
    def from_wire(cls, data: object) -> Self:
        return FieldCodec.decode_record(cls, data)

    @classmethod
    def schema(cls) -> dict[str, JsonValue]:
        return FieldCodec.record_schema(cls)

    def to_wire(self) -> dict[str, JsonValue]:
        return FieldCodec.encode_record(self)


class TaggedRecordMember(RecordMember):
    """A record member whose wire shape retains its declared family selector."""

    @classmethod
    def wire_structure(cls, structural: DecoderPlan) -> DecoderPlan:
        return structural

    @classmethod
    def from_wire(cls, data: object) -> Self:
        return cast(Self, _structural_decoder(cls).decode(data))


class RepresentedProjection(MroDispatch):
    """A represented value's view: its wire encoding, unless its declared record is its wire form."""

    @classmethod
    def of(cls, value: object, view: type[ViewExclusion], annotation: object) -> JsonValue:
        return cls.handler_for(type(value))(value, view, annotation)

    @handles(RecordMember)
    @staticmethod
    def record(value: RecordMember, view: type[ViewExclusion], annotation: object) -> JsonValue:
        return FieldCodec._project_record(value, view)

    @handles(object)
    @staticmethod
    def encoded(value: object, view: type[ViewExclusion], annotation: object) -> JsonValue:
        return FieldCodec.encode(value, annotation)


class InlineRecord(WireValue, ExternalJsonShape):
    """A typed field represented by its declared object's sibling wire fields."""

    field_plan = InlineFieldPlan

    @classmethod
    def wire_record(cls):
        return cls

    @classmethod
    def wire_structure(cls, structural: DecoderPlan) -> DecoderPlan:
        return _member_decoders[cls.wire_record()]

    @classmethod
    def schema(cls):
        return FieldCodec.record_schema(cls.wire_record())


class JsonShapeMember:
    """A declared external JSON shape with one typed ``value`` field.

    Concrete members opt in to shape selection. Other members of their nominal
    family can represent decoded meanings without becoming ingress candidates.
    """

    @classmethod
    def from_json_value(cls, value):
        return cls(value=value)


class JsonShapeFamily(AcceptsNull, ExternalJsonShape, SingleValueEncoding):
    """Untagged external JSON enters one declaration-owned value family.

    Put DeclaredFamily before this capability in the root's bases, preserving
    its name-decoding contract. Each JsonShapeMember declares
    its external shape through its value annotation; this codec owns primitive
    selection and recursive conversion. Rendering stays with the value owners.
    Its wire value is the declared shape itself; ExternalJsonShape decodes it
    through ``from_wire``.
    Each family class owns the map from JSON type to the member beneath it that
    owns that type, filled as members are defined; a bad declaration fails then.
    """

    _json_owners: ClassVar[dict[type, tuple[type, object]]]

    def __init_subclass__(cls, **options: object) -> None:
        super().__init_subclass__(**options)
        if JsonShapeFamily in cls.__bases__ and not issubclass(cls, DeclaredFamily):
            raise TypeError("A JSON shape family requires a declared family")
        cls._json_owners = {}
        if issubclass(cls, JsonShapeMember):
            shape, annotation = cls._json_shape()
            owners = [base for base in cls.__mro__ if issubclass(base, JsonShapeFamily)
                      and "_json_owners" in vars(base)]
            if any(shape in base._json_owners for base in owners):
                raise TypeError(f"Two {cls.__name__} owners for {shape.__name__}")
            for base in owners:
                base._json_owners[shape] = (cls, annotation)

    @classmethod
    def _json_shape(cls) -> tuple[type, object]:
        hints = {name: hint for name, hint in FieldCodec._types(cls).items()
                 if hint is not ClassVar and get_origin(hint) is not ClassVar}
        if tuple(hints) != ("value",):
            raise TypeError("A JSON shape must declare one value field")
        annotation = hints["value"]
        shape = get_origin(annotation) or annotation
        if shape in (tuple, frozenset):
            shape = list
        if not isinstance(shape, type):
            raise TypeError(f"Unsupported JSON shape declaration: {cls.__name__}")
        for base in shape.__mro__:
            if base in (dict, list, str, int, float, bool, type(None)):
                shape = base
                break
        else:
            raise TypeError(f"Unsupported JSON shape declaration: {cls.__name__}")
        return shape, annotation

    @classmethod
    def from_wire(cls, data):
        try:
            member, annotation = cls._json_owners[type(data)]
        except KeyError:
            raise MalformedRecord(
                f"Expected one {cls.__name__} owner for {type(data).__name__}") from None
        owner = cast(type[JsonShapeMember], member)
        result = owner.from_json_value(FieldCodec.decode(annotation, data))
        if not isinstance(result, cls):
            raise TypeError("A JSON shape factory must return its own family")
        return result

    @classmethod
    def wire_structure(cls, structural: DecoderPlan) -> DecoderPlan:
        """The wire value is one owned member's value; a member owns only its own."""
        return compile_decoder(Union[tuple(annotation for _, annotation in cls._json_owners.values())])

    @classmethod
    def schema(cls) -> dict[str, JsonValue]:
        alternatives = [FieldCodec.value_schema(annotation)
                        for _, annotation in cls._json_owners.values()]
        return FieldCodec.alternatives_schema("anyOf", alternatives)


class TextRepresentation[V](FieldRepresentation[V]):
    """External text scalars share strict decoding at the canonical boundary.

    Its schema names the representation, so text with no declared spelling never shares a stored
    form with plain ``str`` or with another representation; SpelledText declares one.
    """

    @classmethod
    def wire_structure(cls, structural: DecoderPlan) -> DecoderPlan:
        return compile_decoder(str)

    @classmethod
    def sql_checks(cls, column: str, quote: Callable[[object], str]) -> tuple[str, ...]:
        return (f"{column} IS NULL OR typeof({column}) = 'text'",)

    @classmethod
    def decode(cls, value: object) -> V:
        with MalformedRecord.refusing(f"Invalid {cls.__name__}"):
            return cls.from_text(FieldCodec.decode(str, value))

    @classmethod
    @abstractmethod
    def from_text(cls, value: str) -> V: ...

    @classmethod
    def text_form(cls) -> type[TextRepresentation]:
        return cls

    @classmethod
    def schema(cls) -> dict[str, JsonValue]:
        form = cls.text_form()
        return {"type": "string", "description": f"{form.__module__}.{form.__qualname__} text"}


class ValidatedScalar(FieldRepresentation):
    """The wire scalar is the decoded value, validated identically in both directions."""

    @classmethod
    def encode(cls, value: object) -> object:
        return cls.decode(value)


class SpelledText(TextRepresentation[str], ValidatedScalar):
    """Text with one declared spelling: what decoding accepts and what its schema reports."""

    spelling: ClassVar[re.Pattern[str]]

    @classmethod
    def spells(cls, value: str) -> bool:
        return bool(cls.spelling.fullmatch(value))

    @classmethod
    def from_text(cls, value: str) -> str:
        if not cls.spells(value):
            raise MalformedRecord(f"{cls.__name__} is spelled {cls.spelling.pattern}")
        return value

    @classmethod
    def command_line(cls, text: str) -> str:
        try:
            return cls.from_text(text)
        except MalformedRecord as error:
            raise argparse.ArgumentTypeError(f"{text!r}: {error}") from error

    @classmethod
    def argument_options(cls, argument: Argument) -> dict[str, object]:
        return {"type": cls.command_line}

    @classmethod
    def anchored(cls) -> str:
        """The whole-value pattern every schema of this spelling declares."""
        return f"^(?:{cls.spelling.pattern})$"

    @classmethod
    def schema(cls) -> dict[str, JsonValue]:
        return {"type": "string", "pattern": cls.anchored()}


class HexDigits(SpelledText):
    """Lowercase hexadecimal text; members declare their digit count."""

    digits: ClassVar[int]

    @classmethod
    def minimum_digits(cls) -> int:
        """Fixed-width spellings use their declared width at both ends."""
        return cls.digits

    @classmethod
    def repetition(cls) -> str:
        minimum = cls.minimum_digits()
        return str(cls.digits) if minimum == cls.digits else f"{minimum},{cls.digits}"

    @classmethod
    def sql_checks(cls, column: str, quote: Callable[[object], str]) -> tuple[str, ...]:
        return (*super().sql_checks(column, quote),
                f"length({column}) BETWEEN {cls.minimum_digits()} AND {cls.digits}",
                f"{column} NOT GLOB '*[^0-9a-f]*'",
                f"instr({column}, char(0)) = 0")

    def __init_subclass__(cls, **options: object) -> None:
        super().__init_subclass__(**options)
        cls.spelling = re.compile(f"[0-9a-f]{{{cls.repetition()}}}")


class NominalText(PresentMember, str):
    """Text whose declared class carries its identity."""

    __slots__ = ()
    spelled_by: ClassVar[type[NominalSpelling]]

    @classmethod
    def representation(cls) -> type[FieldRepresentation]:
        return cls.spelled_by

    @classmethod
    def __get_pydantic_core_schema__(
        cls, _source: object, _handler: GetCoreSchemaHandler
    ) -> core_schema.CoreSchema:
        return core_schema.no_info_plain_validator_function(
            partial(FieldCodec.decode, cls),
            json_schema_input_schema=core_schema.str_schema(
                strict=True, pattern=cls.spelled_by.anchored()
            ),
            serialization=core_schema.plain_serializer_function_ser_schema(cls.spelled_by.encode),
        )


class NominalSpelling[V: NominalText](SpelledText):
    """One spelling declared for a nominal value and inherited by its kinds."""

    value_type: type[V]
    decoder = _NominalTextDecoder

    def __init_subclass__(cls, **options: object) -> None:
        super().__init_subclass__(**options)
        cls.value_type = next(
            get_args(base)[0]
            for base in types.get_original_bases(cls)
            if get_origin(base) is NominalSpelling
        )
        cls.value_type.spelled_by = cls

    @classmethod
    def from_text(cls, value: str) -> V:
        return cls.value_type(super().from_text(value))

    @classmethod
    def decode(cls, value: object) -> V:
        if not isinstance(value, str):
            raise MalformedRecord(f"Expected text for {cls.__name__}")
        return cls.from_text(value)

    @classmethod
    def encode(cls, value: object) -> str:
        return str(cls.decode(value))


class PathText(TextRepresentation[Path]):
    @classmethod
    def encode(cls, value: object) -> str:
        if not isinstance(value, Path):
            raise MalformedRecord("Expected a filesystem path")
        return str(value)

    @classmethod
    def from_text(cls, value: str) -> Path:
        return Path(value)


class AbsolutePathText(PathText):
    """A filesystem path resolved once, where its external spelling enters."""

    @classmethod
    def from_text(cls, value: str) -> Path:
        return Path(value).expanduser().resolve()


class BoundedText(TextRepresentation[str], ValidatedScalar):
    """Nonempty identity text of bounded length: an owner, incarnation or message ID."""

    max_length: ClassVar[int] = 4096

    @classmethod
    def sql_checks(cls, column: str, quote: Callable[[object], str]) -> tuple[str, ...]:
        return (*super().sql_checks(column, quote),
                f"instr({column}, char(0)) = 0",
                f"length({column}) BETWEEN 1 AND {cls.max_length}")

    @classmethod
    def from_text(cls, value: str) -> str:
        if "\0" in value:
            raise MalformedRecord(f"{cls.__name__} cannot contain NUL")
        if not value or len(value) > cls.max_length:
            raise MalformedRecord(f"{cls.__name__} is nonempty and at most {cls.max_length} long")
        return value


class ResourcePathText(BoundedText):
    """A claimed resource, already a canonical absolute path."""

    @classmethod
    def from_text(cls, value: str) -> str:
        path = super().from_text(value)
        if not Path(path).is_absolute() or os.path.normpath(path) != path:
            raise MalformedRecord("A resource is a canonical absolute path")
        return path


class SequenceNumber(ValidatedScalar):
    """An exact integer bus position; its minimum is the kind's one rule."""

    minimum: ClassVar[int]

    @classmethod
    def decode(cls, value: object) -> int:
        position = FieldCodec.decode(int, value)
        if position < cls.minimum:
            raise MalformedRecord(f"{cls.__name__} is at least {cls.minimum}")
        return position

    @classmethod
    def schema(cls) -> dict[str, JsonValue]:
        return {"type": "integer", "minimum": cls.minimum}


class EnvelopeSequence(SequenceNumber):
    """The bus row an envelope was written at."""

    minimum = 1


class ProjectionSequence(SequenceNumber):
    """The last envelope a projection applied; zero before the first."""

    minimum = 0


@dataclass(frozen=True)
class RecordedTimestamp:
    """A time as its writer spelled it; the text round-trips byte for byte."""

    text: str

    @classmethod
    def written(cls, moment: datetime) -> RecordedTimestamp:
        """A time Core writes itself, spelled once in ISO 8601."""
        return cls(moment.isoformat())

    @cached_property
    def at(self) -> datetime:
        return datetime.fromisoformat(self.text)


class TimestampText(TextRepresentation[RecordedTimestamp]):
    @classmethod
    def encode(cls, value: object) -> str:
        return value.text

    @classmethod
    def from_text(cls, value: str) -> RecordedTimestamp:
        recorded = RecordedTimestamp(value)
        if not recorded.at.tzinfo:
            raise ValueError("A recorded time must name its UTC offset")
        return recorded


class AcpSessionSelection:
    """Whether an ACP session is bound; each answer here is the unbound one, and the bound
    id overrides it."""

    bound: ClassVar[bool] = False

    def accepts(self, session: AcpSessionId) -> bool:
        """An unbound attachment takes whichever session answers first."""
        return True

    def selected[T](self, unbound: T, bound: Callable[[AcpSessionId], T]) -> T:
        """The caller's answer for this selection: its unbound answer, or its bound one."""
        return unbound


class AcpSessionId(NominalText, AcpSessionSelection):
    """A local ACP attachment/execution identifier, not a native Pi journal ID."""

    bound = True

    def accepts(self, session: AcpSessionId) -> bool:
        return self == session

    def selected[T](self, unbound: T, bound: Callable[[AcpSessionId], T]) -> T:
        return bound(self)


class AcpSessionIdText(NominalSpelling[AcpSessionId]):
    spelling = re.compile(r"\S{1,4096}")


@dataclass(frozen=True)
class NoAcpSessionId(NullMember, AcpSessionSelection):
    """No ACP session is bound yet: a tab or saved row before the agent answers new_session."""


class StoredSessionId(NominalText):
    """The session a harness's stored history names: a Claude transcript's stem, a Codex
    rollout's or an OpenCode export's session, a Pi journal's entry."""


class StoredSessionIdText(NominalSpelling[StoredSessionId]):
    spelling = re.compile(r"\S{1,4096}")


class Id128(NominalText):
    """A 128-bit identity; subclasses declare the kind it belongs to."""

    @classmethod
    def mint(cls) -> Self:
        return cls(uuid4().hex)


class ClaimId(Id128):
    pass


class RpcCallId(Id128):
    """One JSON-RPC call this client posts: its request id and its progress token."""


class TurnId(Id128):
    pass


class GoalId(Id128):
    pass


class RootId(Id128):
    pass


class ThreadLookup(Id128):
    pass


class ToolCallId(NominalText):
    """A provider's own tool call identity, spelled exactly as the provider sends it
    (OpenAI Responses joins ``call_...|fc_...``). Only equality is defined; slots hash it.
    """


class ToolCallIdText(NominalSpelling[ToolCallId]):
    spelling = re.compile(r"\S{1,256}")


class InputId(Id128):
    pass


class SlotId(Id128):
    """The consumed tool slot, distinct from the input that produced it."""


class GoalWaitId(Id128):
    """One recorded dependency wait for a goal."""


class AttemptId(Id128):
    """One reserved execution attempt of a goal generation."""


@dataclass(frozen=True)
class NoAttemptId(NullMember):
    """A ready goal generation has not reserved an attempt."""


class AttemptToken(Id128):
    """The authority held by the owner of a reserved attempt."""


class RetryDecisionId(Id128):
    """One explicit authorization to retry goal work."""


class PageRequestId(Id128):
    """One request for an earlier transcript page."""


class RestartId(Id128):
    """One queued owner restart."""


class RoomTicket(Id128):
    """One storage-room claim."""


class HuntId(Id128):
    """One recorded teammate hunt."""


class ContextStoreId(Id128):
    """The original context store shared by its recorded turns."""


class ScratchName(Id128):
    """A unique suffix for a disposable file."""


class OwnerRequestKey(Id128):
    """One original owner directive and the work serving it."""


class Id128Text(NominalSpelling[Id128], HexDigits):
    """A 128-bit identity: an input, turn, bus root, recipient lookup or claim generation."""

    digits = 32


class TranscriptRecordId(NominalText):
    """One record of a harness's own transcript, as the harness writes it."""


class TranscriptRecordIdText(NominalSpelling[TranscriptRecordId]):
    """Claude Code spells every transcript record with a UUID."""

    spelling = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")


class MessageId(NominalText):
    @classmethod
    def mint(cls, text: str) -> Self:
        return cls(hashlib.sha256(text.encode()).hexdigest()[:MessageIdText.digits])


class MessageIdText(NominalSpelling[MessageId], HexDigits):
    """A bus message's content identity, the first twelve hex digits of the SHA-256
    of sender, target, timestamp and body.
    """

    digits = 12


class OrderId(NominalText):
    """One immutable problem order identity."""

    @classmethod
    def mint(cls) -> Self:
        return cls(Id128.mint()[:OrderIdText.digits])


class OrderIdText(NominalSpelling[OrderId], HexDigits):
    digits = 12


class Hex256Text(HexDigits):
    """256 bits written as 64 lowercase hex digits."""

    digits = 64


class Sha256Text(Hex256Text):
    """A SHA-256 digest."""


class AssignmentId(NominalText):
    """One recipient's wake claim on one bus message."""

    cohort_codec: ClassVar[str] = "cohort-v1:"

    @classmethod
    def cohort(cls, identity: bytes) -> Self:
        """The claim a sealed cohort mints for one member's identity."""
        return cls(cls.cohort_codec + hashlib.sha256(identity).hexdigest())

    def require_cohort(self) -> Self:
        """Only a cohort-minted claim binds a wake."""
        if not self.startswith(self.cohort_codec):
            raise MalformedRecord("AssignmentId is not cohort-minted")
        Sha256Text.from_text(self.removeprefix(self.cohort_codec))
        return self


class AssignmentIdText(NominalSpelling[AssignmentId]):
    """Spelled and stored as BoundedText, so the wake claim's stored form is unchanged."""

    spelling = re.compile(rf"[\s\S]{{1,{BoundedText.max_length}}}")

    @classmethod
    def schema(cls) -> dict[str, JsonValue]:
        return BoundedText.schema()


class Token256Text(Hex256Text):
    """A random 256-bit secret token."""


class GitCommitText(HexDigits):
    """A git commit, abbreviated to no fewer than seven digits."""

    digits = 40

    @classmethod
    def minimum_digits(cls) -> int:
        return 7


class DisclosedRecord:
    """Records declare their disclosure capability in their own inheritance."""

    __slots__ = ()

    @classmethod
    @cache
    def disclosure_identity(cls) -> tuple[FieldPlan, ...]:
        return tuple(plan for plan in FieldCodec.field_plans(cls)
                     if DisclosureIdentity.read(plan.annotation, False))

    def disclose[T: ValueDescription](self, presentation: type[T]) -> T:
        identity = type(self).disclosure_identity()
        return (presentation.identified_record(self, identity) if identity
                else presentation.record(self))


class ValueDescription(MroDispatch, ABC):
    """Presentation dispatch is independent of FieldCodec's external decoder dispatch."""

    @classmethod
    def describe(cls, value: object) -> Self:
        handler: Callable[[object], Self] = cls.handler_for(type(value))
        return handler(value)

    @handles(DisclosedRecord)
    @classmethod
    def disclosed(cls, value: DisclosedRecord) -> Self:
        return value.disclose(cls)

    @classmethod
    @abstractmethod
    def scalar(cls, value: object) -> Self: ...

    @classmethod
    @abstractmethod
    def record(cls, value: object) -> Self: ...

    @classmethod
    @abstractmethod
    def identified_record(cls, value: object, identity: tuple[FieldPlan, ...]) -> Self: ...

    @classmethod
    @abstractmethod
    def class_value(cls, value: type) -> Self: ...

    @classmethod
    @abstractmethod
    def family_value(cls, value: type[DeclaredFamily]) -> Self: ...

    @classmethod
    @abstractmethod
    def mapping(cls, value: Mapping[Hashable, object]) -> Self: ...

    @classmethod
    @abstractmethod
    def sequence(cls, value: Collection[object]) -> Self: ...


class Projected(ViewColumn, property):
    """A computed field declared by its owner for a named read-only view."""

    _declared: ClassVar[WeakKeyDictionary[type, dict[str, Projected]]] = WeakKeyDictionary()
    fget: Callable[..., object]

    @property
    def name(self) -> str:
        return self.__name__

    def __init__(self, getter, *, view: type[ViewExclusion], name: str | None = None):
        super().__init__(getter)
        self.view = view
        self.wire_name = name or getter.__name__

    def __set_name__(self, owner: type, name: str) -> None:
        """Every class body declaring this field records it, a slots rebuild included."""
        super().__set_name__(owner, name)
        Projected._declared.setdefault(owner, {})[name] = self

    @cached_property
    def annotation(self) -> object:
        return inspect.signature(self.fget, eval_str=True).return_annotation

    def current(self, record: object) -> object:
        return self.__get__(record, type(record))

    @staticmethod
    def of(declaration: type) -> Iterator[tuple[str, Projected]]:
        """Each projected field visible on ``declaration``, base declarations first."""
        for base in reversed(declaration.__mro__):
            yield from Projected._declared.get(base, {}).items()


def projected(*, view: type[ViewExclusion], name: str | None = None):
    return lambda getter: Projected(getter, view=view, name=name)


class FieldCodec(MroDispatch, Sealed):
    """Family tags use their declared ``family_discriminator`` (default ``kind``); aliases
    use Annotated fields carrying WireName and the other typed directives.

    Decoding rejects unknown fields and primitive coercions (including bool as
    int). Missing fields use declared defaults. Tuple fields round-trip as JSON
    arrays. Init fields and explicitly projected wire properties participate;
    projected values are derived again on decode. ClassVars are not stored.
    WireNonNull rejects an explicit null while allowing an omitted default.
    WireInline writes a nested record's keys into its parent's object (a clash is a
    TypeError).
    Annotated field representations add scalar/capture behavior while retaining
    the single record codec and declaration-derived schema.
    """

    @classmethod
    def decode_external[T](
        cls, annotation: TypeForm[T], value: object, record: Mapping[str, object],
    ) -> T:
        return cast(T, compile_decoder(annotation).decode_external(value, record))

    @classmethod
    def decode_resolved[T](cls, annotation: TypeForm[T], value: T) -> T:
        return cast(T, compile_decoder(annotation).decode_resolved(value))

    @classmethod
    def external_decoders(cls, target: type) -> Iterator[ExternalDecoder]:
        for name in cls.handler_names_for(target):
            yield getattr(cls, name)(target)

    @handles(ExternalField)
    @classmethod
    def external_decoder(cls, target: type[ExternalField]) -> ExternalDecoder:
        return target.decode_external

    @classmethod
    @cache
    def representation(
        cls, annotation: object,
    ) -> tuple[object, type[FieldRepresentation]]:
        """The value type and its declared representation, structural when unencoded.

        A declaration's annotation is decoded once, never per value it carries."""
        if annotation is None:
            return None, StructuralRepresentation
        if annotation is object:
            return object, _JsonValueRepresentation
        if get_origin(annotation) is Annotated:
            target, *metadata = get_args(annotation)
        else:
            target, metadata = annotation, ()
        representations = [
            item for item in metadata
            if isinstance(item, type) and issubclass(item, FieldRepresentation)
        ]
        if len(representations) > 1:
            raise TypeError("A field must have one representation")
        if isinstance(target, TypeAliasType):
            if target is JsonValue:
                if representations:
                    return object, representations[0]
                return object, _JsonValueRepresentation
        if representations:
            return target, representations[0]
        if target is object:
            return object, _JsonValueRepresentation
        if isinstance(target, type) and issubclass(target, (NominalText, WireValue)):
            return target, target.representation()
        return target, StructuralRepresentation

    @classmethod
    def _value_representation(
        cls, value: object, annotation: object,
    ) -> type[FieldRepresentation]:
        return cls.representation(annotation)[1].for_value(value)

    @classmethod
    def record_fields(cls, record: type) -> tuple[tuple[Field[object], str], ...]:
        """The compiled record owns declaration order and expanded keys."""
        return cls._record_plan(record).record_fields

    @classmethod
    def field_plans(cls, record: type) -> tuple[FieldPlan, ...]:
        """All declarations, including context fields, without unused value decoders."""
        return cls._record_plan(record).declarations

    @classmethod
    def record_key(cls, record: type, name: str) -> str:
        return next(key for item, key in cls.record_fields(record) if item.name == name)

    @staticmethod
    @cache
    def _types(declaration: type) -> dict[str, type[object]]:
        """Every field annotation a declaration has, each evaluated in the module that wrote it.
        get_type_hints on a class swaps the class dict in as the eval globals, so a lambda in an
        annotation could not see its own module (WireRevision.goal_execution, 2026-10-30); each
        base's own annotations are evaluated here with its module as globals and its type
        parameters and dict as locals, keeping typing's None-to-NoneType and extras."""
        hints: dict[str, type[object]] = {}
        for base in reversed(declaration.__mro__):
            hints |= FieldCodec._evaluate_annotations(base, annotationlib.get_annotations(
                base, format=annotationlib.Format.FORWARDREF))
        return hints

    @staticmethod
    def _evaluate_annotations(
        declaration: type, annotations: dict[str, object],
    ) -> dict[str, type[object]]:
        """One evaluator for complete records and individual compared fields."""
        own = types.ModuleType(declaration.__qualname__)
        own.__annotations__ = annotations
        return get_type_hints(
            own, globalns=vars(sys.modules[declaration.__module__]),
            localns={param.__name__: param for param in declaration.__type_params__}
            | dict(vars(declaration)), include_extras=True,
        )

    @classmethod
    def field_annotation(cls, record: type, name: str) -> type[object]:
        """A field resolves where it was declared, without evaluating unrelated annotations."""
        declarer = next(
            owner for owner in record.__mro__
            if name in annotationlib.get_annotations(owner, format=annotationlib.Format.FORWARDREF)
        )
        annotations = annotationlib.get_annotations(
            declarer, format=annotationlib.Format.FORWARDREF,
        )
        return cls._evaluate_annotations(declarer, {name: annotations[name]})[name]

    @overload
    @classmethod
    def encode(cls, value: DeclaredFamily) -> dict[str, JsonValue]: ...

    @overload
    @classmethod
    def encode(cls, value: object, annotation: object = None) -> JsonValue: ...

    @classmethod
    def encode(cls, value: object, annotation: object = None) -> JsonValue:
        return compile_decoder(annotation).encode(value)

    @staticmethod
    def compact(
        value: object, *, ensure_ascii: bool = True,
        sort_keys: bool = False, allow_nan: bool = True,
    ) -> str:
        """Write an already encoded JSON value without layout whitespace.

        Callers retain their boundary's Unicode, ordering and numeric contract;
        declared values pass through ``encode`` before this text boundary.
        """
        return json.dumps(
            value, ensure_ascii=ensure_ascii, sort_keys=sort_keys,
            allow_nan=allow_nan, separators=(",", ":"),
        )

    @classmethod
    def ordering(cls, encoded: object) -> str:
        """The order of an unordered collection's encoded members: their sorted compact text."""
        return cls.compact(encoded, sort_keys=True)

    @classmethod
    def digest(cls, value: object) -> str:
        """SHA-256 of a declared value's sorted compact encoding."""
        return hashlib.sha256(cls.compact(cls.encode(value), sort_keys=True).encode()).hexdigest()

    @classmethod
    def comparison_digest(cls, value: object) -> str:
        """Stable identity of declared comparison fields, including nested records.

        This is an observation key, not another wire format or load path. Fields
        excluded from dataclass comparison never become notification identity.
        """
        compared = compile_decoder(None).comparison(value)
        return hashlib.sha256(cls.compact(compared, sort_keys=True).encode()).hexdigest()

    @classmethod
    def compared_fields(cls, record: type) -> tuple[FieldPlan, ...]:
        """Construct comparison plans at the codec's declared-record boundary."""
        return tuple(
            cls._field_plan(item, annotation)(declared=item, _annotation=annotation)
            for item in fields(record) if item.compare
            for annotation in (cls.field_annotation(record, item.name),)
        )

    @classmethod
    def compile_comparison(cls, record: type) -> None:
        """Prepare the same declared field view that record comparisons execute."""
        _member_decoders[record].compile_comparison(set())

    @classmethod
    def encode_document(cls, value: object, declared: object) -> object:
        """A document whose declaration names its leaf member stores that member untagged."""
        return compile_decoder(declared).encode_document(value)

    @classmethod
    def decode_document(cls, declared: TypeForm[T], data: object) -> T:
        return cast(T, compile_decoder(declared).decode_document(data))

    @classmethod
    def encode_record(cls, value: object) -> dict[str, JsonValue]:
        """Encode a record: its family tag, then its declared fields."""
        return {**cls._tag(value), **cls.encode_fields(value)}

    @staticmethod
    def _tag(value: object) -> dict[str, str]:
        return RecordTag.of(value)

    @classmethod
    def encode_fields(cls, value: object) -> dict[str, object]:
        """Encode declared fields, except ``wire_exclude`` ones, including inside a custom wire
        representation."""
        return _member_decoders[type(value)].encode(value)

    @classmethod
    def decode_bound(cls, target: TypeForm[T], data: object, **context: object) -> T:
        return cast(T, compile_decoder(target).decode_bound(data, context))

    @classmethod
    def decode_record(
        cls, target: type[T], data: object, *,
        field_types: Mapping[str, type[object]] = types.MappingProxyType({}),
    ) -> T:
        """Decode declared fields, with nominal narrowing supplied by their contextual owner."""
        decoder = _RecordDecoder(target)
        for name, narrowed in field_types.items():
            annotation, _ = cls.representation(cls.field_plan(target, name).annotation)
            if not issubclass(narrowed, annotation):
                raise TypeError(f"{target.__name__}.{name} cannot widen its declared type")
        return cast(T, decoder.decode_selected(
            data, {}, field_types=field_types))

    @classmethod
    def argument_fields(cls, target: type) -> tuple[FieldPlan, ...]:
        return cls._record_plan(target).bindings

    @classmethod
    def add_arguments(cls, target: type, parser: argparse.ArgumentParser) -> None:
        groups: dict[str, argparse._MutuallyExclusiveGroup] = {}
        for entry in cls.argument_fields(target):
            entry.add_argument(parser, groups)

    @classmethod
    def decode_arguments(cls, target: type[T], arguments: object) -> T:
        """Argparse contributes only raw input; field plans own its conversion."""
        raw = vars(arguments)
        return cls.decode_record(target, {
            entry.key: entry.argument_payload(raw[entry.key])
            for entry in cls.argument_fields(target)
            if entry.key in raw
        })

    @classmethod
    def encode_arguments(cls, target: type, value: object) -> tuple[str, ...]:
        """The command line ``decode_arguments`` reads back as ``value``'s ``target`` fields."""
        encoded = cls.encode_fields(value)
        return tuple(
            word
            for entry in cls.argument_fields(target)
            for word in entry.argument_words(encoded[entry.key])
        )

    @classmethod
    def editor_arguments(cls, target: type, values: Mapping[str, object]) -> dict[str, object]:
        plans = {entry.key: entry for entry in cls.argument_fields(target)}
        return {key: plans[key].editor_payload(value) for key, value in values.items()}

    @classmethod
    def decode_selected(cls, target: type[T], data: object, selections, *, fields: tuple[str, ...]) -> T:
        """Decode selected mapping keys by their declaring record and field, not wire shape."""
        entries = tuple(
            entry for entry in cls._record_plan(target).bindings if entry.name in fields
        )
        return cast(T, _RecordDecoder(target).decode_entries(data, entries, selections, {}, {}))

    @classmethod
    def decode(cls, target: TypeForm[T], data: object) -> T:
        return cast(T, compile_decoder(target).decode_bound(data, {}))

    @classmethod
    def field_plan(cls, record: type, name: str) -> FieldPlan:
        return next(item for item in cls._record_plan(record).bindings if item.name == name)

    @staticmethod
    def parse(text: str | bytes) -> object:
        """External JSON text is data: strict UTF-8, syntax and duplicate keys refuse it."""
        with MalformedRecord.refusing("Invalid JSON"):
            return json.loads(
                text.decode("utf-8") if isinstance(text, bytes) else text,
                object_pairs_hook=_unique_object,
            )

    @classmethod
    def require_fields(cls, record: DataclassInstance, *names: str) -> None:
        """A record built in code holds each field, or each one ``names`` selects, to the
        rule its declared type states."""
        for name, annotation in cls.field_types(record.__class__):
            if names and name not in names:
                continue
            value = getattr(record, name)
            if cls.decode(annotation, cls.encode(value)) != value:
                raise MalformedRecord(f"{type(record).__name__}.{name} is not its declared type")

    @staticmethod
    @cache
    def field_types(target: type[DataclassInstance]) -> tuple[tuple[str, type[object]], ...]:
        hints = FieldCodec._types(target)
        return tuple((item.name, hints[item.name]) for item in fields(target) if item.init)

    @staticmethod
    def construct(target: Callable[..., T], values: dict[str, object]) -> T:
        """A record built from decoded data refuses its values as a malformed record."""
        with MalformedRecord.refusing(f"Invalid {target.__name__}"):
            return target(**values)

    @staticmethod
    def alternatives_schema(
        combinator: Literal["anyOf", "oneOf"], alternatives: list[dict[str, JsonValue]],
    ) -> dict[str, JsonValue]:
        """An alternative schema with no possible member rejects every value."""
        return {combinator: alternatives} if alternatives else {"not": {}}

    @classmethod
    def _family_schema(cls, target: type[DeclaredFamily]) -> dict[str, JsonValue]:
        """Instance values carry their selector inside the encoded object."""
        alternatives = []
        for member in target.members_with(target):
            tag = member.family_discriminator
            selector: dict[str, JsonValue] = {
                tag: {"type": "string", "const": member.declared_name}}
            alternatives.append(
                cls._record_schema((member,), selector, [tag]) if is_dataclass(member)
                # A model member (a Pydantic wire model) describes its own fields.
                else cls._tagged_model_schema(member, selector, tag))
        return cls.alternatives_schema("oneOf", alternatives)

    @classmethod
    def _tagged_model_schema(
        cls, member: type, selector: dict[str, JsonValue], tag: str,
    ) -> dict[str, JsonValue]:
        schema = compile_decoder(member).value_schema()
        properties = FieldCodec.decode(dict[str, JsonValue], schema.get("properties", {}))
        required = FieldCodec.decode(list[str], schema.get("required", []))
        return {**schema, "properties": {**selector, **properties}, "required": [tag, *required]}

    @classmethod
    def record_schema(cls, *targets: type) -> dict[str, JsonValue]:
        """Named request fields; external tool/CLI selection remains separate."""
        return SchemaDefinitions.build(lambda: cls._record_schema(targets, {}, []))

    @classmethod
    def _record_schema(
        cls, targets: tuple[type, ...], properties: dict[str, JsonValue], required: list[str]
    ) -> dict[str, JsonValue]:
        """Build fields once, including an internally supplied family selector."""
        for target in targets:
            cls._record_plan(target).schema_fields(properties, required)
        return {
            "type": "object",
            "properties": properties,
            "required": required,
            "additionalProperties": False,
        }

    @classmethod
    def value_schema(cls, annotation: object) -> dict[str, JsonValue]:
        """Derive external scalar/array choices from the same decode declarations."""
        annotation, representation = cls.representation(annotation)
        return SchemaDefinitions.value(
            (annotation, representation), lambda: representation.schema_for(annotation))

    @classmethod
    def project(cls, value: object, view: type[ViewExclusion], annotation: object = None) -> JsonValue:
        """Encode a redacted view using field exclusions and owned properties.

        A family record carries its tag at every depth, as in its wire form.

        Projection is deliberately one way. Excluded secrets cannot be rebuilt
        from a read-only view, and a view never serves as a persistence record.
        """
        return cls._value_representation(value, annotation).project_view(value, view, annotation)

    @classmethod
    def _project_structure(cls, value: object, view: type[ViewExclusion], annotation: object) -> JsonValue:
        if is_dataclass(value) and not isinstance(value, type):
            return cls._project_record(value, view)
        if isinstance(value, (tuple, list)):
            arguments = get_args(cls.representation(annotation)[0])
            return [cls.project(item, view, arguments[0] if arguments else None) for item in value]
        return cls.encode(value)

    @classmethod
    def _project_record(cls, value: object, view: type[ViewExclusion]) -> JsonValue:
        """A record's view: its tag, its view's fields and the properties the view owns."""
        result = cls._tag(value)
        result.update(cls._record_plan(type(value)).encoded(
            value, view, lambda entry, current: cls.project(current, view, entry.annotation)
        ))
        properties = cls.projections(type(value), view)
        result.update(
            (member.wire_name, cls.project(getattr(value, name), view))
            for name, member in properties.items()
        )
        return result

    @dataclass(frozen=True)
    class _RecordPlan:
        """A record's field plan, derived once from its declaration."""

        declarations: tuple[FieldPlan, ...]
        fields: tuple[FieldPlan, ...]
        bindings: tuple[FieldPlan, ...]
        required_keys: tuple[str, ...]
        """The keys every stored row carries, in wire order: one list the decoder enforces
        and the schema publishes."""
        accepted_keys: frozenset[str]

        @cached_property
        def required_wire_keys(self) -> frozenset[str]:
            return frozenset(self.required_keys)

        @cached_property
        def record_fields(self) -> tuple[tuple[Field[object], str], ...]:
            return tuple((plan.declared, plan.key) for plan in self.bindings)

        def encoded(self, value, view, encode_value) -> dict[str, object]:
            result: dict[str, object] = {}
            for entry in self.bindings:
                current = entry.current(value)
                if not entry.excluded_in(view) and not entry.omitted(
                    current
                ):
                    result.update(
                        entry.encoded(
                            encode_value(entry, current),
                            key=entry.key_in(view),
                        )
                    )
            return result

        def schema_fields(self, properties, required):
            for entry in self.fields:
                properties.update(entry.schema_fields())
            required.extend(self.required_keys)
            return properties

    @classmethod
    @cache
    def _record_plan(cls, record: type) -> FieldCodec._RecordPlan:
        """Resolve every per-row type decision for one record declaration once."""
        hints = cls._types(record)
        declarations = tuple(
            cls._field_plan(item, hints[item.name])(declared=item, _annotation=hints[item.name])
            for item in fields(record)
        )
        declared = tuple(plan for plan in declarations if plan.declared.init and plan.records)
        if any(not isinstance(plan.key, str) or not plan.key for plan in declared):
            raise TypeError("Wire field names must be nonempty strings.")
        entries = tuple(
            plan
            for _, plan in sorted(
                enumerate(declared),
                key=lambda row: (WireOrder.read(row[1].annotation, row[0]), row[0]),
            )
        )
        computed = {member.wire_name for member in cls.projections(record, WireExclude).values()}
        wire_fields, required_keys = [], []
        for entry in entries:
            keys = entry.contribute(wire_fields)
            if entry.required or entry.constructor_required:
                required_keys.extend(keys)
        wire_keys = [key for entry in entries for key in entry.wire_keys]
        if len(set(wire_keys)) != len(wire_keys) or (
            issubclass(record, DeclaredFamily) and record.family_discriminator in wire_keys
        ):
            raise TypeError("Conflicting wire field names.")
        return cls._RecordPlan(
            declarations=declarations,
            fields=tuple(wire_fields),
            bindings=entries,
            required_keys=tuple(required_keys),
            accepted_keys=frozenset(wire_keys) | computed,
        )

    @staticmethod
    def _field_plan(field: Field[object], annotation: object) -> type[FieldPlan]:
        claimed = {plan for plan in FieldPlan._plans if plan.claims(field, annotation)}
        selected = claimed - {base for plan in claimed for base in plan.__mro__[1:]}
        if len(selected) != 1:
            raise TypeError(f"Field {field.name} must have exactly one declared field plan: {selected}")
        return selected.pop()

    @classmethod
    def view_columns(cls, declaration: type, view: type[ViewExclusion]) -> tuple[ViewColumn, ...]:
        """One column source for native tables and plain-text views."""
        return (
            *(plan for plan in cls.field_plans(declaration)
              if plan.records and not plan.excluded_in(view)),
            *cls.projections(declaration, view).values(),
        )

    @staticmethod
    @cache
    def projections(declaration: type, view: type[ViewExclusion]) -> types.MappingProxyType[str, Projected]:
        # Cache immutable declarations only. Each consumer still invokes the
        # original property on the current record; projected values are never cached.
        return types.MappingProxyType({
            name: member for name, member in Projected.of(declaration) if member.view == view
        })





class _ContextDecoder[T](ValueDecoder[T]):
    """A standalone decode starts with one empty binding context."""

    def external_decoders(self, data: object) -> Iterable[ExternalDecoder]:
        return FieldCodec.external_decoders(cast(type, self.target))

    def decode(self, data: object) -> T:
        return self.decode_bound(data, {})

    @abstractmethod
    def decode_bound(self, data: object, context: Mapping[str, object]) -> T: ...


class _ChoiceDecoder[T](ValueDecoder[T]):
    """A finite domain: its command line offers exactly the editor's choices."""

    __slots__ = ()

    def sql_checks(self, column: str, quote: Callable[[object], str]) -> tuple[str, ...]:
        # SQL IN is an unordered set: stored schema text must not depend on import order.
        choices = ", ".join(sorted(quote(value) for _, value in self.editor_choices()))
        return (f"{column} IN ({choices})",)

    def argument_options(self, argument: Argument) -> dict[str, object]:
        return {"choices": [self.argument_text(value) for _, value in self.editor_choices()]}


@dataclass(frozen=True, slots=True)
class _ScalarDecoder[T, Target = object](ValueDecoder[T]):
    """A plain target accepts no wire value unless a scalar below declares it."""

    target: Target

    @property
    def accepts_null(self) -> bool:
        return self.accepts(None)

    def decode(self, data: object) -> T:
        if self.accepts(data):
            return data
        raise MalformedRecord(f"Expected {self.target}, received {type(data).__name__}")

    def accepts(self, data: object) -> TypeGuard[T]:
        return False

    def encode(self, value: T) -> object:
        raise TypeError(f"Unsupported JSON value: {type(value).__name__}")


class _OpaqueDecoder[T, Target = object](_ScalarDecoder[T, Target]):
    """A represented value with no structure of its own: its representation is its content."""

    __slots__ = ()

    def represented_comparison(self, represented: ValueDecoder[T], value: T) -> object:
        return represented.encode(value)

    def compile_represented_comparison(self, compiled: set[object]) -> None:
        """Its representation's encoding is its content."""


class _OpaqueRecordDecoder[T](_OpaqueDecoder[T, type[T]]):
    """A represented record compares its declared record fields, not its wire spelling."""

    __slots__ = ()

    def represented_comparison(self, represented: ValueDecoder[T], value: T) -> object:
        return _member_decoders[self.target].compared(value)

    def compile_represented_comparison(self, compiled: set[object]) -> None:
        _member_decoders[self.target].compile_comparison(compiled)


class _ExactScalarDecoder[T](_ScalarDecoder[T], JsonScalar):
    """A JSON scalar decoded only from its own type."""

    __slots__ = ()

    def accepts(self, data: object) -> TypeGuard[T]:
        return type(data) is self.target

    def fits_wire(self, data: object) -> bool:
        return self.accepts(data)

    def accepts_value(self, value: object) -> bool:
        return self.accepts(value)

    def accepts_external_value(self, value: object) -> bool:
        return self.accepts(value)

    def encode(self, value: T) -> T:
        if not self.accepts(value):
            raise TypeError(f"Expected {self.target}, received {type(value).__name__}")
        return value


class _PathDecoder(PathText, ValueDecoder[Path]):
    """The path representation also owns direct and concrete-subclass values."""

    origins = (Path,)

    @classmethod
    def text_form(cls) -> type[TextRepresentation]:
        return PathText


class _NullDecoder(_ExactScalarDecoder[None]):
    __slots__ = ()
    annotations = (type(None),)
    json_type = "null"

    def sql_checks(self, column: str, quote: Callable[[object], str]) -> tuple[str, ...]:
        return (f"{column} IS NULL",)


class _TextDecoder(_ExactScalarDecoder[str]):
    __slots__ = ()
    annotations = (str,)
    json_type = "string"

    def encode(self, value: str) -> str:
        return str(super().encode(value))

    def encode_editor(self, value: str) -> str:
        return value

    def decode_editor(self, value):
        return value


class _FlagDecoder(_ExactScalarDecoder[bool]):
    __slots__ = ()
    annotations = (bool,)
    json_type = "boolean"

    def argument_options(self, argument: Argument) -> dict[str, object]:
        return {"action": "store_true"}


class _NumberDecoder[T: (int, float)](_ExactScalarDecoder[T]):
    __slots__ = ()

    def argument_options(self, argument: Argument) -> dict[str, object]:
        return {"type": self.target}


class _IntegerDecoder(_NumberDecoder[int]):
    __slots__ = ()
    annotations = (int,)
    json_type = "integer"


class _RealDecoder(_NumberDecoder[float]):
    """A finite number; an integer is a real number on the wire."""

    __slots__ = ()
    annotations = (float,)
    json_type = "number"

    def fits_wire(self, data: object) -> TypeGuard[int | float]:
        return type(data) in (int, float)

    def accepts(self, data: object) -> TypeGuard[float]:
        return self.fits_wire(data) and math.isfinite(data)






class _JsonValueRepresentation(FieldRepresentation[JsonValue]):
    """An opaque JSON declaration validates JSON, not Python object representations."""

    @staticmethod
    @lru_cache(maxsize=1)
    def validator():
        from pydantic import ConfigDict, TypeAdapter

        return TypeAdapter(JsonValue, config=ConfigDict(allow_inf_nan=False))

    @classmethod
    def decode(cls, data):
        with MalformedRecord.refusing("Expected a JSON value with string keys and finite numbers"):
            return cls.validator().validate_python(data, strict=True)

    @classmethod
    def encode(cls, value):
        # An in-process value that is not JSON is the caller's bug, not refused data.
        try:
            return cls.validator().validate_python(value, strict=True)
        except ValueError as error:
            raise TypeError("Expected a JSON value with string keys and finite numbers") from error

    @classmethod
    def schema(cls):
        return {}


@dataclass(frozen=True, slots=True)
class _UndeclaredDecoder(_JsonValueRepresentation, ValueDecoder[JsonValue]):
    """Only an undeclared value needs runtime representation selection."""

    annotations = (object, None)

    def accepts_value(self, value: object) -> bool:
        return True

    @classmethod
    def encode(cls, value: object) -> object:
        if isinstance(value, type) and issubclass(value, DeclaredFamily):
            return value.declared_name
        if type(value) is dict:
            if all(type(key) is str for key in value):
                return {key: cls.encode(item) for key, item in value.items()}
            return [[cls.encode(key), cls.encode(item)] for key, item in value.items()]
        return compile_decoder(type(value)).encode(value)

    def compared(self, value: object) -> object:
        if isinstance(value, type):
            return value.__module__, value.__qualname__
        if type(value) is dict:
            return _PairKeyDictDecoder(dict, self, self, (object, object)).compared(value)
        return compile_decoder(type(value)).compared(value)


def _declared_member[Family: DeclaredFamily](
    family: type[Family], name: object,
) -> type[Family]:
    """A wire name the family's recorded_member does not resolve is malformed data."""
    try:
        return family.recorded_member(name)
    except ValueError as error:
        raise MalformedRecord(str(error)) from error


@dataclass(frozen=True, slots=True)
class _TypeDecoder(_ScalarDecoder[type[DeclaredFamily]]):
    origins = (type,)
    bound: type[DeclaredFamily]

    @classmethod
    def from_annotation(cls, target: object, args: tuple[object, ...]) -> ValueDecoder[type[DeclaredFamily]]:
        if args and isinstance(args[0], type) and issubclass(args[0], DeclaredFamily):
            return _FamilyNameDecoder(target, args[0])
        raise UnsupportedFieldType(f"Unsupported JSON type: {target}")

    @classmethod
    def representation_plan(
        cls, target: object, args: tuple[object, ...], representation: type[FieldRepresentation],
    ) -> ValueDecoder[type[DeclaredFamily]]:
        return cls(target, cast(type, args[0]))

    def external_decoders(self, data: object) -> Iterable[ExternalDecoder]:
        return FieldCodec.external_decoders(self.bound)

    def accepts_value(self, value: object) -> bool:
        return isinstance(value, type) and issubclass(value, self.bound)


class _FamilyNameDecoder(_TypeDecoder, _ChoiceDecoder[type[DeclaredFamily]]):
    def fits_wire(self, data: object) -> bool:
        return type(data) is str

    def encode(self, value: type[DeclaredFamily]) -> str:
        return value.declared_name

    def editor_choices(self):
        return tuple((name, name) for name in self.bound.names())

    def decode(self, data):
        if type(data) is not str:
            raise MalformedRecord("Expected a declared family name.")
        return _declared_member(self.bound, data)


@dataclass(frozen=True, slots=True)
class _LiteralDecoder[T](_ChoiceDecoder[T]):
    origins = (Literal,)
    values: tuple[T, ...]
    value_plans: tuple[ValueDecoder[object], ...]

    @classmethod
    def from_annotation(cls, target, args):
        return cls(target, args, tuple(compile_decoder(type(value)) for value in args))

    def accepts_value(self, value: object) -> TypeGuard[T]:
        return any(type(value) is type(item) and value == item for item in self.values)

    def fits_wire(self, data: object) -> bool:
        return any(plan.fits_wire(data) for plan in self.value_plans)

    def encode(self, value: T) -> object:
        for item, plan in zip(self.values, self.value_plans, strict=True):
            if type(value) is type(item) and value == item:
                return plan.encode(value)
        raise TypeError(f"Value does not match {self.target}")

    def editor_choices(self):
        return tuple((str(value), value) for value in self.values)

    def decode(self, data: object) -> T:
        if self.accepts_value(data):
            return data
        raise MalformedRecord(f"Value does not match {self.target}")


@dataclass(frozen=True, slots=True)
class UnionDecoder[T](_ContextDecoder[T]):
    origins = (Union, types.UnionType)
    alternatives: tuple[ValueDecoder[T], ...]

    def sql_checks(self, column: str, quote: Callable[[object], str]) -> tuple[str, ...]:
        alternatives = tuple(
            alternative.sql_checks(column, quote) for alternative in self.alternatives
        )
        if not all(alternatives):
            return ()
        return (" OR ".join(
            "(" + " AND ".join(f"({check})" for check in checks) + ")"
            for checks in alternatives),)

    def field_paths(self, key: str, seen: frozenset[type] = frozenset()) -> tuple[tuple[str, ...], ...]:
        return tuple(path for member in self.alternatives for path in member.field_paths(key, seen))


    @property
    def accepts_null(self) -> bool:
        return any(alternative.accepts_null for alternative in self.alternatives)

    def fits_wire(self, data: object) -> bool:
        return any(alternative.fits_wire(data) for alternative in self.alternatives)

    @classmethod
    def from_annotation(cls, target, args):
        return cls(target, tuple(compile_decoder(item) for item in args))

    @classmethod
    def representation_plan(
        cls, target: object, args: tuple[object, ...], representation: type[FieldRepresentation],
    ) -> ValueDecoder[T]:
        alternatives = tuple(compile_decoder(Annotated[item, representation]) for item in args)
        return cls(target, cast(tuple[ValueDecoder[T], ...], alternatives))

    def decode_external(self, data: object, record: Mapping[str, object]) -> T:
        if any(alternative.accepts_external_value(data) for alternative in self.alternatives):
            return self.decode_bound(data, record)
        return self.decode_resolved(self.decode_candidates(
            data, lambda alternative: alternative.decode_external(data, record),
            fits=lambda alternative: alternative.fits_external(data),
        ))

    @property
    def editor_annotation(self):
        return Union[tuple(item.editor_annotation for item in self.alternatives)]

    def argument_options(self, argument: Argument) -> dict[str, object]:
        return self.alternatives[0].argument_options(argument)

    def accepts_value(self, value: object) -> bool:
        return any(alternative.accepts_value(value) for alternative in self.alternatives)

    def selected(self, value: T) -> ValueDecoder[T]:
        for alternative in self.alternatives:
            if alternative.accepts_value(value):
                return alternative
        raise TypeError(f"Value does not match {self.target}")

    def encode(self, value: T) -> object:
        return self.selected(value).encode(value)

    def compared(self, value: T) -> object:
        return self.selected(value).compared(value)

    def compile_comparison(self, compiled: set[object]) -> None:
        for alternative in self.alternatives:
            alternative.compile_comparison(compiled)

    def decode_bound(self, data: object, context: Mapping[str, object]) -> T:
        return self.decode_candidates(
            data, lambda alternative: alternative.decode_bound(data, context),
            fits=lambda alternative: alternative.fits_wire(data),
        )

    def shape_refusal(self, data: object) -> MalformedRecord:
        refusals = tuple(alternative.shape_refusal(data) for alternative in self.alternatives)
        refusal = MalformedRecord(
            f"Value does not match {self.target}: " + "; ".join(map(str, refusals)))
        refusal.__cause__ = refusals[0]
        return refusal

    def decode_candidates(
        self, data: object, decode: Callable[[ValueDecoder[T]], T], *,
        fits: Callable[[ValueDecoder[T]], bool],
    ) -> T:
        first_error = None
        # Shapes only rule alternatives out. When they rule out every one, the
        # union refuses with each shape's own reason and decodes nothing.
        candidates = tuple(filter(fits, self.alternatives))
        if not candidates:
            raise self.shape_refusal(data)
        try:
            for alternative in candidates:
                try:
                    return decode(alternative)
                except MalformedRecord as error:
                    if first_error is None:
                        first_error = error
            # Keep the original declaration-owned reason on total failure.
            raise MalformedRecord(
                f"Value does not match {self.target}: {first_error}"
            ) from first_error
        finally:
            # A swallowed traceback points back to this frame. End that
            # loan even on success, rather than leaving a cyclic payload
            # graph for a later UI-thread garbage collection.
            first_error = None


@dataclass(frozen=True, slots=True)
class _ArrayDecoder[T: Iterable[object]](ValueDecoder[T]):
    container: ClassVar[type]
    items: tuple[ValueDecoder[object], ...]

    def field_paths(self, key: str, seen: frozenset[type] = frozenset()) -> tuple[tuple[str, ...], ...]:
        return tuple(('[]', *path) for item in self.items for path in item.field_paths(key, seen))

    def fits_wire(self, data: object) -> bool:
        return isinstance(data, list)

    def shape_refusal(self, data: object) -> MalformedRecord:
        return MalformedRecord("Expected a JSON array.")

    @classmethod
    def from_annotation(cls, target, args):
        return cls(target, tuple(compile_decoder(item) for item in (args or (None,))))

    @classmethod
    def representation_plan(
        cls, target: object, args: tuple[object, ...], representation: type[FieldRepresentation],
    ) -> ValueDecoder[T]:
        return _OpaqueDecoder[T](cls.container)

    def decode_external(self, data: object, record: Mapping[str, object]) -> T:
        return self.decode_resolved(self.decode_items(
            data, lambda plan, value: plan.decode_external(value, record),
        ))

    def accepts_value(self, value: object) -> bool:
        return isinstance(value, self.container)

    def encode(self, value: T) -> list[object]:
        return self.encode_items(value)

    def compared(self, value: T) -> list[object]:
        return [plan.comparison(item) for plan, item in self.plan_items(list(value))]

    def compile_comparison(self, compiled: set[object]) -> None:
        for plan in self.items:
            plan.compile_comparison(compiled)

    def decode(self, data: object) -> T:
        return self.decode_items(data, lambda plan, value: plan.decode_bound(value, {}))

    def encode_items(self, items: Iterable[object]) -> list[object]:
        return [self.items[0].encode(item) for item in items]

    def decode_items(
        self, data: object, read: Callable[[ValueDecoder[object], object], object],
    ) -> T:
        if not isinstance(data, list):
            raise _ArrayDecoder.shape_refusal(self, data)
        construct: Callable[[Iterable[object]], T] = self.container
        return construct(read(plan, value) for plan, value in self.plan_items(data))

    def plan_items(self, data: list[object]) -> Iterable[tuple[ValueDecoder[object], object]]:
        return ((self.items[0], value) for value in data)


class _FrozenSetDecoder[E](_ArrayDecoder[frozenset[E]]):
    origins = (frozenset,)
    container = frozenset

    def encode(self, value: frozenset[E]) -> list[object]:
        return sorted(self.encode_items(value), key=FieldCodec.ordering)

    def compared(self, value: frozenset[E]) -> list[object]:
        return sorted(super().compared(value), key=FieldCodec.ordering)


class _ListDecoder[E](_ArrayDecoder[list[E]]):
    origins = (list,)
    container = list


class _TupleDecoder[E](_ArrayDecoder[tuple[E, ...]]):
    origins = (tuple,)
    container = tuple

    @classmethod
    def from_annotation(cls, target, args):
        if target is tuple:
            return _VariadicTupleDecoder(target, (compile_decoder(None),))
        if len(args) == 2 and args[1] is Ellipsis:
            return _VariadicTupleDecoder(target, (compile_decoder(args[0]),))
        return _FixedTupleDecoder(target, tuple(compile_decoder(item) for item in args))


class _VariadicTupleDecoder[E](_TupleDecoder[E]):
    """The inherited item decoder applies to every tuple element."""

    def argument_options(self, argument: Argument) -> dict[str, object]:
        if "nargs" in argument.options:
            return self.items[0].argument_options(argument)
        return super().argument_options(argument)


class _FixedTupleDecoder[E](_TupleDecoder[E]):
    def fits_wire(self, data: object) -> bool:
        return super().fits_wire(data) and len(cast(list[object], data)) == len(self.items)

    def shape_refusal(self, data: object) -> MalformedRecord:
        if super().fits_wire(data):
            return MalformedRecord("Tuple length does not match declaration")
        return super().shape_refusal(data)

    def plan_items(self, data: list[object]) -> Iterable[tuple[ValueDecoder[object], object]]:
        if not self.fits_wire(data):
            raise self.shape_refusal(data)
        return tuple(zip(self.items, data, strict=True))

    def encode_items(self, items: Iterable[object]) -> list[object]:
        return [plan.encode(item) for plan, item in zip(self.items, items, strict=True)]


def _unique_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result = dict(pairs)
    if len(result) != len(pairs):
        raise MalformedRecord("Duplicate JSON field")
    return result


def _object_entries(data: object) -> Iterable[tuple[object, object]]:
    if not isinstance(data, dict):
        raise MalformedRecord("Expected a JSON object.")
    return data.items()


def _object_or_pair_entries(data: object) -> Iterable[tuple[object, object]]:
    """Keys that are not strings travel as an array of [key, value] pairs."""
    if isinstance(data, dict):
        return data.items()
    if isinstance(data, list) and all(isinstance(pair, list) and len(pair) == 2 for pair in data):
        return data
    raise MalformedRecord("Expected a JSON object or an array of key-value pairs.")


@dataclass(frozen=True, slots=True)
class _DictDecoder[K, V](ValueDecoder[dict[K, V]]):
    key: ValueDecoder[K]
    value: ValueDecoder[V]
    arguments: tuple[object, object]
    origins = (dict, Mapping)

    def field_paths(self, key: str, seen: frozenset[type] = frozenset()) -> tuple[tuple[str, ...], ...]:
        return tuple(('*', *path) for path in self.value.field_paths(key, seen))

    @staticmethod
    @abstractmethod
    def wire_mapping(entries: Iterable[tuple[object, object]]) -> object: ...

    def argument_options(self, argument: Argument) -> dict[str, object]:
        return {"type": FieldCodec.parse}

    @classmethod
    def from_annotation(cls, target, args):
        key, value = args or (str, None)
        plan = _StringKeyDictDecoder if key is str else _PairKeyDictDecoder
        return plan(target, compile_decoder(key), compile_decoder(value), (key, value))

    @classmethod
    def representation_plan(
        cls, target: object, args: tuple[object, ...], representation: type[FieldRepresentation],
    ) -> ValueDecoder[dict[K, V]]:
        return _OpaqueDecoder[dict[K, V]](dict)

    def accepts_value(self, value: object) -> bool:
        return isinstance(value, dict)

    def compile_comparison(self, compiled: set[object]) -> None:
        self.key.compile_comparison(compiled)
        self.value.compile_comparison(compiled)

    def compared(self, value: dict[K, V]) -> list[object]:
        entries = [(self.key.comparison(key), self.value.comparison(item))
                   for key, item in value.items()]
        return sorted(entries, key=lambda entry: FieldCodec.ordering(entry[0]))

    def decode(self, data: object) -> dict[K, V]:
        return self.decode_entries(
            data, lambda key: self.key.decode_bound(key, {}),
            lambda value: self.value.decode_bound(value, {}),
        )

    def decode_external(self, data: object, record: Mapping[str, object]) -> dict[K, V]:
        return self.decode_resolved(self.decode_entries(
            data, lambda key: self.key.decode_external(key, record),
            lambda value: self.value.decode_external(value, record),
        ))

    @staticmethod
    @abstractmethod
    def entries(data: object) -> Iterable[tuple[object, object]]:
        """The wire entries, as the key kind spells them: an object or a list of pairs."""

    def decode_entries(
        self, data: object, read_key: Callable[[object], K], read_value: Callable[[object], V],
    ) -> dict[K, V]:
        return {read_key(key): read_value(value) for key, value in self.entries(data)}

    def decode_keys(self, data, keys, selections):
        encoded = tuple(FieldCodec.encode(key) for key in keys)
        return {self.key.decode_bound(key, {}): self.value.decode_selected(value, selections)
                for key, value in self.entries(data) if key in encoded}


class _StringKeyDictDecoder[V](_DictDecoder[str, V]):
    def value_schema(self) -> dict[str, JsonValue]:
        return {"type": "object", "additionalProperties": FieldCodec.value_schema(self.arguments[1])}

    entries = staticmethod(_object_entries)

    def fits_wire(self, data: object) -> bool:
        return isinstance(data, dict)

    @staticmethod
    def wire_mapping(entries: Iterable[tuple[object, object]]) -> dict:
        return dict(entries)

    def encode(self, value: dict[str, V]) -> dict[str, object]:
        return self.wire_mapping((key, self.value.encode(item)) for key, item in value.items())

    def encode_document(self, value: dict[str, V]) -> dict[str, object]:
        return {key: self.value.encode_document(item) for key, item in value.items()}

    def decode_document(self, data: object) -> dict[str, V]:
        return {self.key.decode_bound(key, {}): self.value.decode_document(value)
                for key, value in self.entries(data)}


class _PairKeyDictDecoder[K, V](_DictDecoder[K, V]):
    def value_schema(self) -> dict[str, JsonValue]:
        return {"type": "array", "items": {
            "type": "array",
            "prefixItems": [FieldCodec.value_schema(argument) for argument in self.arguments],
            "minItems": 2, "maxItems": 2,
        }}

    entries = staticmethod(_object_or_pair_entries)

    def fits_wire(self, data: object) -> bool:
        return isinstance(data, (dict, list))

    @staticmethod
    def wire_mapping(entries: Iterable[tuple[object, object]]) -> list:
        return [[key, value] for key, value in entries]

    def encode(self, value: dict[K, V]) -> list[list[object]]:
        return self.wire_mapping((self.key.encode(key), self.value.encode(item))
                                 for key, item in value.items())


@dataclass(frozen=True, slots=True)
class _FamilyRecordDecoder[Member: DeclaredFamily](_ContextDecoder[Member]):
    """The encoded object carries its member's name under the family tag."""

    target: type[Member]

    def field_paths(self, key: str, seen: frozenset[type] = frozenset()) -> tuple[tuple[str, ...], ...]:
        return tuple(path for member in self.target.members_with(self.target)
                     for path in _member_decoders[member].field_paths(key, seen))

    def tagged(self, data: object) -> TypeGuard[dict[str, object]]:
        """The family form: an object naming its member under the family tag."""
        return isinstance(data, dict) and isinstance(data.get(self.target.family_discriminator), str)

    def fits_wire(self, data: object) -> bool:
        return self.tagged(data)

    def encode(self, value: Member) -> dict[str, object]:
        return {**value.record_tag(), **_member_decoders[type(value)].encode(value)}

    def compared(self, value: Member) -> object:
        return _member_decoders[type(value)].compared(value)

    def compile_comparison(self, compiled: set[object]) -> None:
        for member in self.target.members_with(self.target):
            _member_decoders[member].compile_comparison(compiled)

    def editor_choices(self):
        return tuple((member.label, {self.target.family_discriminator: member.declared_name})
                     for member in self.target.members_with(self.target))

    def argument_options(self, argument: Argument) -> dict[str, object]:
        """Every member is a command-line choice, labelled or not."""
        return {"choices": list(self.target.names())}

    def argument_text(self, encoded: object) -> object:
        return cast(Mapping[str, object], encoded)[self.target.family_discriminator]

    def argument_payload(self, text: object) -> object:
        return {self.target.family_discriminator: text}

    def shape_refusal(self, data: object) -> MalformedRecord:
        if isinstance(data, dict):
            return MalformedRecord(f"Expected a string family {self.target.family_discriminator}.")
        return MalformedRecord("Expected a family object.")

    def member(self, data: object) -> tuple[type[Member], dict]:
        if not self.tagged(data):
            raise _FamilyRecordDecoder.shape_refusal(self, data)
        tag = self.target.family_discriminator
        return _declared_member(self.target, data[tag]), {
            key: value for key, value in data.items() if key != tag
        }

    def decode_bound(self, data: object, context: Mapping[str, object]) -> Member:
        member, payload = self.member(data)
        return cast(Member, _member_decoders[member].decode_bound(payload, context))


class _LeafDocumentDecoder(_FamilyRecordDecoder):
    """A directly declared leaf document omits its family selector."""

    @property
    def leaf(self) -> ValueDecoder[object]:
        """The decoder of the record this document declares directly."""
        return _member_decoders[self.target]

    def fits_wire(self, data: object) -> bool:
        return self.tagged(data) or self.leaf.fits_wire(data)

    def shape_refusal(self, data: object) -> MalformedRecord:
        # The direct leaf form is this document's declared shape.
        return self.leaf.shape_refusal(data)

    def encode_document(self, value: DeclaredFamily) -> object:
        return _member_decoders[type(value)].encode(value)

    def decode_document(self, data: object) -> object:
        return self.leaf.decode_bound(data, {})


@dataclass(frozen=True, slots=True)
class _RecordDecoder[T](_ContextDecoder[T]):
    """A dataclass record. Its plan is looked up at decode time, so a
    record that contains itself compiles without recursion."""

    target: type[T]

    @property
    def plan(self) -> FieldCodec._RecordPlan:
        return FieldCodec._record_plan(self.target)

    @cached_property
    def compared_fields(self) -> tuple[FieldPlan, ...]:
        """The compiled decoder owns the compared-only view's lifetime. Class metadata
        and excluded context never enter this view; FieldPlan owns its value decoders."""
        return FieldCodec.compared_fields(self.target)

    def fits_wire(self, data: object) -> TypeGuard[dict[str, object]]:
        if not isinstance(data, dict):
            return False
        plan = self.plan
        return plan.required_wire_keys <= data.keys() <= plan.accepted_keys

    def encode(self, value: object) -> dict[str, object]:
        if not isinstance(value, self.target):
            raise MalformedRecord(f"Expected {self.target.__name__} record")
        result = self.plan.encoded(
            value, WireExclude, lambda entry, current: entry.value.encode(current)
        )
        result.update(
            (member.wire_name, FieldCodec.encode(getattr(value, name)))
            for name, member in FieldCodec.projections(self.target, WireExclude).items()
        )
        return result

    def compared(self, value: T) -> object:
        # Each compared field compares through its declared type. Value decoders
        # compile per field on demand, so excluded live readers never compile.
        return tuple((entry.name, entry.value.comparison(entry.current(value)))
                     for entry in self.compared_fields)

    def compile_comparison(self, compiled: set[object]) -> None:
        if self.target in compiled:
            return
        compiled.add(self.target)
        for entry in self.compared_fields:
            entry.value.compile_comparison(compiled)

    def field_paths(self, key: str, seen: frozenset[type] = frozenset()) -> tuple[tuple[str, ...], ...]:
        if self.target in seen:
            return ()
        visited = seen | {self.target}
        return tuple(path for entry in self.plan.bindings
                     for path in entry.field_paths(key, visited))

    def missing_fields(self, data: dict) -> dict[str, str]:
        return {key: f"Missing required fields for {self.target.__name__}: {key}; "
                     'fix: supply this declared field'
                for key in self.plan.required_wire_keys.difference(data)}

    def unknown_fields(self, data: dict) -> tuple[UnknownField, ...]:
        return tuple(UnknownField(self, (key,)) for key in data.keys() - self.plan.accepted_keys)


    def shape_refusal(self, data: object) -> MalformedRecord:
        if isinstance(data, dict):
            return RecordProblems(self.missing_fields(data), self.unknown_fields(data))
        return MalformedRecord("Expected a record object; fix: supply a JSON object.")

    def checked(self, data: object) -> dict[str, object]:
        if not self.fits_wire(data):
            raise self.shape_refusal(data)
        return data

    def decode_bound(self, data: object, context: Mapping[str, object]) -> T:
        return self.decode_entries(data, self.plan.bindings, {}, context, {})

    def decode_selected(
        self, data: object, selections: Mapping[tuple[type, str], object], *,
        context: Mapping[str, object] = {},
        field_types: Mapping[str, type[object]] = types.MappingProxyType({}),
    ) -> T:
        return self.decode_entries(data, self.plan.bindings, selections, context, field_types)

    def decode_entries(
        self, data: object, entries: tuple[FieldPlan, ...],
        selections: Mapping[tuple[type, str], object], context: Mapping[str, object],
        field_types: Mapping[str, type[object]],
    ) -> T:
        if not isinstance(data, dict):
            raise MalformedRecord("Expected a record object; fix: supply a JSON object.")
        problems = self.missing_fields(data)
        unknown = list(self.unknown_fields(data))
        target = self.target
        values = {}
        for entry in entries:
            key = (target, entry.name)
            try:
                if entry.name in field_types:
                    narrowed = compile_decoder(field_types[entry.name])
                    values.update(entry.decoded_using(
                        data, lambda raw: narrowed.decode_bound(raw, context),
                    ))
                else:
                    values.update(entry.decoded_selected(data, selections[key], selections)
                                  if key in selections else entry.decoded_bound(data, context))
            except MalformedRecord as refused:
                entry.locate(problems, refused)
                unknown.extend(entry.unknown_under(refused, self))
        if problems or unknown:
            raise RecordProblems(problems, tuple(unknown))
        return FieldCodec.construct(target, values)


@dataclass(frozen=True, slots=True)
class _EnumDecoder(_ChoiceDecoder[Enum]):
    origins = (Enum,)
    target: type[Enum]
    value_plan: ValueDecoder[object]

    @classmethod
    def from_annotation(cls, target, args):
        value_types = tuple(dict.fromkeys(type(member.value) for member in target))
        return cls(target, ValueDecoder.for_members(value_types))

    def encode(self, value: Enum) -> object:
        return self.value_plan.encode(value.value)

    def editor_choices(self):
        return tuple((str(member.value), member.value) for member in self.target)

    def decode(self, data):
        with MalformedRecord.refusing(f"Invalid {self.target.__name__}"):
            return self.target(data)


class _IntFlagDecoder(_EnumDecoder):
    """Declared flags support combinations beyond their individually named values."""

    __slots__ = ()
    origins = (IntFlag,)

    def sql_checks(self, column: str, quote: Callable[[object], str]) -> tuple[str, ...]:
        return ()


@overload
def compile_decoder[T](annotation: type[T]) -> ValueDecoder[T]: ...
@overload
def compile_decoder(annotation: object) -> ValueDecoder[object]: ...
@lru_cache(maxsize=None)
def compile_decoder(annotation: object) -> ValueDecoder[object]:
    """Compile each immutable declaration once; value paths never parse it again."""
    declared, representation = FieldCodec.representation(annotation)
    return representation.decoder_for(annotation, declared)


def _structural_decoder(annotation: object) -> ValueDecoder[object]:
    try:
        decoder = ValueDecoder.annotation_class(annotation)
    except KeyError:
        pass
    else:
        return decoder.from_annotation(annotation, get_args(annotation))
    if isinstance(annotation, type) and issubclass(annotation, DeclaredFamily):
        # A leaf document is its own only declared member.
        leaf_document = annotation.decodes_tagged_records() and annotation._members == (annotation,)
        plan = _LeafDocumentDecoder if leaf_document else _FamilyRecordDecoder
        return cast(ValueDecoder[object], plan(annotation))
    return _member_decoders[annotation]


@dataclass(frozen=True, slots=True)
class _PydanticDecoder(ValueDecoder[object]):
    """An external model owns its validation and JSON representation."""

    origins = (BaseModel,)
    target: type[BaseModel]

    def value_schema(self) -> dict[str, JsonValue]:
        # A model's root-relative references belong to that model's resource,
        # even when its schema is nested inside a tool field or union.
        identity = quote(f"{self.target.__module__}.{self.target.__qualname__}", safe="")
        return {
            "$id": f"urn:python-schema:{identity}",
            **FieldCodec.decode(dict[str, JsonValue], self.target.model_json_schema(
                by_alias=True, mode="validation",
            )),
        }

    @boundary_decoder
    def decode(self, data: object) -> BaseModel:
        with MalformedRecord.refusing(f"Invalid {self.target.__name__}"):
            return self.target.model_validate(data)

    def encode(self, value: object) -> object:
        if not isinstance(value, self.target):
            raise TypeError(f"Expected {self.target.__name__}, received {type(value).__name__}")
        return value.model_dump(mode="json", by_alias=True, exclude_none=True)


class ReportedError(Exception):
    """An error raised on the other side of a boundary, reported by its class and message.
    Its arguments are not its constructor's inputs or its whole state, so the original is
    never rebuilt; a field typed with an error class receives the reported error that also
    inherits that class (declared beside it), or the decode is refused."""

    reports: ClassVar[type[BaseException]] = Exception
    reporting: ClassVar[dict[type[BaseException], type[ReportedError]]] = {}

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        ReportedError.reporting[cls.reports] = cls

    @classmethod
    def reporting_for(cls, target: type[BaseException]) -> type[ReportedError]:
        """The reported error a field of ``target`` receives; a target with none declared refuses."""
        reporting = {Exception: ReportedError} | ReportedError.reporting
        if target not in reporting:
            raise MalformedRecord(f"No reported error is declared for {target.__name__}")
        return reporting[target]

    def __init__(self, kind: str, message: str):
        super().__init__(kind, message)
        self.kind, self.message = kind, message

    def __str__(self) -> str:
        return f"{self.kind}: {self.message}"


class ErrorRecord(TaggedUnion, affix=""):
    """How an error crosses a boundary: a declared error as its declared form, any other
    as its class and message. Each record answers the error a field of ``target`` receives."""


    @staticmethod
    def of(value: BaseException) -> ErrorRecord:
        """The boundary: an outgoing error is foreign until its class's recorder records it."""
        record: ErrorRecord = ErrorRecorder.handler_for(type(value))(value)
        return record

    @staticmethod
    def class_of(value: object) -> str:
        return f"{type(value).__module__}.{type(value).__qualname__}"

    @abstractmethod
    def error(self, target: type[BaseException]) -> BaseException: ...


@dataclass(frozen=True)
class DeclaredErrorRecord(TaggedRecordMember, ErrorRecord):
    error_class: str
    declared: JsonValue

    def error(self, target: type[BaseException]) -> BaseException:
        if self.error_class not in DeclaredError.declared_errors:
            raise MalformedRecord(f"{self.error_class} is not a declared error")
        return DeclaredError.declared_errors[self.error_class].from_wire(self.declared)


@dataclass(frozen=True)
class ReportedErrorRecord(TaggedRecordMember, ErrorRecord):
    error_class: str
    message: str

    def error(self, target: type[BaseException]) -> BaseException:
        return ReportedError.reporting_for(target)(self.error_class, self.message)


class ErrorRecorder(MroDispatch):
    """Each error kind declares how it crosses: the first handler along its MRO records it.

    DeclaredError is a mixin listed after its exception base, so BaseException precedes it in
    a declared error's MRO; the reported form is therefore declared on ``object``, which every
    MRO ends with."""

    @handles(DeclaredError)
    @classmethod
    def declared(cls, value: DeclaredError) -> ErrorRecord:
        return DeclaredErrorRecord(ErrorRecord.class_of(value), value.to_wire())

    @handles(object)
    @classmethod
    def reported(cls, value: BaseException) -> ErrorRecord:
        return ReportedErrorRecord(ErrorRecord.class_of(value), str(value))


class _ExceptionDecoder(ValueDecoder[BaseException]):
    """An error crosses as its ErrorRecord and arrives as the error that record answers for
    the field's type, refused when it is not one."""

    origins = (BaseException,)
    target: type[BaseException]

    def value_schema(self) -> dict[str, JsonValue]:
        return FieldCodec.value_schema(ErrorRecord)

    @boundary_decoder
    def decode(self, data: object) -> BaseException:
        error = FieldCodec.decode(ErrorRecord, data).error(self.target)
        if not isinstance(error, self.target):
            raise MalformedRecord(f"{type(error).__qualname__} is not a {self.target.__name__}")
        return error

    def encode(self, value: object) -> object:
        return FieldCodec.encode(ErrorRecord.of(cast(BaseException, value)), ErrorRecord)


class _MemberDecoders(dict[object, ValueDecoder[object]]):
    """Concrete declarations own one decoder for this process, after family-tag removal.

    Dictionary lookup retains the declared key/value types as well as the decoder lifetime;
    a generic record class is not confused with the hashability of its decoded instances.
    """

    def __missing__(self, target: object) -> ValueDecoder[object]:
        decoder: ValueDecoder[object]
        if isinstance(target, type) and issubclass(target, BaseModel):
            decoder = _PydanticDecoder(target)
        elif isinstance(target, type) and is_dataclass(target):
            decoder = _RecordDecoder(target)
        else:
            raise UnsupportedFieldType(f"Unsupported JSON type: {target}")
        self[target] = decoder
        return decoder


_member_decoders = _MemberDecoders()
