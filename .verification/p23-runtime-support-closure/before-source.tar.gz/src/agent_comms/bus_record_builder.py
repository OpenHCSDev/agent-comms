from __future__ import annotations

import sqlite3
from collections.abc import Callable

from agent_comms.messaging import messages

type RecordBuilder = Callable[[int, sqlite3.Connection], messages.BusRecord]
