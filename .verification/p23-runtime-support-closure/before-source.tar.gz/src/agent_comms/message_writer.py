"""The original bus append operations used by initial publication."""
from __future__ import annotations

from abc import ABC, abstractmethod
from agent_comms.bus_record_builder import RecordBuilder
from agent_comms.messaging import messages


class MessageWriter(ABC):
    __slots__ = ()

    @abstractmethod
    def append(self, build: RecordBuilder) -> messages.BusRecord: ...

    @abstractmethod
    def append_original(self, build: RecordBuilder) -> messages.BusRecord: ...
