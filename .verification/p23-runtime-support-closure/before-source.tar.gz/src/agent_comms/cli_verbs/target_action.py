from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from typing import Annotated

from pydantic import JsonValue

from agent_comms.messaging.channel_targets import CommandTarget
from agent_comms.cli_command import CliCommand
from agent_comms.cli_result import CliResult
from agent_comms.cli_support.target_arguments import TargetArguments
from agent_comms.comms import Comms
from agent_comms.nominal.field_codec import Argument


@dataclass(frozen=True, kw_only=True)
class TargetActionCliCommand(TargetArguments, declared_name="target-action"):
    help = "Execute a declared operation against its current target"
    operation: Annotated[str, Argument(flags=("--operation",))]
    arguments: Annotated[
        dict[str, JsonValue],
        Argument(
            flags=("--arguments",)
        ),
    ] = dataclasses.field(default_factory=dict)
    confirmed: Annotated[bool, Argument(flags=("--confirmed",))] = (
        False
    )

    def apply(self, ctx: Comms) -> CliResult:
        declaration = CliCommand.member_named(self.operation)
        return declaration.execute_target(
            ctx, declaration.selected_targets(CommandTarget.arguments(self.target, self.project)), self.arguments,
            confirmed=self.confirmed, channel=self.channel, project=self.project)
