"""Original work authority and the declared outcome of an attempt."""

from __future__ import annotations

from dataclasses import dataclass

from agent_comms.nominal.declared_family import DeclaredFamily
from agent_comms.nominal.field_codec import (
    MessageId,
    NullMember,
    OrderId,
    RetryDecisionId,
    TaggedRecordMember,
    TaggedUnion,
    TurnId,
)


class WorkDecision(DeclaredFamily, affix="Decision"):
    """The original authority granting new work, retained as its declared member."""


@dataclass(frozen=True)
class RetryDecision(WorkDecision):
    decision: RetryDecisionId


@dataclass(frozen=True)
class ComplianceDecision(WorkDecision):
    answer: MessageId


@dataclass(frozen=True)
class VerifiedTurnDecision(WorkDecision):
    turn: TurnId


@dataclass(frozen=True)
class OrderDecision(WorkDecision):
    order: OrderId


class AttemptResolution(TaggedUnion, affix="Resolution"):
    """Why an attempt ended; the absent member keeps the original null wire shape."""



class RecordedResolution(TaggedRecordMember, AttemptResolution, declared_name=None):
    """A supplied outcome keeps its original tagged record representation."""


@dataclass(frozen=True)
class NoResolution(NullMember, AttemptResolution):
    """The attempt has not recorded an outcome."""


@dataclass(frozen=True)
class DecidedResolution(RecordedResolution):
    decision: WorkDecision


@dataclass(frozen=True)
class GoalCleared(RecordedResolution):
    pass


@dataclass(frozen=True)
class OperatorStopped(RecordedResolution):
    pass


@dataclass(frozen=True)
class OriginFailed(RecordedResolution):
    pass


@dataclass(frozen=True)
class UnverifiedLaunchRetired(RecordedResolution):
    pass
