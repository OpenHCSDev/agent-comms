"""Real turn acquisition and terminal handling share the execution owner."""

import os
import signal
import sqlite3
import subprocess
import sys
from collections.abc import Callable
from contextlib import AbstractAsyncContextManager, closing
from dataclasses import fields

import pytest

from agent_comms import agent_events as events
from agent_comms.acp_failure import NativeTurnError
from agent_comms.comms import Comms, wire
from agent_comms.execution.child_process import ChildOutcome, ProcessIdentity
from agent_comms.execution.owned_turn import OwnedTurn
from agent_comms.execution.turn_failure import NativeChildSignaled
from agent_comms.goal_execution import GoalExecution
from agent_comms.goal_ledger import FailedTurnEvidence
from agent_comms.nominal.field_codec import FieldCodec, GoalId
from agent_comms.planning.goal_actions import (
    ActiveGoalAction,
    GoalAction,
    PausedGoalAction,
    RetryGoalAction,
    SetGoalAction,
)
from agent_comms.planning.goal_history import RecordedGoalHistory
from agent_comms.planning.goal_presentation import (
    AttemptFailedExecution,
    AttemptUnresolvedExecution,
    CompletedExecution,
    GoalExecutionControls,
    GoalSnapshot,
    IdleGoalExecution,
    PausedExecution,
    RetryableBlockExecution,
    RunnableExecution,
    RunningExecution,
    StandbyExecution,
)
from agent_comms.planning.goal_scope import OneGoal
from agent_comms.planning.goal_states import ActiveGoal, ModelPause
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import NativeThread
from agent_comms.storage.maintenance_barrier import MaintenanceOperator
from agent_comms.tool_caller import ToolCaller
from agent_comms.transport.tools.goals import CommsGoalHistoryTool
from goal_owner_fixture import GoalTurnOwners


@pytest.fixture
def execution_bus(copied_goal_bus):
    comms = copied_goal_bus
    comms.registry.declare(NativeThread(
        "worker", frozenset(), Checkout(comms.root.parent),
        process_identity=ProcessIdentity.capture(os.getpid())))
    comms.goals.update_goal("worker", SetGoalAction(text="Repair original work"))
    return comms


@pytest.mark.parametrize("execution_type", tuple(
    member for member in GoalExecution.members_with(GoalExecution)
    if fields(member) == fields(RunnableExecution)
))
def test_execution_identity_survives_wire_and_change_detection(execution_bus, execution_type):
    goal = execution_bus.registry.require("worker").goal
    execution = execution_type(goal.id)
    decoded = FieldCodec.decode(GoalExecution, FieldCodec.encode(execution))
    assert decoded == execution
    assert decoded.runnable() == execution.runnable()
    current = GoalSnapshot(goal, RunnableExecution(goal.id))
    assert current.execution.runnable()
    assert current.changed_by(GoalSnapshot(goal, execution)) == (current.execution != execution)


@pytest.mark.asyncio
@pytest.mark.parametrize("execution, expected_actions", (
    (IdleGoalExecution(), ()),
    (CompletedExecution(GoalId.mint()), ()),
    (AttemptUnresolvedExecution(GoalId.mint()), ()),
    (RunnableExecution(GoalId.mint()), (PausedGoalAction,)),
    (RunningExecution(GoalId.mint()), (PausedGoalAction,)),
    (StandbyExecution(GoalId.mint(), (), ()), (PausedGoalAction,)),
    (PausedExecution(GoalId.mint(), ModelPause()), (ActiveGoalAction,)),
    (RetryableBlockExecution(GoalId.mint(), "source fixture"), (RetryGoalAction,)),
))
async def test_execution_owns_toggle_dispatch_and_unavailability(
    execution: GoalExecutionControls, expected_actions: tuple[type[GoalAction], ...],
) -> None:
    actions: list[type[GoalAction]] = []
    unavailable: list[None] = []

    async def change(action: type[GoalAction]) -> None:
        actions.append(action)

    await execution.apply_toggle(change, lambda: unavailable.append(None))
    assert tuple(actions) == expected_actions
    assert execution.can_toggle() == bool(expected_actions)
    assert len(unavailable) == int(not expected_actions)


@pytest.fixture
async def turn_on(
    execution_bus: Comms, goal_turn_owners: GoalTurnOwners,
) -> Callable[..., AbstractAsyncContextManager[OwnedTurn]]:
    return await goal_turn_owners.for_bus(execution_bus)


def failure_count(comms):
    with closing(sqlite3.connect(comms.goals.open_goal_store().path)) as db:
        return FailedTurnEvidence.count(db)


@pytest.mark.asyncio
async def test_failed_turn_writes_ledger_once_and_reads_failed_execution(execution_bus, turn_on):
    comms = execution_bus
    goal = comms.registry.require("worker").goal.require()
    async with turn_on(comms) as turn:
        await turn.progress.done(events.Done("backend failed", False))
        turn.finish_goals()
        turn.finish_goals()
        assert failure_count(comms) == 1
        assert comms.registry.require("worker").goal == goal
        assert isinstance(comms.goals.goal_execution("worker"), AttemptFailedExecution)
    execution = comms.goals.goal_execution("worker")
    assert isinstance(execution, AttemptFailedExecution)
    async with turn_on(comms):
        # A message turn on the blocked goal leaves the block on the heartbeat.
        assert comms.goals.goal_execution("worker") == execution
    assert execution.toggle is RetryGoalAction
    assert execution.evidence.turn_id == turn.turn_id
    assert failure_count(comms) == 1
    assert comms.registry.require("worker").goal.state == ActiveGoal()


@pytest.mark.asyncio
async def test_goal_history_shows_the_ledgers_failed_attempt_beside_active_revisions(
    execution_bus, turn_on,
):
    comms = execution_bus
    async with turn_on(comms) as turn:
        await turn.progress.done(events.Done("backend failed", False))
        turn.finish_goals()
    recorded = CommsGoalHistoryTool(thread="worker").apply(comms, ToolCaller.from_actor("worker"))
    assert recorded.history[-1].after.state == ActiveGoal()
    assert recorded.failures == (comms.goals.goal_execution("worker").evidence,)
    assert recorded.failures[0].turn_id == turn.turn_id
    other = CommsGoalHistoryTool(thread="worker", goal_id=OneGoal(GoalId.mint())).apply(
        comms, ToolCaller.from_actor("worker"))
    assert other == RecordedGoalHistory.empty()


@pytest.mark.asyncio
async def test_provider_retry_during_live_turn_writes_no_goal_failure(execution_bus, turn_on):
    comms = execution_bus
    goal = comms.registry.require("worker").goal.require()
    async with turn_on(comms) as turn:
        store = comms.goals.open_goal_store()
        before = store.snapshot(goal.id)
        await turn.progress.done(events.Done("provider is retrying", False))
        await turn.progress.tool_ended(events.ToolEnd("read", "read", True, "source read"))
        assert store.snapshot(goal.id) == before
        assert failure_count(comms) == 0
        assert comms.registry.require("worker").goal == goal
        execution = comms.goals.goal_execution("worker")
        assert isinstance(execution, RunningExecution)
        assert execution.toggle is PausedGoalAction


@pytest.mark.asyncio
async def test_owner_stop_beats_backend_failure_and_next_turn_runs_without_retry(execution_bus, turn_on):
    comms = execution_bus
    async with turn_on(comms) as turn:
        await turn.progress.done(events.Done("dying backend", False))
        turn.runner.inputs.state(turn.session_id).owned().stop.request()
    # A new reader observes the same retained bus, without a Retry or goal write.
    relaunched = wire(comms.root)
    assert isinstance(relaunched.goals.goal_execution("worker"), RunnableExecution)
    assert relaunched.registry.require("worker").goal.state == ActiveGoal()
    assert failure_count(relaunched) == 0
    async with turn_on(relaunched) as next_turn:
        assert isinstance(relaunched.goals.goal_execution("worker"), RunningExecution)
        await next_turn.progress.tool_ended(events.ToolEnd("read", "read", True, "source read"))
        await next_turn.progress.done(events.Done("Continued without Retry", True))
    assert isinstance(relaunched.goals.goal_execution("worker"), RunnableExecution)
    assert failure_count(relaunched) == 0


@pytest.mark.asyncio
async def test_turn_failing_under_install_hold_is_stopped_not_blocked(execution_bus, turn_on):
    """An install holds maintenance before it signals owners; the hold is the stop."""
    comms = execution_bus
    async with turn_on(comms) as turn:
        await turn.progress.done(events.Done("tool claim refused under maintenance", False))
        held = comms.owners.maintenance.begin(MaintenanceOperator.current())
        turn.finish_goals()
        comms.owners.maintenance.clear(held)
    assert isinstance(comms.goals.goal_execution("worker"), RunnableExecution)
    assert failure_count(comms) == 0


def stopped_after(script: str) -> bool:
    """Whether the outcome a real child process leaves behind reports a stop."""
    code = subprocess.run([sys.executable, "-c", script], timeout=30).returncode
    reports: list[None] = []
    ChildOutcome.from_returncode(code).report_stopped(
        lambda: reports.append(None), NativeChildSignaled.stop_exits)
    return bool(reports)


def test_only_a_signal_ends_the_native_child_as_stopped():
    """A kill, and Pi's own SIGTERM/SIGHUP shutdown exits, are stops; a crash is not."""
    assert stopped_after("import os, signal; os.kill(os.getpid(), signal.SIGKILL)")
    assert stopped_after(f"raise SystemExit({128 + signal.SIGTERM})")
    assert stopped_after(f"raise SystemExit({128 + signal.SIGHUP})")
    assert not stopped_after("raise SystemExit(1)")
    assert not stopped_after("raise SystemExit(0)")


@pytest.mark.asyncio
async def test_turn_whose_child_was_signaled_is_stopped_not_blocked(execution_bus, turn_on):
    """A group kill reaches the child before the owner's stop callback; the goal stays runnable."""
    comms = execution_bus
    async with turn_on(comms) as turn:
        await turn.progress.done(events.Done(
            "killed with its owner", False, failure=NativeChildSignaled("Pi exited 143")))
    assert isinstance(comms.goals.goal_execution("worker"), RunnableExecution)
    assert failure_count(comms) == 0


@pytest.mark.asyncio
async def test_verified_productive_turn_recovers_blocked_generation(execution_bus, turn_on):
    comms = execution_bus
    async with turn_on(comms) as failed:
        await failed.progress.done(events.Done("backend failed", False))
    assert isinstance(comms.goals.goal_execution("worker"), AttemptFailedExecution)
    async with turn_on(comms, original_owner_input=True) as productive:
        await productive.progress.tool_ended(events.ToolEnd("read", "read", True, "source read"))
        await productive.progress.done(events.Done("Verified productive progress", True))
    assert isinstance(comms.goals.goal_execution("worker"), RunnableExecution)
    assert comms.registry.require("worker").goal.state == ActiveGoal()
    assert failure_count(comms) == 1  # The old failure remains evidence, never replayed.


@pytest.mark.asyncio
async def test_turn_refused_by_coordination_is_resumable_not_blocked(execution_bus, turn_on):
    """A bus refusal inside the turn's own drain says nothing about the backend; the goal resumes.

    The copied bus is not a private root, so the turn's drain (prepare_native) is refused
    by the real coordinator, as a stale fence or coverage deadline refuses it on a live bus.
    """
    comms = execution_bus
    async with turn_on(comms) as turn:
        with pytest.raises(NativeTurnError, match="PublicationActivationBlocked"):
            await turn.run_native()
    assert isinstance(comms.goals.goal_execution("worker"), RunnableExecution)
    assert failure_count(comms) == 0
