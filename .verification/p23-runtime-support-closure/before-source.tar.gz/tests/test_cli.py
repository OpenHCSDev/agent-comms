import argparse
import json
import os
import sys
from dataclasses import replace
from pathlib import Path

import pytest

from agent_comms.activity import ActivityState
from agent_comms.bus import Bus
from agent_comms.catalog_document import NoCatalog
from agent_comms.channel_management import ArchiveThreadsTagDisposition, TagDisposition
from agent_comms.messaging.channel_targets import (
    ChannelTarget,
    CommandTarget,
    NoChannel,
    PerTargetChannels,
    ProjectTarget,
)
from agent_comms.cli import CliInvocation, build_parser
from agent_comms.cli_bridges.shared import Send
from agent_comms.cli_command import (
    CliCommand,
    CommandSelectionChanged,
    TargetBatchResult,
    TargetCompleted,
    TargetEdit,
    TargetFailed,
)
from agent_comms.cli_commands import ThreadCreatedResult, ThreadStoppedResult
from agent_comms.cli_verbs.archive import ArchiveCliCommand
from agent_comms.cli_verbs.delete_tag import DeleteTagCliCommand
from agent_comms.cli_verbs.fork import ForkCliCommand
from agent_comms.cli_verbs.new import NewThreadCliCommand
from agent_comms.cli_verbs.pin_thread import PinThreadCliCommand
from agent_comms.cli_verbs.queue_restart import QueueRestartCliCommand
from agent_comms.cli_verbs.read_target import ReadTargetCliCommand
from agent_comms.cli_verbs.restart import RestartCliCommand
from agent_comms.cli_verbs.start import StartCliCommand
from agent_comms.cli_verbs.stop import StopCliCommand
from agent_comms.comms import wire
from agent_comms.errors import UnregisteredThreadError
from agent_comms.execution.child_process import NoProcess, ProcessIdentity
from agent_comms.execution.native_arguments import GivenArguments, GivenBinary
from agent_comms.execution.owner_lifecycle import OwnerStartResult
from agent_comms.execution.turn_lease import ActiveTurn, RecordedGeneration, StoredTurnRecord
from agent_comms.lifecycle_capability import Successful
from agent_comms.messaging.messages import NoticeRole, SendableRole
from agent_comms.nominal.field_codec import FieldCodec, MessageId, TurnId, compile_decoder
from agent_comms.pi_vocabulary import ServiceTier
from agent_comms.projects.checkouts import Checkout, LaunchCheckout
from agent_comms.registry.registry_store import RegistryStore
from agent_comms.registry.thread_identity import TurnIdentity, UserThreadRole
from agent_comms.registry.thread_model import UndeclaredModel
from agent_comms.registry.thread_status import (
    ArchivedThreadStatus,
    RunningThreadStatus,
    StoppedThreadStatus,
)
from agent_comms.registry.threads import (
    ChosenServiceTier,
    ExternalThread,
    NativeThread,
    NextTurnConfiguration,
)
from agent_comms.restart_scope import OneOwner
from agent_comms.session_file import RegistrySessionLocation
from agent_comms.ui_model.unread import ReplyUnread
from agent_comms.wake_policy import BoundedTriageWake, PassiveWake
from conftest import installed_comms
from native_unread_fixture import completed_snapshot


@pytest.fixture
def cli(capsys, tmp_path):
    """The command line over a root the installer prepared, as every installed root is."""
    Bus.install(Bus.path_in(tmp_path))

    def run(root_path, *argv: str) -> tuple[int, dict | None]:
        code = CliInvocation().invoke(["--root", str(root_path), *argv], sys.stdout)
        captured = capsys.readouterr().out
        return code, (json.loads(captured) if captured.strip() else None)

    return run


class TestCliSuccess:
    def test_thread_and_poll_requests_choose_their_member_from_the_command(
            self, cli, tmp_path, monkeypatch):
        """thread counts unread unless --no-pending; poll reads the calling thread unless
        --thread names one."""
        monkeypatch.setenv("AGENT_COMMS_THREAD", "a")
        monkeypatch.setenv("PI_WORKTREE", str(tmp_path))
        for name in ("a", "b"):
            assert cli(tmp_path, "register", "--name", name, "--worktree", "/wt")[0] == 0
        assert cli(tmp_path, "send", "--from", "b", "--to", "a", "--body", "hello")[0] == 0
        _, counted = cli(tmp_path, "thread", "--name", "a")
        _, uncounted = cli(tmp_path, "thread", "--name", "a", "--no-pending")
        assert counted["pending"] == 1 and "pending" not in uncounted
        assert counted.keys() - {"pending"} == uncounted.keys()
        _, mine = cli(tmp_path, "poll")
        _, named = cli(tmp_path, "poll", "--thread", "b")
        assert (mine["thread"]["name"], mine["thread"]["pending"], len(mine["inbox"])) \
            == ("a", 1, 1)
        assert (named["thread"]["name"], named["thread"]["pending"], named["inbox"]) == ("b", 0, [])

    def test_tool_catalog_and_generic_invocation(self, cli, tmp_path, monkeypatch):

        monkeypatch.delenv("AGENT_COMMS_THREAD", raising=False)
        code, out = cli(tmp_path, "tools")
        assert code == 0
        assert "service_tier" not in out
        assert "comms_archive" in {tool["name"] for tool in out["tools"]}
        cli(tmp_path, "register", "--name", "a", "--worktree", "/wt", "--execution", "native")
        comms = wire(tmp_path)
        for tier in ServiceTier:
            comms.threads.set_thread_configuration(
            comms.registry.require("a"), NextTurnConfiguration(service_tier=ChosenServiceTier(tier)))
            code, catalog = cli(tmp_path, "tools", "--name", "a")
            assert code == 0
            code, detail = cli(tmp_path, "thread", "--name", "a", "--no-pending")
            assert code == 0 and catalog["service_tier"] == detail["service_tier"] == tier.value
        code, out = cli(
            tmp_path,
            "tool",
            "--tool",
            "comms_threads",
            "--arguments",
            '{"active_only": false}',
        )
        assert code == 0 and out["threads"][0]["name"] == "a"

    def test_register_and_threads(self, cli, tmp_path):
        code, out = cli(tmp_path, "register", "--name", "a", "--worktree", "/wt", "--tags", "x,y")
        assert code == 0 and out == {"registered": "a"}
        code, out = cli(tmp_path, "threads")
        assert code == 0 and out["threads"][0]["name"] == "a"
        assert out["threads"][0]["tags"] == ["x", "y"]
        assert isinstance(out["threads"][0]["activity"], str)
        assert "activity_detail" in out["threads"][0]
        code, presence = cli(tmp_path, "who")
        assert code == 0 and presence == {"who": []}

    def test_send_and_inbox(self, cli, tmp_path):
        cli(tmp_path, "register", "--name", "a", "--worktree", "/wt")
        cli(tmp_path, "register", "--name", "b", "--worktree", "/wt")
        code, out = cli(
            tmp_path, "send", "--from", "a", "--to", "b", "--body", "hi", "--type", "alert"
        )
        assert code == 0 and "id" in out
        code, out = cli(tmp_path, "inbox", "--thread", "b")
        assert out["messages"][0]["text"] == "hi"
        assert out["messages"][0]["type"] == "alert"

    def test_send_notice_and_conversation_record_channel_wake_modes(self, cli, comms):

        comms.channels.create_tag("comms")
        for name in ("sender", "one", "two"):
            tags = frozenset() if name == "sender" else frozenset({"comms"})
            comms.registry.declare(NativeThread(name, tags, Checkout(comms.root)))
        for role, expected in (("notice", PassiveWake()), ("conversation", BoundedTriageWake())):
            code, sent = cli(comms.root, "send", "--from", "sender", "--to", "#comms",
                             "--body", "public record", "--role", role)
            assert code == 0
            message_id = FieldCodec.decode(MessageId, sent["id"])
            delivery, = comms.bus.bus.lookup_message(message_id).deliveries()
            assert len(delivery.recipients) == 2
            assert [decision.wake_policy() for decision in delivery.decisions] == [expected] * 2
        parser = argparse.ArgumentParser()
        Send.add_arguments(parser)
        bridged = Send.from_arguments(parser.parse_args(
            ["--to", "#comms", "--body", "record", "--role", "notice"]))
        assert bridged.role is NoticeRole
        assert SendableRole.names() == ("conversation", "notice")

    def test_thread_detail_and_stop_and_heartbeat(self, cli, tmp_path):
        # A CLI registration is an inbox; only an attached process connects it.
        cli(tmp_path, "register", "--name", "a", "--worktree", "/wt")
        code, out = cli(tmp_path, "thread", "--name", "a")
        assert out["name"] == "a" and out["status"] == "no_bridge"
        code, out = cli(tmp_path, "heartbeat", "--name", "a")
        assert out == {"heartbeat": "a"}
        assert cli(tmp_path, "thread", "--name", "a")[1]["status"] == "no_bridge"

        with wire(tmp_path).registry.external_process("a", ProcessIdentity.capture(os.getpid())):
            assert cli(tmp_path, "thread", "--name", "a")[1]["status"] == "connected"
        assert cli(tmp_path, "thread", "--name", "a")[1]["status"] == "no_bridge"
        code, out = cli(tmp_path, "stop", "--name", "a")
        assert out == {"stopped": "a"}
        code, out = cli(tmp_path, "thread", "--name", "a")
        assert out["status"] == "no_bridge"

    def test_archive_retains_thread_declaration(self, cli, tmp_path):
        cli(tmp_path, "register", "--name", "archived", "--worktree", "/wt")
        cli(tmp_path, "stop", "--name", "archived")
        code, out = cli(tmp_path, "archive", "--name", "archived")
        assert code == 0 and out == {"archived": "archived"}

    def test_rename_self_uses_declared_caller(self, cli, tmp_path):
        cli(tmp_path, "register", "--name", "a", "--worktree", "/wt")
        code, out = cli(tmp_path, "tool", "--tool", "comms_rename_self", "--from", "a",
                        "--arguments", '{"display_name":"renamed"}')
        assert code == 0
        assert out == {"previous": "a", "current": "renamed", "changed": True}
        _, detail = cli(tmp_path, "thread", "--name", "a")
        assert detail["name"] == "renamed"

    def test_ledger_read_and_merge(self, cli, tmp_path):
        merge_file = tmp_path / "merge.json"
        merge_file.write_text(json.dumps({"k": "v"}))
        cli(tmp_path, "register", "--name", "a", "--worktree", "/wt")
        code, out = cli(tmp_path, "ledger-merge", "--merge-from", str(merge_file), "--author", "a")
        assert out == {"merged": True}
        code, out = cli(tmp_path, "ledger")
        assert out["k"] == "v"


class TestCliFailClosed:

    def test_generic_invocation_rejects_non_object_arguments(self, cli, tmp_path):
        code, out = cli(tmp_path, "tool", "--tool", "comms_threads", "--arguments", "[]")
        assert code == 1 and "JSON object" in out["error"]

    def test_unknown_sender_is_error_exit_code(self, cli, tmp_path):
        cli(tmp_path, "register", "--name", "b", "--worktree", "/wt")
        code, out = cli(tmp_path, "send", "--from", "ghost", "--to", "b", "--body", "hi")
        assert code == 1 and "Sender" in out["error"]

    def test_unknown_thread_detail_is_one_failed_json_object(self, cli, tmp_path):
        code, out = cli(tmp_path, "thread", "--name", "ghost")
        assert code == 1 and "not registered" in out["error"]
        assert set(out) == {"error", "type"} and out["type"] == "failed"


class TestStatusCommand:
    def test_status_empty_wire(self, cli, tmp_path):
        code, out = cli(tmp_path, "status")
        assert out == {"status": []}

    def test_status_shows_activity(self, cli, tmp_path):

        cli(tmp_path, "register", "--name", "a", "--worktree", "/wt", "--pid", str(os.getpid()))

        comms = wire(tmp_path)
        comms.agents.set_activity("a", ActivityState.WORKING, "bash: echo hi")
        code, out = cli(tmp_path, "status")
        row = out["status"][0]
        assert row["thread"] == "a" and row["state"] == "working"
        assert row["detail"] == "bash: echo hi"


class TestDeclaredTargetActions:
    def test_catalog_edit_rename_review_delete_and_reopen(self, cli, tmp_path):
        cli(tmp_path, 'register', '--name', 'tagged', '--worktree', str(tmp_path), '--tags', 'first')
        code, catalog = cli(tmp_path, 'target-actions', '--target', 'tagged', '--project', str(tmp_path))
        assert code == 0
        edit = next(action for action in catalog['actions'] if action['command'] == 'thread-tags')
        assert edit['parameters']['properties']['tags']['editor_default'] == 'first'
        assert 'name' not in edit['parameters']['properties']
        code, edited = cli(tmp_path, 'target-edit', '--project', str(tmp_path), '--target', 'tagged', '--operation', 'thread-tags',
                           '--arguments', '{"tags":"first,second"}')
        assert code == 0 and edited['tags'] == ['first', 'second']
        code, renamed = cli(tmp_path, 'target-edit', '--project', str(tmp_path), '--target', '#second', '--operation', 'rename-tag',
                            '--arguments', '{"new_name":"renamed"}')
        assert code == 0 and renamed['name'] == 'renamed'
        code, refused = cli(tmp_path, 'target-action', '--project', str(tmp_path), '--target', '#renamed', '--operation', 'delete-tag')
        assert code == 1 and 'Remove #renamed' in refused['error']
        code, deleted = cli(tmp_path, 'target-action', '--project', str(tmp_path), '--target', '#renamed', '--operation', 'delete-tag', '--confirmed')
        outcome, = deleted['outcomes']
        assert code == 0 and outcome['result']['tag'] == 'renamed'
        assert outcome['result']['removed_tag']
        assert outcome['result']['removed_threads'] == []
        _, detail = cli(tmp_path, 'thread', '--name', 'tagged')
        assert detail['tags'] == ['first']
        _, builtins = cli(tmp_path, 'target-actions', '--project', str(tmp_path), '--target', '#all')
        assert not {'rename-tag','delete-tag','delete-view'} & {action['command'] for action in builtins['actions']}
        code, refused = cli(tmp_path, 'target-action', '--project', str(tmp_path), '--target', 'tagged', '--operation', 'thread-tags',
                            '--arguments', '{"name":"other","tags":[]}')
        assert code == 1 and 'overridden' in refused['error']


class TestSelectedTargetActions:
    @staticmethod
    def declared(root):

        comms = installed_comms(root)
        for name, tags in (("alpha", {"team"}), ("beta", {"other"})):
            comms.registry.declare(NativeThread(name, frozenset(tags), Checkout(root)), StoppedThreadStatus())
        return comms

    def test_catalog_absent_view_actor_has_no_backend_actions(self, tmp_path):

        comms = self.declared(tmp_path)
        for name in ('project', 'missing'):
            selected = CliCommand.selected_targets((CommandTarget.named(name),))
            assert CliCommand.target_catalog(comms, selected, project=Checkout(tmp_path)) == ()
        refused = TargetEdit(ArchiveCliCommand,
                             ArchiveCliCommand.selected_targets((CommandTarget.named('project'),)),
                             {}, project=Checkout(tmp_path)).apply(comms)
        failed, = refused.outcomes
        assert failed.error_type == UnregisteredThreadError.__name__
        comms.registry.declare(NativeThread('project', frozenset(), Checkout(tmp_path)), StoppedThreadStatus())
        actions = CliCommand.target_catalog(
            comms, CliCommand.selected_targets((CommandTarget.named('project'),)),
            project=Checkout(tmp_path))
        assert any(action.declaration is ArchiveCliCommand for action in actions)

    def test_restart_catalog_queues_for_the_original_owner_even_while_busy(self, tmp_path):

        comms = self.declared(tmp_path)
        # Observe an authentic other process; this check never signals or restarts it.
        owner = replace(comms.registry.require('alpha'),
                        process_identity=ProcessIdentity.capture(os.getppid()))
        status = RunningThreadStatus()
        comms.registry.register(owner, status)
        action = next(action for action in CliCommand.target_catalog(
            comms, CliCommand.selected_targets((CommandTarget.named('alpha'),)),
            project=Checkout(tmp_path))
            if action.declaration is QueueRestartCliCommand)
        assert action.bound == (QueueRestartCliCommand(name='alpha'),)
        assert action.editable_fields == ()
        for arguments in ({'agent_bin': json.dumps('/other/native')}, {'agent_args': '--other'}):
            with pytest.raises(ValueError):
                RestartCliCommand.execute_target(
                    comms, RestartCliCommand.selected_targets((CommandTarget.named('alpha'),)),
                    arguments, project=str(tmp_path))
        explicit = RestartCliCommand(name=OneOwner('alpha'), agent_bin=GivenBinary('/operator/native'),
                                      agent_args=GivenArguments(('--no-extensions',)))
        options = build_parser().parse_args([
            'restart', '--name', 'alpha', '--agent-bin', '/operator/native',
            '--agent-args=--no-extensions'])
        parsed = options.command_declaration.from_arguments(options)
        assert parsed == explicit
        assert not QueueRestartCliCommand.thread_bindings(comms, owner, StoppedThreadStatus(), NoChannel(), catalog=NoCatalog())
        busy = TurnIdentity(owner.incarnation, owner.turn_generation + 1)
        record = StoredTurnRecord.begin(
            comms.registry.store.path,
            busy,
            ActiveTurn(
                TurnId('c9bc072f4fa8189466c2a8f2c36a56a4'),
                owner.require_process(),
                turn_generation=RecordedGeneration(busy.generation),
            ),
            registry_type=RegistryStore,
        )
        assert QueueRestartCliCommand.thread_bindings(comms,
            replace(owner, turn_record=record, turn_generation=busy.generation), status, NoChannel(), catalog=NoCatalog())
        assert not QueueRestartCliCommand.thread_bindings(comms,
            replace(owner, process_identity=ProcessIdentity.capture(os.getpid())), status, NoChannel(), catalog=NoCatalog())
        assert not QueueRestartCliCommand.thread_bindings(comms,
            owner.as_member(ExternalThread), status, NoChannel(), catalog=NoCatalog())

    def test_tag_batch_requires_each_confirmation_before_removing_any_tag(self, tmp_path):

        comms = self.declared(tmp_path)
        selected = ('#team', '#other')
        action = next(action for action in CliCommand.target_catalog(
            comms, CliCommand.selected_targets(tuple(CommandTarget.named(name) for name in selected)), project=Checkout(tmp_path))
            if action.declaration is DeleteTagCliCommand)
        assert tuple(command.name for command in action.bound) == ('team', 'other')
        assert 'Remove #team' in action.confirmation
        assert '#other' in action.confirmation
        assert action.confirmation.count('Threads, saved views and history remain.') == 1
        before = comms.registry.snapshot()
        with pytest.raises(ValueError):
            TargetEdit(DeleteTagCliCommand, DeleteTagCliCommand.selected_targets(tuple(CommandTarget.named(name) for name in selected)), {}, project=Checkout(tmp_path)).apply(comms)
        assert comms.registry.snapshot() == before
        result = TargetEdit(DeleteTagCliCommand, DeleteTagCliCommand.selected_targets(tuple(CommandTarget.named(name) for name in selected)), {}, project=Checkout(tmp_path), confirmed=True).apply(comms)
        assert result.successful
        assert tuple(outcome.result.tag for outcome in result.outcomes) == ('team', 'other')
        assert all(outcome.result.removed_tag for outcome in result.outcomes)
        assert not comms.registry.require('alpha').tags
        assert not comms.registry.require('beta').tags

    def test_tag_batch_preserves_active_refusal_and_mixed_target_outcomes(self, tmp_path):

        comms = self.declared(tmp_path)
        comms.registry.register(comms.registry.require('beta'), RunningThreadStatus())
        selected = ('#team', '#other', 'alpha', '#all')
        action = next(action for action in CliCommand.target_catalog(
            comms, CliCommand.selected_targets(tuple(CommandTarget.named(name) for name in selected)), project=Checkout(tmp_path))
            if action.declaration is DeleteTagCliCommand)
        assert tuple(command.name for command in action.bound) == ('team', 'other')
        result = TargetEdit(DeleteTagCliCommand, DeleteTagCliCommand.selected_targets(tuple(CommandTarget.named(name) for name in selected)),
            {'disposition': compile_decoder(TagDisposition).encode_editor(ArchiveThreadsTagDisposition())},
            project=Checkout(tmp_path), confirmed=True).apply(comms)
        assert not result.successful
        assert tuple(outcome.target for outcome in result.outcomes) == tuple(
            CommandTarget.named(name) for name in selected)
        assert result.outcomes[0].items_with(Successful, result.outcomes[0])
        assert not any(outcome.items_with(Successful, outcome) for outcome in result.outcomes[1:])
        with pytest.raises(ValueError, match="Initial direct target must be visible"):
            comms.registry.status('alpha').require_visible()
        comms.registry.status('beta').require_active()
        assert comms.registry.require('alpha').tags == frozenset({'team'})
        assert comms.registry.require('beta').tags == frozenset({'other'})

    def test_catalog_projects_mixed_operations_and_original_editor_fields(self, tmp_path):

        comms = self.declared(tmp_path)
        actions = CliCommand.target_catalog(
            comms, CliCommand.selected_targets((CommandTarget.named('alpha'), CommandTarget.named('beta'), CommandTarget.named('#team'))),
            PerTargetChannels({"alpha": ("#team",), "beta": ("#other",)}), project=Checkout(tmp_path),
        )
        catalog = {action.declaration.declared_name: action for action in actions}
        assert set(catalog) == {"start", "stop", "restore-owner", "archive", "pin-thread", "read-target", "delete-tag"}
        assert len(catalog["pin-thread"].bound) == 3
        assert not catalog["pin-thread"].editable_fields
        assert catalog["archive"].confirmation.startswith("Archive #team?")
        with pytest.raises(ValueError):
            catalog["archive"].edited({}).with_confirmation(False)
        reviewed = catalog["archive"].edited({}).with_confirmation(True)
        assert reviewed.targets == ("alpha", "beta", "#team")
        assert not catalog["read-target"].encode()["parameters"]["properties"]
        assert all(command.worktree == Checkout(tmp_path)
                   for command in catalog["read-target"].bound)

    def test_mixed_archive_reports_partial_results_in_selection_order(self, cli, tmp_path):

        comms = self.declared(tmp_path)
        comms.registry.declare(NativeThread('active', frozenset({'team'}), Checkout(tmp_path)),
                               RunningThreadStatus())
        code, result = cli(tmp_path, "target-action", "--project", str(tmp_path), "--targets", "alpha", "active", "#team",
                           "--operation", "archive", "--confirmed")
        assert code == 1
        assert tuple(FieldCodec.decode(CommandTarget, outcome["target"])
                     for outcome in result["outcomes"]) == tuple(
                         CommandTarget.named(name) for name in ("alpha", "active", "#team"))
        assert result["outcomes"][0]["result"] == {"archived": "alpha"}
        assert result["outcomes"][1]["error_type"] == CommandSelectionChanged.__name__
        assert "no longer available" in result["outcomes"][1]["error"]
        assert result["outcomes"][2]["result"]["archived"] is True
        with pytest.raises(ValueError, match="Initial direct target must be visible"):
            comms.registry.status("alpha").require_visible()
        comms.registry.status("active").require_active()
        assert comms.bus.require_channel("#team").archived

    def test_confirmation_and_target_override_refuse_before_any_batch_write(self, cli, tmp_path):
        comms = self.declared(tmp_path)
        original = comms.registry.snapshot()
        catalog = comms.channels.catalog.read()
        code, failure = cli(tmp_path, "target-edit", "--project", str(tmp_path), "--targets", "alpha", "#team",
                            "--operation", "archive", "--arguments", "{}")
        assert code == 1 and "Archive #team" in failure["error"]
        assert comms.registry.snapshot() == original
        assert comms.channels.catalog.read() == catalog
        code, failure = cli(tmp_path, "target-action", "--project", str(tmp_path), "--targets", "alpha", "#team",
                            "--operation", "archive", "--arguments", '{"name":"beta"}', "--confirmed")
        assert code == 1 and "overridden" in failure["error"]
        assert comms.registry.snapshot() == original
        assert comms.channels.catalog.read() == catalog

    def test_channel_stop_deduplicates_selected_member(self, tmp_path):

        comms = self.declared(tmp_path)
        comms.channels.update_tags("beta", add=frozenset({"team"}))
        for name in ("alpha", "beta"):
            comms.registry.register(comms.registry.require(name), RunningThreadStatus())
        result = TargetEdit(StopCliCommand, StopCliCommand.selected_targets((CommandTarget.named('#team'), CommandTarget.named('alpha'))), {}, project=Checkout(tmp_path)).apply(comms)
        assert isinstance(result, TargetBatchResult) and result.successful
        assert len(result.outcomes) == 2
        assert {outcome.result.stopped for outcome in result.outcomes} == {"alpha", "beta"}
        assert all(comms.registry.status(name).stopped for name in ("alpha", "beta"))
        assert not result.reconnect_targets()

    def test_channel_start_uses_native_visible_roster_without_launching(self, tmp_path):

        comms = self.declared(tmp_path)
        comms.registry.declare(ExternalThread('external', frozenset({'team'}), Checkout(tmp_path)), StoppedThreadStatus())
        comms.registry.declare(NativeThread('archived', frozenset({'team'}), Checkout(tmp_path)),
                               ArchivedThreadStatus())
        comms.registry.declare(NativeThread('human', frozenset({'team'}), Checkout(tmp_path), role=UserThreadRole),
                               StoppedThreadStatus())

        snapshot = comms.registry.snapshot()
        catalog = comms.channels.catalog.read()
        target = ChannelTarget("#team")
        commands = StartCliCommand.bindings(
            target.resolve(snapshot, comms.bus.require_channel), comms, NoChannel(),
            project=Checkout(tmp_path), snapshot=snapshot, catalog=catalog)
        assert tuple(command.name for command in commands) == ("alpha",)
        assert all(comms.registry.require(name).process_identity == NoProcess()
                   for name in ("alpha", "external", "archived", "human"))

    def test_mixed_pins_keep_each_rows_original_channel(self, tmp_path):

        comms = self.declared(tmp_path)
        before = {name: comms.registry.require(name).tags for name in ("alpha", "beta")}
        result = TargetEdit(PinThreadCliCommand, PinThreadCliCommand.selected_targets((CommandTarget.named('alpha'), CommandTarget.named('beta'), CommandTarget.named('#team'))), {},
                            project=Checkout(tmp_path), channel=PerTargetChannels({"alpha": ("#team",), "beta": ("#other",)})).apply(comms)
        assert result.successful and len(result.outcomes) == 3
        catalog = comms.channels.catalog.read()
        assert comms.bus.require_channel("#team").pinned
        assert catalog.pinned_threads("#team") == {"alpha"}
        assert catalog.pinned_threads("#other") == {"beta"}
        assert {name: comms.registry.require(name).tags for name in before} == before

    def test_same_owner_memberships_pin_independently_and_archive_once(self, tmp_path):

        comms = self.declared(tmp_path)
        comms.channels.update_tags("alpha", add=frozenset({"other"}))
        channels = {"alpha": ("#team", "#other")}
        action = next(action for action in CliCommand.target_catalog(
            comms, CliCommand.selected_targets((CommandTarget.named('alpha'),)), PerTargetChannels(channels), project=Checkout(tmp_path))
            if action.declaration is PinThreadCliCommand)
        assert tuple(command.channel for command in action.bound) == ("#team", "#other")
        result = TargetEdit(PinThreadCliCommand, PinThreadCliCommand.selected_targets(tuple(CommandTarget.named(name) for name in action.targets)), {}, project=Checkout(tmp_path), channel=action.channels).apply(comms)
        assert result.successful and len(result.outcomes) == 2
        document = comms.channels.catalog.read()
        assert document.pinned_threads("#team") == {"alpha"}
        assert document.pinned_threads("#other") == {"alpha"}
        assert comms.registry.require("alpha").tags == frozenset({"team", "other"})
        with pytest.raises(ValueError):
            TargetEdit(ArchiveCliCommand, ArchiveCliCommand.selected_targets((CommandTarget.named('alpha'),)), {},
                       project=Checkout(tmp_path), channel=PerTargetChannels(channels)).apply(comms)
        archive = next(action for action in CliCommand.target_catalog(
            comms, CliCommand.selected_targets((CommandTarget.named('alpha'),)), PerTargetChannels(channels), project=Checkout(tmp_path))
            if action.declaration is ArchiveCliCommand)
        result = TargetEdit(ArchiveCliCommand, ArchiveCliCommand.selected_targets((CommandTarget.named('alpha'),)), {}, project=Checkout(tmp_path), channel=archive.channels).apply(comms)
        assert result.successful and len(result.outcomes) == 1
        assert result.outcomes[0].result.archived == "alpha"

    def test_missing_membership_reports_failure_without_losing_other_pin(self, tmp_path):

        comms = self.declared(tmp_path)
        comms.channels.update_tags("alpha", add=frozenset({"other"}))
        channels = {"alpha": ("#team", "#other")}
        action = next(action for action in CliCommand.target_catalog(
            comms, CliCommand.selected_targets((CommandTarget.named('alpha'),)), PerTargetChannels(channels), project=Checkout(tmp_path))
            if action.declaration is PinThreadCliCommand)
        comms.channels.update_tags("alpha", remove=frozenset({"team"}))
        result = TargetEdit(PinThreadCliCommand, PinThreadCliCommand.selected_targets(tuple(CommandTarget.named(name) for name in action.targets)), {}, project=Checkout(tmp_path), channel=action.channels).apply(comms)
        assert not result.successful and len(result.outcomes) == 2
        assert not result.outcomes[0].items_with(Successful, result.outcomes[0])
        assert "#team" in result.outcomes[0].error
        assert result.outcomes[1].items_with(Successful, result.outcomes[1])
        document = comms.channels.catalog.read()
        assert not document.pinned_threads("#team")
        assert document.pinned_threads("#other") == {"alpha"}

    def test_mixed_read_marks_human_views_without_advancing_executor_delivery(self, tmp_path):

        comms = self.declared(tmp_path)
        source = tmp_path / 'alpha.jsonl'
        source.write_text(json.dumps({'type': 'message', 'timestamp': '2026-09-20T00:00:01Z', 'message': {
            'role': 'assistant', 'content': [{'type': 'text', 'text': 'Saved reply'}],
        }}) + '\n')
        comms.registry.declare(NativeThread('alpha', frozenset({'team'}), Checkout(tmp_path), session_file=RegistrySessionLocation.from_path(str(source), comms.root)))
        comms.channels.update_tags('beta', add=frozenset({'team'}))
        viewer = comms.messaging.user_identity(Checkout(tmp_path)).name
        comms.messaging.send('alpha', 'beta', 'Executor message').message.message_id
        comms.messaging.send('alpha', viewer, 'Human DM').message.message_id
        comms.messaging.send('alpha', '#team', 'Channel message').message.message_id
        before = completed_snapshot(comms, Checkout(tmp_path))
        assert before.thread_unread['alpha'] == ReplyUnread(1)
        assert before.unread['alpha'].count == 1
        # The canonical tag change also publishes its membership notification.
        assert before.channel_unread['#team'].count == 2
        result = TargetEdit(ReadTargetCliCommand, ReadTargetCliCommand.selected_targets((CommandTarget.named('alpha'), CommandTarget.named('#team'))),
                            {}, project=Checkout(tmp_path)).apply(comms)
        assert result.successful and tuple(item.result.read for item in result.outcomes) == ('alpha', '#team')
        after = completed_snapshot(comms, Checkout(tmp_path))
        assert after.thread_unread['alpha'] == ReplyUnread(0)
        assert after.unread['alpha'].count == 0
        assert after.channel_unread['#team'].count == 0
        assert comms.bus.pending_count('beta', CommandTarget.named('alpha')) == 1
        # DeliveryScope excludes beta's own membership notice from its inbox.
        assert comms.bus.pending_count('beta', CommandTarget.named('#team')) == 1

    def test_catalog_and_execution_keep_missing_and_single_only_targets_truthful(self, tmp_path):

        comms = self.declared(tmp_path)
        actions = CliCommand.target_catalog(comms, CliCommand.selected_targets((CommandTarget.named('missing'), CommandTarget.named('alpha'))), project=Checkout(tmp_path))
        assert {action.declaration.declared_name for action in actions} >= {"archive", "read-target"}
        result = TargetEdit(ArchiveCliCommand, ArchiveCliCommand.selected_targets((CommandTarget.named('missing'), CommandTarget.named('alpha'))), {}, project=Checkout(tmp_path)).apply(comms)
        assert not result.successful
        assert result.outcomes[0].target == CommandTarget.named("missing") and not result.outcomes[0].items_with(Successful, result.outcomes[0])
        assert result.outcomes[1].result.archived == "alpha"
        with pytest.raises(ValueError):
            TargetEdit(ForkCliCommand, ForkCliCommand.selected_targets((CommandTarget.named('alpha'), CommandTarget.named('beta'))), {}, project=Checkout(tmp_path)).apply(comms)


def test_result_kind_decides_exit_code_and_navigation_targets():

    launched = OwnerStartResult("alpha", 11, True)
    attached = OwnerStartResult("beta", 12, False)
    batch = TargetBatchResult((
        TargetCompleted(CommandTarget.named("alpha"), StartCliCommand(name="alpha"), launched),
        TargetCompleted(CommandTarget.named("beta"), StartCliCommand(name="beta"), attached),
        TargetFailed(CommandTarget.named("gamma"), "ValueError", "gone"),
    ))
    assert launched.reconnect_targets() == ("alpha",) and attached.reconnect_targets() == ("beta",)
    assert batch.reconnect_targets() == ("alpha", "beta")
    assert batch.completed_count == 2
    assert TargetBatchResult(batch.outcomes[:1]).completed_count == 1
    assert TargetBatchResult(batch.outcomes[-1:]).completed_count == 0
    assert batch.exit_code() == 1
    assert TargetBatchResult(batch.outcomes[:2]).exit_code() == 0
    assert ThreadStoppedResult("alpha").exit_code() == 0
    assert not launched.open_targets() and not batch.open_targets()
    created = ThreadCreatedResult("child", NoProcess())
    assert created.open_targets() == ("child",)
    command = NewThreadCliCommand(name="child", project=LaunchCheckout(Path("/project")), model=UndeclaredModel())

    completed = TargetCompleted(ProjectTarget(Checkout(Path("/project"))), command, created)
    assert TargetBatchResult((completed, batch.outcomes[-1], completed)).open_targets() == ("child",)
