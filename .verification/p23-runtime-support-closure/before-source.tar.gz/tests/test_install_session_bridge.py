"""Real session endpoint retirement; no live home, provider, or package mutation."""



import json
import os
import signal
import socket
import sqlite3
import subprocess
import sys
import time
from contextlib import ExitStack, closing, contextmanager
from functools import partial
from html import escape
from pathlib import Path

import pytest

from agent_comms.activity import ActivityStore
from agent_comms.cli_bridges import claude, hook_session
from agent_comms.cli_bridges.claude_protocol import ClaudeMonitorFrame
from agent_comms.cli_bridges.monitor import (
    ClaimedReplacement,
    InspectSession,
    PauseSession,
    SessionInformation,
)
from agent_comms.cli_bridges.session_watch import LapsedWatch, LiveWatch, WatchClaim
from agent_comms.cli_bridges.shared import (
    MONITOR_FRAME,
    Binding,
    MonitorBridgeStopped,
    MonitorBridgeSwapping,
    MonitorProbe,
    ReleasedSessionBridge,
    Serve,
    SessionBridge,
    SessionBridgeResumes,
    UnacknowledgedPause,
    UnobservedBridge,
)
from agent_comms.comms import wire
from agent_comms.execution.child_process import (
    ProcessIdentity,
    SpawnedProcess,
)
from agent_comms.execution.turn_bound import LastTurns
from agent_comms.fd_readiness import ready
from agent_comms.installer.native_build_inputs import DetachedChildStdio
from agent_comms.installer.refusals import UpgradeRefused
from agent_comms.launch_runtime import LaunchRuntime
from agent_comms.nominal.field_codec import FieldCodec
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import ExternalThread
from agent_comms.root_runtime import RootRuntime
from agent_comms.transcript_events import AssistantTranscript
from agent_comms_hooks.watch import NoSessionBridge, WatchRecord
from conftest import installed_comms
from source_programs import SourcePrograms
from transcript_record_fixture import transcript_record

SERVE_FROM_SOURCE = (sys.executable, '-c', 'from agent_comms.cli_bridges.claude import main; main()')


@contextmanager
def session_bridge(tmp_path, home, program=SERVE_FROM_SOURCE, *, state_directory=None,
                   runtime=LaunchRuntime.running()):
    """``runtime`` serves ``program`` and so owns the bus it attaches to."""
    comms = installed_comms(tmp_path / 'bus')
    RootRuntime.publish(comms.root, runtime)
    comms.registry.declare(ExternalThread(
        'bridge-copy', frozenset(), Checkout(tmp_path)))
    transcript = tmp_path / 'copied-session.jsonl'
    transcript.write_text('')
    state = (home / '.local/state/agent-comms/claude-bridge-copy'
             if state_directory is None else state_directory)
    base_state = state
    state = base_state / 'bridge-copy'
    binding = Binding(
        root=str(comms.root), owner=comms.registry.require('bridge-copy').incarnation,
        thread=transcript.stem, start=Binding.bus_head(str(comms.root)))
    with Binding.open(state) as db:
        binding.bind(db)
    claim = WatchClaim(binding.thread, home)
    command = (str(Path(sys.executable).with_name('agent-comms-claude-bridge')),
               'watch', '--state', str(state))
    claim.enrol(WatchRecord(binding.bus, binding.root, command, base_state))
    owner = ProcessIdentity.capture(os.getpid())
    log = tmp_path / 'bridge.log'
    env = {**os.environ, 'HOME': str(home), 'CLAUDE_CODE_SESSION_ID': claim.thread}
    with log.open('wb') as output:
        child = subprocess.Popen(
            (*program, 'serve', '--state', str(state), '--owner',
             json.dumps(FieldCodec.encode_record(owner)), '--transcript', str(transcript)),
            env=env, stdout=output, stderr=output,
        )
    try:
        deadline = time.monotonic() + 20
        while child.poll() is None and time.monotonic() < deadline:
            try:
                observed = InspectSession().information(claim.socket_path)
                break
            except (FileNotFoundError, ConnectionRefusedError):
                time.sleep(.05)
        else:
            pytest.fail(log.read_text())
        yield home, claim, observed, child, log, env
    finally:
        stop(child)


def stop(child):
    if child.poll() is None:
        child.terminate()
    child.wait(timeout=15)


def frame(child):
    assert ready(child.stdout.fileno(), 15), 'Monitor wrote nothing'
    line = child.stdout.readline()
    assert line, child.stderr.read().decode()
    return MONITOR_FRAME.validate_json(line)


def probe(child):
    value = frame(child)
    assert isinstance(value, MonitorProbe)
    return value


@pytest.mark.timeout(180)
def test_real_bridge_outlives_a_held_activity_store_and_publishes_once(tmp_path, bridge_home):
    """A real serve process, a real transcript line and a real write lock held past the store's
    busy timeout: the process stays up, and on release the update lands exactly once."""
    with session_bridge(tmp_path, bridge_home) as (_home, _claim, _observed, child, log, _env):
        comms = wire(tmp_path / 'bus')
        activity = ActivityStore(comms.root)
        with activity.writing():
            pass
        transcript = tmp_path / 'copied-session.jsonl'
        record = dict(sessionId='copied-session', timestamp='2026-10-31T01:00:00Z')
        with closing(sqlite3.connect(activity.path, isolation_level=None)) as held:
            held.execute('BEGIN IMMEDIATE')
            with transcript.open('a') as stream:
                stream.write(json.dumps(record | dict(
                    type='user', uuid='00000000-0000-4000-8000-000000000001', promptId='held',
                    origin=dict(kind='human'), message=dict(content='hold it'))) + '\n')
                stream.write(json.dumps(record | dict(
                    type='assistant', uuid='00000000-0000-4000-8000-000000000002',
                    message=dict(content=[dict(type='text', text='published once')]))) + '\n')
                stream.write(json.dumps(dict(type='system', subtype='turn_duration')) + '\n')
            deadline = time.monotonic() + 60
            while (b'Transcript update waits for the store' not in log.read_bytes()
                   and child.poll() is None and time.monotonic() < deadline):
                time.sleep(.1)
            assert child.poll() is None, log.read_text()
            assert b'Transcript update waits for the store' in log.read_bytes(), log.read_text()
            held.execute('ROLLBACK')

        def published():
            return [event for turn in comms.transcripts.turns('bridge-copy', LastTurns()).turns
                    for event in turn.events
                    if isinstance(event, AssistantTranscript) and event.text == 'published once']

        deadline = time.monotonic() + 60
        while not published() and child.poll() is None and time.monotonic() < deadline:
            time.sleep(.1)
        time.sleep(1)
        assert child.poll() is None, log.read_text()
        assert len(published()) == 1, log.read_text()


def test_real_monitor_survives_bridge_retirement_and_requires_a_fresh_probe(tmp_path, bridge_home):
    with (
        session_bridge(tmp_path, bridge_home) as (home, claim, _, child, log, env),
        ExitStack() as cleanup,
    ):
        monitor = subprocess.Popen(
            (sys.executable, '-c',
             'import asyncio; from agent_comms.cli_bridges.monitor import read_monitor; '
             'from agent_comms.cli_bridges.shared import '
             'MonitorBridgeStopped, MonitorBridgeSwapping; '
             'from agent_comms.cli_bridges.session_watch import WatchClaim; '
             'from agent_comms.cli_bridges.shared import Serve; '
             'asyncio.run(read_monitor(WatchClaim("copied-session"), '
             'MonitorBridgeStopped.announce, MonitorBridgeSwapping.announce, Serve.relaunch))'),
            env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        cleanup.callback(stop, monitor)
        first = probe(monitor)
        (bridge,) = Serve.running(home)
        with ExitStack() as resources:
            bridge.pause(resources)
            assert monitor.poll() is None
        assert child.wait(timeout=15) == 0, log.read_text()
        # A stopped bridge is an outage the session hears about, once, from the reader.
        notice = frame(monitor)
        assert isinstance(notice, MonitorBridgeStopped)
        assert str(claim.path.with_suffix('.log')) in notice.notice
        with log.open('ab') as output:
            successor = subprocess.Popen(child.args, env=env, stdout=output, stderr=output)
        cleanup.callback(stop, successor)
        second = probe(monitor)
        assert second.session == first.session
        assert second.token != first.token
        assert monitor.poll() is None

def confirm(transcript, line, record):
    """The session's transcript records the Monitor event, as Claude writes it."""
    with transcript.open('a') as output:
        output.write(json.dumps(dict(
            type='user', uuid=transcript_record(record), timestamp='2026-10-16T16:40:05.123Z',
            sessionId=transcript.stem, promptId='prompt', origin=dict(kind='task-notification'),
            message=dict(content='<task-notification><event>' + escape(line)
                         + '</event></task-notification>'))) + '\n')


def relayed(child):
    """A delivered message reaches the Monitor as text, not a protocol frame: its sender's
    header line, then the one-line body these tests send."""
    assert ready(child.stdout.fileno(), 15), 'Monitor wrote nothing'
    assert child.stdout.readline().decode().startswith(ClaudeMonitorFrame.HEADER_PREFIX)
    return child.stdout.readline().decode()


def send_as_peer(built, tmp_path, env, body, *, declare=False):
    """The bus belongs to the built runtime, so the sender attaches as that runtime."""
    code = (
        'import sys; from pathlib import Path; from agent_comms.comms import wire; '
        'from agent_comms.projects.checkouts import Checkout; from agent_comms.registry.threads import NativeThread; '
        'comms = wire(Path(sys.argv[1])); '
        + ('comms.registry.declare(NativeThread("peer", frozenset(), Checkout(Path(sys.argv[3])))); ' if declare else '')
        + 'comms.messaging.send("peer", "bridge-copy", sys.argv[2])'
    )
    sources = os.pathsep.join(dict.fromkeys(str(package.parent) for package in built.packages))
    subprocess.run(
        (str(built.runtime.interpreter), '-c', code, str(tmp_path / 'bus'), body, str(tmp_path)),
        env={**env, 'PYTHONPATH': os.pathsep.join((sources, env.get('PYTHONPATH', '')))},
        check=True, capture_output=True, timeout=60)


def test_a_sigkilled_bridge_comes_back_through_its_claim_with_no_repeat(
        tmp_path, bridge_home, monkeypatch):
    built = SourcePrograms.create(tmp_path / 'built')
    with (
        session_bridge(tmp_path, bridge_home, (str(built.script(claude.main)),), runtime=built.runtime)
        as (home, claim, observed, child, log, env),
        ExitStack() as cleanup,
    ):
        current = home / LaunchRuntime.current_pointer().relative_to(Path.home())
        current.parent.mkdir(parents=True)
        current.symlink_to(built.prefix.absolute(), target_is_directory=True)
        monitor = subprocess.Popen(
            (sys.executable, '-c',
             'import asyncio; from agent_comms.cli_bridges.monitor import read_monitor; '
             'from agent_comms.cli_bridges.shared import MonitorBridgeStopped, MonitorBridgeSwapping, Serve; '
             'from agent_comms.cli_bridges.session_watch import WatchClaim; '
             f'asyncio.run(read_monitor(WatchClaim({claim.thread!r}), '
             'MonitorBridgeStopped.announce, MonitorBridgeSwapping.announce, Serve.relaunch))'),
            env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        cleanup.callback(stop, monitor)
        send = partial(send_as_peer, built, tmp_path, env)
        first = probe(monitor)
        confirm(observed.transcript, first.model_dump_json(), 'first-probe')
        send('uncertain when the bridge dies', declare=True)
        assert 'uncertain when the bridge dies' in relayed(monitor)

        os.kill(child.pid, signal.SIGKILL)
        child.wait(timeout=15)
        assert claim.socket_path.exists()

        # Nothing announced an outage and nothing was replayed: the next line is a fresh probe.
        second = probe(monitor)
        assert second.token != first.token
        resumed = InspectSession().information(claim.socket_path)
        assert resumed.process != observed.process
        cleanup.callback(os.kill, resumed.process.pid, signal.SIGTERM)
        assert isinstance(claim.state(), LiveWatch)
        confirm(observed.transcript, second.model_dump_json(), 'second-probe')
        send('sent after the kill')
        after = relayed(monitor)
        assert 'sent after the kill' in after
        assert 'uncertain when the bridge dies' not in after
        assert not [row for row in Path(f'/proc/{resumed.process.pid}/task').iterdir()
                    for grandchild in (row / 'children').read_text().split()
                    if b'watch' in Path(f'/proc/{grandchild}/cmdline').read_bytes()]


def test_a_bridge_that_stopped_itself_is_announced_and_not_relaunched(tmp_path, bridge_home):
    """No socket file is left behind, so the reader says the outage instead of restarting it."""
    with (
        session_bridge(tmp_path, bridge_home) as (home, claim, _, child, log, env),
        ExitStack() as cleanup,
    ):
        monitor = subprocess.Popen(
            (sys.executable, '-c',
             'import asyncio; from agent_comms.cli_bridges.monitor import read_monitor; '
             'from agent_comms.cli_bridges.shared import MonitorBridgeStopped, MonitorBridgeSwapping, Serve; '
             'from agent_comms.cli_bridges.session_watch import WatchClaim; '
             f'asyncio.run(read_monitor(WatchClaim({claim.thread!r}), '
             'MonitorBridgeStopped.announce, MonitorBridgeSwapping.announce, Serve.relaunch))'),
            env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        cleanup.callback(stop, monitor)
        probe(monitor)
        child.terminate()
        child.wait(timeout=15)
        assert isinstance(frame(monitor), MonitorBridgeStopped)
        assert isinstance(claim.state(), LapsedWatch)


@pytest.mark.parametrize('wrong_identity', ('owner', 'process'))
def test_wrong_pause_identity_cannot_stop_the_real_session_bridge(
        tmp_path, bridge_home, wrong_identity):
    with session_bridge(tmp_path, bridge_home) as (_, claim, observed, child, log, _):
        other = ProcessIdentity.capture(os.getppid())
        request = PauseSession(
            owner=other if wrong_identity == 'owner' else observed.owner,
            process=other if wrong_identity == 'process' else observed.process,
        )
        with pytest.raises(ValueError, match='different'):
            request.exchange(claim.socket_path)
        assert InspectSession().information(claim.socket_path).process == observed.process
        assert child.poll() is None, log.read_text()


def test_installer_pause_closes_the_real_bridge_and_eof_never_replays_or_relaunches(
        tmp_path, bridge_home):
    with session_bridge(tmp_path, bridge_home) as (home, claim, observed, child, log, _):
        directory = home / '.local/state/agent-comms'
        with Binding.open(directory / 'claude-bridge-copy' / 'bridge-copy') as db:
            (binding,) = Binding.select(db)
        with Binding.open(directory / 'claude-bridge-historical-copy') as db:
            binding.bind(db)
        # Historical journals can name the same canonical live claim.
        (bridge,) = Serve.running(home)
        assert bridge.observed.process == observed.process
        with ExitStack() as resources:
            paused = bridge.pause(resources)
            assert paused.bridge == bridge
            assert child.poll() is None
            # The paused process keeps the claim; no session hook sees it lapse.
            assert isinstance(claim.state(), LiveWatch)
            assert not claim.socket_path.exists()
        # Losing the installer connection grants no fallback runtime or retry.
        assert child.wait(timeout=15) == 0, log.read_text()
        assert isinstance(claim.state(), LapsedWatch)
        with Binding.open(home / '.local/state/agent-comms/claude-bridge-copy/bridge-copy') as db:
            assert Binding.select(db)[0].thread == claim.thread


@pytest.mark.parametrize('state_directory', (
    Path('.local/state/claude-comms-inbox'), Path('custom session storage'),
), ids=('default-claude-state', 'custom-state'))
def test_installer_discovers_the_live_claim_independent_of_state_directory(
        tmp_path, bridge_home, state_directory):
    with session_bridge(tmp_path, bridge_home,
                        state_directory=bridge_home / state_directory) as (
            home, claim, observed, child, log, _):
        (bridge,) = Serve.running(home)
        assert bridge.claim == claim
        assert bridge.observed.process == observed.process
        with ExitStack() as resources:
            paused = bridge.pause(resources)
            assert paused.bridge == bridge
            assert isinstance(claim.state(), LiveWatch)
            # A held claim's absent socket is an install's gap: the reader waits it out.
            claim.state().await_socket(claim, FileNotFoundError(claim.socket_path))
        assert child.wait(timeout=15) == 0, log.read_text()
        assert isinstance(claim.state(), LapsedWatch)
        # A bridge that stopped ends the Monitor reader with the reason, not a silent spin.
        with pytest.raises(NoSessionBridge):
            claim.state().await_socket(claim, FileNotFoundError(claim.socket_path))


def test_session_start_and_runtime_replacement_share_the_declared_launcher(tmp_path):
    owner = ProcessIdentity.capture(os.getpid())
    operation = Serve(owner=owner, transcript=tmp_path / 'copied-session.jsonl')
    record = WatchRecord('copy', '/copied/bus', ('/old/bin/agent-comms-claude-bridge',
                                             'watch', '--state', '/copied/state'),
                         Path('/copied/state'))
    runtime = LaunchRuntime(tmp_path / 'runtime-B/bin/python')
    command = operation.command(record, runtime)
    assert command[:4] == (str(runtime.interpreter.with_name('agent-comms-claude-bridge')),
                           'serve', '--state', '/copied/state')
    assert FieldCodec.decode(ProcessIdentity, FieldCodec.parse(command[5])) == owner
    assert command[7] == str(operation.transcript)


def bridges_serving(state):
    """Every process serving this test's state; a second bridge would show here."""
    key = os.fsencode(state)  # under the per-test home; the successor's absolute path ends with it
    serving = []
    for entry in Path('/proc').iterdir():
        try:
            arguments = (entry / 'cmdline').read_bytes().split(b'\0')
        except (NotADirectoryError, FileNotFoundError, PermissionError, ProcessLookupError):
            continue
        if any(argument.endswith(key) for argument in arguments):
            serving.append(int(entry.name))
    return serving


def test_install_swap_keeps_the_claim_and_resumes_the_same_process_on_the_new_runtime(
        tmp_path, bridge_home, monkeypatch):
    old, new = (SourcePrograms.create(tmp_path / name) for name in ('old', 'new'))
    with session_bridge(tmp_path, bridge_home, (str(old.script(claude.main)),), runtime=old.runtime) as (
            home, claim, observed, child, log, env):
        current = home / LaunchRuntime.current_pointer().relative_to(Path.home())
        current.parent.mkdir(parents=True)
        current.symlink_to(new.prefix.absolute(), target_is_directory=True)
        # Publication hands the bus to the installed runtime, as the installer's does.
        RootRuntime.publish(tmp_path / 'bus', new.runtime)
        monkeypatch.setenv('HOME', str(home))
        assert observed.runtime.prefix == old.prefix.resolve()
        packet = json.dumps(dict(session_id=claim.thread, hook_event_name='SessionStart',
                                 transcript_path=str(observed.transcript)))
        (bridge,) = Serve.running(home)
        bridges = SessionBridgeResumes()
        with ExitStack() as cleanup:
            with bridges.holding((bridge,)):
                assert not claim.socket_path.exists()
                assert isinstance(claim.state(), LiveWatch)
                hook = subprocess.run(
                    (str(old.script(hook_session.SessionHook.main)),), input=packet, text=True, capture_output=True,
                    timeout=40, env={**env, 'CLAUDE_CODE_SESSION_ID': claim.thread,
                                     'CLAUDE_PID': str(os.getpid())})
                assert hook.returncode != 0
                assert 'No second bridge launched' in hook.stdout + hook.stderr
                assert bridges_serving(
                    home / '.local/state/agent-comms/claude-bridge-copy' / 'bridge-copy'
                ) == [child.pid]
                # A Monitor started inside the gap waits for the endpoint instead of exiting.
                monitor = subprocess.Popen(
                    (sys.executable, '-c',
                     'import asyncio; from agent_comms.cli_bridges.monitor import read_monitor; '
                     'from agent_comms.cli_bridges.shared import MonitorBridgeStopped, MonitorBridgeSwapping; '
                     'from agent_comms.cli_bridges.session_watch import WatchClaim; '
                     'from agent_comms.cli_bridges.shared import Serve; '
                     f'asyncio.run(read_monitor(WatchClaim({claim.thread!r}), '
                     'MonitorBridgeStopped.announce, MonitorBridgeSwapping.announce, Serve.relaunch))'),
                    env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                )
                cleanup.callback(stop, monitor)
                swapping = frame(monitor)
                assert isinstance(swapping, MonitorBridgeSwapping)
                assert swapping.notice == (
                    f'Waiting for the session bridge of {claim.thread}: '
                    'an install holds its claim and is replacing it.'
                )
            bridges.require_resumed()
            assert bridges.failures == ()
            # The install no longer waits for the bridge; the bridge resumes itself.
            resumed = InspectSession().awaited(claim, lambda claim: None)
            assert resumed.process == observed.process
            assert resumed.process.pid == child.pid
            assert resumed.runtime.prefix == new.prefix.resolve()
            state = claim.state()
            assert isinstance(state, LiveWatch)
            assert Path(state.record.command[0]).resolve() == new.script(claude.main).resolve()
            assert bridges_serving(
                home / '.local/state/agent-comms/claude-bridge-copy' / 'bridge-copy'
            ) == [child.pid]
            # The next frame must be the probe, so a second swapping frame fails here.
            assert probe(monitor).session == claim.thread
            assert child.poll() is None, log.read_text()


def test_a_bridge_that_never_answers_pause_refuses_the_install_by_name(
        tmp_path, bridge_home, monkeypatch):
    claim = WatchClaim('silent-session', bridge_home)
    current = bridge_home / LaunchRuntime.current_pointer().relative_to(Path.home())
    current.parent.mkdir(parents=True)
    (tmp_path / 'runtime').mkdir()
    current.symlink_to(tmp_path / 'runtime', target_is_directory=True)
    monkeypatch.setenv('HOME', str(bridge_home))
    claim.socket_path.parent.mkdir(parents=True, exist_ok=True)
    me = ProcessIdentity.capture(os.getpid())
    observed = SessionInformation(owner=me, process=me, runtime=LaunchRuntime.running(),
                                  transcript=tmp_path / 'silent-session.jsonl')
    bridges = SessionBridgeResumes()
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as silent:
        silent.bind(str(claim.socket_path))
        silent.listen()
        with pytest.raises(UpgradeRefused) as refused, bridges.holding(
                (SessionBridge(claim, observed),)):
            pass
        # The late bridge finds its runtime waiting once it acknowledges.
        accepted, _ = silent.accept()
        with accepted, accepted.makefile('rb') as stream:
            pause = FieldCodec.decode(PauseSession, FieldCodec.parse(stream.readline().decode()))
            assert pause.process == me
            assert FieldCodec.decode(LaunchRuntime, FieldCodec.parse(stream.readline().decode()))
    unanswered = (f'Session bridge silent-session at {claim.socket_path} '
                  'did not acknowledge pause within 30 s')
    assert str(refused.value) == f'install: refused: {unanswered}'
    (failure,) = bridges.failures
    assert isinstance(failure, UnacknowledgedPause)
    assert str(failure) == unanswered


def test_a_successor_that_exits_before_serving_is_unobserved_without_a_deadline(
        tmp_path, bridge_home):
    """The released claim lock, not a clock, says the successor is gone."""
    claim = WatchClaim('exited-session', bridge_home)
    with claim.held(WatchRecord('bridge-copy', str(tmp_path), ('serve',), tmp_path)):
        pass
    assert isinstance(claim.state(), LapsedWatch)
    me = ProcessIdentity.capture(os.getpid())
    observed = SessionInformation(owner=me, process=me, runtime=LaunchRuntime.running(),
                                  transcript=tmp_path / 'exited-session.jsonl')
    runtime = LaunchRuntime.running()
    outcome = ReleasedSessionBridge(SessionBridge(claim, observed), runtime).confirm()
    assert outcome == UnobservedBridge(
        'exited-session', f'process exited before serving {runtime.prefix}')


def test_a_bridge_whose_installer_left_before_ready_stays_stopped(tmp_path, capsys):
    installer, peer = socket.socketpair()
    installer.close()
    operation = Serve(owner=ProcessIdentity.capture(os.getpid()),
                      transcript=tmp_path / 'copied-session.jsonl')
    record = WatchRecord('bridge-copy', str(tmp_path), ('watch',), tmp_path)
    ClaimedReplacement(peer, claim=-1).finish(operation, record)
    assert 'Session bridge installer gone before ready; left stopped' in capsys.readouterr().err


def test_a_bridge_that_dies_during_pause_counts_as_stopped(tmp_path, bridge_home, monkeypatch):
    """Installs 21, 22 and 23 (2026-10-25): the outgoing bridge died writing the registry
    under the install's hold and closed its socket unanswered; the pause parsed the empty
    line. Its exited process, checked by identity, is the stop the pause asked for."""
    claim = WatchClaim('dying-session', bridge_home)
    current = bridge_home / LaunchRuntime.current_pointer().relative_to(Path.home())
    current.parent.mkdir(parents=True)
    (tmp_path / 'runtime').mkdir()
    current.symlink_to(tmp_path / 'runtime', target_is_directory=True)
    monkeypatch.setenv('HOME', str(bridge_home))
    claim.socket_path.parent.mkdir(parents=True, exist_ok=True)
    with SpawnedProcess.launch((sys.executable, '-c', (
        'import socket, sys; s = socket.socket(socket.AF_UNIX); s.bind(sys.argv[1]); '
        's.listen(); print(flush=True); peer, _ = s.accept(); peer.makefile("rb").readline()'),
        str(claim.socket_path)), stdio=DetachedChildStdio(stdout=subprocess.PIPE)) as dying:
        dying.process.stdout.readline()
        me = ProcessIdentity.capture(os.getpid())
        observed = SessionInformation(owner=me, process=dying.identity,
                                      runtime=LaunchRuntime.running(),
                                      transcript=tmp_path / 'dying-session.jsonl')
        bridges = SessionBridgeResumes()
        with bridges.holding((SessionBridge(claim, observed),)):
            pass
        assert dying.process.wait(10) == 0
    assert bridges.failures == ()
    assert bridges.lines() == ('Session bridge dying-session: bridge exited during pause; '
                               'left stopped',)
