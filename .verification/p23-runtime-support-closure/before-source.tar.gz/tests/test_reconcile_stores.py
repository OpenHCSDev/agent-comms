"""The installer's reconcile, run the way the installer runs it: the target's CLI under the
root's maintenance hold, on a bus whose stored schemas differ. Every file it rewrites is
named, so the backup and the rehearsal account for it like a carry's rewrite; nothing the
CLI opens first reconciles a store behind the verb's back. Without the hold, a schema that
differs is refused, naming the store, and the file stays as it was."""
from __future__ import annotations

import json
import sqlite3
import subprocess
import sys
from collections.abc import Callable
from contextlib import closing
from dataclasses import dataclass, field
from functools import partial
from pathlib import Path
from typing import Annotated

import pytest

from agent_comms.activity import ActivityStore
from agent_comms.bus import Bus
from agent_comms.bus_tables import MessageIdentitySource
from agent_comms.cli_bridges.codex import CodexBridge
from agent_comms.cli_bridges.shared import BridgeDeliveryStore, BridgeStateTable
from agent_comms.cli_command import CliCommand
from agent_comms.cli_commands import PlannedStoresResult
from agent_comms.cli_verbs.planned_reconcile import PlannedReconcileCliCommand
from agent_comms.cli_verbs.read_back import ReadBackCliCommand
from agent_comms.cli_verbs.reconcile_stores import ReconcileStoresCliCommand
from agent_comms.cohort_schema import PrivateCoordinatorSchema
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.database import CoordinationStore
from agent_comms.coordination.session import CoordinationSession
from agent_comms.errors import RelationViolationError
from agent_comms.execution.native_runtime_input import NativeRuntimeInput
from agent_comms.goal_ledger import FailedTurnEvidence
from agent_comms.installer.backup import StoreBackup, bus_files
from agent_comms.installer.commands import InstallCommands
from agent_comms.installer.practice import PracticeCopy
from agent_comms.installer.probes.carry import WriterOwnedOpeningProbe
from agent_comms.installer.upgrade import Stack
from agent_comms.launch_runtime import LaunchRuntime
from agent_comms.messaging.messages import (
    BusProjectionTables,
    BusRow,
    ClaimOperations,
    HeldResources,
)
from agent_comms.nominal.field_codec import ClaimId, FieldCodec, MessageId
from agent_comms.planning.goal_attempts import GoalAttemptStore
from agent_comms.root_runtime import RootRuntime, RootRuntimeStore
from agent_comms.storage.locked_store import LiveFilesRequest, RegistryFile, SQLiteFile
from agent_comms.storage.maintenance_barrier import (
    MaintenanceBarrier,
    MaintenanceHolder,
    MaintenanceOperator,
    NoMaintenanceHolder,
)
from agent_comms.storage.typed_table import (
    Column,
    DurableTables,
    HeldBusFile,
    PracticeRoot,
    ProjectionProducer,
    ReconciledFile,
    SharedFileTables,
    TableSchema,
    TypedTable,
    WriterOwnedFile,
    WriterOwnedStore,
)
from agent_comms.triage_native_sources import TriageNativeSource
from bus_record_fixture import OWNER_LOOKUP
from cli_command import core
from conftest import ledger_one_failure_short, maintenance_held
from test_bus_resource_claims import ClaimBus, claims

NO_MAINTENANCE_HOLDER = NoMaintenanceHolder()


def reconcile(root: Path, holder: MaintenanceHolder = NO_MAINTENANCE_HOLDER,
              command: type[CliCommand] = ReconcileStoresCliCommand,
              *arguments: str) -> subprocess.CompletedProcess:
    with holder.acting():
        return core("--root", str(root), *command.invocation(*arguments))


def planned_reconcile(
    root: Path, holder: MaintenanceHolder = NO_MAINTENANCE_HOLDER,
) -> PlannedStoresResult:
    completed = reconcile(root, holder, PlannedReconcileCliCommand)
    assert completed.returncode == 0, completed.stdout + completed.stderr
    return FieldCodec.decode(PlannedStoresResult, FieldCodec.parse(completed.stdout))


@pytest.fixture
def practice_projections(claims: ClaimBus, tmp_path: Path) -> Path:
    resource = str(tmp_path / "owned.py")
    owner = claims.acquire("alice", resource, claims.scope("alice", ClaimId.mint()))
    seed = tmp_path / "seed"
    claims.bus.backup(Bus.path_in(seed))
    claims.release(owner)
    claims.acquire("bob", resource, claims.scope("bob", ClaimId.mint()))
    return seed


def missing_claim_producer(db: sqlite3.Connection) -> None:
    ProjectionProducer.delete(db, projection=ClaimOperations.declared_name)


def different_seed_identity(db: sqlite3.Connection) -> None:
    MessageIdentitySource.update(
        db, where="{seq}=?", parameters=(BusRow.last_seq(db),),
        message_id=MessageId.mint("different practice bus"))


def test_practice_projections_seed_matches_full_after_claim_transition(
    claims: ClaimBus, practice_projections: Path, tmp_path: Path,
) -> None:
    full = tmp_path / "full"
    claims.bus.backup(Bus.path_in(full))
    for database in (claims.bus.path, Bus.path_in(full)):
        with closing(sqlite3.connect(database)) as db:
            missing_claim_producer(db)
            db.commit()
    with maintenance_held(claims.bus.path.parent) as holder:
        seeded = reconcile(claims.bus.path.parent, holder, ReconcileStoresCliCommand,
                           "--practice-root", str(practice_projections))
    assert seeded.returncode == 0, seeded.stdout + seeded.stderr
    with maintenance_held(full) as holder:
        rebuilt = reconcile(full, holder)
    assert rebuilt.returncode == 0, rebuilt.stdout + rebuilt.stderr
    with closing(SQLiteFile.read_snapshot(claims.bus.path)) as live_db, closing(
        SQLiteFile.read_snapshot(Bus.path_in(full))
    ) as full_db:
        for row in BusProjectionTables.schema_rows():
            actual = tuple(row.select(live_db))
            expected = tuple(row.select(full_db))
            assert len(actual) == len(expected), row
            assert all(value in expected for value in actual), row


@pytest.mark.parametrize("damage", (missing_claim_producer, different_seed_identity))
def test_practice_projections_refuse_mismatch_before_writing(
    claims: ClaimBus, practice_projections: Path,
    damage: Callable[[sqlite3.Connection], None],
) -> None:
    with closing(sqlite3.connect(Bus.path_in(practice_projections))) as db:
        damage(db)
        db.commit()
    with closing(sqlite3.connect(claims.bus.path)) as db:
        missing_claim_producer(db)
        db.commit()
    before = claims.bus.path.read_bytes()
    with maintenance_held(claims.bus.path.parent), pytest.raises(RelationViolationError):
        Bus.reconcile_at(claims.bus.path, PracticeRoot(practice_projections))
    assert claims.bus.path.read_bytes() == before


def test_practice_projections_rollback_rebuilds_the_omitted_bus(
    claims: ClaimBus, practice_projections: Path, source_programs, tmp_path: Path,
) -> None:
    root = claims.bus.path.parent
    source_programs.bind(tmp_path)
    RootRuntime.publish(root, source_programs.runtime)
    barrier = MaintenanceBarrier(RegistryFile.path_in(root))
    hold = barrier.begin(MaintenanceOperator.current())
    with InstallCommands() as commands:
        outgoing = Stack(Path(__file__).resolve().parents[1], commands, home=tmp_path,
                         runtime=source_programs.runtime)
        with hold.holding():
            with closing(sqlite3.connect(claims.bus.path)) as db:
                missing_claim_producer(db)
                db.commit()
            backup = StoreBackup.take(root, tmp_path / "route", (), tmp_path / "spill")
            assert claims.bus.path.relative_to(root) not in backup.selected_files()
            carried = reconcile(root, MaintenanceHolder.current(), ReconcileStoresCliCommand,
                                "--practice-root", str(practice_projections))
            assert carried.returncode == 0, carried.stdout + carried.stderr
            RootRuntime.publish(root, LaunchRuntime.running())
            with closing(sqlite3.connect(claims.bus.path)) as db:
                db.execute(f'DROP TABLE "{HeldResources.declared_name}"')
                db.commit()
            hold = backup.restore(partial(outgoing.restore_stores, hold))
            with hold.holding():
                assert outgoing.verify(root).threads == len(claims.registry.snapshot().threads)
            assert RootRuntimeStore.at(root).read().runtime() == source_programs.runtime
            with claims.bus.observing() as db:
                assert HeldResources.count(db) == 1
            assert not backup.restoring.exists()
    barrier.clear(hold)


def drop_one_index_each(root: Path) -> dict[str, str]:
    dropped = {}
    for path in ReconciledFile.existing_in(root):
        with closing(sqlite3.connect(path)) as db:
            index = db.execute("SELECT name FROM sqlite_master WHERE type='index'"
                               " AND sql IS NOT NULL ORDER BY name LIMIT 1").fetchone()
            if index:
                db.execute(f'DROP INDEX "{index[0]}"')
                db.commit()
                dropped[str(path.relative_to(root))] = index[0]
    assert dropped
    return dropped


def test_reconcile_names_every_store_it_carried_back_under_the_hold(private_comms):
    root = private_comms.root
    dropped = drop_one_index_each(root)
    with maintenance_held(root) as holder:
        completed = reconcile(root, holder)
        assert completed.returncode == 0, completed.stdout + completed.stderr
        assert tuple(json.loads(completed.stdout)["rewritten"]) == tuple(sorted(dropped))
        named = {(each["path"], each["difference"]["name"])
                 for each in json.loads(completed.stdout)["differences"]}
        assert named >= set(dropped.items()), "each rebuild names the object that differed"
        for name, index in dropped.items():
            with closing(sqlite3.connect(root / name)) as db:
                assert db.execute("SELECT 1 FROM sqlite_master WHERE name=?", (index,)).fetchone()
        again = json.loads(reconcile(root, holder).stdout)
        assert again["rewritten"] == [] and again["differences"] == []


def test_a_schema_change_outside_the_hold_is_refused_naming_the_store(private_comms):
    root = private_comms.root
    dropped = drop_one_index_each(root)
    completed = reconcile(root)
    assert completed.returncode != 0
    assert any(name in completed.stdout + completed.stderr for name in dropped)
    for name, index in dropped.items():
        with closing(sqlite3.connect(root / name)) as db:
            assert not db.execute("SELECT 1 FROM sqlite_master WHERE name=?", (index,)).fetchone()


def test_planned_reconcile_names_the_same_stores_and_writes_nothing(private_comms):
    """The installer asks this before its backup, under the hold that would let a write
    through: it must name what reconcile-stores rewrites and leave every byte alone."""
    root = private_comms.root
    dropped = drop_one_index_each(root)
    # A schema-named runtime projection is rebuilt by its runtime, never carried
    # or included in the installer's backup/reconcile set.
    projection = ActivityStore(root)
    with projection.writing() as db:
        db.execute('CREATE TABLE retired_derived_shape (unused INTEGER)')
    with maintenance_held(root) as holder:
        before = bus_files(LiveFilesRequest(root))
        planned = planned_reconcile(root, holder)
        assert planned.rewritten == tuple(Path(name) for name in sorted(dropped))
        assert bus_files(LiveFilesRequest(root)) == before
        completed = reconcile(root, holder)
        assert completed.returncode == 0, completed.stdout + completed.stderr
        assert tuple(json.loads(completed.stdout)["rewritten"]) == tuple(sorted(dropped))
    with closing(sqlite3.connect(projection.path)) as db:
        assert db.execute("SELECT 1 FROM sqlite_master WHERE name='retired_derived_shape'").fetchone()


def test_read_back_under_the_hold_writes_nothing_on_a_drifted_bus(private_comms):
    """The installer reads the bus back before its carries, after the backup; a write the
    read made would be refused as a change no step names, so a correct install needs it to
    write nothing even where every store's schema differs."""
    root = private_comms.root
    drop_one_index_each(root)
    with maintenance_held(root) as holder:
        before = bus_files(LiveFilesRequest(root))
        completed = reconcile(root, holder, ReadBackCliCommand)
        assert completed.returncode == 0, completed.stdout + completed.stderr
        assert bus_files(LiveFilesRequest(root)) == before


def test_a_pinned_bus_reconciles_without_moving_committed_wal_frames(private_comms):
    """An owner that ends without the last close leaves its commits in the WAL. Unpinned,
    reconcile's own last close moves those frames into the file (same rows, new bytes) and
    the carry refuses a change no step names; the pin keeps every close from being last."""
    root = private_comms.root
    # The child rewrites one row in place: frames in the WAL, the same rows in the store.
    framed = subprocess.run(
        [sys.executable, "-c",
         "import os, sqlite3, sys\n"
         "for path in sys.argv[1:]:\n"
         "    db = sqlite3.connect(path, isolation_level=None)\n"
         "    if db.execute('PRAGMA journal_mode').fetchone() != ('wal',):\n"
         "        continue\n"
         "    db.execute('PRAGMA wal_autocheckpoint=0')\n"
         "    tables = db.execute(\"SELECT name FROM sqlite_master WHERE type='table'\")\n"
         "    for (table,) in tables.fetchall():\n"
         "        try:\n"
         "            if db.execute(f'UPDATE \"{table}\" SET rowid=rowid').rowcount:\n"
         "                print(path, flush=True)\n"
         "                os._exit(0)\n"
         "        except sqlite3.OperationalError:\n"
         "            pass\n"
         "os._exit(1)\n",
         *map(str, ReconciledFile.existing_in(root))],
        capture_output=True, text=True, check=True, timeout=60)
    database = Path(framed.stdout.strip())
    assert SQLiteFile.wal_path(database).stat().st_size
    with maintenance_held(root) as holder, SQLiteFile.pinned(database):
        # A reader of the latest snapshot (a bridge, a `sqlite3 -readonly`) is open when the
        # pin is taken and closes during the carry; neither waits on the other.
        with closing(SQLiteFile.read_snapshot(database)):
            before = bus_files(LiveFilesRequest(root))
        completed = reconcile(root, holder)
        assert completed.returncode == 0, completed.stdout + completed.stderr
        assert json.loads(completed.stdout)["rewritten"] == []
        assert bus_files(LiveFilesRequest(root)) == before


def test_private_carry_plans_and_restores_missing_native_tables(private_comms):
    root = private_comms.root
    database = CoordinationStore.path_in(root)
    with Coordination(database) as store:
        store.participants.register(OWNER_LOOKUP, committed=True)
        retained = store.participants.get(OWNER_LOOKUP)
        store.session._connection.execute(f"DROP TABLE {TriageNativeSource.declared_name}")

    with maintenance_held(root) as holder:
        before = bus_files(LiveFilesRequest(root))
        planned = planned_reconcile(root, holder)
        assert planned.rewritten == (Path(database.name),)
        assert bus_files(LiveFilesRequest(root)) == before
        carried = reconcile(root, holder)
        assert carried.returncode == 0, carried.stdout + carried.stderr
        assert json.loads(carried.stdout)["rewritten"] == [database.name]
        assert planned_reconcile(root, holder).rewritten == ()

    with Coordination(database) as store:
        assert store.participants.get(OWNER_LOOKUP) == retained
        PrivateCoordinatorSchema.require_installed(store.session._connection)


def test_public_reconcile_does_not_install_native_state(tmp_path):
    root = tmp_path / "public"
    Bus.install(Bus.path_in(root))
    database = CoordinationStore.path_in(root)
    with CoordinationSession(database):
        pass
    before = bus_files(LiveFilesRequest(root))
    assert planned_reconcile(root).rewritten == ()
    carried = reconcile(root)
    assert carried.returncode == 0, carried.stdout + carried.stderr
    assert json.loads(carried.stdout)["rewritten"] == []
    assert bus_files(LiveFilesRequest(root)) == before
    with closing(sqlite3.connect(database)) as db:
        assert not db.execute(
            "SELECT name FROM sqlite_master WHERE name=?", (NativeRuntimeInput.declared_name,)
        ).fetchone()


def test_planned_reconcile_refuses_a_writer_owned_store_its_declaration_cannot_open(tmp_path):
    """Toad's laptop toad.db, 10-24: a pre-STRICT file the declaration refuses fails the
    install's plan, naming the file, before any owner stops; the file itself is untouched."""
    class LaunchTables(SharedFileTables, DurableTables):
        """A view's own durable file, outside the bus."""

    @dataclass(frozen=True)
    class LaunchRow(LaunchTables, TypedTable, declared_name="launch_rows"):
        key: Annotated[str, Column(primary_key=True)]
        count: int = field()

    stored = tmp_path / "state" / "launch.db"
    stored.parent.mkdir()

    class LaunchStore(WriterOwnedStore):
        @classmethod
        def path(cls) -> Path:
            return stored

        @classmethod
        def table_schema(cls) -> type[TableSchema]:
            return LaunchTables

    with closing(sqlite3.connect(stored)) as db:
        db.execute("CREATE TABLE launch_rows (key TEXT NOT NULL, count TEXT DEFAULT '0', "
                   "PRIMARY KEY (key))")
        db.execute("INSERT INTO launch_rows VALUES ('first', '1')")
        db.commit()
    before = stored.read_bytes()
    root = tmp_path / "bus"
    root.mkdir()
    try:
        with pytest.raises(RelationViolationError, match=str(stored)):
            PlannedReconcileCliCommand().answer(root)
        assert stored.read_bytes() == before
    finally:
        stored.unlink()
    assert PlannedReconcileCliCommand().answer(root).rewritten == ()


@pytest.mark.parametrize("readable", (False, True))
def test_planned_reconcile_refuses_a_bridge_delivery_store_its_declaration_cannot_open(
        tmp_path, monkeypatch, readable):
    """Each binding keeps its own delivery.sqlite3 under its bridge's state directory; one in
    a shape the bridge cannot open fails the install's plan, naming that binding's file."""
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    stored = tmp_path / "home" / CodexBridge.state_directory / "unit-old" / "delivery.sqlite3"
    stored.parent.mkdir(parents=True)
    if readable:
        with closing(SQLiteFile.writer(stored)) as db, db:
            BridgeStateTable.install_schema(db, WriterOwnedFile())
            db.execute('CREATE TABLE observed_part (id TEXT NOT NULL, number TEXT NOT NULL, '
                       'sender TEXT NOT NULL, body TEXT NOT NULL, record_id TEXT NOT NULL, '
                       'timestamp REAL NOT NULL, PRIMARY KEY (id, number))')
            db.execute("INSERT INTO observed_part VALUES ('m', 'first', 'a', 'b', 'r', 0)")
    else:
        with closing(sqlite3.connect(stored)) as db:
            db.execute('CREATE TABLE binding (thread TEXT NOT NULL, owner TEXT, '
                       'PRIMARY KEY (thread))')
            db.execute("INSERT INTO binding VALUES ('session', 'not-an-identity')")
            db.commit()
    sibling = stored.parent.with_name("unit-second") / BridgeStateTable.filename
    sibling.parent.mkdir()
    with closing(SQLiteFile.writer(sibling)) as db, db:
        BridgeStateTable.install_schema(db, WriterOwnedFile())
    originals = {path: path.read_bytes() for path in (stored, sibling)}
    root = tmp_path / "bus"
    root.mkdir()
    files = LiveFilesRequest(root)
    resources = BridgeDeliveryStore.resources(files)
    assert {files.location(resource) for resource in resources} == set(originals)
    assert len({resource.path for resource in resources}) == 2
    practice = PracticeCopy(root, tmp_path / "practice")
    practice.include(tuple(originals))
    copied = practice.request
    probe = WriterOwnedOpeningProbe(copied, (BridgeDeliveryStore,), scratch=tmp_path / "scratch")
    copied_paths = tuple(copied.location(resource) for resource in resources)
    planned = subprocess.run(
        [sys.executable, "-m", "agent_comms.cli", "--root", str(root),
         *PlannedReconcileCliCommand.invocation()],
        capture_output=True, text=True, timeout=60,
    )
    if readable:
        assert planned.returncode == 0, planned.stdout + planned.stderr
        result = FieldCodec.decode(PlannedStoresResult, FieldCodec.parse(planned.stdout))
        assert result.rewritten == ()
        assert probe.run() == copied_paths
    else:
        assert planned.returncode != 0
        assert str(stored) in planned.stdout + planned.stderr
        with pytest.raises(RelationViolationError, match=str(copied_paths[0])):
            probe.run()
    assert {path: path.read_bytes() for path in originals} == originals


def test_an_opening_refuses_a_drifted_store_and_reconcile_stores_carries_it(private_comms):
    """Install 13: the ledger kept a failure CHECK one member short. Opening it refuses,
    naming the carry, even under the hold, and rewrites nothing; reconcile-stores is the
    one carry, keeping every row, and the next opening reads it."""
    root = private_comms.root
    path = ledger_one_failure_short(root)
    schema = "SELECT sql FROM sqlite_master WHERE name=?"
    with closing(sqlite3.connect(path)) as db:
        drifted = db.execute(schema, (FailedTurnEvidence.declared_name,)).fetchone()
    with maintenance_held(root), pytest.raises(RelationViolationError,
                                               match=HeldBusFile.carry_verb):
        GoalAttemptStore.at(path.parent)
    with closing(sqlite3.connect(path)) as db:
        assert db.execute(schema, (FailedTurnEvidence.declared_name,)).fetchone() == drifted
    with maintenance_held(root) as holder:
        completed = reconcile(root, holder)
    assert completed.returncode == 0, completed.stdout + completed.stderr
    assert str(path.relative_to(root)) in json.loads(completed.stdout)["rewritten"]
    GoalAttemptStore.at(path.parent)


def test_a_dropped_closed_scan_column_is_named_by_the_refusal_and_carried(tmp_path):
    """Install of #3458: the closed scan stopped storing `oldest`. The refusal names the
    table and both shapes, and the reconcile drops the declared column, keeping the row."""
    from agent_comms.planning.orders import StoredClosedRepository, TodoStore

    with TodoStore(tmp_path).writing():
        pass
    path = TodoStore.path_in(tmp_path)
    table = StoredClosedRepository.declared_name
    with closing(sqlite3.connect(path)) as db, db:
        db.execute(f'DROP TABLE "{table}"')
        db.execute(f'CREATE TABLE "{table}" ("repo" TEXT NOT NULL, "main" TEXT NOT NULL, '
                   '"oldest" TEXT NOT NULL, "observed_at" REAL NOT NULL, '
                   'PRIMARY KEY ("repo")) STRICT')
        db.execute(f'INSERT INTO "{table}" VALUES (?, ?, ?, 1.0)',
                   ("OpenHCSDev/agent-comms", "a" * 40, "b" * 40))
    with closing(sqlite3.connect(path)) as db, pytest.raises(
            RelationViolationError, match=f'{table}: stored .*"oldest"'):
        TodoStore.require_schema(db)
    with maintenance_held(tmp_path):
        assert TodoStore.reconcile_at(path)
    with closing(sqlite3.connect(path)) as db:
        TodoStore.require_schema(db)
        assert db.execute(f'SELECT repo, main FROM "{table}"').fetchall() == [
            ("OpenHCSDev/agent-comms", "a" * 40)]
