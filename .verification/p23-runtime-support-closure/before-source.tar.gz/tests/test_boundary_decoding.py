"""Boundary declarations reject malformed records without inventing another shape."""
import hashlib
from dataclasses import replace
from pathlib import Path

import pytest
from agent_comms_project import AgentCommsProject
from nominal_refactor_advisor import audit

from agent_comms.channel_coding_tools import CodingToolRequest
from agent_comms.cli_bridges.claude_protocol import ClaudeHeader
from agent_comms.input_attempt import (
    HistoricalInput,
    OwnerQueueInputDeliveryScope,
    UnobservedInputDeliveryScope,
    UnresolvedInput,
)
from agent_comms.input_disposition import DeliveryOverview
from agent_comms.input_key import BusInputKey
from agent_comms.installer.native_package import NativeSourceDeclaration
from agent_comms.nominal.field_codec import FieldCodec
from agent_comms.registry.thread_identity import UnobservedTools
from agent_comms.tool_denial import SelectedToolDenied
from agent_comms.ui_model.delivery import DeliveryView


def test_coding_socket_record_keeps_object_arguments_and_strict_fields():
    payload = {'token': 'secret', 'call_id': 'call-1', 'name': 'read',
               'arguments': {'path': 'source.py'}}
    request = FieldCodec.decode(CodingToolRequest, payload)
    assert request.arguments == {'path': 'source.py'}
    assert request.authenticate('secret', UnobservedTools()).call_id == 'call-1'
    with pytest.raises(SelectedToolDenied):
        request.authenticate('wrong', UnobservedTools())
    with pytest.raises(ValueError):
        FieldCodec.decode(CodingToolRequest, {**payload, 'unexpected': True})


def test_delivery_uses_declared_overview_and_preserves_typed_rows():
    current = UnresolvedInput('worker', BusInputKey(4), 'unknown', text='retained input')
    historical = HistoricalInput('worker', BusInputKey(3), 'unknown', text='earlier input',
                                 notice_dismissed=True)
    overview = DeliveryOverview((current,), 1, 2, (historical,), OwnerQueueInputDeliveryScope)
    wire = FieldCodec.encode(overview)
    delivery = DeliveryView.from_wire(wire)
    assert delivery.overview.inputs == (current,)
    assert delivery.overview.historical_inputs == (historical,)
    assert (delivery.overview.historical_count, delivery.overview.dismissed_historical_count) == (1, 2)
    assert delivery.overview.current_scope is OwnerQueueInputDeliveryScope
    # Each scope's own label, asked of the scope: the wording is its to change, and the
    # assertion is that the decoded scope is the one whose label comes back.
    assert delivery.pending == OwnerQueueInputDeliveryScope.pending_label
    assert DeliveryView.from_wire(FieldCodec.encode(replace(
        overview, current_scope=UnobservedInputDeliveryScope,
    ))).pending == UnobservedInputDeliveryScope.pending_label
    assert OwnerQueueInputDeliveryScope.pending_label != UnobservedInputDeliveryScope.pending_label
    with pytest.raises(ValueError):
        DeliveryView.from_wire({**wire, 'unexpected': True})


@pytest.mark.parametrize('payload, expected', (
    ({'type': 'user'}, 'local-command'),
    ({'type': 'user', 'isCompactSummary': True}, 'local-command'),
    ({'type': 'user', 'promptId': ''}, 'user'),
    ({'type': 'user', 'promptId': 'turn', 'isCompactSummary': True}, 'compact-summary'),
    ({'type': 'user', 'promptId': 'turn', 'isMeta': True}, 'harness-note'),
    ({'type': 'user', 'promptId': 'turn', 'isMeta': True, 'origin': {'kind': 'peer'}}, 'user'),
    ({'type': 'user', 'promptId': 'turn', 'isMeta': True, 'turnOrigin': 'scheduled'}, 'user'),
    ({'type': 'user', 'origin': {'kind': 'task-notification'}, 'isCompactSummary': True}, 'task-user'),
    ({'type': 'assistant', 'origin': 'not a user header'}, 'assistant'),
))
def test_claude_header_preserves_sparse_field_presence_and_precedence(payload, expected):
    assert ClaudeHeader.model_validate(payload).type == expected


def test_native_source_receipt_checks_bytes_without_installing(tmp_path):
    content = b'export default () => 1;\n'
    (tmp_path / 'source.ts').write_bytes(content)
    destination = tmp_path / 'installed.ts'
    payload = {'path': str(destination), 'snapshot': 'source.ts',
               'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content)}
    source = FieldCodec.decode(NativeSourceDeclaration, payload).load(tmp_path)
    assert source.destination == destination and source.content == content
    assert not destination.exists()
    for changed in ({'bytes': True}, {'bytes': -1}, {'sha256': 'bad'},
                    {'path': 'relative.ts'}, {'snapshot': str(tmp_path / 'source.ts')},
                    {'unexpected': True}):
        with pytest.raises(ValueError):
            FieldCodec.decode(NativeSourceDeclaration, {**payload, **changed})


def test_raw_shape_guard_reuses_the_existing_overlay_detector():
    project = AgentCommsProject(Path(__file__).resolve().parents[1])
    raw = b'def read(row):\n return row["a"], row["b"], row.get("c")\n'
    typed = b'def read(row):\n return row.a, row.b, row.c\n'
    assert audit.source_measures.RawRecordShapes.count(project, raw, 'src/example.py') == 1
    assert audit.source_measures.RawRecordShapes.count(project, typed, 'src/example.py') == 0
    assert audit.source_measures.RawRecordShapes.count(project, raw, 'src/agent_comms/nominal/field_codec.py') == 1
