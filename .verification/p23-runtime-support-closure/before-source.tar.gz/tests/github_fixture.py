"""A real gh subprocess with controlled foreign responses and retained call records."""

import json
import os
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

import pytest

from agent_comms.nominal.field_codec import FieldCodec
from agent_comms.planning.orders import (
    ListedPullRequest,
    UnmergedListedPullRequest,
)
from agent_comms.projects.repository_name import RepositoryName
from github_cli_stub import hold, store


@dataclass(frozen=True)
class PullRequestCreation:
    """The fixture's creation response, including the real foreign transport outcomes."""

    listed: ListedPullRequest
    remotes: tuple[Path, ...] = ()
    reply_refusal: str = ""
    lag_reads: int = 0


@dataclass(frozen=True)
class GitHubFixture:
    directory: Path

    @property
    def path(self) -> Path:
        return self.directory / "pull_requests.json"

    @contextmanager
    def changing(self):
        """The forge state for one change, under the lock every gh call takes."""
        with hold(self.directory):
            data = json.loads(self.path.read_text()) if self.path.exists() else {}
            yield data
            store(self.directory, data)

    def configure(self, *repositories: RepositoryName):
        with self.changing() as data:
            for repository in repositories:
                data.setdefault(repository.to_wire(), {
                    "open_kinds": [kind.declared_name for kind in
                                   UnmergedListedPullRequest.members_with(UnmergedListedPullRequest)],
                    "requests": {},
                })
        return self

    def put(self, repository: RepositoryName, row: ListedPullRequest, body: str = "") -> None:
        with self.changing() as data:
            data[repository.to_wire()]["requests"][str(row.number)] = {"body": body, "listed": FieldCodec.encode(row)}

    def refuse_read(self, repository: RepositoryName, number: int, refusal: str) -> None:
        """An existing remote PR is inaccessible at GitHub's actual process boundary."""
        with self.changing() as data:
            data[repository.to_wire()]["requests"][str(number)]["read_refusal"] = refusal

    def create_next(self, repository: RepositoryName, row: ListedPullRequest, *,
                    remotes: tuple[Path, ...] = (), reply_refusal: str = "",
                    lag_reads: int = 0) -> None:
        """The forge can follow a real pushed branch and lose its reply after creating it."""
        with self.changing() as data:
            data[repository.to_wire()]["next_creation"] = FieldCodec.encode(
                PullRequestCreation(row, remotes, reply_refusal, lag_reads))

    def refuse_status(self, repository: RepositoryName, head: str, context: str,
                      refusal: str, *, state: str = "") -> None:
        with self.changing() as data:
            data[repository.to_wire()].setdefault("status_refusals", {}).setdefault(head, {})[context] = {
                "state": state, "message": refusal}

    def refuse_arm(self, repository: RepositoryName, number: int, refusal: str) -> None:
        """GitHub's answer when enabling auto-merge on this pull request fails."""
        with self.changing() as data:
            data[repository.to_wire()]["requests"][str(number)]["arm_refusal"] = refusal

    def calls(self) -> tuple[tuple[str, ...], ...]:
        path = self.directory / "calls.jsonl"
        return tuple(tuple(json.loads(line)) for line in path.read_text().splitlines()) if path.exists() else ()


@pytest.fixture
def github_cli(tmp_path, monkeypatch):
    directory = tmp_path / "bin"
    directory.mkdir()
    (directory / "gh").symlink_to(Path(__file__).with_name("github_cli_stub.py"))
    monkeypatch.setenv("PATH", os.pathsep.join((str(directory), os.environ["PATH"])))
    return GitHubFixture(directory)
