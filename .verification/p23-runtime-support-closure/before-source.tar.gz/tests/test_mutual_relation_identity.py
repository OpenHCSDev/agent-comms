"""Shared relation behavior extends without endpoint-comparison consumer edits."""
from pathlib import Path

from agent_comms.peer_relevance import GoalContactRelevance
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import NativeThread
from agent_comms.relationships import MutualThreadRelation, RelationRecord


def test_new_relation_reuses_owned_incident_and_counterpart_behavior(*, thread_registration):
    first = NativeThread('first', frozenset(), Checkout(Path('/wt')), created_at=1)
    second = NativeThread('second', frozenset(), Checkout(Path('/wt')), created_at=2)
    replacement = NativeThread('second', frozenset(), Checkout(Path('/wt')), created_at=3)

    class ReviewRelation(MutualThreadRelation):
        relevance = GoalContactRelevance
        note = "Reviewing"

        def record(self, peer):
            return RelationRecord(peer.name, self.relevance, first.name, None, self.note, ())

        @property
        def owner_incarnation(self):
            return first.incarnation

        @property
        def peer_incarnation(self):
            return second.incarnation

    relation = ReviewRelation()
    assert relation.incident(first) and relation.incident(second)
    assert relation.counterpart(first) == second.incarnation
    assert relation.counterpart(second) == first.incarnation
    assert not relation.incident(replacement)
    assert relation.counterpart(replacement) is None
    assert relation.record(second.incarnation).peer == "second"
