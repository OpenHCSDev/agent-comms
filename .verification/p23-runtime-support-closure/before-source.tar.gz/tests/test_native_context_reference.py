"""Original nullable SQL groups cannot mint a partial recorded native reference."""


import sqlite3
from dataclasses import replace
from functools import partial
from pathlib import Path

import pytest

from agent_comms.acp_extension import EmptyCursorObservation, VerifiedCursorObservation
from agent_comms.assignment_states import TriagePendingAssignment
from agent_comms.comms import wire
from agent_comms.coordination.errors import IdentityConflict, StaleFence
from agent_comms.cursor_owner import (
    CommittedCursorOwner,
    CursorOwner,
    InheritedCursor,
    RecordedCursor,
    UnstartedCursor,
)
from agent_comms.execution.native_claim_epoch import RecordedNativeClaim
from agent_comms.execution.native_input_proof import NativeContextProof
from agent_comms.execution.native_input_record import (
    FullNativeExecution,
    NativeInputReference,
    NumberNativeColumn,
    RecordedNativePosition,
    TextNativeColumn,
    TriageNativeExecution,
    UnrecordedNativeColumn,
    UnrecordedNativeInputReference,
)
from agent_comms.execution.native_runtime_input import CurrentNativeCursor, NativeRuntimeInput
from agent_comms.execution.native_session_reopen import PiSessionId
from agent_comms.execution.selected.triage import (
    AbsentTriageDecisionRecord,
    DecidedTriageRecord,
    FullSelectedTriage,
    IgnoreSelectedTriage,
)
from agent_comms.historical_native_inputs import (
    FullHistoricalNativeInput,
    TriageHistoricalNativeInput,
)
from agent_comms.nominal.field_codec import FieldCodec, InputId, MessageId, RootId, ThreadLookup
from agent_comms.projects.checkouts import Checkout
from agent_comms.proven_source_coverage import (
    InjectedInput,
    NoInjectedInput,
    ProvenSourceCoverage,
    SourcePrefix,
)
from agent_comms.registry.threads import NativeThread
from agent_comms.storage.private_path import FileIdentity


def cursor() -> CurrentNativeCursor:
    return CurrentNativeCursor(
        wire_root_id=RootId("a" * 32), recipient_lookup=ThreadLookup("b" * 32),
        owner_generation=1, owner_claimed_generation=2, covered_seq=1, injected_seq=1,
        input_id=TextNativeColumn("c" * 32), stage=TextNativeColumn("full"),
        session_id=TextNativeColumn("original-session"), request_generation=NumberNativeColumn(1),
    )


@pytest.mark.parametrize("state, observation, covered_seq, proves", [
    (UnstartedCursor(), EmptyCursorObservation(), 0, False),
    (RecordedCursor(cursor()), VerifiedCursorObservation(cursor()), 1, True),
])
def test_native_cursor_state_owns_start_observation_and_input_proof(
    state, observation, covered_seq, proves,
):
    assert state.covered_seq == covered_seq
    assert state.observation() == observation
    assert state.proves_input("c" * 32) is proves
    assert not state.proves_input("d" * 32)


def reservation() -> NativeRuntimeInput:
    return NativeRuntimeInput(
        input_id=FieldCodec.decode(InputId, "c" * 32), stage=TriageNativeExecution,
        execution_id=UnrecordedNativeColumn(), attempt_ordinal=UnrecordedNativeColumn(),
        owner_lookup=FieldCodec.decode(ThreadLookup, "b" * 32), owner_generation=1,
        owner_token_digest="e" * 64,
    )


@pytest.fixture
def recorded() -> NativeRuntimeInput:
    return replace(
        reservation(), sent_owner_claimed_generation=RecordedNativeClaim(2),
        session_id=PiSessionId("original-session"), session_file="/original/session.jsonl",
        session_entry_id=TextNativeColumn("original-entry"),
        session_entry_start=RecordedNativePosition(128),
        request_generation=NumberNativeColumn(1),
        llm_context_digest=TextNativeColumn("f" * 64),
        committed_at_ms=NumberNativeColumn(1_791_964_800_001),
    )


@pytest.mark.parametrize("changes", [
    {"input_id": UnrecordedNativeColumn()}, {"stage": UnrecordedNativeColumn()},
    {"session_id": UnrecordedNativeColumn()}, {"session_id": NumberNativeColumn(1)},
    {"session_id": TextNativeColumn("")}, {"request_generation": UnrecordedNativeColumn()},
    {"request_generation": NumberNativeColumn(0)}, {"request_generation": NumberNativeColumn(True)},
])
def test_partial_original_cursor_never_becomes_unrecorded_or_complete(changes):
    with pytest.raises(IdentityConflict):
        _ = replace(cursor(), **changes).reference


def test_original_unrecorded_context_and_reserved_input_remain_distinct_from_corruption(
    recorded: NativeRuntimeInput,
) -> None:
    empty = replace(cursor(), covered_seq=0, injected_seq=0, input_id=UnrecordedNativeColumn(),
                    stage=UnrecordedNativeColumn(), session_id=UnrecordedNativeColumn(),
                    request_generation=UnrecordedNativeColumn())
    assert empty.reference == UnrecordedNativeInputReference()
    assert reservation().reference == UnrecordedNativeInputReference()
    with pytest.raises(IdentityConflict):
        _ = replace(reservation(), request_generation=NumberNativeColumn(1)).reference
    reference = recorded.reference.require_recorded()
    assert reference == NativeInputReference(
        recorded.input_id, type(recorded.execution), recorded.session_id, 1
    )
    assert reference.session_id is recorded.session_id
    selected = cursor().reference.require_recorded().session_id
    assert selected == recorded.session_id and selected.require_recorded_session() is selected
    with pytest.raises(IdentityConflict):
        _ = replace(recorded, session_file=None).reference
    for name in ("session_entry_id", "session_entry_start", "llm_context_digest", "committed_at_ms"):
        with pytest.raises(IdentityConflict):
            _ = replace(recorded, **{name: UnrecordedNativeColumn()}).reference


@pytest.fixture
def native_source(recorded):
    return dict(
        wire_root_id="a" * 32, source_seq=1, source_message_id=MessageId.mint("original-message"),
        assignment_id="d" * 32, input_id=recorded.input_id,
        owner_lookup=recorded.owner_lookup,
        owner_generation=recorded.owner_generation,
        context=NativeContextProof(recorded.input_id, recorded.session_id,
            recorded.context_value("session_entry_id"), 1, "f" * 64, 1_791_964_800_001,
            Path(recorded.session_file), session_entry_start=recorded.session_entry_start.offset),
        native_reference=recorded.reference,
        expected_prompt_equality_established=True,
    )


@pytest.mark.parametrize("make_owner, permitted", [
    (CursorOwner, True),
    (partial(CommittedCursorOwner, input_id=InputId("c" * 32)), True),
    (partial(CommittedCursorOwner, input_id=InputId("d" * 32)), False),
])
def test_cursor_owner_enforces_exact_settlement_without_restricting_refresh(
    tmp_path, recorded, native_source, make_owner, permitted,
):
    thread = NativeThread("owner", frozenset(), Checkout(tmp_path))
    original = replace(
        recorded, owner_lookup=thread.incarnation.require_recorded().lookup,
        verdict=DecidedTriageRecord(IgnoreSelectedTriage),
    )
    owner = make_owner(thread=thread, claimed_generation=2, generation=1, wire_root_id="a" * 32)
    source = {**native_source, "owner_lookup": original.owner_lookup}
    with sqlite3.connect(":memory:") as db:
        NativeRuntimeInput.create(db)
        original.insert(db)
        proof = original.execution.historical_proof(
            original, lifecycle=TriagePendingAssignment(), **source,
        )
        assert InjectedInput(proof).allows(owner, db, UnstartedCursor()) is permitted


def test_original_native_sql_acquires_required_triage_or_full_recorded_proof(recorded, native_source):
    source = native_source
    with sqlite3.connect(":memory:") as db:
        NativeRuntimeInput.create(db)
        recorded.insert(db)
        # SQL NULL describes an original input without a recorded decision;
        # it cannot acquire a recorded triage proof.
        missing = NativeRuntimeInput.one(db, input_id=recorded.input_id)
        with pytest.raises((TypeError, ValueError)):
            missing.execution.historical_proof(missing, lifecycle=TriagePendingAssignment(), **source)
        for identity, decision in (("9", IgnoreSelectedTriage), ("8", FullSelectedTriage)):
            original = replace(recorded, input_id=FieldCodec.decode(InputId, identity * 32),
                               verdict=DecidedTriageRecord(decision))
            original.insert(db)
            assert db.execute("SELECT verdict FROM native_runtime_input WHERE input_id=?",
                              (original.input_id,)).fetchone() == (decision.declared_name.lower(),)
            actual = NativeRuntimeInput.one(db, input_id=original.input_id)
            proof_source = {**source, "input_id": original.input_id,
                            "context": replace(source["context"], input_id=original.input_id)}
            proof = actual.execution.historical_proof(actual, lifecycle=TriagePendingAssignment(), **proof_source)
            assert isinstance(proof, TriageHistoricalNativeInput)
            assert proof.assignment_id == source["assignment_id"]
            assert proof.decision is decision
            assert proof.proves_triage_source((proof,)) == (decision is IgnoreSelectedTriage)
            with pytest.raises(sqlite3.IntegrityError):
                NativeRuntimeInput.update(db, where="input_id=?", parameters=(original.input_id,),
                                          verdict=AbsentTriageDecisionRecord())
        full = replace(recorded, input_id=FieldCodec.decode(InputId, "7" * 32),
                       stage=FullNativeExecution, **FullNativeExecution("5" * 32, 1).binding_fields(),
                       verdict=AbsentTriageDecisionRecord())
        full.insert(db)
        actual = NativeRuntimeInput.one(db, input_id=full.input_id)
        proof = actual.execution.historical_proof(actual, lifecycle=TriagePendingAssignment(),
                                                 **{**source, "input_id": full.input_id})
        assert isinstance(proof, FullHistoricalNativeInput)
        assert not proof.proves_triage_source((proof,))
        with pytest.raises((TypeError, ValueError)):
            replace(actual, verdict=DecidedTriageRecord(IgnoreSelectedTriage)).execution.historical_proof(
                replace(actual, verdict=DecidedTriageRecord(IgnoreSelectedTriage)), lifecycle=TriagePendingAssignment(), **source,
            )
        with pytest.raises(TypeError):
            TriageHistoricalNativeInput(execution=TriageNativeExecution(), **source)


def test_a_restarted_claim_advances_past_the_inputs_its_earlier_claim_sent(
    tmp_path, recorded, native_source,
):
    """Every install mints a new claim; the thread's cursor and its inputs stay its own."""
    thread = NativeThread("owner", frozenset(), Checkout(tmp_path))
    lookup = thread.incarnation.require_recorded().lookup
    root = FieldCodec.decode(RootId, "a" * 32)
    sent = replace(recorded, owner_lookup=lookup, verdict=DecidedTriageRecord(IgnoreSelectedTriage))
    restarted = CursorOwner(thread=thread, claimed_generation=5, generation=1, wire_root_id=root)
    with sqlite3.connect(":memory:") as db:
        NativeRuntimeInput.create(db)
        CurrentNativeCursor.create(db)
        sent.insert(db)
        proof = sent.execution.historical_proof(
            sent, lifecycle=TriagePendingAssignment(), **{**native_source, "owner_lookup": lookup},
        )
        assert restarted.matches_prefix(db, (proof,))
        assert InjectedInput(proof).allows(restarted, db, UnstartedCursor())
        earlier = CursorOwner(thread=thread, claimed_generation=2, generation=1, wire_root_id=root)
        earlier_row = InjectedInput(proof).build(earlier, 1)
        earlier_row.insert(db)
        inherited = restarted.state(db)
        assert type(inherited) is InheritedCursor and inherited.covered_seq == 1
        assert inherited.observation() == EmptyCursorObservation()
        coverage = ProvenSourceCoverage(
            root, lookup, 3, (), (), None, source_prefix=SourcePrefix(FileIdentity.from_stat(tmp_path.stat()), 3),
        )
        published = inherited.publish(db, restarted, coverage, NoInjectedInput())
        assert restarted.state(db) == published == RecordedCursor(replace(
            earlier_row, owner_claimed_generation=5, covered_seq=3,
        ))
        assert CurrentNativeCursor.select(db) == [published.row]
        with pytest.raises(StaleFence):
            earlier.state(db)
        newer = replace(sent, input_id=FieldCodec.decode(InputId, "9" * 32), sent_owner_claimed_generation=RecordedNativeClaim(6))
        newer.insert(db)
        newer_proof = newer.execution.historical_proof(newer, lifecycle=TriagePendingAssignment(), **{
            **native_source, "owner_lookup": lookup, "input_id": newer.input_id,
            "context": replace(native_source["context"], input_id=newer.input_id),
            "native_reference": newer.reference,
        })
        assert restarted.matches_prefix(db, (proof,))
        assert not restarted.matches_prefix(db, (newer_proof,))


def test_a_retried_participant_generation_advances_past_the_inputs_its_earlier_attempt_sent(
    tmp_path, recorded, native_source,
):
    """A retry advances the participant generation (selected_participant.py prepare_attempt); same participant."""
    thread = NativeThread("owner", frozenset(), Checkout(tmp_path))
    lookup = thread.incarnation.require_recorded().lookup
    root = FieldCodec.decode(RootId, "a" * 32)
    sent = replace(recorded, owner_lookup=lookup, verdict=DecidedTriageRecord(IgnoreSelectedTriage))
    attempt = CursorOwner(thread=thread, claimed_generation=2, generation=1, wire_root_id=root)
    retried = CursorOwner(thread=thread, claimed_generation=2, generation=2, wire_root_id=root)
    with sqlite3.connect(":memory:") as db:
        NativeRuntimeInput.create(db)
        CurrentNativeCursor.create(db)
        sent.insert(db)
        proof = sent.execution.historical_proof(
            sent, lifecycle=TriagePendingAssignment(), **{**native_source, "owner_lookup": lookup},
        )
        assert retried.matches_prefix(db, (proof,))
        assert InjectedInput(proof).allows(retried, db, UnstartedCursor())
        InjectedInput(proof).build(attempt, 1).insert(db)
        inherited = retried.state(db)
        assert type(inherited) is InheritedCursor and inherited.covered_seq == 1
