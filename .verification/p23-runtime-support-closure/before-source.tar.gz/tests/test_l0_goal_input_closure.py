"""Current goal/input boundaries through durable stores and the real owner socket."""

import os
import sqlite3
from dataclasses import replace

import pytest

from agent_comms.comms import wire
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.execution.turn_failure import BackendFailed, FailedTurnResolution
from agent_comms.goal_ledger import GoalWorkDecision
from agent_comms.input_disposition import InputDispositions
from agent_comms.input_key import BusInputKey
from agent_comms.nominal.field_codec import FieldCodec, GoalId, InputId, TurnId
from agent_comms.planning.goal_actions import (
    GoalPrecondition,
    OwnerInvocable,
    RetryGoalAction,
    SetGoalAction,
    StandbyGoalAction,
)
from agent_comms.planning.goal_generation import ReadyGeneration
from agent_comms.planning.goal_history import GoalHistoryEntry
from agent_comms.planning.goal_scope import OneGoal
from agent_comms.planning.goal_states import BlockedGoal, GoalState, UnrecordedBlockGoal
from agent_comms.planning.goal_waits import GoalWait, GoalWaits
from agent_comms.planning.goals import Goal
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import NativeThread
from stored_inputs import stored_inputs


def register(comms, name):
    comms.registry.declare(
        NativeThread(name, frozenset(), Checkout(comms.root), process_identity=ProcessIdentity.capture(os.getpid()))
    )


def test_unknown_reason_survives_real_history_without_inventing_provenance(tmp_path):
    comms = wire(tmp_path)
    register(comms, "owner")
    # Goals creates the goal and its generation; the carried record supplies a block whose
    # reason and provenance were never recorded, which no live transition produces.
    set_goal = comms.goals.update_goal("owner", SetGoalAction(text="Retained objective"))
    goal = replace(
        set_goal, progress="Unrelated progress", mention_source=None, state=UnrecordedBlockGoal()
    )
    comms.registry.register(replace(comms.registry.require("owner"), goal=goal))
    history = comms.goals.goal_history("owner")
    assert history[-1].after == goal and history[-1].after.mention_source is None
    # The durable record says only "unrecorded": no explicit reason was stored or invented.
    assert type(history[-1].after.state) is UnrecordedBlockGoal
    assert history[-1].after.to_wire()["state"] == {"kind": "unrecorded_block"}
    assert (
        comms.goals.goal_execution("owner").presentation("owner").summary
        == "Blocked · reason unavailable"
    )
    with sqlite3.connect(tmp_path / "goal_history.sqlite3") as database:
        before = database.execute(
            f"SELECT * FROM {GoalHistoryEntry.declared_name} ORDER BY sequence"
        ).fetchall()
    reopened = wire(tmp_path)
    assert reopened.goals.goal_history("owner") == history
    assert not reopened.relationships.goal_contacts("owner")[0]
    with sqlite3.connect(tmp_path / "goal_history.sqlite3") as database:
        assert (
            database.execute(
                f"SELECT * FROM {GoalHistoryEntry.declared_name} ORDER BY sequence"
            ).fetchall()
            == before
        )
    for data in ({"kind": "blocked"}, {"kind": "blocked", "block_reason": None}):
        with pytest.raises((TypeError, ValueError)):
            FieldCodec.decode(GoalState, data)
    assert FieldCodec.decode(GoalState, {"kind": "unrecorded_block"}) == UnrecordedBlockGoal()


@pytest.mark.parametrize(
    "state", [BlockedGoal("Inspect the failed attempt"), UnrecordedBlockGoal()]
)
def test_retry_requires_existing_private_generation_and_never_adopts(tmp_path, state):
    goal_id = GoalId.mint()
    comms = wire(tmp_path / "wire")
    register(comms, "owner")
    goal = Goal("Objective", goal_id, published_seq=0, state=state)
    comms.registry.register(replace(comms.registry.require("owner"), goal=goal))
    store = comms.goals.open_goal_store()
    retry = RetryGoalAction(
        expect=GoalPrecondition(goal_id=OneGoal(goal.id), expected_owner=ProcessIdentity.capture(os.getpid()))
    )
    with pytest.raises(ValueError):
        comms.goals.update_goal("owner", retry, actor=OwnerInvocable)
    assert store.snapshot(goal.id) is None
    assert comms.registry.require("owner").goal == goal
    # A known failed generation requires an explicit owner decision to advance.
    store.create_goal(goal.id)
    reservation = store.reserve(goal.id, 1)
    reservation.fail(store, FailedTurnResolution(BackendFailed))
    assert not store.snapshot(goal.id).lifecycle.allows_resume(False)
    changed = comms.goals.update_goal("owner", retry, actor=OwnerInvocable)
    changed.require_active()
    assert changed.id == goal.id
    assert store.snapshot(goal.id).lifecycle == ReadyGeneration()
    assert store.snapshot(goal.id).number == 2
    with sqlite3.connect(store.path) as database:
        assert (
            database.execute(f"SELECT count(*) FROM {GoalWorkDecision.declared_name}").fetchone()[
                0
            ]
            == 1
        )


def test_standby_uses_native_receipts_and_explicit_reviews_not_read_ack(tmp_path):
    from goal_owner_fixture import canonical_goal_wire

    comms = canonical_goal_wire(tmp_path)
    register(comms, "owner")
    register(comms, "peer")
    comms.agents.begin_turn("peer", TurnId('6f8eb8c4b59c9b52ce7c7d823f5d7b84'))
    goal = comms.goals.update_goal("owner", SetGoalAction(text="Wait for the peer"))
    message = comms.messaging.send("peer", "owner", "Review this uncertain reply").message
    store = InputDispositions(tmp_path)
    claim_scope = comms.registry.snapshot().claim_generation("owner")
    key = BusInputKey(message.seq)
    store.record(
        key, seq=message.seq, owner="owner", claim_scope=claim_scope, target="owner", text=message.body
    )
    messages = comms.bus.inbox("owner").page.messages
    comms.bus.mark_read_through("owner", messages[-1].seq)
    action = StandbyGoalAction(expect=GoalPrecondition(goal_id=OneGoal(goal.id)), wait_for=("peer",))
    with pytest.raises(ValueError):
        comms.goals.update_goal("owner", action)
    review = comms.goals.goal_input_review("owner", goal.id, ["peer"])
    assert list(review.reviewed_inputs) == [key]
    comms.goals.update_goal("owner", replace(action, reviewed_inputs=(key,)))
    row = stored_inputs(store.root).rows[key]
    assert row.accepts_reservation and row.reviewed_for_goal(goal.id)
    # A later native-started reply is already handled, regardless of display reads.
    second = comms.messaging.send("peer", "owner", "Native reply").message
    second_key = BusInputKey(second.seq)
    store.record(
        second_key,
        seq=second.seq,
        owner="owner",
        claim_scope=claim_scope,
        target="owner",
        text=second.body,
    )
    assert store.bind(
        second_key,
        claim_scope=claim_scope,
        turn_id=TurnId('d139335a14223f343b5786bbd9e20434'),
        native_id=InputId("a" * 32),
        text=second.body,
    )
    assert store.started(
        second_key,
        turn_id=TurnId('d139335a14223f343b5786bbd9e20434'),
        native_id=InputId("a" * 32),
        text=second.body,
    )
    comms.goals.update_goal("owner", action)
    wait = comms.goals.goal_wait("owner")
    assert wait.owner == comms.registry.require("owner").incarnation
    assert wait.report_turn_id is None and wait.report_turn_generation is None
    saved = FieldCodec.encode(wait)
    for missing in (
        "owner",
        "target_turn_generations",
        "report_turn_id",
        "report_turn_generation",
    ):
        data = dict(saved)
        del data[missing]
        with pytest.raises((TypeError, ValueError)):
            FieldCodec.decode(GoalWait, data)
    assert GoalWaits(tmp_path).read()[goal.id] == wait


