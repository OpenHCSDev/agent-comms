"""Release proof follows process identity, not unrelated thread metadata."""

from dataclasses import replace

from agent_comms.comms import wire
from agent_comms.owner_release import (
    NoRelease,
    OwnerReleaseEvidence,
)
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.thread_text import GivenThreadText
from agent_comms.registry.threads import NativeThread


def test_release_survives_metadata_changes_and_reads_only_its_row(tmp_path):
    comms = wire(tmp_path)
    originals = [comms.registry.declare(NativeThread(name, frozenset(), Checkout(tmp_path)))
                 for name in ('worker', 'other')]
    before = comms.registry.snapshot()
    generation = before.claim_generation('worker')
    for thread in originals:
        comms.owners.stop(thread.name)
    snapshot = comms.registry.snapshot()
    # Stopping a thread with no live owner records no release (test_owner_release_restart),
    # so this store test writes each release through the store's own writer.
    comms.owners.releases.record(snapshot, tuple(
        (thread, before.claim_generation(thread.name)) for thread in originals))
    current = snapshot.threads['worker']
    comms.registry.register(replace(current, title=GivenThreadText('changed title'), task=GivenThreadText('changed task')),
                            status=snapshot.statuses['worker'])
    releases = comms.owners.releases
    # An invalid unrelated row must not even be decoded by this lookup.
    with releases.writing() as db:
        OwnerReleaseEvidence.update(db, where='name=?', parameters=('other',), after=0)
    record = releases.read_many(('worker',))['worker']
    assert record.current(comms.registry.snapshot(), originals[0], generation)
    assert record.incarnation() == originals[0].incarnation
    assert record.process_identity == originals[0].process_identity
    releases.remove_threads((originals[0],))
    assert isinstance(releases.read_many(('worker',))['worker'], NoRelease)


def test_empty_release_store_is_not_proof(tmp_path):
    comms = wire(tmp_path)
    thread = comms.registry.declare(NativeThread('worker', frozenset(), Checkout(tmp_path)))
    record = comms.owners.releases.read_many((thread.name,))[thread.name]
    assert isinstance(record, NoRelease)
    assert not record.current(comms.registry.snapshot(), thread, 1)
    assert not record.matches(thread)
    with comms.owners.releases.snapshot() as db:
        assert OwnerReleaseEvidence.count(db) == 0
