"""Saved check commands are data; revision policy is enforced when writing new checks."""

from pathlib import Path

import pytest

from agent_comms.nominal.field_codec import FieldCodec
from agent_comms.planning.goals import (
    CountCheckResult,
    OrderCheck,
)
from agent_comms.team.order import CheckRequest
from agent_comms.work_branches import WorkBranches
from agent_comms_hooks.shell_commands import ShellCommand


@pytest.mark.parametrize('command', ['git checkout main', 'git -C /repo switch work',
                                   'true && git checkout HEAD',
                                   'echo first\ngit checkout main',
                                   'echo first\n\ngit switch main'])
def test_saved_checks_decode_but_new_checks_refuse_revision_selection(command):
    saved = OrderCheck(Path('.'), command)
    assert FieldCodec.decode(OrderCheck, FieldCodec.encode(saved)) == saved
    with pytest.raises(ValueError):
        saved.require_writable()
    with pytest.raises(ValueError):
        CheckRequest.parse(f'. :: {command} -> 0')


def test_multiline_checks_keep_quoted_newlines_and_command_boundaries():
    command = "printf 'first\\nsecond'\n\ngrep -c obsolete owner.py"
    check = CheckRequest.parse(f'. :: {command} -> 0')
    assert check is not None and check.command == command
    assert [simple.words for simple in ShellCommand.split(command)] == [
        ('printf', 'first\\nsecond'), ('grep', '-c', 'obsolete', 'owner.py'),
    ]


@pytest.mark.parametrize('command', [
    'pytest tests/test_todos.py',
    'py.test tests/test_todos.py',
    '/venv/bin/pytest tests/test_todos.py',
    'python -m pytest tests/test_todos.py',
    'python3.14 -m pytest tests/test_todos.py',
    'timeout 300 bash -c "python -m pytest tests/test_todos.py"',
])
def test_saved_pytest_checks_decode_but_cannot_run(command, tmp_path):
    saved = OrderCheck(tmp_path, command)
    assert FieldCodec.decode(OrderCheck, FieldCodec.encode(saved)) == saved
    with pytest.raises(ValueError, match='integrator'):
        saved.require_writable()
    with pytest.raises(ValueError, match='integrator'):
        saved.run_at('HEAD', tmp_path, tmp_path / 'checkouts')
    assert not (tmp_path / 'checkouts').exists()


@pytest.mark.parametrize('command,expected', [('grep -c . owner.py', 3), ('printf missing', 0)])
def test_acceptance_refuses_passing_and_unmeasurable_checks(source_repository, tmp_path, command, expected):
    check = OrderCheck(source_repository.checkout, command, CountCheckResult(expected))
    with pytest.raises(ValueError):
        check.require_acceptance(WorkBranches.main, tmp_path / 'checks')
    assert not tuple((tmp_path / 'checks').iterdir())


def test_check_uses_configured_persistent_checkout_and_retains_real_result(source_repository, tmp_path):
    checkout_base = tmp_path / "persistent-checkouts"
    marker = tmp_path / "observed-checkouts"
    checkout = source_repository.checkout
    check = OrderCheck(checkout, f'pwd >> "{marker}"; echo 0', CountCheckResult(0))
    commit = source_repository.main_commit
    first = check.at(commit, checkout, checkout_base)
    assert check.at(commit, checkout, checkout_base) == first
    (actual,) = marker.read_text().splitlines()
    assert actual.startswith(str(checkout_base) + "/order-check-")
    assert not tuple(checkout_base.iterdir())
    assert len(check.recorded(commit, checkout)) == 1


