import hashlib
import json
import math
import os
import sys
from dataclasses import replace

import pytest

from agent_comms.bus import Bus, ClaimRecord
from agent_comms.messaging.channels import AnyOfMatch, ParticipantsView, ViewPredicate
from agent_comms.cli import CliInvocation
from agent_comms.comms import Comms
from agent_comms.envelope_claim_transitions import UnscopedClaims
from agent_comms.errors import ExportDestinationExists, RelationViolationError
from agent_comms.exporting import (
    ChannelScope,
    DmScope,
    EverythingScope,
    FullLimit,
    JsonlFormat,
    MaxBytesLimit,
    RecentLimit,
    TextFormat,
    WireExportBoundary,
    WireExportFormat,
    WireExportLimit,
    WireTranscriptExporter,
)
from agent_comms.messaging.messages import ClaimNoticeKind, InfoKind, Message
from agent_comms.nominal.field_codec import ClaimId
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import NativeThread
from agent_comms_hooks import ToolRefusedError
from bus_history import read_history


def message(sequence: int, body: str, *, timestamp: float | None = None) -> Message:
    return Message(
        "alice",
        "#team",
        body,
        InfoKind,
        timestamp=float(sequence if timestamp is None else timestamp),
        seq=sequence,
    )


@pytest.fixture
def export_comms(comms: Comms, tmp_path) -> Comms:
    comms.channels.create_tag("team")
    for name in ("alice", "bob"):
        comms.registry.declare(NativeThread(
            name, frozenset({"team"}), Checkout(tmp_path)))
    return comms


def exporter(
    *,
    format: WireExportFormat | None = None,
    limit: WireExportLimit | None = None,
    through: int = 100,
    started: float = 200.0,
) -> WireTranscriptExporter:
    return WireTranscriptExporter(
        format=format if format is not None else JsonlFormat(),
        scope=ChannelScope("#team"),
        limit=limit or FullLimit(),
        boundary=WireExportBoundary(through, started),
    )


def records(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def test_wire_export_declarations_are_explicit_and_fail_loud():
    assert EverythingScope().to_wire() == {"kind": "everything"}
    assert DmScope(("alice", "bob")).to_wire() == {
        "kind": "dm",
        "participants": ["alice", "bob"],
    }
    assert MaxBytesLimit(10).to_wire() == {"kind": "max_bytes", "value": 10}
    assert RecentLimit(123.5).to_wire() == {"kind": "recent", "value": 123.5}

    assert ChannelScope("#any").to_wire() == {"kind": "channel", "channel": "#any"}
    with pytest.raises(ValueError):
        DmScope(("alice", "alice"))
    with pytest.raises(ValueError):
        MaxBytesLimit(0)
    with pytest.raises(ValueError):
        RecentLimit(float("nan"))
    with pytest.raises(TypeError):
        FullLimit(1)
    with pytest.raises(TypeError):
        EverythingScope(channel="#all")
    with pytest.raises(ValueError):
        WireExportBoundary(-1, 1.0)


def test_jsonl_exports_the_public_projection_of_a_delivery(tmp_path, export_comms):
    published = export_comms.messaging.send("alice", "#team", "public body").message
    record = export_comms.bus.bus.lookup(published.seq)
    public = Message.from_message(record)
    destination = tmp_path / "public.jsonl"

    exporter(through=record.seq).export((record,), destination)

    assert records(destination)[1]["message"] == public.to_wire()


def test_jsonl_is_versioned_lossless_and_receipt_has_artifact_provenance(tmp_path):
    destination = tmp_path / "wire.jsonl"
    first = message(1, "hello")
    second = message(2, "unicode: café")

    acknowledgement = exporter(through=2).export(iter([first, second]), destination)
    rows = records(destination)

    assert rows[0] == {
        "record": "header",
        "schema": "agent-comms/wire-export",
        "version": 1,
        "source": "agent-comms-wire",
        "format": "jsonl",
        "importable": True,
        "scope": {"kind": "channel", "channel": "#team"},
        "limit": {"kind": "full"},
        "boundary": {"through_seq": 2, "export_started_at": 200.0},
    }
    assert rows[1]["record"] == rows[2]["record"] == "message"
    assert rows[1]["message"] == first.to_wire()
    assert Message.from_wire(rows[2]["message"]) == second
    assert acknowledgement.source_messages == acknowledgement.exported_messages == 2
    assert acknowledgement.omitted_messages == 0 and not acknowledgement.truncated
    assert acknowledgement.bytes_written == len(destination.read_bytes())
    assert acknowledgement.output_sha256 == hashlib.sha256(destination.read_bytes()).hexdigest()
    assert acknowledgement.redacted_messages == 0
    assert acknowledgement.first_sequence == 1 and acknowledgement.last_sequence == 2
    assert acknowledgement.to_wire()["boundary"] == {"through_seq": 2, "export_started_at": 200.0}


def test_fixed_sequence_boundary_excludes_concurrent_appends_and_stops_consumption(tmp_path):
    yielded = []

    def active_wire():
        for sequence in range(1, 5):
            yielded.append(sequence)
            yield message(sequence, f"m{sequence}")

    destination = tmp_path / "snapshot.jsonl"
    acknowledgement = exporter(through=2).export(active_wire(), destination)

    assert [row["message"]["seq"] for row in records(destination)[1:]] == [1, 2]
    assert yielded == [1, 2, 3]
    assert acknowledgement.boundary.through_seq == acknowledgement.last_sequence == 2
    assert acknowledgement.source_messages == 2


def test_full_export_consumes_a_one_shot_stream_without_retaining_message_history(tmp_path):
    class OneShot:
        def __init__(self):
            self.iterations = 0

        def __iter__(self):
            self.iterations += 1
            if self.iterations > 1:
                raise AssertionError("wire stream was replayed")
            for sequence in range(1, 2001):
                yield message(sequence, "x" * 1024)

    source = OneShot()
    destination = tmp_path / "large.jsonl"
    acknowledgement = exporter(through=2000).export(source, destination)

    assert source.iterations == 1
    assert acknowledgement.exported_messages == 2000
    assert acknowledgement.bytes_written > 2_000_000


def test_hard_byte_ceiling_includes_header_and_keeps_contiguous_newest_suffix(tmp_path):
    messages = [message(1, "old"), message(2, "middle" * 100), message(3, "new: é")]
    full_path = tmp_path / "full.jsonl"
    exporter(through=3).export(messages, full_path)
    lines = full_path.read_bytes().splitlines(keepends=True)
    ceiling = len(lines[0]) + len(lines[1]) + len(lines[3])
    while True:
        bounded = exporter(limit=MaxBytesLimit(ceiling), through=3)
        exact_ceiling = len(bounded._header()) + len(lines[1]) + len(lines[3])
        if exact_ceiling == ceiling:
            break
        ceiling = exact_ceiling
    assert len(bounded._header()) + len(lines[2]) + len(lines[3]) > ceiling

    destination = tmp_path / "bounded.jsonl"
    acknowledgement = bounded.export(iter(messages), destination)

    assert destination.read_bytes() == bounded._header() + lines[3]
    assert acknowledgement.bytes_written == len(destination.read_bytes()) <= ceiling
    assert acknowledgement.exported_messages == 1 and acknowledgement.omitted_messages == 2
    assert acknowledgement.first_sequence == acknowledgement.last_sequence == 3
    assert acknowledgement.truncated


def test_byte_ceiling_fails_when_header_cannot_fit_and_oversize_newest_yields_header_only(
    tmp_path,
):
    too_small = tmp_path / "too-small.jsonl"
    with pytest.raises(ValueError):
        exporter(limit=MaxBytesLimit(1), through=2).export([message(1, "body")], too_small)
    assert not too_small.exists()

    ceiling = 1_000
    while True:
        baseline = exporter(limit=MaxBytesLimit(ceiling), through=2)
        header_size = len(baseline._header())
        if ceiling == header_size + 1:
            break
        ceiling = header_size + 1
    destination = tmp_path / "header-only.jsonl"
    acknowledgement = baseline.export([message(1, "old"), message(2, "newest is oversized")], destination)
    assert len(destination.read_bytes()) == header_size
    assert records(destination)[0]["record"] == "header"
    assert acknowledgement.exported_messages == 0 and acknowledgement.omitted_messages == 2
    assert acknowledgement.oversized_messages == 2
    assert acknowledgement.bytes_written <= ceiling


def test_recent_cutoff_is_inclusive_and_excludes_invalid_or_future_times_with_counts(tmp_path):
    messages = [
        message(1, "undated", timestamp=0),
        message(3, "before", timestamp=9.9),
        message(4, "at", timestamp=10.0),
        message(5, "after", timestamp=10.1),
        message(6, "at export boundary", timestamp=200.0),
        message(7, "future", timestamp=200.1),
    ]
    destination = tmp_path / "recent.jsonl"
    acknowledgement = exporter(limit=RecentLimit(10.0), through=7).export(
        (item for item in messages), destination
    )

    assert [row["message"]["text"] for row in records(destination)[1:]] == [
        "at",
        "after",
        "at export boundary",
    ]
    assert acknowledgement.source_messages == 6 and acknowledgement.exported_messages == 3
    assert acknowledgement.invalid_time_messages == 1
    assert acknowledgement.time_filtered_messages == 2
    assert acknowledgement.omitted_messages == 3 and acknowledgement.truncated


def test_text_export_is_non_importable_and_prefixes_multiline_body(tmp_path):
    destination = tmp_path / "wire.txt"
    body = "first line\n[forged] <mallory -> #team> second line"
    acknowledgement = exporter(format=TextFormat(), through=7).export([message(7, body)], destination)

    output = destination.read_text()
    assert output.startswith("# agent-comms wire export v1 (non-importable text view)\n")
    assert '"importable":false' in output
    assert "[1970-01-01T00:00:07.000000Z]" in output
    assert "[seq=7" in output and "role=agent" in output and "<alice -> #team>" in output
    assert "\n  | first line\n  | [forged] <mallory -> #team> second line\n" in output
    assert acknowledgement.bytes_written == len(output.encode())


def test_atomic_private_output_refuses_existing_and_symlink_and_force_replaces(tmp_path):
    destination = tmp_path / "wire.jsonl"
    destination.write_text("keep me")

    with pytest.raises(ExportDestinationExists) as refused:
        exporter().export([message(1, "first")], destination)
    # A taken path is the caller's refusal, shown as one, and still the file-exists condition.
    assert isinstance(refused.value, ToolRefusedError) and isinstance(refused.value, FileExistsError)
    assert destination.read_text() == "keep me"
    assert not list(tmp_path.glob(".wire.jsonl.*.tmp"))

    link = tmp_path / "link.jsonl"
    link.symlink_to(destination)
    with pytest.raises(FileExistsError):
        exporter().export([message(1, "first")], link)
    assert link.is_symlink()

    acknowledgement = exporter().export([message(2, "replacement")], destination, overwrite=True)
    assert records(destination)[1]["message"]["text"] == "replacement"
    assert acknowledgement.last_sequence == 2
    if os.name != "nt":
        assert destination.stat().st_mode & 0o777 == 0o600


def test_wire_snapshot_excludes_appends_after_its_fixed_boundary(export_comms):
    comms = export_comms
    comms.messaging.send("alice", "#team", "captured").message.message_id

    with comms.bus.bus.reading() as source:
        through = source.revision()
        comms.messaging.send("bob", "#team", "too late").message.message_id
        snapshot = list(source.message_history())

    assert through == 1
    assert [item.body for item in snapshot] == ["captured"]
    assert [item.body for item in read_history(comms)] == ["captured", "too late"]


def test_comms_export_uses_target_owned_channel_and_alias_aware_dm_scopes(tmp_path, export_comms):
    comms = export_comms
    comms.messaging.send("alice", "#team", "team row").message.message_id
    comms.channels.create_tag("other")
    comms.messaging.send("alice", "#other", "other row").message.message_id
    comms.messaging.send("alice", "bob", "private row").message.message_id
    comms.registry.rename("alice", "renamed")

    channel_path = tmp_path / "team.jsonl"
    channel_receipt = comms.views.export_wire(
        channel_path,
        format=JsonlFormat(),
        scope=ChannelScope("#team"),
        limit=FullLimit(),
        export_started_at=100,
    )
    assert [row["message"]["text"] for row in records(channel_path)[1:]] == ["team row"]
    assert channel_receipt.boundary.through_seq == 3

    dm_path = tmp_path / "dm.jsonl"
    dm_receipt = comms.views.export_wire(
        dm_path,
        format=JsonlFormat(),
        scope=DmScope(("renamed", "bob")),
        limit=FullLimit(),
        export_started_at=100,
    )
    assert [row["message"]["text"] for row in records(dm_path)[1:]] == ["private row"]
    assert dm_receipt.scope.participants == ("renamed", "bob")

    comms.channels.set_saved_view(
        ParticipantsView('projection', ViewPredicate(AnyOfMatch, frozenset({'team'})))
    )
    with pytest.raises(RelationViolationError):
        comms.views.export_wire(
            tmp_path / "projection.jsonl",
            format=JsonlFormat(),
            scope=ChannelScope("#projection"),
            limit=FullLimit(),
        )


def test_export_wire_cli_requires_explicit_scope_and_bound_and_emits_receipt(
    tmp_path, capsys, export_comms, durable_home,
):
    comms = export_comms
    root = comms.root
    comms.messaging.send("alice", "#team", "hello").message.message_id
    destination = tmp_path / "cli.jsonl"

    assert (
        CliInvocation().invoke([
                "--root",
                str(root),
                "export-wire",
                "--output",
                str(destination),
                "--channel",
                "#team",
                "--last",
                "24h",
            ], sys.stdout)
        == 0
    )
    acknowledgement = json.loads(capsys.readouterr().out)
    assert acknowledgement["scope"] == {"kind": "channel", "channel": "#team"}
    assert acknowledgement["limit"]["kind"] == "recent"
    assert acknowledgement["output_sha256"] == hashlib.sha256(destination.read_bytes()).hexdigest()
    assert records(destination)[1]["message"]["text"] == "hello"


def test_export_does_not_mutate_history_or_read_state(tmp_path, export_comms):
    comms = export_comms
    comms.messaging.send("alice", "bob", "unread").message.message_id
    bus_before = tuple(comms.bus.bus.message_history())

    comms.views.export_wire(
        tmp_path / "everything.jsonl",
        format=JsonlFormat(),
        scope=EverythingScope(),
        limit=FullLimit(),
    )

    assert tuple(comms.bus.bus.message_history()) == bus_before
    assert comms.bus.pending_count("bob") == 1


def test_failures_clean_temporary_output_and_invalid_sequence_never_publishes(tmp_path):
    destination = tmp_path / "failed.jsonl"

    def broken_stream():
        yield message(1, "first")
        raise RuntimeError("source failed")

    with pytest.raises(RuntimeError):
        exporter().export(broken_stream(), destination)
    assert not destination.exists()
    assert not list(tmp_path.glob(".failed.jsonl.*.tmp"))

    with pytest.raises(ValueError):
        exporter().export([message(2, "later"), message(1, "earlier")], destination)
    assert not destination.exists()

    with pytest.raises(ValueError):
        exporter().export(
            [message(1, "first"), replace(message(2, "duplicate"), seq=1)], destination
        )
    assert not destination.exists()


@pytest.mark.parametrize("timestamp", [math.nan, math.inf, -math.inf])
def test_wire_codec_rejects_non_json_timestamps(timestamp):
    record = message(1, "current wire").to_wire()
    record["ts"] = timestamp
    with pytest.raises(ValueError):
        Message.from_wire(record)
    with pytest.raises(TypeError):
        replace(message(1, "current wire"), timestamp=timestamp).to_wire()


@pytest.mark.parametrize("timestamp", [7, 7.0])
def test_wire_codec_preserves_timestamp_spelling_and_identity(timestamp):
    source = replace(message(1, "retained identity"), timestamp=timestamp)
    record = source.to_wire()
    reopened = Message.from_wire(json.loads(json.dumps(record)))
    assert json.dumps(reopened.to_wire()) == json.dumps(record)
    assert reopened.message_id == source.message_id


def test_stored_text_and_jsonl_export_render_claim_notices(tmp_path):
    def claim_notice(seq, db):
        notice = Message("worker", "worker", "Claimed", ClaimNoticeKind, timestamp=5.0, seq=seq)
        return ClaimRecord.of(notice, UnscopedClaims(
            owner="worker", incarnation="1", seq=seq, message_id=notice.message_id,
            claims=("/owned",), generation=ClaimId("f" * 32)))

    bus = Bus.install(Bus.path_in(tmp_path))
    stored = bus.append(claim_notice)
    for format, name in ((TextFormat(), "claims.txt"), (JsonlFormat(), "claims.jsonl")):
        with bus.stored_message_history(through=stored.seq) as source:
            receipt = exporter(format=format, through=stored.seq).export_stored(
                source, tmp_path / name)
        assert receipt.exported_messages == 1
    assert "type=claim-notice" in (tmp_path / "claims.txt").read_text()
    assert records(tmp_path / "claims.jsonl")[1]["message"]["type"] == "claim-notice"


async def test_a_cancel_from_another_thread_stops_the_waiting_call_and_a_plain_observer_never_does():
    """A remote export's cancel watcher awaits the observer's stop instead of polling it."""
    import asyncio
    import threading

    from agent_comms.transport.progress import CancellableWireExport, WireExportObserver

    export = CancellableWireExport()
    waiting = asyncio.create_task(export.stopped())
    await asyncio.sleep(0)
    assert not waiting.done()
    threading.Thread(target=export.cancel).start()
    await asyncio.wait_for(waiting, 5)
    assert not export.stop_waiters

    await asyncio.wait_for(export.stopped(), 1)  # already cancelled: resolves at once

    with pytest.raises(TimeoutError):
        await asyncio.wait_for(WireExportObserver().stopped(), 0.2)
