"""How a selected turn's final answer becomes replies.

Real private bus, registry and coordination stores. Found on a live thread
whose model ended a direct-message turn in plain text: the turn was recorded as failed
and the answer was never delivered.
"""

from __future__ import annotations

import os
import sys
from contextlib import contextmanager
from pathlib import Path
from tempfile import TemporaryDirectory

import pytest

from agent_comms.comms import wire
from agent_comms.coordination.cohort import sealed_cohort_assignments
from agent_comms.coordination.coordinator import Coordination
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.execution.native_failures import NativePiUnavailable
from agent_comms.execution.selected.source_batch import (
    SelectedSource,
    SelectedSourceBatch,
)
from agent_comms.messaging.messages import InfoKind
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import NativeThread
from bus_record_fixture import prepare_native_comms
from conftest import accept_initial, publish_initial

pytestmark = pytest.mark.skipif(
    sys.platform != "linux", reason="private cohort claim_scope requires real /var/tmp"
)


@contextmanager
def alice_batch(*sent: tuple[str, str]):
    """Alice's selected sources for these (target, text) messages from sender."""
    with TemporaryDirectory(prefix="ac-answer-", dir="/var/tmp") as dirname:
        root = Path(dirname) / "wire"
        root.mkdir(mode=0o700)
        comms = prepare_native_comms(wire(root))
        for name, created in (("sender", 17021.0), ("Alice", 17022.0)):
            comms.registry.declare(NativeThread(name, frozenset({'team'}), Checkout(Path(dirname)), process_identity=ProcessIdentity.capture(os.getpid()), created_at=created))
        root_id = comms.registry.store.prepare_native_root().namespace
        messages = [publish_initial(comms, "sender", target, text) for target, text in sent]
        with Coordination(str(root / "coordination.sqlite3")) as store:
            deliveries = [comms.bus.bus.delivery(m.seq) for m in messages]
            for recipient in deliveries[0].recipients:
                store.participants.register(
                    recipient.recipient_lookup, committed=True,
                )
            for message in messages:
                accept_initial(comms.bus, root_id, message.seq, store)
            lookup = comms.registry.require("Alice").incarnation.lookup
            assignments = sealed_cohort_assignments(store, lookup)
            yield SelectedSourceBatch.first_route(tuple(
                SelectedSource(assignment.assignment_id, store.assignments, delivery)
                for assignment, delivery in zip(assignments, deliveries, strict=True)
            ))


def test_plain_answer_to_one_reply_route_is_that_routes_reply() -> None:
    with alice_batch(("Alice", "What did you find?")) as batch:
        assert batch.target == "sender"
        reply = batch.response_message("Blocked: the edit did not run.\n", "Alice")
        assert (reply.sender, reply.target, reply.body, reply.type) == (
            "Alice", "sender", "Blocked: the edit did not run.", InfoKind,
        )
        # A JSON answer is plain text too: Core stamps it onto the route as written.
        reply = batch.response_message('{"files": 3}', "Alice")
        assert reply.body == '{"files": 3}'
        with pytest.raises(NativePiUnavailable):
            batch.response_message("  \n", "Alice")


def test_one_selected_turn_answers_one_reply_route() -> None:
    """A mixed direct/channel wave never shares one answer across audiences.

    The batch type itself groups the captured sources by reply route
    (SelectedSourceBatch.first_route); the gathered batch answers only the
    earliest route and the later routes stay pending for their own turns.
    """
    with alice_batch(("Alice", "A private question"), ("#team", "@Alice a team question")) as batch:
        assert batch.target == "sender"
        assert all(source.delivery.message.target == "Alice" for source in batch.sources)
        reply = batch.response_message("One answer for everyone.", "Alice")
        assert (reply.target, reply.body) == ("sender", "One answer for everyone.")
