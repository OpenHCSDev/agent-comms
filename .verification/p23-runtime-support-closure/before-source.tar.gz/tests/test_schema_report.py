import sys

from agent_comms.planning.orders import Todo

"""The CLI reports stored declarations without changing existing databases."""
import hashlib
import sqlite3
from contextlib import closing
from dataclasses import MISSING, fields

from agent_comms.cli import CliInvocation
from agent_comms.cli_verbs.schema_report import SchemaReportCliCommand
from agent_comms.nominal.field_codec import FieldCodec
from agent_comms.storage.typed_table import SQLiteSchemaDifference, SQLiteSchemaObject
from bus_record_fixture import context_comms


def unfinished_todo(db):
    """Write one unfinished todo; each column it does not name holds its declared default."""
    named = {"id": "one", "repo": "team/repo", "text": "unfinished", "creator": "Alice",
             "creator_created": 17002, "state": "open", "revision": 1, "order": "{}"}
    defaults = {item.name: item.default if item.default_factory is MISSING else item.default_factory()
                for item in fields(Todo) if (item.default, item.default_factory) != (MISSING, MISSING)}
    row = {item.wire_name: named[item.name] if item.name in named else item.encode(defaults[item.name])
           for item in Todo._fields if item.name in named or item.name in defaults}
    columns = ", ".join(f'"{name}"' for name in row)
    db.execute(f"INSERT INTO todo ({columns}) VALUES ({', '.join('?' * len(row))})", tuple(row.values()))


def _old_todo(path):
    """A store created before the declared column CHECKs."""
    target = Todo.schema_objects()[Todo.declared_name]
    original = target
    for item in Todo._fields:
        for constraint in item.storage.constraints(item.name, item.annotation):
            original = original.replace(f" CHECK ({constraint})", "", 1)
    assert original != target
    with closing(sqlite3.connect(path)) as db:
        db.execute(original)
        unfinished_todo(db)
        db.commit()


def test_comparison_names_changed_missing_and_extra_objects():
    assert SQLiteSchemaObject.differences(
        [SQLiteSchemaObject("changed", "old"), SQLiteSchemaObject("extra", "sql")],
        {"changed": "new", "missing": "sql"}) == (
            SQLiteSchemaDifference("changed", "old", "new"),
            SQLiteSchemaDifference("extra", "sql", None),
            SQLiteSchemaDifference("missing", None, "sql"))


def test_cli_inspects_existing_stores_without_rewriting_them(tmp_path, capsys, durable_home):
    comms = context_comms(tmp_path)
    path = comms.root / "todos.sqlite3"
    _old_todo(path)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    result = FieldCodec.encode(SchemaReportCliCommand().apply(comms).reports)
    todo = next(row for row in result if row["path"] == str(path))
    # The old store has the table without its CHECKs and none of the indexes declared since.
    assert [change["name"] for change in todo["differences"]] == sorted(Todo.schema_objects())
    assert CliInvocation().invoke(["--root", str(comms.root), "schema-report"], sys.stdout) == 0
    assert '"differences"' in capsys.readouterr().out
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest


def test_unknown_and_unavailable_stores_do_not_look_clean(tmp_path):
    comms = context_comms(tmp_path)
    with closing(sqlite3.connect(comms.root / "unknown.sqlite3")) as db:
        db.execute("CREATE TABLE unowned (x)")
    (comms.root / "broken.sqlite3").write_bytes(b"not a database")
    reports = FieldCodec.encode(SchemaReportCliCommand().apply(comms).reports)
    assert next(row for row in reports if row["path"].endswith("unknown.sqlite3"))["undeclared_tables"] == ["unowned"]
    assert next(row for row in reports if row["path"].endswith("broken.sqlite3"))["error"]
