"""Whole conversations derive their original frozen wire sources, in both directions."""

import sqlite3
import sys
from dataclasses import replace

import pytest

from agent_comms.activity import StoppedDrainDiagnostic
from agent_comms.assignment_states import DeferredAssignment
from agent_comms.messaging.channel_targets import CommandTarget
from agent_comms.messaging.channels import AnyChannel
from agent_comms.comms import wire
from agent_comms.coordination.cohort import sealed_cohort_assignments
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.errors import (
    CoordinationReadUnavailable,
    ReloadRequired,
    StaleRevision,
)
from agent_comms.coordination.tables.assignments import WakeAssignment
from agent_comms.errors import RelationViolationError
from agent_comms.execution.native_runtime_input import NativeRuntimeTable
from agent_comms.messaging.messages import Message
from agent_comms.nominal.field_codec import FieldCodec
from agent_comms.notification_assignment import (
    AssignmentActivityEvidence,
    AssignmentSource,
    NotificationAssignment,
    NotificationSelection,
)
from agent_comms.notification_evidence import AllOutcomes, OwnerOutcomes
from agent_comms.notification_progress import (
    PendingProgress,
    SentProgress,
    UnrecordedProgress,
)
from agent_comms.pi_payloads import PublishedMessageToolDetails
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.registry_store import RegistryStore
from agent_comms.registry.threads import NativeThread
from agent_comms.routing import MessageRoute, TurnRouting
from agent_comms.tool_caller import ThreadCaller
from agent_comms.transcript_sources import AssignedTranscriptSource
from agent_comms.transcripts import EarlierThan, TranscriptRead, TranscriptSourceWindow
from agent_comms.transport.tools.served import invoke_tool
from conftest import accept_initial, publish_initial
from test_coordinated_runtime import _root, tmp_path  # noqa: F401


def test_original_read_contention_is_unavailable_then_same_receipts_return(tmp_path):  # noqa: F811

    root, _root_id, comms, initial, _people = _root(tmp_path)
    database = root / "coordination.sqlite3"
    selection = NotificationSelection.of(AllOutcomes(), (initial,))
    captured = NotificationAssignment.read(root, selection)
    original = NotificationAssignment.resolve(captured)
    wire_before = comms.bus.bus.revision()
    assert original
    with Coordination(str(database)) as writer:
        with writer.session.writing():
            with pytest.raises(CoordinationReadUnavailable) as unavailable:
                NotificationAssignment.read(root, selection)
            assert unavailable.value.__cause__.sqlite_errorcode & 0xFF in (
                sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED,
            )
            with pytest.raises(CoordinationReadUnavailable):
                with TranscriptRead.publication_source(root):
                    pytest.fail("Busy acquisition reached the native schema decoder")
    reopened = NotificationAssignment.read(root, selection)
    assert reopened == captured
    assert NotificationAssignment.resolve(reopened) == original
    with TranscriptRead.publication_source(root) as native_read:
        assert native_read is not None
    assert comms.bus.bus.revision() == wire_before


def test_a_read_selects_only_its_viewers_claims_and_attempts_before_decoding(tmp_path):  # noqa: F811

    root, _root_id, comms, initial, people = _root(tmp_path)
    lookups = {person.name: person.incarnation.lookup for person in people}
    reference = initial.message.reference
    everyone = NotificationAssignment.read(root, NotificationSelection.of(AllOutcomes(), (initial,)))
    recipients = {recipient.canonical_thread: recipient.recipient_lookup
                  for recipient in initial.recipients}
    assert len(recipients) >= 2 and "sender" not in recipients
    assert {claim.recipient for claim, _evidence in everyone.rows} == recipients.keys()
    decoded = 0
    decode = AssignmentActivityEvidence._decode_row.__func__.__code__

    def count_decodes(frame, event, argument):
        nonlocal decoded
        if event == "call" and frame.f_code is decode:
            decoded += 1

    for name, lookup in recipients.items():
        viewer = OwnerOutcomes(lookup)
        decoded = 0
        profiling = sys.getprofile()
        sys.setprofile(count_decodes)
        try:
            own = NotificationAssignment.read(root, NotificationSelection.of(viewer, (initial,)))
        finally:
            sys.setprofile(profiling)
        assert decoded == 1
        assert own.selection.viewer == viewer and own.sources == (initial,)
        assert own.rows == tuple(row for row in everyone.rows if row[0].recipient == name)
        assert own.evidence[reference].claims == own.rows
        assert own.evidence[reference].consumption == {
            recipient: attempts for recipient, attempts in everyone.evidence[reference].consumption.items()
            if recipient == lookup}
    sender = NotificationAssignment.read(root, NotificationSelection.of(OwnerOutcomes(lookups["sender"]), (initial,)))
    assert sender.rows == everyone.rows
    assert sender.evidence == everyone.evidence


def test_invisible_recipients_allocate_no_placeholder_source(tmp_path):  # noqa: F811
    root, _root_id, _comms, initial, people = _root(tmp_path)
    lookups = {person.name: person.incarnation.lookup for person in people}
    recipient = initial.recipients[0]
    (source, outcomes), = NotificationAssignment.for_deliveries(
        NotificationSelection.of(OwnerOutcomes(recipient.recipient_lookup), (initial,)), ())
    assert source is initial
    assert [outcome.recipient() for outcome in outcomes] == [recipient]
    (_source, all_outcomes), = NotificationAssignment.for_deliveries(
        NotificationSelection.of(OwnerOutcomes(lookups["sender"]), (initial,)), ())
    assert [outcome.recipient() for outcome in all_outcomes] == list(initial.recipients)


def test_retained_reads_refresh_only_for_changes_their_viewer_sees(tmp_path):  # noqa: F811

    root, _root_id, _comms, initial, people = _root(tmp_path)
    lookups = {person.name: person.incarnation.lookup for person in people}
    changed, unchanged = initial.recipients[:2]
    reads = {
        "changed": NotificationAssignment.read(
            root, NotificationSelection.of(OwnerOutcomes(changed.recipient_lookup), (initial,))),
        "foreign": NotificationAssignment.read(
            root, NotificationSelection.of(OwnerOutcomes(unchanged.recipient_lookup), (initial,))),
        "sender": NotificationAssignment.read(
            root, NotificationSelection.of(OwnerOutcomes(lookups["sender"]), (initial,))),
        "operator": NotificationAssignment.read(root, NotificationSelection.of(AllOutcomes(), (initial,))),
    }
    assert NotificationAssignment.changed(reads.values(), AssignmentSource(root)) == ()
    with Coordination(str(root / "coordination.sqlite3")) as store:
        assignment, = sealed_cohort_assignments(store, changed.recipient_lookup)
        store.assignments.transition_preengagement(
            assignment.assignment_id, DeferredAssignment, expected_revision=assignment.revision)
    refreshed = NotificationAssignment.changed(reads.values(), AssignmentSource(root))
    assert {name for name, read in reads.items() if read in refreshed} == {
        "changed", "sender", "operator"}


@pytest.mark.parametrize('direct', [False, True])
def test_saved_notification_does_not_mix_owner_drain_readiness(tmp_path, direct):  # noqa: F811

    _path, _root_id, comms, initial, _people = _root(tmp_path, direct=direct)
    owner = comms.registry.snapshot().owner_identity('beta')
    diagnostic = StoppedDrainDiagnostic(
        owner, 'NativePiUnavailable', 'Original outcome uncertain', recorded_at=1.0
    )
    assert comms.agents.set_drain_diagnostic('beta', owner, diagnostic)
    notice = next(item for item in comms.views.thread_presentations(('sender',)).require('sender').notifications
                  if item.recipient=='beta')
    assert type(notice.state) is SentProgress
    assert notice.state.detail == ''
    assert notice.message.reference==initial.message.reference
    assert not notice.state.working
    # A diagnostic from another owner generation cannot block a current
    # participant; neither its text nor a running PID grants that relation.
    foreign = replace(diagnostic,owner=replace(owner,generation=owner.generation+1))
    activity = comms.agents.activity_of('beta', snapshot=comms.registry.snapshot()).source_event()
    comms.agents.activity.emit(replace(activity,diagnostic=foreign))
    current = next(item for item in comms.views.thread_presentations(('sender',)).require('sender').notifications
                   if item.recipient=='beta')
    assert type(current.state) is SentProgress


def test_frozen_unhandled_delivery_projects_recovery_without_claiming(tmp_path):  # noqa: F811

    root, _root_id, comms, _initial, _people = _root(tmp_path)
    owner = comms.registry.snapshot().owner_identity('beta')
    diagnostic = StoppedDrainDiagnostic(
        owner, 'NativePiUnavailable', 'Original uncertain outcome', recorded_at=1.0
    )
    assert comms.agents.set_drain_diagnostic('beta', owner, diagnostic)
    message = comms.messaging.send_user_message(CommandTarget.named('#team'), 'Independent saved original',
                                               worktree=Checkout(tmp_path))
    with Coordination(str(root/'coordination.sqlite3')) as store:
        before = WakeAssignment.select(store.session._connection)
    wire_before = comms.bus.bus.revision()
    notices = comms.views.message_notifications_for_references(AllOutcomes(), (message.reference,)).outcomes[message.seq,message.message_id]
    beta = next(notice for notice in notices if notice.recipient=='beta')
    assert beta.state == PendingProgress(UnrecordedProgress())
    assert beta.state.detail == ''
    assert beta.recipient_identity.recipient_lookup==comms.registry.require('beta').incarnation.require_recorded().lookup
    with Coordination(str(root/'coordination.sqlite3')) as store:
        assert WakeAssignment.select(store.session._connection)==before
    assert not any(row.wire_seq==message.seq for row in before)
    assert comms.bus.bus.revision()==wire_before
    # The immutable source's recipient survives rename; current readiness must
    # join its original birth rather than manufacture a new membership/claim.
    comms.registry.rename('beta','renamed')
    renamed = comms.views.message_notifications_for_references(AllOutcomes(), (message.reference,)).outcomes[message.seq,message.message_id]
    assert {item.recipient_identity for item in renamed}=={item.recipient_identity for item in notices}


def test_capture_page_window_names_zero_and_nonzero_sent_windows(tmp_path):  # noqa: F811

    _path, _root_id, comms, initial, _people = _root(tmp_path)
    ordinary = comms.transcripts.capture_page_window("sender")
    assert isinstance(ordinary, TranscriptSourceWindow)
    assert ordinary.sent_sources == ()
    with_sent = comms.transcripts.capture_page_window("sender", sent_source_limit=5)
    assert isinstance(with_sent, TranscriptSourceWindow)
    assert [source.message.reference for source in with_sent.sent_sources] == [
        initial.message.reference
    ]


def test_notification_window_preserves_exact_receipts_and_rejects_duplicates(tmp_path):  # noqa: F811
    root, _root_id, comms, initial, _people = _root(tmp_path)
    selection = NotificationSelection.of(AllOutcomes(), (initial,))
    records = NotificationAssignment.resolve(NotificationAssignment.read(root, selection))
    assert records
    projected = tuple(NotificationAssignment.for_deliveries(selection, records))
    assert projected[0][0] is initial
    assert any(outcome is records[0] for outcome in projected[0][1])
    with pytest.raises(ValueError):
        tuple(NotificationAssignment.for_deliveries(selection, (*records, records[0])))
    # Duplicate evidences outside the acquired deliveries do not change their result.
    assert tuple(NotificationAssignment.for_deliveries(NotificationSelection.of(AllOutcomes(), ()), (*records, records[0]))) == ()


def test_publication_intent_joins_original_sender_and_target_only(tmp_path):  # noqa: F811

    _path, _root_id, comms, initial, _people = _root(tmp_path)
    reply = comms.messaging.send("beta", "sender", "First original reply").message
    source = AssignedTranscriptSource.for_thread(
        comms.root, comms.registry.require("beta"), comms.bus.bus
    )
    original = source.rows(sequences=(reply.seq,))
    lookup = source.recipient.require_recorded().lookup
    intent = TurnRouting((initial.message.reference,), MessageRoute("beta", ("sender", "alpha")))
    # A later send can fail; this first committed subset stays a valid relation.
    intent.require_publications(original, lookup)
    absent = TurnRouting()
    assert not absent.outgoing
    assert FieldCodec.encode(absent)["reply"] is None
    assert TurnRouting.from_wire(absent.to_wire()) == absent
    absent.require_publications((), lookup)
    with pytest.raises(RelationViolationError):
        absent.require_publications(original, lookup)
    reference_only = FieldCodec.encode(intent)["requests"]
    assert reference_only == [FieldCodec.encode(initial.message.reference)]
    assert TurnRouting.from_wire(intent.to_wire()) == intent
    with pytest.raises((TypeError, ValueError)):
        TurnRouting.from_wire({"requests": [initial.message.to_wire()], "reply": None})
    with pytest.raises(RelationViolationError):
        intent.require_publications(original, "foreign-incarnation")
    with pytest.raises(RelationViolationError):
        replace(intent, reply=MessageRoute("beta", ("alpha",))).require_publications(original, lookup)
    with pytest.raises(RelationViolationError):
        replace(intent, publications=(reply.reference,)).require_publications(original, lookup)


def test_open_sender_source_advances_without_a_native_tool_copy(tmp_path):  # noqa: F811
    _path, _root_id, comms, initial, _people = _root(tmp_path)
    before = comms.transcripts.capture_page_read("beta")
    acknowledgement = PublishedMessageToolDetails.from_wire(invoke_tool(
        comms, "comms_send",
        {"to": "sender", "body": "Original outgoing ownership reply"},
        caller=ThreadCaller("beta"),
    ))
    message, = comms.bus.bus.messages_for_references((acknowledgement.message.source,))
    after = comms.transcripts.capture_page_read("beta")
    assert after.identity.wire_frontier.sequence == message.seq
    assert not before.current()
    with pytest.raises(StaleRevision):
        before.read()
    events = after.read().events
    assert [event.text for event in events] == [initial.message.body, message.body]
    assert [event.timestamp for event in events] == [initial.message.timestamp, message.timestamp]
    sent = events[-1]
    assert sent.declared_name == "sent"
    assert sent.source == message.reference
    assert sent.routing.reply.targets == (message.target,)
    # The reader's name changes; the original messages and sent source do not.
    comms.registry.rename("beta", "renamed")
    reopened = wire(comms.root).transcripts.capture_page_read("renamed").read()
    assert reopened.events == (replace(events[0], reader="renamed"), events[1])
    assert list(comms.views.history_page(AnyChannel.target()).messages)[-1] == message


def test_unrelated_canonical_append_keeps_open_source_content(tmp_path):  # noqa: F811
    _path, _root_id, comms, _initial, _people = _root(tmp_path)
    before = comms.transcripts.capture_page_read("beta")
    page = before.read()
    comms.messaging.send("sender", "alpha", "Unrelated original").message
    after = comms.transcripts.capture_page_read("beta")
    assert before.identity.bus_revision != after.identity.bus_revision
    assert before.identity.wire_frontier == after.identity.wire_frontier
    assert not before.current()
    assert before.content_current()
    assert before.read() == page
    assert before.identity.same_content(after.identity)
    comms.messaging.send("sender", "beta", "Related original").message
    assert not before.content_current()


def test_open_source_rejects_replaced_wire_inode(tmp_path):  # noqa: F811
    _path, _root_id, comms, _initial, _people = _root(tmp_path)
    before = comms.transcripts.capture_page_read("beta")
    replacement = comms.bus.bus.path.with_suffix(".replacement")
    comms.bus.bus.backup(replacement)
    replacement.replace(comms.bus.bus.path)
    assert not before.content_current()
    with pytest.raises(StaleRevision):
        before.read()


def test_published_source_binding_keeps_exact_original_request(tmp_path):  # noqa: F811
    _path, _root_id, comms, _initial, _people = _root(tmp_path)
    identity = comms.views.thread_presentations(("beta",)).require("beta").read_identity
    assert comms.transcripts.bind_page_read("beta", identity).identity is identity
    with pytest.raises(ReloadRequired):
        comms.transcripts.bind_page_read("alpha", identity)
    with pytest.raises(ReloadRequired):
        wire(tmp_path / "other").transcripts.bind_page_read("beta", identity)
    with pytest.raises(ReloadRequired):
        comms.transcripts.bind_page_read(
            "beta", identity,
            position=EarlierThan(identity.page_bound.at_offset(0)),
        )
    comms.registry.rename("beta", "renamed")
    assert comms.transcripts.bind_page_read("renamed", identity).identity is identity
    comms.registry.unregister("renamed")
    comms.registry.remove("renamed")
    comms.registry.declare(NativeThread('renamed', frozenset(), Checkout(tmp_path)))
    with pytest.raises(ReloadRequired):
        comms.transcripts.bind_page_read("renamed", identity)


def test_missing_bus_cannot_be_an_empty_presentation(tmp_path):  # noqa: F811
    _path, _root_id, comms, _initial, _people = _root(tmp_path)
    comms.bus.bus.path.unlink()
    # The store owner refuses a missing file (locked_store.reader_snapshot) before SQLite opens it.
    with pytest.raises(FileNotFoundError):
        comms.views.thread_presentations(("beta",)).require("beta")


def test_a_forced_key_batch_captures_the_same_evidence_through_the_recipient_index(tmp_path):  # noqa: F811

    root, root_id, comms, initial, _people = _root(tmp_path)
    database = root / "coordination.sqlite3"
    privacy = RegistryStore.at(root).privacy()
    # The lowered limit still admits capture's own schema validation: each catalog read
    # binds every declared object name and every table name of its schema.
    limit = max(6, *(
        len({name for row in schema.schema_rows() for name in row.schema_names})
        + len(schema.schema_rows())
        for schema in (privacy.coordinator_schema(), NativeRuntimeTable)))
    key_fields = 3
    originals = limit // (key_fields * len(initial.recipients)) + 1
    assert originals + 1 <= NotificationSelection.window_limit
    sources = [initial]
    for index in range(originals - 1):
        later = publish_initial(comms, "sender", "#team", f"Broadcast {index} for the window")
        with Coordination(str(database)) as store:
            accept_initial(comms.bus, root_id, later.seq, store)
        sources.append(comms.bus.bus.delivery(later.seq))
    sources = (*sources, initial)
    keys = tuple({"recipient_lookup": recipient.recipient_lookup, "wire_seq": source.message.seq,
                  "message_id": source.message.message_id}
                 for source in sources for recipient in source.recipients)
    distinct = tuple(dict.fromkeys(tuple(key.values()) for key in keys))
    assert key_fields * len(distinct) > limit and len(keys) > len(distinct)
    selection = NotificationSelection.of(AllOutcomes(), sources)
    ordinary = NotificationAssignment.read(root, selection)
    assert ordinary.rows
    statements: list[str] = []
    with Coordination(str(database)) as store, store.session.read():
        connection = store.session._connection
        unlimited, = WakeAssignment.requested_keys(connection, keys)
        previous = connection.setlimit(sqlite3.SQLITE_LIMIT_VARIABLE_NUMBER, limit)
        assert limit < previous
        connection.set_trace_callback(statements.append)
        try:
            bound = connection.getlimit(sqlite3.SQLITE_LIMIT_VARIABLE_NUMBER)
            batches = tuple(WakeAssignment.requested_keys(connection, keys))
            limited = NotificationAssignment.capture(connection, selection, privacy)
        finally:
            connection.set_trace_callback(None)
            connection.setlimit(sqlite3.SQLITE_LIMIT_VARIABLE_NUMBER, previous)
        index, = (name for _seq, name, unique, *_rest in connection.execute(
                      f'PRAGMA index_list("{WakeAssignment.declared_name}")')
                  if unique and [column for _rank, _cid, column in connection.execute(
                      f'PRAGMA index_info("{name}")')] == ["recipient_lookup", "wire_seq"])
        claim_statements = [statement for statement in statements
                            if statement.startswith("WITH requested") and "w AS MATERIALIZED" in statement]
        plans = [[row[3] for row in connection.execute(f"EXPLAIN QUERY PLAN {statement}")]
                 for statement in claim_statements]

    limited = NotificationAssignment.capture_detached(root, limited)
    assert len(batches) > 1
    assert all(len(batch.bindings) <= bound for batch in batches)
    assert sum(len(batch.bindings) for batch in batches) == key_fields * len(distinct)
    assert tuple(value for batch in batches for value in batch.bindings) == unlimited.bindings
    assert limited.selection.viewer == AllOutcomes() and limited.sources == sources
    assert limited.rows == ordinary.rows
    assert limited.consumption == ordinary.consumption
    assert limited.evidence == ordinary.evidence
    assert len({claim.assignment_id for claim, _evidence in limited.rows}) == len(limited.rows)
    order = [(-claim.wire_seq, claim.recipient) for claim, _evidence in limited.rows]
    assert order == sorted(order)
    assert len(claim_statements) >= 2
    for plan in plans:
        assert any(detail.startswith(f"SEARCH {WakeAssignment.declared_name} USING INDEX {index}")
                   for detail in plan), plan
        assert not any(detail.startswith(f"SCAN {WakeAssignment.declared_name}") for detail in plan), plan


def test_a_page_retains_its_sent_publication_answers_across_the_wire(tmp_path):
    from agent_comms.sent_message import PublishedSentMessage
    from agent_comms.transcripts import TranscriptPage

    _path, _root_id, comms, _initial, _people = _root(tmp_path)
    message = comms.messaging.send("beta", "sender", "Retained remote publication").message
    page = comms.transcripts.capture_page_read("beta").read()
    sent = page.events[-1]
    remote = FieldCodec.decode(TranscriptPage, FieldCodec.encode(page))
    database = comms.bus.bus.path
    absent = database.with_suffix(".off-device")
    database.rename(absent)
    try:
        resolved, = remote.resolve_sent((sent,))
    finally:
        absent.rename(database)
    assert isinstance(resolved, PublishedSentMessage)
    assert resolved.original == Message.from_message(message)
    assert resolved.reference.message == message.reference
    assert resolved.scope.recipient == comms.registry.require("beta").incarnation
    assert resolved.scope.root == str(comms.root)


def test_captured_report_evidence_keeps_unproved_reports_unproved(tmp_path):
    from agent_comms.nominal.field_codec import ToolCallId
    from agent_comms.sent_message import PublishedSentMessage
    from agent_comms.sent_reports import CapturedSentReports
    from agent_comms.transcript_events import SentTranscript, ToolEndTranscript

    _path, _root_id, comms, _initial, _people = _root(tmp_path)
    message = comms.messaging.send("beta", "sender", "Exact original").message
    report = SentTranscript.from_message(message)
    forged = replace(report, text="Not the original body")
    source = AssignedTranscriptSource.for_thread(comms.root, comms.registry.require("beta"), comms.bus.bus)
    tool = ToolEndTranscript(tool_call_id=ToolCallId("send"), tool_name="comms_send", timestamp=message.timestamp,
                             position=0, sent_message=report)
    assert tool.sent_reports() == (report,)
    captured = CapturedSentReports(sent_resolutions=source.capture_sent_reports((report, forged)))
    remote = FieldCodec.decode(CapturedSentReports, FieldCodec.encode(captured))
    resolved, unproved = remote.resolve_sent((report, forged))
    assert isinstance(resolved, PublishedSentMessage)
    assert resolved.original == Message.from_message(message)
    assert unproved == forged
