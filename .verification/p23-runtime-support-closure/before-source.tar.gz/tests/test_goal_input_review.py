"""Canonical inspection unblocks standby without fabricating native delivery."""

import os

import pytest

from agent_comms.messaging.channel_targets import CommandTarget
from agent_comms.comms import wire
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.goal_execution import GoalExecution
from agent_comms.input_disposition import InputDispositions
from agent_comms.input_key import AcpInputKey, BusInputKey, InputKeyText
from agent_comms.lifecycle_capability import Unresolved
from agent_comms.nominal.field_codec import FieldCodec, InputId, MalformedRecord, TurnId
from agent_comms.planning.goal_actions import (
    ActiveGoalAction,
    GoalPrecondition,
    OwnerInvocable,
    PausedGoalAction,
    SetGoalAction,
    StandbyGoalAction,
)
from agent_comms.planning.goal_scope import OneGoal
from agent_comms.projects.checkouts import Checkout
from agent_comms.messaging.read_basis import NamedViewer
from agent_comms.registry.threads import NativeThread
from agent_comms.tool_caller import ThreadCaller
from agent_comms.transport.tools.goals import CommsGoalTool
from agent_comms.transport.tools.inbox import CommsInboxTool
from conftest import installed_comms, publish_initial
from stored_inputs import stored_inputs

OWNER_INPUT_KEY = AcpInputKey(InputId.mint())


def test_inspected_canonical_dependencies_allow_standby_without_replay(tmp_path, monkeypatch):
    monkeypatch.setenv("AGENT_COMMS_THREAD", "worker")
    comms = wire(tmp_path / "wire")
    for name in ("worker", "parent", "other"):
        comms.registry.declare(
            NativeThread(name, frozenset(), Checkout(tmp_path), process_identity=ProcessIdentity.capture(os.getpid()))
        )
    comms.agents.begin_turn("parent", TurnId('aa7988bb017ade70857b6b2966e64ea2'))
    goal = comms.goals.update_goal("worker", SetGoalAction(text="Delegate and wait"))
    messages = [
        publish_initial(comms, "parent", "worker", text)
        for text in ("Set standby", "Yes wait")
    ]
    ledger = InputDispositions(comms.root)
    claim_scope = comms.registry.snapshot().claim_generation("worker")
    ledger.record(
        OWNER_INPUT_KEY,
        seq=None,
        owner="worker",
        claim_scope=claim_scope,
        target="worker",
        text="An uncertain user follow-up",
    )
    args = {
        "goal_id": goal.id,
        "status": "standby",
        "progress": "Waiting for later reply",
        "wait_for": ["parent"],
    }
    with pytest.raises(ValueError):
        CommsGoalTool.invoke(comms, args, caller=ThreadCaller("worker"))
    before = ledger.path.read_bytes()
    messages = comms.bus.inbox("worker").page.messages
    comms.bus.mark_read_through("worker", messages[-1].seq)
    result = CommsInboxTool.invoke(comms, {"thread": "worker", "standby": {"goal_id": goal.id, "wait_for": ["parent"]}}, caller=ThreadCaller("worker"))
    # A human read hides nothing from the agent: only what its runtime took leaves its inbox.
    assert result["messages"] == [message.to_wire() for message in messages]
    review = result["standby_review"]
    # The review names each input by its public key, "bus:<sequence>"; the old bare
    # "sequence" field was renamed to inputId and this assertion still asked for it.
    assert [row["inputId"] for row in review["messages"]] == [f"bus:{m.seq}" for m in messages]
    assert review["excluded_inputs"][0]["reason"] == "owner_input_without_bus_sequence"
    assert ledger.path.read_bytes() == before  # Inspection cannot adopt or schedule inputs.
    keys = review["reviewed_inputs"]
    for invalid in ([str(OWNER_INPUT_KEY)], [str(BusInputKey(999999))]):
        with pytest.raises(ValueError):
            CommsGoalTool.invoke(comms, {**args, "reviewed_inputs": invalid}, caller=ThreadCaller("worker"))
    with pytest.raises(ValueError):
        CommsGoalTool.invoke(comms, {**args, "reviewed_inputs": keys[1:]}, caller=ThreadCaller("worker"))
    assert ledger.path.read_bytes() == before  # Failed partial review commits nothing.
    unrelated = comms.messaging.send("other", "worker", "Not a declared dependency").message
    ledger.record(
        BusInputKey(unrelated.seq),
        seq=unrelated.seq,
        owner="worker",
        claim_scope=claim_scope,
        target="worker",
        text=unrelated.body,
    )
    scoped = comms.goals.goal_input_review("worker", goal.id, ["parent"])
    assert [str(key) for key in scoped.reviewed_inputs] == keys and len(scoped.excluded_inputs) == 2
    with pytest.raises(ValueError):
        CommsGoalTool.invoke(comms, {**args, "reviewed_inputs": [*keys, f"bus:{unrelated.seq}"]}, caller=ThreadCaller("worker"))
    result = CommsGoalTool.invoke(comms, {**args, "reviewed_inputs": keys}, caller=ThreadCaller("worker"))
    assert FieldCodec.decode(GoalExecution, result["goal_execution"]).standby()
    again = comms.goals.goal_input_review("worker", goal.id, ["parent"])
    assert again.reviewed_inputs == ()
    assert [str(row.input_id) for row in again.already_reviewed_inputs] == keys
    for message, key in zip(messages, keys, strict=True):
        row = stored_inputs(ledger.root).rows[InputKeyText.from_text(key)]
        row.require(Unresolved, ValueError("review required"))
        assert row.accepts_reservation
        assert row.source_text == message.body
        assert row.claim_generation == claim_scope and row.reviewed_for_goal(goal.id)
    assert not stored_inputs(ledger.root).rows[OWNER_INPUT_KEY].goal_reviews
    generation = comms.goals.open_goal_store().snapshot(goal.id)
    assert generation is not None and generation.lifecycle.ready
    assert generation.attempt_id.present() == ()
    reopened = wire(comms.root)
    reopened.goals.update_goal("worker", ActiveGoalAction(expect=GoalPrecondition(goal_id=OneGoal(goal.id))))
    reopened.goals.update_goal(
        "worker", StandbyGoalAction(expect=GoalPrecondition(goal_id=OneGoal(goal.id)), wait_for=("parent",))
    )
    fresh = comms.messaging.send("parent", "worker", "New result").message
    assert reopened.goals.goal_input_review("worker", goal.id, ["parent"]).reviewed_inputs == (
        BusInputKey(fresh.seq),
    )
    comms.goals.update_goal(
        "worker", PausedGoalAction(expect=GoalPrecondition(goal_id=OneGoal(goal.id))), actor=OwnerInvocable
    )
    with pytest.raises(ValueError):
        CommsGoalTool.invoke(comms, {**args, "reviewed_inputs": keys}, caller=ThreadCaller("worker"))
    assert comms.registry.require("worker").goal.state.declared_name == "paused"


@pytest.mark.parametrize("rebound", ["worker", "parent"])
def test_standby_excludes_retained_rebound_history_but_retains_rename(tmp_path, rebound):
    comms = installed_comms(tmp_path)
    for name in ("worker", "parent"):
        comms.registry.declare(
            NativeThread(name, frozenset(), Checkout(tmp_path), process_identity=ProcessIdentity.capture(os.getpid()))
        )
    old = comms.messaging.send("parent", "worker", "Old incarnation").message
    comms.registry.unregister(rebound)
    comms.registry.remove(rebound)
    comms.registry.declare(
        NativeThread(rebound, frozenset(), Checkout(tmp_path), process_identity=ProcessIdentity.capture(os.getpid()))
    )
    comms.agents.begin_turn("parent", TurnId('18ab1892f9f48635ac465d11156044ce'))
    goal = comms.goals.update_goal("worker", SetGoalAction(text="Current goal"))
    assert comms.goals.goal_input_review("worker", goal.id, ["parent"]).reviewed_inputs == ()
    action = StandbyGoalAction(expect=GoalPrecondition(goal_id=OneGoal(goal.id)), wait_for=("parent",))
    comms.goals.update_goal("worker", action)
    current = comms.messaging.send("parent", "worker", "Current incarnation").message
    comms.registry.rename("parent", "renamed-parent")
    review = comms.goals.goal_input_review("worker", goal.id, ["renamed-parent"])
    assert review.reviewed_inputs == (BusInputKey(current.seq),)
    assert old in list(comms.views.history_page(CommandTarget.named("worker"), viewer=NamedViewer("renamed-parent")).messages)


def test_inbox_standby_is_one_record(wired, monkeypatch):
    monkeypatch.setenv("AGENT_COMMS_THREAD", "fixer")
    goal = wired.goals.update_goal("fixer", SetGoalAction(text="Wait for the parent"))
    wired.messaging.send("PR111", "fixer", "Reply").message
    standby = {"goal_id": goal.id, "wait_for": ["PR111"]}
    for half in ({"goal_id": goal.id}, {"wait_for": ["PR111"]}):
        with pytest.raises(MalformedRecord):
            CommsInboxTool.invoke(wired, {"thread": "fixer", "standby": half}, caller=ThreadCaller("fixer"))
    result = CommsInboxTool.invoke(wired, {"thread": "fixer", "standby": standby}, caller=ThreadCaller("fixer"))
    assert len(result["messages"]) == 1  # A refused half record read nothing.
    assert (result["standby_review"]["goal_id"], result["standby_review"]["wait_for"]) == (goal.id, ["PR111"])


def test_standby_accepts_inbox_keys_delivered_since_the_inbox_cut(tmp_path, monkeypatch):
    monkeypatch.setenv("AGENT_COMMS_THREAD", "worker")
    comms = wire(tmp_path / "wire")
    for name in ("worker", "parent"):
        comms.registry.declare(
            NativeThread(name, frozenset(), Checkout(tmp_path),
                   process_identity=ProcessIdentity.capture(os.getpid()))
        )
    comms.agents.begin_turn("parent", TurnId('aa7988bb017ade70857b6b2966e64ea2'))
    goal = comms.goals.update_goal("worker", SetGoalAction(text="Delegate and wait"))
    early = publish_initial(comms, "parent", "worker", "Early answer")
    late = comms.messaging.send("parent", "worker", "Steered into the turn").message
    ledger = InputDispositions(comms.root)
    claim_scope = comms.registry.snapshot().claim_generation("worker")
    ledger.record(BusInputKey(late.seq), seq=late.seq, owner="worker", claim_scope=claim_scope,
                  target="worker", text=late.body)
    review = CommsInboxTool.invoke(
        comms, {"thread": "worker",
                "standby": {"goal_id": goal.id, "wait_for": ["parent"]}},
        caller=ThreadCaller("worker"))["standby_review"]
    keys = review["reviewed_inputs"]
    assert keys == [str(BusInputKey(early.seq)), str(BusInputKey(late.seq))]
    # pi-mi 10-24: bus:21929 was steered into its turn between comms_inbox and comms_goal.
    turn, native = TurnId('5d0c1f2bd8a64e0f9a7b3c2d1e0f4a5b'), InputId("c" * 32)
    assert ledger.bind(BusInputKey(late.seq), claim_scope=claim_scope, turn_id=turn,
                       native_id=native, text=late.body)
    assert ledger.started(BusInputKey(late.seq), turn_id=turn, native_id=native, text=late.body)
    args = {"goal_id": goal.id, "status": "standby", "progress": "Waiting", "wait_for": ["parent"]}
    with pytest.raises(ValueError):
        CommsGoalTool.invoke(comms, {**args, "reviewed_inputs": [str(BusInputKey(999999))]},
                      caller=ThreadCaller("worker"))
    result = CommsGoalTool.invoke(comms, {**args, "reviewed_inputs": keys}, caller=ThreadCaller("worker"))
    assert FieldCodec.decode(GoalExecution, result["goal_execution"]).standby()
    assert stored_inputs(ledger.root).rows[BusInputKey(early.seq)].reviewed_for_goal(goal.id)
