"""Root-owned controls for the shared heartbeat and native HUD presentation."""

from dataclasses import replace

from agent_comms.disclosure_text import (
    DisclosureText,
    EntityKey,
    FieldKey,
    IdentifiedRecordText,
    MappingText,
    SequenceText,
    ViewTable,
)
from agent_comms.nominal.field_codec import DisclosureIdentity, FieldCodec, HudExclude, OrderId
from agent_comms.planning.orders import OpenPrProgress
from agent_comms.recorded_time import RecordedEventTime
from agent_comms.registry.thread_identity import RecordedThreadIncarnation
from agent_comms.task_attachments.team_pings import (
    AlarmSection,
    FoldedRule,
    NewAlarms,
    RulePing,
    TeamDecisions,
    WatchingAlarms,
)
from agent_comms.team.standing_rules import ServicePassFailing
from agent_comms.team.vibe_check import OverloadDegradation
from agent_comms.team_hud import CodexUsage, TeamHud, UnreadableUsage
from agent_comms.team_hud_records import HudRecord, Teammate, TeamOrder
from agent_comms.ui_model.hud_groups import (
    IdleGroup,
    InProgressGroup,
    ProblemsGroup,
    ReadyToTestGroup,
    UrgentGroup,
)
from agent_comms.ui_model.teammate_state import (
    AwaitingApplicationRun,
    Idle,
    Moving,
    NoPendingClock,
    PendingClock,
    Stuck,
)


def example_hud() -> TeamHud:
    """Controlled source example; no provider call or claim about the installed fleet."""
    order = TeamOrder(
        "P930", "Make the screen readable", OrderId("123456789abc"),
        "pending", OpenPrProgress(3589, "8636a6f28", at=1.0), (), 0, 0,
    )
    worker = Teammate(
        RecordedThreadIncarnation("screen", 2.0), Moving, NoPendingClock(),
        (order,), 0, (), (),
    )
    colleague = RecordedThreadIncarnation("colleague", 1.0)
    old = replace(RulePing.capture(ServicePassFailing(watch="source", since=900, error="read refused",
                                                      failed_at=900)),
                  since=RecordedEventTime(900))
    new = replace(RulePing.capture(ServicePassFailing(watch="review", since=1000, error="head needs review",
                                                      failed_at=1000)),
                  since=RecordedEventTime(1000))
    return TeamHud(
        teammate=colleague, units=(
            worker,
            replace(worker, unit=RecordedThreadIncarnation("blocked", 3.0), state=Stuck),
            replace(worker, unit=RecordedThreadIncarnation("run-next", 4.0), state=AwaitingApplicationRun),
            replace(worker, unit=RecordedThreadIncarnation("idle", 5.0), state=Idle, orders=()),
        ), phases=(), load=OverloadDegradation(3, 1, 2), forks=(),
        usage=CodexUsage(UnreadableUsage(reason="not requested in source example")),
        packets=(TeamDecisions(colleague, (old, new), (new,), (old,)),),
        heartbeat=RecordedEventTime(990), open_pings=(),
    )


def test_team_hud_projection_has_one_progress_answer() -> None:
    unit = example_hud().units[0]
    assert tuple(FieldCodec.projections(Teammate, HudExclude)) == ("work", "change", "next")
    columns = FieldCodec.view_columns(Teammate, HudExclude)
    assert tuple(column.name for column in columns) == ("unit", "state", "work", "change", "next")
    assert tuple(plan.name for plan in FieldCodec.field_plans(type(unit.unit))
                 if DisclosureIdentity.read(plan.annotation, False)) == ("name",)
    second = replace(unit.orders[0], problem="P931", order=OrderId("abcdef123456"))
    table = ViewTable(Teammate, HudExclude, (replace(unit, orders=(*unit.orders, second)),))
    assert "\n" in table.texts[0][2]


def test_shared_hud_groups_strip_full_alarms_and_plain_text() -> None:
    hud = example_hud()
    groups = hud.groups
    assert tuple(section.group for section in groups) == (
        ProblemsGroup, UrgentGroup, InProgressGroup, ReadyToTestGroup, IdleGroup,
    ), "problems lead the board"
    problems, *units = groups
    # One row per problem, naming every unit on it. Three of this example's units hold the
    # same order, which a card per holder would have shown three times.
    assert tuple((card.card.problem, card.held_by) for card in problems.records) == (
        ("P930", "screen, blocked, run-next"),
    )
    assert tuple(unit.unit.name for section in units for unit in section.records) == (
        "blocked", "screen", "run-next", "idle",
    )
    plain = hud.hud_text(1000)
    status = tuple(hud.status_strip(1000).splitlines())
    assert plain[:len(status)] == status
    assert "\x1b" not in "\n".join(plain)
    headings = [section.heading() for section in groups]
    assert [plain.index(heading) for heading in headings] == sorted(plain.index(heading) for heading in headings)
    assert "Teammate" not in "\n".join(plain)
    assert "\x1b[" in "\n".join(hud.hud_text(1000, colour=True))
    assert sum(len(section.pings) for section in hud.alarms) == len(hud.packets[0].handled)
    assert all(shows_every_word(ping, hud.alarm_text(hud.alarms, 1000))
               for ping in hud.packets[0].handled)
    assert hud.board == ()
    details = hud.alarm_detail(hud.alarms, 1000)
    assert all(section.heading() not in details for section in hud.alarms)
    assert all(ping.text in "\n".join(details) for ping in hud.packets[0].handled)
    for section in groups:
        for table in section.tables:
            layout = table.layout(60)
            narrow = "\n".join(layout.render_lines(layout.widths(60)))
            # Each record's own identity, asked of the record: a unit answers its name and
            # a problem answers its problem id, so this holds for every kind of row rather
            # than only the ones that happen to have a .unit.
            assert all(DisclosureText.describe(record).summary in narrow
                       for record in table.records)
    urgent, = (section for section in groups if section.group is UrgentGroup)
    assert tuple(unit.unit for unit in urgent.records) == (hud.units[1].unit,)


def test_display_facts_ignore_only_hidden_clocks_and_paint_time() -> None:
    hud = example_hud()
    unit = replace(hud.units[0], clock=PendingClock(1, 2))
    hud = replace(hud, units=(unit, *hud.units[1:]))
    later = replace(hud, units=(replace(unit, clock=PendingClock(1, 3)), *hud.units[1:]),
                    heartbeat=RecordedEventTime(999))
    assert hud.display_facts == later.display_facts
    assert hud.status_table(1000).facts == hud.status_table(1060).facts
    assert hud.display_facts != replace(hud, usage=CodexUsage(
        UnreadableUsage(reason="a different visible usage observation"))).display_facts
    assert hud.display_facts != replace(hud, units=(replace(unit, state=Stuck), *hud.units[1:])).display_facts


def test_disclosure_reuses_original_children_and_declared_identity() -> None:
    unit = example_hud().units[0]
    text = DisclosureText.describe(unit)
    assert isinstance(text, IdentifiedRecordText)
    assert text.summary == unit.unit.name
    original_unit = next(child for child in text.children if child.key == FieldKey(Teammate, "unit"))
    assert original_unit.value is text.identity_values[0]
    assert text.sequence_key == EntityKey(Teammate, (EntityKey(type(unit.unit), (unit.unit.name,)),))
    # Identity-only text still discloses every original field, including hidden HUD columns.
    assert tuple(child.key for child in text.children) == tuple(
        FieldKey(Teammate, plan.name) for plan in FieldCodec.field_plans(Teammate) if plan.records)
    assert next(child for child in text.children if child.key == FieldKey(Teammate, "strikes")).value.value == unit.strikes

    mapping = DisclosureText.describe({"units": (unit,)})
    assert isinstance(mapping, MappingText)
    sequence = mapping.children[0].value
    assert isinstance(sequence, SequenceText)
    assert sequence.children[0].key == text.sequence_key
    assert sequence.children[0].value.value is unit
    assert sequence.summary == "1 item"
    table = ViewTable(Teammate, HudExclude, (unit,))
    assert table.entities[text.sequence_key] is unit


def test_every_native_record_producer_declares_entity_identity() -> None:
    for declaration in HudRecord.__subclasses__():
        assert any(DisclosureIdentity.read(plan.annotation, False)
                   for plan in FieldCodec.field_plans(declaration)), declaration


def test_heartbeat_prints_every_alarm_with_watching_below_the_unit_tables() -> None:

    hud = example_hud()
    pings = hud.packets[0].handled
    hud.__dict__["alarms"] = (AlarmSection(NewAlarms, pings[:1]), AlarmSection(WatchingAlarms, pings[1:] or pings))
    plain = hud.hud_text(1000)
    new, watching = (plain.index(section.heading()) for section in hud.alarms)
    units = [plain.index(section.heading()) for section in hud.groups]
    assert new < min(units) and max(units) < watching
    assert all(shows_every_word(ping, plain) for ping in pings)


def shows_every_word(ping, lines: tuple[str, ...]) -> bool:
    """Folding moves shared words into the rule header; it never drops one."""
    shown = "\n".join(lines)
    return all(word in shown for word in ping.text.replace(" -> ", " ").split(" "))


def test_alarm_text_names_each_rule_once_above_all_of_its_rows() -> None:
    hud = example_hud()
    section = hud.alarms[0]
    lines = section.text_lines(1000)
    for kind, pings in section.by_kind().items():
        start = next(index for index, line in enumerate(lines)
                     if line.startswith(f"{kind.declared_name} · {len(pings)}"))
        rows = lines[start + 1:start + 1 + len(pings)]
        assert all(row.startswith("  ") for row in rows)
        assert all(shows_every_word(ping, (lines[start], *rows)) for ping in pings)
    assert "Kind:" not in "\n".join(lines)
    assert sum(len(pings) for pings in section.by_kind().values()) == len(section.pings)


def test_rows_of_one_rule_print_their_shared_words_once() -> None:
    ping = example_hud().packets[0].handled[0]
    texts = (
        "JUDGE openhcsdev/agent-comms#3766 29e260518 is sitting there unjudged. you read it yet?"
        " -> judge ok/back --repo openhcsdev/agent-comms --pr 3766 --head 29e2605180debb204a7c77ca4b8cf772f51091da",
        "JUDGE openhcsdev/toad#1375 31e3ca17e is sitting there unjudged. you read it yet?"
        " -> judge ok/back --repo openhcsdev/toad --pr 1375 --head 31e3ca17e0c61cd2b827afe0c66082e0da55756b",
    )
    pings = tuple(replace(ping, text=text) for text in texts)
    header, *rows = FoldedRule.of(ping.alarm_kind, pings).lines(1000)
    assert header.endswith(": JUDGE … is sitting there unjudged. you read it yet?"
                           " -> judge ok/back --repo REPO --pr PR --head HEAD")
    assert rows[0].startswith("  openhcsdev/agent-comms#3766 29e2605180debb204a7c77ca4b8cf772f51091da ·")
    assert all(shows_every_word(folded, (header, *rows)) for folded in pings)


def test_board_opens_with_what_is_owed_and_the_oldest_line() -> None:
    hud = example_hud()
    plain = hud.hud_text(1000)
    for section in hud.alarms:
        oldest = min(section.pings, key=lambda ping: ping.since.chronology())
        digest = section.digest(1000)
        assert digest in plain[:plain.index(section.heading())]
        assert oldest.since.age(1000) in digest
        assert all(f"{len(pings)} {kind.declared_name.replace('_', ' ')}" in digest
                   for kind, pings in section.by_kind().items())
