"""Native Pi arguments come from one declared default, or from the environment when set."""


from agent_comms.execution.native_arguments import (
    ConfiguredBinary,
    GivenArguments,
    InheritedArguments,
    NativeArguments,
)
from agent_comms.pi_vocabulary import OffThinkingLevel
from agent_comms.registry.thread_model import (
    DeclaredModel,
    ThreadModel,
)


def test_native_arguments_configured_has_one_default(monkeypatch):
    monkeypatch.delenv(NativeArguments.arguments_key, raising=False)
    monkeypatch.delenv(NativeArguments.binary_key, raising=False)
    assert ConfiguredBinary().configured() == NativeArguments.default_binary
    assert InheritedArguments().configured().argv == ()
    monkeypatch.setenv(NativeArguments.binary_key, "/fixture/pi")
    monkeypatch.setenv(NativeArguments.arguments_key, '--model "fixture/model" --thinking off')
    assert ConfiguredBinary().configured() == "/fixture/pi"
    assert ThreadModel.selected_by(InheritedArguments().configured()) == DeclaredModel("fixture/model")
    assert InheritedArguments().configured().thinking is OffThinkingLevel
    assert GivenArguments(()).configured().argv == ()


