"""Private snapshot boundary negatives, durability faults and process races."""

from __future__ import annotations

import os
import sqlite3
import subprocess
import sys

import pytest

import agent_comms.private_sidecar as sidecar
from agent_comms.coordination.errors import IdentityConflict
from agent_comms.execution.native_input_record import TriageNativeExecution, UnrecordedNativeColumn
from agent_comms.execution.native_prompt_binding import PromptBinding, PromptBindings
from agent_comms.nominal.field_codec import FieldCodec, InputId, RootId, ThreadLookup
from agent_comms.storage.maintenance_barrier import MaintenanceNotHeldError
from agent_comms.storage.typed_table import ReconciledFile
from conftest import maintenance_held


@pytest.fixture
def path(tmp_path):
    if os.name != "posix":
        pytest.skip("snapshot boundary requires POSIX descriptors")
    # Platforms may expose their temp root through /var -> /private/var.
    # Positive fixtures use a real lexical root; redirect negatives add aliases.
    tmp_path = tmp_path.resolve()
    tmp_path.chmod(0o700)
    return PromptBindings.path_in(tmp_path)


def _insert(db, key="1"):
    return PromptBinding(
        input_id=InputId(key * 32),
        stage=TriageNativeExecution,
        execution_id=UnrecordedNativeColumn(),
        attempt_ordinal=UnrecordedNativeColumn(),
        owner_lookup=FieldCodec.decode(ThreadLookup, "2" * 32),
        owner_generation=1,
        wire_root_id=FieldCodec.decode(RootId, "3" * 32),
        expected_prompt_digest="a" * 64,
        bound_at_ms=1,
    ).insert(db)


def test_declared_private_snapshot_carries_old_checks_without_changing_records(path):
    previous = PromptBindings.declared_schema().copy()
    column = PromptBinding._fields_named(("input_id",))[0]
    check = column.storage.constraints(column.wire_name, column.annotation)[0]
    previous[PromptBinding.declared_name] = previous[PromptBinding.declared_name].replace(
        f" CHECK ({check})", "", 1,
    )
    with sqlite3.connect(":memory:") as db:
        for statement in previous.values():
            db.execute(statement)
        sidecar.SnapshotMeta.for_schema(previous).insert(db)
        _insert(db)
        before = db.execute("SELECT * FROM prompt_binding").fetchall()
        db.commit()
        path.write_bytes(db.serialize())
        path.chmod(0o600)
    original = path.read_bytes()
    with pytest.raises(IdentityConflict), PromptBindings.connection_at(path):
        pytest.fail("an old schema reached a normal reader")
    with pytest.raises(MaintenanceNotHeldError):
        PromptBindings.reconcile_at(path)
    assert path.read_bytes() == original
    selected = ReconciledFile.existing_in(path.parent)[path]
    assert selected is PromptBindings
    with maintenance_held(path.parent):
        assert selected.reconcile_at(path)
        carried = path.read_bytes()
        assert not selected.reconcile_at(path)
        assert path.read_bytes() == carried
    with PromptBindings.connection_at(path, read_only=True) as db:
        assert [tuple(row) for row in db.execute("SELECT * FROM prompt_binding")] == before
    copied = path.with_name("copied.sqlite3")
    PromptBindings.copy_file(path, copied)
    with PromptBindings.connection_at(copied, read_only=True) as db:
        assert [tuple(row) for row in db.execute("SELECT * FROM prompt_binding")] == before
    sidecar.StoreOwner.snapshot_intent(path).write_text("uncertain", encoding="utf-8")
    with pytest.raises(sidecar.SidecarCommitUnknown):
        PromptBindings.copy_file(path, copied)
    with pytest.raises(sidecar.SidecarCommitUnknown):
        PromptBindings.reconcile_at(path)
    assert path.read_bytes() == carried


@pytest.mark.parametrize(
    "kind", ["symlink", "dangling", "hardlink", "fifo", "directory", "public", "empty"]
)
def test_invalid_leaf_never_mutates_external_target(path, kind):
    external = path.with_name("external.sqlite3")
    external.touch(mode=0o600)
    if kind == "symlink":
        path.symlink_to(external)
    elif kind == "dangling":
        path.symlink_to(path.with_name("missing"))
    elif kind == "hardlink":
        os.link(external, path)
    elif kind == "fifo":
        os.mkfifo(path, 0o600)
    elif kind == "directory":
        path.mkdir(mode=0o700)
    elif kind == "public":
        path.touch(mode=0o644)
    else:
        path.touch(mode=0o600)
    with pytest.raises((IdentityConflict, OSError)):
        PromptBindings.create_at(path)
    assert external.read_bytes() == b""
    assert not path.with_name("missing").exists()


@pytest.mark.parametrize("kind", ["file", "dangling", "directory", "fifo"])
def test_pending_intent_is_present_without_following_or_opening_it(path, kind):
    PromptBindings.create_at(path)
    before = path.read_bytes()
    intent = sidecar.StoreOwner.snapshot_intent(path)
    if kind == "file":
        intent.write_text("unresolved commit")
    elif kind == "dangling":
        intent.symlink_to(path.with_name("missing-intent-target"))
    elif kind == "directory":
        intent.mkdir()
    else:
        os.mkfifo(intent, 0o600)
    identity = intent.lstat()
    with pytest.raises(sidecar.SidecarCommitUnknown):
        with PromptBindings.connection_at(path):
            pytest.fail("a pending commit reached the database caller")
    assert path.read_bytes() == before
    assert intent.lstat() == identity
    assert not path.with_name("missing-intent-target").exists()


def test_symlink_ancestor_refused(path):
    directory = path.parent / "real"
    directory.mkdir(mode=0o700)
    link = path.parent / "alias"
    link.symlink_to(directory, target_is_directory=True)
    with pytest.raises((IdentityConflict, OSError)):
        PromptBindings.create_at(link / path.name)
    assert not (directory / path.name).exists()


@pytest.mark.parametrize(
    "sql",
    [
        "CREATE TRIGGER unrelated_insert_suppressor BEFORE INSERT ON prompt_binding "
        "BEGIN SELECT RAISE(IGNORE); END",
        "CREATE INDEX unrelated_index ON prompt_binding(owner_lookup)",
        "CREATE VIEW unrelated_view AS SELECT * FROM prompt_binding",
        "CREATE TABLE unrelated_table (x)",
        *(f'DROP TRIGGER "{name}"' for name in PromptBinding.triggers()),
    ],
)
def test_all_schema_objects_checked_independent_of_name(path, sql):
    PromptBindings.create_at(path)
    with sqlite3.connect(path) as db:
        db.execute(sql)
    before = path.read_bytes()
    with pytest.raises(IdentityConflict), PromptBindings.connection_at(path):
        pass
    with pytest.raises(IdentityConflict), PromptBindings.connection_at(path):
        pytest.fail("tampered schema reached caller")
    assert path.read_bytes() == before


@pytest.mark.parametrize("replacement", ["file", "symlink", "hardlink", "lock"])
def test_mid_scope_replacement_refuses_before_publish(path, replacement):
    PromptBindings.create_at(path)
    before = path.read_bytes()
    external = path.with_name("external.sqlite3")
    external.write_bytes(before)
    external.chmod(0o600)
    with pytest.raises(IdentityConflict), PromptBindings.connection_at(path) as db:
        _insert(db)
        if replacement == "lock":
            lock = path.with_name(f".{path.name}.snapshot-lock")
            lock.rename(lock.with_suffix(".old"))
            lock.touch(mode=0o600)
        else:
            path.rename(path.with_suffix(".old"))
            if replacement == "file":
                path.write_bytes(before)
                path.chmod(0o600)
            elif replacement == "symlink":
                path.symlink_to(external)
            else:
                os.link(external, path)
    assert external.read_bytes() == before
    assert not path.with_name(f".{path.name}.pending").exists()


def test_mutation_of_loaded_inode_refuses_before_publish(path):
    PromptBindings.create_at(path)
    with (
        pytest.raises(IdentityConflict),
        PromptBindings.connection_at(path) as db,
    ):
        _insert(db)
        with sqlite3.connect(path) as other:
            _insert(other, "4")
    with sqlite3.connect(path) as db:
        rows = db.execute("SELECT input_id FROM prompt_binding").fetchall()
    assert rows == [("4" * 32,)]


def test_schema_drift_during_scope_cannot_publish(path):
    PromptBindings.create_at(path)
    before = path.read_bytes()
    with pytest.raises(sqlite3.DatabaseError), PromptBindings.connection_at(path) as db:
        db.execute(
            "CREATE TRIGGER suppress BEFORE INSERT ON prompt_binding "
            "BEGIN SELECT RAISE(IGNORE); END"
        )
    assert path.read_bytes() == before


def test_drop_table_is_refused_before_schema_changes(path):
    PromptBindings.create_at(path)
    before = path.read_bytes()
    with pytest.raises(sqlite3.DatabaseError), PromptBindings.connection_at(path) as db:
        db.execute("DROP TABLE prompt_binding")
    assert path.read_bytes() == before


def test_mode_drift_and_connection_attachment_are_not_admitted(path):
    PromptBindings.create_at(path)
    before = path.read_bytes()
    with pytest.raises(IdentityConflict), PromptBindings.connection_at(path) as db:
        _insert(db)
        path.chmod(0o644)
    path.chmod(0o600)
    with (
        pytest.raises(sqlite3.DatabaseError),
        PromptBindings.connection_at(path) as db,
    ):
        db.execute("ATTACH ':memory:' AS other")
    assert path.read_bytes() == before


_WORKER = r"""
import os, signal, sys
from pathlib import Path
import agent_comms.private_sidecar as s
from agent_comms.execution.native_input_record import TriageNativeExecution, UnrecordedNativeColumn
from agent_comms.execution.native_prompt_binding import PromptBinding, PromptBindings
from agent_comms.nominal.field_codec import FieldCodec, InputId, RootId, ThreadLookup
p = Path(sys.argv[1])
print('READY', flush=True)
assert sys.stdin.readline() == 'GO\n'
PromptBindings.create_at(p)
if len(sys.argv) > 2:
    sync = os.fsync
    count = 0
    def crash(fd):
        global count
        sync(fd)
        count += 1
        if count == int(sys.argv[2]):
            os.kill(os.getpid(), signal.SIGKILL)
    s.os.fsync = crash
    with PromptBindings.connection_at(p) as db:
        PromptBinding(input_id=InputId('1'*32),stage=TriageNativeExecution,
            execution_id=UnrecordedNativeColumn(),attempt_ordinal=UnrecordedNativeColumn(),owner_lookup=FieldCodec.decode(ThreadLookup,'2'*32),
            owner_generation=1,wire_root_id=FieldCodec.decode(RootId,'3'*32),
            expected_prompt_digest='a'*64,
            bound_at_ms=1).insert(db)
print('OK', flush=True)
"""


def _worker(path, *extra):
    return subprocess.Popen(
        [sys.executable, "-u", "-c", _WORKER, str(path), *extra],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )


def test_two_process_installers_serialize_one_exact_schema(path):
    children = [_worker(path), _worker(path)]
    try:
        for child in children:
            assert child.stdout.readline() == "READY\n"
        for child in children:
            child.stdin.write("GO\n")
            child.stdin.flush()
        for child in children:
            stdout, stderr = child.communicate(timeout=10)
            assert child.returncode == 0, stderr
            assert stdout == "OK\n"
        with PromptBindings.connection_at(path):
            pass
    finally:
        for child in children:
            if child.poll() is None:
                child.kill()
            child.wait(timeout=10)


@pytest.mark.parametrize("cut", [3, 4])
def test_process_crash_before_or_after_replacement_leaves_unreplayable_intent(path, cut):
    PromptBindings.create_at(path)
    child = _worker(path, str(cut))
    try:
        assert child.stdout.readline() == "READY\n"
        stdout, stderr = child.communicate("GO\n", timeout=10)
        assert child.returncode < 0, stderr
        assert "OK" not in stdout
        with pytest.raises(sidecar.SidecarCommitUnknown):
            PromptBindings.create_at(path)
    finally:
        if child.poll() is None:
            child.kill()
        child.wait(timeout=10)


def test_a_verified_snapshot_is_checked_again_the_moment_its_bytes_change(path):
    """A remembered pass requires the same complete snapshot identity."""
    PromptBindings.create_at(path)
    with PromptBindings.connection_at(path) as db:
        _insert(db)
    with sqlite3.connect(path) as db:
        db.execute("CREATE TABLE unrelated_table (x)")
    with pytest.raises(IdentityConflict), PromptBindings.connection_at(path):
        pytest.fail("a changed snapshot reached the caller on a remembered pass")
