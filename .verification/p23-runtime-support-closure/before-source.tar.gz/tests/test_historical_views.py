"""Actual saved buses and transcripts, with colliding live/source sequences."""


import json
import os
from dataclasses import fields, replace
from pathlib import Path

import pytest

from agent_comms.bus import Bus, PublicRecord
from agent_comms.messaging.channel_targets import CommandTarget, ThreadTarget
from agent_comms.comms import wire
from agent_comms.coordination.errors import HistoricalSourceChanged, ReloadRequired
from agent_comms.execution.turn_item import FreshNativeId
from agent_comms.historical_views import (
    AllHistoricalSenders,
    HistoricalMessage,
    HistoricalSelection,
    HistoryArchive,
    HistorySource,
    NamedHistoricalSender,
)
from agent_comms.installer.backup import bus_files
from agent_comms.messaging.messages import Message
from agent_comms.messaging.message_page import (
    MessagePageRequest,
    PageBounds,
)
from agent_comms.messaging.read_ledger import ReadLedger
from agent_comms.nominal.field_codec import FieldCodec, InputId
from agent_comms.page_traversal import HistoryCursor
from agent_comms.projects.checkouts import Checkout
from agent_comms.messaging.read_basis import (
    AllChannelDisplayScope,
    ChannelConversation,
    ChannelSelection,
    ConversationCursor,
    DMSelection,
    NamedViewer,
    ReadCursor,
)
from agent_comms.registry.registration import Registration
from agent_comms.registry.threads import NativeThread, ThreadProvenance
from agent_comms.registry_provenance import RegistryProvenance
from agent_comms.routing import MessageRoute, TurnRouting
from agent_comms.session_file import RegistrySessionLocation
from agent_comms.storage.locked_store import LiveFilesRequest, RegistryFile
from agent_comms.storage.store_files import StoreOwner
from agent_comms.transcript_routes import DisplayText
from agent_comms.transcripts import (
    RecordedPageSource,
    RecordedTranscriptReadIdentity,
    TranscriptReadIdentity,
)
from agent_comms.transport.tools.reads import TranscriptPageRead
from test_locked_store import process
from test_transcript_pages import shared_page


@pytest.mark.parametrize('exists', [False, True])
def test_catalogue_creation_or_change_during_read_is_rejected(tmp_path, exists):
    archive = HistoryArchive.at(tmp_path)
    if exists:
        archive.path.write_text('[]')
    with pytest.raises(HistoricalSourceChanged):
        with archive.read_sources() as sources:
            assert sources == ()
            archive.path.write_text('[ ]')


def test_missing_catalogue_is_empty_without_creating_it(tmp_path):
    archive = HistoryArchive.at(tmp_path)
    assert archive.sources() == ()
    assert not archive.path.exists()


def setup(root, count=5):
    comms = wire(root)
    comms.registry.declare(NativeThread('alice', frozenset({'team'}), Checkout(root), created_at=10.0))
    comms.registry.declare(NativeThread('bob', frozenset({'team'}), Checkout(root), created_at=11.0))
    viewer = comms.messaging.user_identity(Checkout(root)).name
    for i in range(count):
        comms.messaging.send("alice", "#team", f"{root.name} channel {i}").message.message_id
        comms.messaging.send("alice", viewer, f"{root.name} direct {i}").message.message_id
    return comms


def collect(comms, method, *args, **kwargs):
    page = getattr(comms.views, method)(*args, bounds=PageBounds(limit=3), **kwargs)
    result = list(page.messages)
    for _ in range(40):
        if not page.has_older:
            return result
        page = getattr(comms.views, method)(*args, bounds=PageBounds(page.oldest_cursor.older(), 3), **kwargs)
        result[0:0] = page.messages
    raise AssertionError("paging did not terminate")


@pytest.fixture
def migrated(tmp_path):
    old = setup(tmp_path / "old")
    prior = setup(tmp_path / "prior", 2)
    live = setup(tmp_path / "live", 2)
    before = live.bus.bus.revision()
    source = live.views.attach_history(old.root)
    live.views.attach_history(prior.root)
    assert live.bus.bus.revision() == before
    return old, prior, live, source


@pytest.mark.parametrize(
    "method,args,reader",
    [
        ("channel_display_page", ("#team",), lambda live: dict(viewer=live.views.display_viewer(Checkout(live.root)))),
        ("dm_display_page", (ThreadTarget("alice"),), lambda live: dict(worktree=Checkout(live.root))),
        ("channel_display_page", ("#any",), lambda live: dict(viewer=live.views.display_viewer(Checkout(live.root)))),
    ],
)
def test_all_history_backward_and_forward(migrated, method, args, reader):
    old, prior, live, source = migrated
    scope = reader(live)
    rows = collect(live, method, *args, **scope)
    expected = 18 if args == ("#any",) else 9
    assert len(rows) == expected
    assert len({row.view_key for row in rows}) == expected
    assert len({row.seq for row in rows}) < expected
    assert rows == sorted(rows, key=lambda row: row.view_order)
    forward = []
    cursor = HistoryCursor(source=source.key, sequence=0)
    for _ in range(40):
        page = getattr(live.views, method)(*args, bounds=PageBounds(cursor.newer(), 2), **scope)
        forward.extend(page.messages)
        if not page.has_newer:
            break
        cursor = page.newest_cursor
    assert [m.view_key for m in forward] == [m.view_key for m in rows]


def test_original_identity_and_no_delivery_authority(migrated):
    old, prior, live, source = migrated
    rows = collect(live, "channel_display_page", "#team", viewer=live.views.display_viewer(Checkout(live.root)))
    historical = [m for m in rows if isinstance(m, HistoricalMessage) and m.source == source]
    original = list(old.views.history_page(CommandTarget.named("#team")).messages)
    assert [m.to_wire() for m in historical] == [Message.from_message(m).to_wire() for m in original]
    assert all(m.sender_created_at == 10.0 for m in historical)
    assert len(live.bus.inbox("bob").page.messages) == 2
    assert live.bus.bus.revision() == 4
    assert live.views.attach_history(old.root) == source
    assert len(live.bus.history.sources()) == 2


def test_sparse_historical_ack_does_not_ack_live(migrated):
    _, _, live, source = migrated
    viewer = live.messaging.user_identity(Checkout(live.root))
    page = live.views.channel_display_page(
        "#team", viewer=NamedViewer(live.messaging.user_identity(Checkout(live.root)).name),
        bounds=PageBounds(HistoryCursor(source=source.key, sequence=100).older(), 3),
    )
    live.views.mark_page_read(page.select([page.messages[1].seq]), worktree=Checkout(live.root))
    snapshot = live.registry.snapshot()
    assert ReadLedger.at(source.root).read().messages == {
        viewer.incarnation: ReadCursor({
            ChannelConversation('#team'): ConversationCursor(exceptions=(page.messages[1].seq,)),
        })
    }
    assert live.bus.reads.cursor(viewer.name, snapshot) == ReadCursor()
    assert live.bus.pending_count("bob", CommandTarget.named("#team")) == 2
    with pytest.raises(ValueError):
        live.views.mark_page_read(
            replace(page, selection=replace(page.selection, displayed=replace(
                page.selection.displayed,
                displayed=replace(page.selection.displayed.displayed, viewer_created_at=-9.0),
            ))), worktree=Checkout(live.root),
        )


@pytest.mark.parametrize("conversation", ["channel", "dm"])
@pytest.mark.parametrize("archived", [False, True])
def test_select_painted_page_keeps_its_source_with_attached_history(migrated, conversation, archived):
    _, _, live, source = migrated
    bounds = PageBounds(HistoryCursor(source=source.key, sequence=100).older(), 2) if archived else PageBounds(limit=2)
    if conversation == "channel":
        page = live.views.channel_display_page(
            "#team", viewer=live.views.display_viewer(Checkout(live.root)), bounds=bounds,
        )
    else:
        page = live.views.dm_display_page(ThreadTarget("alice"), worktree=Checkout(live.root), bounds=bounds)
    message = page.messages[-1]
    selected = page.select((message.seq,))
    assert selected.messages == (message,)
    assert selected.selection.history_revision == page.selection.history_revision
    if archived:
        assert isinstance(selected.selection, HistoricalSelection)
        assert selected.selection.displayed.source == source
    else:
        assert isinstance(selected.selection, (ChannelSelection, DMSelection))


def test_duplicate_and_newer_incarnations_sessions(tmp_path):
    old = setup(tmp_path / "old", 0)
    # Historical invalid-for-live alias timestamps must survive as evidence.
    # Author the recorded ambiguous namespace through the original typed store;
    # a raw registry overwrite would invalidate its private integrity guard.
    session = tmp_path / "saved.jsonl"
    native_id = InputId("a" * 32)
    records = [
        {"type": "session", "version": 3, "id": "saved", "timestamp": "2026-09-20T00:00:00Z"},
        {
            "type": "message",
            "timestamp": "2026-09-20T00:00:01Z",
            "id": "one",
            "message": {
                "role": "user",
                "inputId": native_id,
                "content": [{"type": "text", "text": "old question"}],
            },
        },
        {
            "type": "message",
            "timestamp": "2026-09-20T00:00:02Z",
            "id": "two",
            "message": {"role": "assistant", "content": [{"type": "text", "text": "old answer"}]},
        },
    ]
    session.write_text("".join(json.dumps(r) + "\n" for r in records))
    with old.registry.store.editing() as edit:
        edit.document.threads["bob"] = replace(edit.document.threads["bob"], created_at=10.0)
        edit.document.threads["alice"] = replace(edit.document.threads["alice"], session_file=RegistrySessionLocation.from_path(str(session), tmp_path))
        edit.commit()
    routing = TurnRouting(reply=MessageRoute("alice", ("#team",)))
    old.transcripts.routes.record(str(session), (FreshNativeId("two"),), routing)
    old.transcripts.routes.record_input_display(native_id, DisplayText("original owner question"))
    live = setup(tmp_path / "live", 0)
    newer = replace(live.registry.require("alice"), created_at=20.0)
    live.registry.unregister("alice")
    live.registry.remove("alice")
    live.registry.register(newer)
    source = live.views.attach_history(old.root)
    # Later source annotations cannot change the already attached snapshot.
    old.transcripts.routes.record(
        str(session), (FreshNativeId("two"),), TurnRouting(reply=MessageRoute("alice", ("#later",)))
    )
    declarations = {h.thread.name: h.thread for h in live.bus.history.threads(AllHistoricalSenders())}
    assert declarations["alice"].created_at == declarations["bob"].created_at == 10.0
    assert live.registry.require("alice").created_at == 20.0
    page = live.transcripts.capture_page_read("alice", page_source=RecordedPageSource(source.key)).read()
    (answer,) = (e for e in page.events if e.declared_name == "assistant")
    assert answer.text == "old answer"
    assert answer.routing == routing
    assert [e.text for e in page.events if e.declared_name == "user"] == [
        "original owner question"
    ]
    assert session.read_text() == "".join(json.dumps(r) + "\n" for r in records)


def test_stale_cursor_is_rejected(migrated):
    _, _, live, _ = migrated
    with pytest.raises(HistoricalSourceChanged):
        live.views.channel_display_page("#team", bounds=PageBounds(HistoryCursor(source="detached", sequence=2).older()))


def test_recorded_transcript_witness_roundtrip_keeps_original_namespace(tmp_path):

    old, live = setup(tmp_path / "old", 1), setup(tmp_path / "live", 0)
    native = tmp_path / "recorded.jsonl"
    native.write_text(json.dumps({"type": "message", "timestamp": "2026-09-20T00:00:01Z", "message": {
        "role": "assistant", "content": [{"type": "text", "text": "original recorded answer"}],
    }}) + "\n")
    old.threads.attach_session((attachment_owner := old.registry.require("alice")), str(native), process=attachment_owner.process_identity)
    old.registry.rename("alice", "recorded-alice")
    replacement = replace(live.registry.require("alice"), created_at=20.0)
    live.registry.unregister("alice")
    live.registry.remove("alice")
    live.registry.register(replacement)
    source = live.views.attach_history(old.root)
    original_registry = (old.root / "registry.json").read_bytes()
    original_native = native.read_bytes()

    read = live.transcripts.capture_page_read("alice", page_source=RecordedPageSource(source.key))
    assert isinstance(read.identity, RecordedTranscriptReadIdentity)
    assert read.identity.thread.incarnation == old.registry.require("recorded-alice").incarnation
    decoded = FieldCodec.decode(TranscriptReadIdentity, FieldCodec.encode(read.identity))
    assert decoded == read.identity
    assert set(TranscriptReadIdentity.names()) == {"live", "recorded"}
    assert FieldCodec.value_schema(type[TranscriptReadIdentity])["enum"] == list(TranscriptReadIdentity.names())
    with pytest.raises(ValueError):
        FieldCodec.decode(TranscriptReadIdentity, {**FieldCodec.encode(read.identity), "kind": "unregistered"})

    recorded = shared_page(live, TranscriptPageRead(thread="alice", page_source=RecordedPageSource(source.key)))
    assert recorded.identity == read.identity
    assert any(event.text == "original recorded answer" for event in recorded.page.events)
    rebound = live.transcripts.bind_page_read("recorded-alice", decoded)
    assert rebound.current_identity() == decoded
    assert any(event.text == "original recorded answer" for event in rebound.read().events)
    delivered = []
    decoded.publish_turn(lambda root, thread: delivered.append((root, thread)))
    assert delivered == []
    live_identity = live.transcripts.capture_page_read("alice").identity
    live_identity.publish_turn(lambda root, thread: delivered.append((root, thread)))
    assert delivered == [(str(live.root), live.registry.require("alice"))]
    assert (old.root / "registry.json").read_bytes() == original_registry
    assert native.read_bytes() == original_native




def test_detached_recorded_witness_cannot_rebind_to_same_name_live_thread(migrated):

    _old, _prior, live, source = migrated
    read = live.transcripts.capture_page_read("alice", page_source=RecordedPageSource(source.key))
    with pytest.raises(ReloadRequired):
        live.transcripts.bind_page_read("bob", read.identity)
    live.bus.history.path.write_text("[]")
    with pytest.raises(HistoricalSourceChanged):
        read.current_identity()
    with pytest.raises(HistoricalSourceChanged):
        live.transcripts.bind_page_read("alice", read.identity)


def test_normal_comms_api_contains_history_and_execution_stays_live(migrated):
    _, _, live, _ = migrated
    viewer = NamedViewer(live.messaging.user_identity(Checkout(live.root)).name)
    assert len(collect(live, "history_page", CommandTarget.named("#team"))) == 9
    assert len(collect(live, "history_page", CommandTarget.named("alice"), viewer=viewer)) == 9
    assert len(collect(live, "history_page", CommandTarget.named("#any"))) == 18
    for message in collect(live, "history_page", CommandTarget.named("#any")):
        if isinstance(message, HistoricalMessage):
            assert not message.role.response_policy(message).starts_turn
            assert not message.role.response_policy(message).starts_turn_for(message, "bob")
            assert message.display_metadata["history"]["source"] == message.source.original_root
    assert len(MessagePageRequest(AllChannelDisplayScope('#any')).read_opened(
        live.bus.bus).messages) == 4


def root_bytes(root: Path) -> dict[Path, bytes]:
    """The bytes of every member the backup owner records for this root."""
    return {path: (root / path).read_bytes()
            for members in bus_files(LiveFilesRequest(root)).values() for path in members}


def test_attach_only_reads_original_roots_and_rejects_changed_snapshot(tmp_path):
    old = setup(tmp_path / "old")
    (old.root / "unknown-input.json").write_text('{"verdict":"UNKNOWN"}')
    original = root_bytes(old.root)
    live = setup(tmp_path / "live", 1)
    source = live.views.attach_history(old.root)
    assert root_bytes(old.root) == original
    assert not (Path(source.root) / "unknown-input.json").exists()
    page = live.views.channel_display_page(
        "#team", viewer=NamedViewer(live.messaging.user_identity(Checkout(live.root)).name),
        bounds=PageBounds(HistoryCursor(source=source.key, sequence=100).older()),
    )
    archived = Bus(Bus.path_in(Path(source.root)))
    original = page.messages[0]
    archived.append(lambda seq, db: PublicRecord.from_message(Message(
        original.sender, original.target, "external archive mutation", original.type, seq=seq)))
    with pytest.raises(ValueError):
        live.views.mark_page_read(page, worktree=Checkout(live.root))
    with pytest.raises(ValueError):
        live.views.channel_display_page(
            "#team", bounds=PageBounds(HistoryCursor(source=source.key, sequence=100).older())
        )


def test_older_than_registry_incarnation_stays_unattributed(migrated):
    _, _, live, source = migrated
    original = MessagePageRequest(AllChannelDisplayScope('#any')).read_opened(
        live.bus.bus).messages[0]
    projected = HistoricalMessage.project(
        replace(original, timestamp=1.0), source, 0, source.provenance
    )
    assert projected.sender_created_at is None
    assert projected.timestamp == 1.0


def test_missing_historical_peer_is_browsable_without_live_registration(migrated):
    _, _, live, source = migrated
    live.registry.unregister("alice")
    live.registry.remove("alice")
    page = live.views.dm_display_page(ThreadTarget("alice"), worktree=Checkout(live.root))
    assert page.messages
    assert all(isinstance(message, HistoricalMessage) for message in page.messages)
    assert "alice" not in live.registry


def test_historical_namespace_has_recorded_provenance_and_no_live_authority(migrated):


    old, _, live, source = migrated
    recorded = source.provenance.require("alice")
    assert type(recorded) is ThreadProvenance
    assert recorded.incarnation == old.registry.require("alice").incarnation
    assert set(FieldCodec.encode(recorded)) == {
        item.name for item in fields(ThreadProvenance) if item.init and item.name != 'backend'
    }
    # Required creation is parsed before any constructor clock/default can run.
    raw = FieldCodec.encode(recorded)
    raw.pop("created_at")
    with pytest.raises(ValueError):
        FieldCodec.decode(ThreadProvenance, raw)
    # Original finite historical timestamps are preserved, never synthesized.
    zero = replace(recorded, created_at=0.0)
    archived_zero = RegistryProvenance(threads={zero.name: zero}, aliases={})
    assert FieldCodec.decode(RegistryProvenance, FieldCodec.encode(archived_zero)) == archived_zero
    aliased = RegistryProvenance(threads={"alice": recorded}, aliases={"original-alice": "alice"})
    assert aliased.require("original-alice") is recorded
    with pytest.raises(ValueError):
        FieldCodec.decode(ThreadProvenance, {**FieldCodec.encode(recorded), "active_turn": None})
    # Source identity is separate from today's live owner, including renames.
    before = FieldCodec.encode(source.provenance)
    live.registry.rename("alice", "new-alice")
    assert FieldCodec.encode(source.provenance) == before
    assert live.bus.history.threads(NamedHistoricalSender("alice"))



def _attach_preserved_source(destination: Path, original: Path) -> None:
    HistoryArchive.at(destination).attach(original)


def test_snapshot_preparation_allows_another_process_to_attach_and_keeps_both_sources(tmp_path):

    old = setup(tmp_path / "old")
    other = setup(tmp_path / "other")
    live = setup(tmp_path / "live", 0)
    before = root_bytes(old.root), root_bytes(other.root)

    class ConcurrentSource(HistorySource):
        def retain(self, destination):
            assert destination not in HistoryArchive.archived_roots(live.root)
            with process(_attach_preserved_source, live.root, other.root):
                pass
            return super().retain(destination)

    source = live.bus.history.attach(old.root, source_read=ConcurrentSource.capture_original(old.root))
    sources = live.bus.history.sources()
    assert {item.original_root for item in sources} == {str(old.root), str(other.root)}
    assert len(sources) == 2 and source in sources
    for item in sources:
        item.validate()
        assert Path(item.root).parent == HistoryArchive.archive_directory(live.root)
    assert not any(StoreOwner.is_staging(path) for path in HistoryArchive.archive_directory(live.root).iterdir())
    assert (root_bytes(old.root), root_bytes(other.root)) == before


def test_uncertain_catalog_publication_preserves_the_promoted_snapshot(tmp_path, monkeypatch):
    old = setup(tmp_path / "old")
    live = setup(tmp_path / "live", 0)
    archive = live.bus.history
    before = root_bytes(old.root)
    replace_file = os.replace

    def uncertain_replace(source, destination, *args, **kwargs):
        replace_file(source, destination, *args, **kwargs)
        if Path(destination) == archive.path:
            raise OSError("catalog publication acknowledgement lost")

    monkeypatch.setattr(os, "replace", uncertain_replace)
    with pytest.raises(OSError, match="acknowledgement lost"):
        archive.attach(old.root)
    assert archive.sources() == ()
    retained, = archive.archived_roots(live.root)
    assert Bus(Bus.path_in(retained)).revision() == old.bus.bus.revision()
    assert Registration(RegistryFile.path_in(retained)).snapshot().threads.keys() == old.registry.snapshot().threads.keys()
    assert not any(StoreOwner.is_staging(path) for path in HistoryArchive.archive_directory(live.root).iterdir())
    assert root_bytes(old.root) == before
