"""The observed empty native1011 response retains typed stage without send inference."""

import copy
import json
from pathlib import Path

import pytest
from acp import RequestError

from agent_comms.acp_extension import RequestFailedUpdate, decode_updates, encode_updates
from agent_comms.acp_failure import (
    ACPFailure,
    ProviderConnectionFailure,
    RequestACPFailure,
    RequestFailure,
)
from agent_comms.execution.turn_failure import (
    ModelRequestFailed,
    ProviderTransportFailed,
    RetryableProviderFailure,
)
from agent_comms.input_attempt import StartedInput
from agent_comms.pi_counts import PiCount
from agent_comms.pi_events import MessageEnd
from agent_comms.pi_payloads import (
    AfterMessageStreamStartStage,
    CodedProviderDiagnosticError,
    CodelessProviderDiagnosticError,
    RequestBytes,
    UnrecognizedTransportStage,
)
from agent_comms.pi_rpc import PiRpcChannel
from agent_comms.pi_vocabulary import ErrorStopReason

FIXTURE = Path(__file__).with_name("fixtures") / "native_provider_transport_1011.json"


def observed():
    return json.loads(FIXTURE.read_text())


def test_observed_native_failure_preserves_stage_and_no_content_assumptions():
    event = PiRpcChannel.decode_record(FIXTURE.read_bytes(), strict=True)
    assert isinstance(event, MessageEnd)
    assert event.message.parts == ()
    assert event.message.stop_reason is ErrorStopReason
    assert event.message.usage.total_tokens == PiCount.from_wire(0)
    (diagnostic,) = event.message.diagnostics
    assert type(diagnostic.error) is CodedProviderDiagnosticError
    assert diagnostic.error.description == "WebSocketCloseError (code 1011)"
    assert diagnostic.error.code == 1011
    assert diagnostic.details.request_bytes == RequestBytes(159312)
    assert isinstance(diagnostic.details.phase, AfterMessageStreamStartStage)
    failure = ACPFailure.from_detail(
        -32603, event.message.error_message.value_or(""), diagnostics=event.message.diagnostics
    )
    assert isinstance(failure, ProviderConnectionFailure)
    assert failure.input_state is None
    assert decode_updates(encode_updates(RequestFailedUpdate(failure)))[0].failure == failure


def test_structured_started_remains_started_and_no_text_changes_it():
    record = observed()["message"]
    failure = RequestFailure.from_error(RequestError(
        -32603,
        record["errorMessage"],
        {
            "inputStatus": "started",
            "diagnostics": record["diagnostics"],
        },
    )).failure
    assert isinstance(failure, ProviderConnectionFailure)
    assert failure.input_state is StartedInput
    bare = RequestFailure.from_error(RequestError(
        -32603, "WebSocket closed1011 after start; original remains unbound"
    )).failure
    assert isinstance(bare, RequestACPFailure)
    assert bare.input_state is None


@pytest.mark.parametrize(
    "field,value", [("eventsEmitted", 1), ("requestBytes", True), ("requestBytes", -1)]
)
def test_malformed_native_diagnostic_is_rejected_at_existing_boundary(field, value):
    record = observed()
    record["message"]["diagnostics"][0]["details"][field] = value
    with pytest.raises(ValueError):
        PiRpcChannel.decode_record((json.dumps(record) + "\n").encode(), strict=True)


def test_unrecognized_phase_is_a_typed_observation_not_a_send_decision():
    record = copy.deepcopy(observed())
    record["message"]["diagnostics"][0]["details"]["phase"] = "future_native_stage"
    event = PiRpcChannel.decode_record((json.dumps(record) + "\n").encode(), strict=True)
    (diagnostic,) = event.message.diagnostics
    assert isinstance(diagnostic.details.phase, UnrecognizedTransportStage)
    failure = ACPFailure.from_detail(
        -32603, event.message.error_message.value_or(""), diagnostics=event.message.diagnostics
    )
    assert failure.input_state is None


def test_native_1006_decodes_code_without_parsing_error_prose():
    record = observed()
    record["message"]["diagnostics"][0]["error"].update(
        code=1006, message="Opaque native close"
    )
    record["message"]["errorMessage"] = "Unrelated prose with no close code"
    event = PiRpcChannel.decode_record((json.dumps(record) + "\n").encode(), strict=True)
    diagnostic, = event.message.diagnostics
    assert diagnostic.error.code == 1006
    failure = ModelRequestFailed.from_diagnostics(
        event.message.error_message.value_or(""), event.message.diagnostics
    )
    assert isinstance(failure, ProviderTransportFailed)
    assert isinstance(failure, RetryableProviderFailure)


def test_native_close_without_code_uses_the_declared_codeless_state():
    record = observed()
    del record["message"]["diagnostics"][0]["error"]["code"]
    event = PiRpcChannel.decode_record((json.dumps(record) + "\n").encode(), strict=True)
    diagnostic, = event.message.diagnostics
    assert isinstance(diagnostic.error, CodelessProviderDiagnosticError)
    assert diagnostic.error.description == "WebSocketCloseError"
    assert "code" not in diagnostic.error.to_wire()


@pytest.mark.parametrize("code", [None, True, {}])
def test_present_malformed_code_is_not_treated_as_codeless(code):
    record = observed()
    record["message"]["diagnostics"][0]["error"]["code"] = code
    with pytest.raises(ValueError):
        PiRpcChannel.decode_record((json.dumps(record) + "\n").encode(), strict=True)


def test_error_prose_does_not_invent_a_close_diagnostic():
    record = observed()
    del record["message"]["diagnostics"]
    record["message"]["errorMessage"] = "WebSocket closed 1006"
    event = PiRpcChannel.decode_record((json.dumps(record) + "\n").encode(), strict=True)
    assert event.message.diagnostics == ()


def test_native_1012_with_empty_thinking_reaches_provider_feedback():
    """The observed comms428 terminal must survive RPC and ACP publication."""
    record = observed()
    message = record["message"]
    message["content"] = [{"type": "thinking", "thinking": ""}]
    message["errorMessage"] = "WebSocket closed 1012"
    diagnostic = message["diagnostics"][0]
    diagnostic["error"]["code"] = 1012
    diagnostic["error"]["message"] = message["errorMessage"]
    diagnostic["details"]["requestBytes"] = 1565058
    event = PiRpcChannel.decode_record((json.dumps(record) + "\n").encode(), strict=True)
    assert event.message.stop_reason is ErrorStopReason
    failure = RequestFailure.from_error(
        RequestError(-32603, event.message.error_message.value_or(""), {
            "inputStatus": "started", "diagnostics": message["diagnostics"],
        }),
    ).failure
    assert isinstance(failure, ProviderConnectionFailure)
    assert failure.input_state is StartedInput
    assert decode_updates(encode_updates(RequestFailedUpdate(failure)))[0].failure == failure
