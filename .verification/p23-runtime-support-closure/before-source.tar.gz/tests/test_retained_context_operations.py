import sys

"""One original human-source workflow through the public CLI and file effects."""
import json
from pathlib import Path

import pytest

from agent_comms.messaging.channel_targets import CommandTarget
from agent_comms.cli import CliInvocation
from agent_comms.cli_commands import ConstraintPinnedResult
from agent_comms.context_segments.retained import RetainedSegment
from agent_comms.execution.turn_lease import NoTurnLease
from agent_comms.input_key import AcpInputKey
from agent_comms.lifecycle_capability import Unresolved
from agent_comms.nominal.field_codec import FieldCodec, GoalId, InputId
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import NativeThread
from agent_comms.session_file import RegistrySessionLocation
from bus_history import read_history
from stored_inputs import stored_inputs

ORIGINAL_UNKNOWN_KEY = AcpInputKey(InputId.mint())


pytestmark = pytest.mark.usefixtures("durable_home")


def test_original_retained_source_narrow_export(comms, tmp_path, capsys):
    """Export carries only the pinned human constraint; it neither admits nor rewrites facts."""
    original_goal_id = GoalId.mint()
    import hashlib

    from agent_comms.input_disposition import InputDispositions
    from agent_comms.planning.goals import Goal
    from test_task_decisions import saved_source

    saved = tmp_path / "original.jsonl"
    saved_source(saved)
    goal = Goal("Original task goal, not an exported human constraint", original_goal_id,
        published_seq=0, revision=7)
    owner = comms.registry.declare(NativeThread('reader', frozenset(), Checkout(tmp_path), session_file=RegistrySessionLocation.from_path(str(saved), comms.root), goal=goal))
    wording = "Original human constraint λ; preserve UNKNOWN and its source."
    original = comms.messaging.send_user_message(CommandTarget.named(owner.name), wording, worktree=owner.worktree)
    comms.messaging.pin_user_constraint(owner.name, original.reference, worktree=owner.worktree)
    inputs = InputDispositions(comms.root)
    inputs.record(ORIGINAL_UNKNOWN_KEY, seq=None, owner=owner.name, claim_scope=1,
                  target=owner.name, text="Unpinned original UNKNOWN input; never export/replay")

    def command(*args):
        code = CliInvocation().invoke(["--root", str(comms.root), *args], sys.stdout)
        return code, json.loads(capsys.readouterr().out)

    protected = (saved, inputs.path, comms.registry.store.path)
    hashes = {file: hashlib.sha256(file.read_bytes()).hexdigest() for file in protected}
    original_history = read_history(comms)
    destination = tmp_path / "authored-export.md"
    code, exported = command("export-retained", owner.name, "--output", str(destination))
    assert code == 0 and exported["exported_messages"] == 1
    text = destination.read_text()
    assert wording in text and goal.text not in text
    assert "Unpinned original UNKNOWN input" not in text
    assert all(hashlib.sha256(file.read_bytes()).hexdigest() == digest for file, digest in hashes.items())
    assert read_history(comms) == original_history


def test_original_human_pin_revision_drop_and_atomic_export(comms, capsys):
    owner = comms.registry.declare(NativeThread('recipient', frozenset(), Checkout(comms.root)))
    other = comms.registry.declare(NativeThread('unaddressed', frozenset(), Checkout(comms.root)))
    wording = "Never replay UNKNOWN.\nPreserve exact λ /source/owned bytes."
    original = comms.messaging.send_user_message(CommandTarget.named(owner.name), wording, worktree=owner.worktree)
    original_prefix = read_history(comms)

    def command(*args):
        code = CliInvocation().invoke(["--root", str(comms.root), *args], sys.stdout)
        return code, json.loads(capsys.readouterr().out)

    def reference(ref):
        return f"{ref['seq']}:{ref['message_id']}"

    source = reference(FieldCodec.encode(original.reference))
    code, pinned = command("pin-constraint", owner.name, "--source", source,
                           "--worktree", str(owner.worktree))
    assert code == 0
    pin = reference(pinned["pin"])
    snapshot = comms.views.retained_context(owner.name)
    assert FieldCodec.decode(RetainedSegment, FieldCodec.encode(snapshot)) == snapshot
    assert snapshot.text().count(wording.replace("\n", "\\n")) == 1
    assert comms.registry.require(owner.name).turn_lease == NoTurnLease()

    destination = comms.root / "AGENTS-export.md"
    code, exported = command("export-retained", owner.name, "--output", str(destination))
    assert code == 0 and exported["exported_messages"] == 1
    artifact = destination.read_bytes()
    assert artifact.count(wording.encode()) == 1 and source.split(":")[1].encode() in artifact
    assert b'"author":"user"' in artifact and b'"author_role":"user"' in artifact
    assert b'"human_constraint_pin"' in artifact
    code, refused = command("export-retained", owner.name, "--output", str(destination))
    assert code == 1 and destination.read_bytes() == artifact
    assert not list(comms.root.glob(".AGENTS-export.md.*.tmp"))
    before_refusal = read_history(comms)
    code, refused = command("pin-constraint", other.name, "--source", source,
                            "--worktree", str(other.worktree))
    assert code == 1 and "did not receive" in refused["error"]
    assert read_history(comms) == before_refusal
    code, empty = command("export-retained", other.name, "--output", str(comms.root / "other.md"))
    assert code == 0 and empty["exported_messages"] == 0
    assert wording.encode() not in (comms.root / "other.md").read_bytes()

    replacement = "Keep only the human's corrected /source/new instruction."
    code, revised = command("supersede-constraint", owner.name, "--source", pin,
                            "--body", replacement, "--worktree", str(owner.worktree))
    assert code == 0
    code, exported = command("export-retained", owner.name, "--output", str(destination), "--overwrite")
    assert code == 0 and exported["exported_messages"] == 1
    assert replacement in destination.read_text() and wording not in destination.read_text()
    assert snapshot.text().count(wording.replace("\n", "\\n")) == 1
    current = comms.views.retained_context(owner.name)
    assert wording.replace("\n", "\\n") in current.text() and replacement in current.text()
    code, dropped = command("drop-constraint", owner.name, "--source", pin,
                            "--worktree", str(owner.worktree))
    assert code == 0
    code, exported = command("export-retained", owner.name, "--output", str(destination), "--overwrite")
    assert code == 0 and exported["exported_messages"] == 0
    assert replacement not in destination.read_text()
    assert read_history(comms)[:len(original_prefix)] == original_prefix
    assert comms.registry.require(owner.name).turn_lease == NoTurnLease()

    # No semantic sidecar is needed for a new Comms instance to read the result.
    from agent_comms.comms import wire

    reopened = wire(comms.root)
    restored = reopened.views.retained_context(owner.name)
    assert restored.text() == comms.views.retained_context(owner.name).text()


async def original_input_consumer_journey(tmp_path, command):
    """Reuse the original ACP reservation fixture; never dispatch its inputs."""
    from agent_comms.queued_input import QueuedInput
    from agent_comms.retained_task_facts import InputTaskFact
    from test_acp_queue_contract import _owner
    from test_current_input_origin import Client, capture

    comms, agent, _, _ = _owner(tmp_path)
    origin = capture(comms)
    wording = "Never replay UNKNOWN.\nPreserve original λ /source/owned bytes."
    originals = []
    for _ in range(2):
        async with QueuedInput.reserve(
            agent.inputs, "beta", "beta", text=wording, prompt=wording, echo=True,
            images=(), controller=Client(), origin=origin,
         input_id=InputId.mint()) as reservation:
            originals.append(reservation.source)
            reservation.release()
    assert agent.inputs.dispositions.record(
        AcpInputKey(InputId.mint()), seq=None, owner="beta",
        claim_scope=origin.claimed_identity.claimed_generation, target="beta", text=wording)
    inputs = agent.inputs.dispositions
    original_inputs = inputs.path.read_bytes()
    other = comms.registry.declare(NativeThread('unaddressed', frozenset(), Checkout(Path(origin.project))))

    def invoke(*args):
        result = command(comms.root, args)
        assert inputs.path.read_bytes() == original_inputs
        assert comms.registry.require("beta").turn_lease == NoTurnLease()
        return result

    def reference(ref):
        return f"{ref['seq']}:{ref['message_id']}"

    pins = []
    for row in (originals[0], originals[0], originals[1]):
        code, result = invoke("pin-input-constraint", "beta", "--source", str(row.key),
                              "--worktree", str(origin.project))
        assert code == 0
        pinned = FieldCodec.decode(ConstraintPinnedResult, result)
        assert pinned.source == row.context_provenance()
        pins.append(reference(result["pin"]))
    snapshot = comms.views.retained_context("beta")
    assert FieldCodec.decode(RetainedSegment, FieldCodec.encode(snapshot)) == snapshot
    # Distinct original human inputs retain equal wording twice; neutral
    # delivery evidence cannot decide that they are one human instruction.
    retained_inputs = [fact.source for fact in snapshot.retained.facts
                       if isinstance(fact, InputTaskFact)]
    assert sorted(
        (row.key for row in retained_inputs if row.source_text == wording), key=str,
    ) == sorted((row.key for row in originals), key=str)
    assert all(row.context_provenance() in snapshot.provenance for row in originals)

    destination = comms.root / "original-input-context.md"
    code, result = invoke("export-retained", "beta", "--output", str(destination))
    assert code == 0 and result["exported_messages"] == 2
    artifact = destination.read_bytes()
    assert artifact.count(wording.encode()) == 2
    assert all(str(row.key).encode() in artifact for row in originals)
    assert b'"author":"user"' in artifact and b'"author_role":"user"' in artifact
    code, _ = invoke("export-retained", "beta", "--output", str(destination))
    assert code == 1 and destination.read_bytes() == artifact
    before_refusal = read_history(comms)
    for recipient, key in ((other.name, originals[0].key), ("beta", "absent"),
                           ("beta", "neutral-original")):
        code, _ = invoke("pin-input-constraint", recipient, "--source", str(key),
                         "--worktree", str(origin.project))
        assert code == 1
        assert read_history(comms) == before_refusal

    comms.registry.rename("beta", "renamed-beta")

    def renamed(*args):
        result = command(comms.root, args)
        assert inputs.path.read_bytes() == original_inputs
        assert comms.registry.require("renamed-beta").turn_lease == NoTurnLease()
        return result

    code, result = renamed("export-retained", "renamed-beta", "--output", str(destination),
                           "--overwrite")
    assert code == 0 and result["exported_messages"] == 2
    replacement = "Keep only the human's corrected original instruction."
    code, _ = renamed("supersede-constraint", "renamed-beta", "--source", pins[1],
                      "--body", replacement, "--worktree", str(origin.project))
    assert code == 0
    code, result = renamed("export-retained", "renamed-beta", "--output", str(destination),
                           "--overwrite")
    assert code == 0 and result["exported_messages"] == 2
    assert destination.read_text().count(wording) == 1
    assert replacement in destination.read_text()
    code, _ = renamed("drop-constraint", "renamed-beta", "--source", pins[2],
                      "--worktree", str(origin.project))
    assert code == 0
    code, result = renamed("export-retained", "renamed-beta", "--output", str(destination),
                           "--overwrite")
    assert code == 0 and result["exported_messages"] == 1
    assert wording not in destination.read_text() and replacement in destination.read_text()
    assert snapshot.retained.original_text_source(snapshot.retained.current_authored_sources(
        comms.registry.require("renamed-beta"), comms.registry.snapshot())[0].reference) == originals[0]
    from agent_comms.comms import wire
    reopened = wire(comms.root)
    assert reopened.views.retained_context("renamed-beta").text() == (
        comms.views.retained_context("renamed-beta").text())
    assert all(stored_inputs(inputs.root).lookup(row.key) == row and bool(row.items_with(Unresolved, True)) for row in originals)
    return {"original_inputs": 2, "distinct_equal_wording": True, "pins": 3,
            "refusals": 4, "rename_correction_drop_reopen": True,
            "original_input_bytes_preserved": True, "native_inputs": 0,
            "provider_calls": 0, "public_changes": []}


async def test_original_input_pin_query_export_correction_and_drop(tmp_path, capsys):
    def command(root, args):
        code = CliInvocation().invoke(["--root", str(root), *args], sys.stdout)
        return code, json.loads(capsys.readouterr().out)

    await original_input_consumer_journey(tmp_path, command)
