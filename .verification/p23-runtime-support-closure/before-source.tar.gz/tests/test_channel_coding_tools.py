"""Normal coding policies use existing claims; no provider or user work is touched."""


import json
import os
import secrets
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

import pytest

from agent_comms.channel_coding_tools import CodingToolSocket
from agent_comms.comms import wire
from agent_comms.coordination.session import NativeCapture
from agent_comms.envelope_claim_transitions import (
    ClaimConflict,
    ClaimTransitionError,
    ExistingFileClaim,
    NativeClaim,
    WritableFileClaim,
)
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.nominal.field_codec import ClaimId, InputId, TurnId
from agent_comms.pi_events import ToolExecutionEnd, ToolExecutionStart
from agent_comms.pi_payloads import (
    AssistantMessage,
    ReportedFlag,
    ReportedParts,
    ReportedText,
    ToolCallContent,
)
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import NativeThread
from agent_comms.storage_room import NoRoomNeeded
from agent_comms.transport.native_tools import CodingTool, NativeToolDeclaration
from coding_owner_fixture import OwnerDouble


def acquire(comms, name, turn_id, resource, work):
    """Publish one claim for a declared owner's turn, as a native tool call would."""
    with NativeCapture(comms.bus) as boundary:
        owner = boundary.registry.require(name)
        scope = NativeClaim(
            owner_claimed_generation=boundary.registry.claim_generation(name),
            operation_id=ClaimId.mint(), turn_id=turn_id, input_id=InputId.mint(),
        )
        return comms.bus.publisher._publish_acquisition_unlocked(
            boundary.registry, owner, resource.normalized(work), scope, activity=boundary.activity,
        )


def test_create_claim_competes_before_file_exists_and_releases_without_creation():
    with TemporaryDirectory(prefix="comms-create-claim-", dir="/var/tmp") as directory:
        root = Path(directory) / "wire"
        root.mkdir(mode=0o700)
        work = Path(directory) / "work"
        work.mkdir()
        c = wire(root)
        turns = {}
        for name, created in [("a", 21.0), ("b", 22.0)]:
            turns[name] = TurnId.mint()
            thread = NativeThread(name, frozenset({'team'}), Checkout(work), created_at=created)
            c.registry.declare(replace(thread, process_identity=ProcessIdentity.capture(os.getpid())))
        resource = WritableFileClaim(Path("new/nested/file.py"))
        committed = acquire(c, "a", turns["a"], resource, work)
        assert not (work / "new").exists()
        assert c.bus.bus.claim_projection()[str(work / "new/nested/file.py")].seq == committed.seq
        with pytest.raises(ClaimConflict):
            acquire(c, "b", turns["b"], resource, work)
        with NativeCapture(c.bus) as boundary:
            c.bus.publisher.release_resources(boundary, (committed,), "Release unused creation")
        assert acquire(c, "b", turns["b"], resource, work).owner == "b"


@pytest.mark.parametrize("existing", (False, True))
def test_stopped_holder_reclaimed_in_copied_root(tmp_path, monkeypatch, existing):
    import shutil

    monkeypatch.delenv("AGENT_COMMS_THREAD", raising=False)
    work = tmp_path / "work"
    work.mkdir()
    resource = WritableFileClaim(work / "shared.py")
    if existing:
        resource.resource.write_text("original\n")
    original = wire(tmp_path / "original")
    turns = {}
    for name in ("holder-a", "holder-b"):
        turns[name] = TurnId.mint()
        thread = NativeThread(name, frozenset(), Checkout(work))
        original.registry.declare(replace(
            thread, process_identity=ProcessIdentity.capture(os.getpid())
        ))

    first = acquire(original, "holder-a", turns["holder-a"], resource, work)
    original_revision = original.bus.bus.revision()
    copied = wire(shutil.copytree(original.root, tmp_path / "copied"))
    assert first.live(copied.registry.snapshot())
    with pytest.raises(ClaimConflict):
        acquire(copied, "holder-b", turns["holder-b"], resource, work)
    copied.registry.unregister("holder-a")
    assert not first.live(copied.registry.snapshot())
    second = acquire(copied, "holder-b", turns["holder-b"], resource, work)
    assert second.owner == "holder-b" and second.generation != first.generation
    with NativeCapture(copied.bus) as boundary:
        copied.bus.publisher.release_resources(boundary, (first,), "Late old release")
    assert copied.bus.bus.claim_projection()[second.resource] == second
    assert original.bus.bus.revision() == original_revision
    original.registry.status("holder-a").require_active()
    assert resource.resource.exists() == existing
    if existing:
        assert resource.resource.read_text() == "original\n"


def test_create_claim_preserves_physical_paths_without_aliases(tmp_path):
    outside = tmp_path / "outside"
    outside.mkdir()
    root = tmp_path / "work"
    root.mkdir()
    (root / "link").symlink_to(outside, target_is_directory=True)
    for path in ("../outside/x", "link/missing.py", ".", outside):
        with pytest.raises(ClaimTransitionError):
            WritableFileClaim(Path(path)).normalized(root)
    assert WritableFileClaim(outside / "x").normalized(root) == str(outside / "x")
    with pytest.raises(ClaimTransitionError):
        ExistingFileClaim(Path("new.py")).normalized(root)
    (root / "existing").write_text("a")
    (root / "alias").hardlink_to(root / "existing")
    with pytest.raises(ClaimTransitionError):
        WritableFileClaim(Path("existing")).normalized(root)


def test_coding_names_and_argument_types_come_from_declarations():
    assert set(CodingTool.names()) == {"read", "bash", "edit", "write"}
    call = NativeToolDeclaration.decode("call", "write", {"path": "x", "content": "value"})
    assert isinstance(call.claim, WritableFileClaim)
    with pytest.raises((TypeError, ValueError)):
        NativeToolDeclaration.decode("call", "write", {"path": True, "content": "v"}).allowed_claim()
    # Pi's full tool schema stays authoritative, including its current edits[]
    # representation; only the mutation path is decoded by the claim policy.
    args = {"path": "x", "edits": [{"oldText": "a", "newText": "b"}]}
    assert NativeToolDeclaration.decode("edit", "edit", args).arguments == args
    with pytest.raises(ValueError):
        NativeToolDeclaration.decode("call", "forged", {}).allowed_claim()


@pytest.mark.parametrize("name,arguments", [
    ("bash", "pwd"),
    ("bash", []),
    ("read", {"file_path": "x"}),
    ("read", {"path": "x", "file_path": "x"}),
    ("read", {"path": "x", "limit": True}),
    ("bash", {}),
    ("bash", {"command": True}),
    ("bash", {"command": "pwd", "timeout": "1"}),
    ("edit", {"path": "x", "oldText": "old", "newText": "new"}),
    ("edit", {"path": "x", "edits": []}),
    ("edit", {"path": "x", "edits": [{"oldText": False, "newText": "new"}]}),
    ("edit", {"path": "x", "edits": [{"oldText": "old", "newText": "new", "newText_should_not_exist": "extra"}]}),
    ("write", {"path": "x", "content": 3}),
    # A name no member declares is refused, not left to kill the owner's socket.
    ("mcp_fixture_echo_092c79e8f8", {"message": "ACCEPTANCE_ECHO"}),
])
def test_pi_argument_records_reject_bad_shapes_without_claiming(name, arguments):
    from agent_comms.tool_denial import SelectedToolDenied
    from agent_comms.transport.native_tool_call import RefusedCodingCall

    call = NativeToolDeclaration.decode("bad-argument-shape", name, arguments)
    assert isinstance(call, RefusedCodingCall)
    with pytest.raises(SelectedToolDenied):
        call.allowed_claim()


def test_an_offered_mcp_tool_decodes_as_its_call_and_an_unoffered_one_is_refused():
    from agent_comms.registry.thread_identity import (
        ReportedTools,
        ToolName,
    )
    from agent_comms.transport.native_tool_call import RefusedCodingCall
    from agent_comms.transport.native_tools import McpToolCall

    name, arguments = "mcp_fixture_echo_092c79e8f8", {"message": "ACCEPTANCE_ECHO"}
    offered = ReportedTools("pi-test", frozenset({ToolName("read"), ToolName(name)}))
    call = NativeToolDeclaration.decode("echo-1", name, arguments, offered)
    assert call == McpToolCall(call_id="echo-1", declared_name=name, arguments=arguments)
    assert call.allowed_claim() is None
    # A name this turn was not offered is refused, digest suffix or not.
    other = NativeToolDeclaration.decode("echo-2", "mcp_fixture_echo_ffffffffff", arguments, offered)
    assert isinstance(other, RefusedCodingCall)


def test_family_selector_is_denied_but_record_presentation_stays_readable():
    from agent_comms.tool_declaration import NoToolRecord, ToolDeclaration
    from agent_comms.tool_denial import SelectedToolDenied

    arguments = {"path": "x", "tool": "write"}
    with pytest.raises(SelectedToolDenied):
        NativeToolDeclaration.decode("selector", "read", arguments)
    assert ToolDeclaration.record("read", arguments, call_id="refused") == NoToolRecord()


@pytest.mark.parametrize("name,arguments,title", [
    ("read", {"path": "x", "offset": 2, "limit": 3}, "Read x"),
    ("bash", {"command": "pwd", "timeout": 2}, "Run pwd"),
    ("edit", {"path": "x", "edits": [{"oldText": "old", "newText": "new"}]}, "Edit x"),
    ("write", {"path": "x", "content": "value"}, "Write x"),
])
def test_pi_argument_fields_own_roundtrip_and_display(name, arguments, title):
    from agent_comms.agent_events import ToolStart

    call = NativeToolDeclaration.decode("typed-argument-shape", name, arguments)
    assert call.arguments == arguments
    assert ToolStart.from_call("typed", name, arguments).title == title


def _request(socket, id, name, args):
    return (
        json.dumps({"token": socket.listener.token, "call_id": id, "name": name, "arguments": args}) + "\n"
    ).encode()



@pytest.mark.asyncio
async def test_tool_error_while_check_waits_cannot_receive_late_permission(
        tmp_path, tool_listener, undealt_gate):
    import asyncio

    checking, release = asyncio.Event(), asyncio.Event()

    class Owner(OwnerDouble):
        async def allow(self, turn, round_number, call):
            checking.set()
            await release.wait()
            return NoRoomNeeded()

    owner = Owner()
    socket = CodingToolSocket(
        tool_listener(tmp_path, secrets.token_hex(32)), owner, undealt_gate, pid=os.getpid())
    socket.turn = SimpleNamespace(launch=SimpleNamespace(root=tmp_path))
    socket.announce(AssistantMessage(content=ReportedParts((
        ToolCallContent(id="late", name="read", arguments={"path": "a"}),
    ))))
    socket.tool_started(ToolExecutionStart(
        tool_call_id=ReportedText("late"), tool_name=ReportedText("read"), args={"path": "a"}
    ))
    pending = asyncio.create_task(socket.handle_request(_request(socket, "late", "read", {"path": "a"})))
    await checking.wait()
    socket.tool_finished(ToolExecutionEnd(
        tool_call_id=ReportedText("late"), tool_name=ReportedText("read"), is_error=ReportedFlag(True)
    ), owner.input_id)
    release.set()
    with pytest.raises(ValueError):
        await pending
    socket.assert_complete()


@pytest.mark.asyncio
@pytest.mark.parametrize("refused", [False, True])
async def test_child_that_stopped_waiting_is_logged_not_raised(
        tmp_path, caplog, refused, tool_listener, undealt_gate):
    """The live owner logged two tracebacks when Pi gave up on a slow tool check."""
    import asyncio
    import os

    answered = asyncio.Event()

    class Owner(OwnerDouble):
        async def allow(self, turn, round_number, call):
            from agent_comms.tool_denial import SelectedToolDenied

            answered.set()
            if refused:
                raise SelectedToolDenied("Original owner refusal")
            return NoRoomNeeded()

    tmp_path.chmod(0o700)
    socket = CodingToolSocket(
        tool_listener(tmp_path, secrets.token_hex(32)), Owner(), undealt_gate, pid=os.getpid())
    socket.turn = object()
    await socket.start()
    try:
        call = ("slow", "read", {"path": "a"})
        socket.announce(AssistantMessage(content=ReportedParts((
            ToolCallContent(id=call[0], name=call[1], arguments=call[2]),
        ))))
        reader, writer = await asyncio.open_unix_connection(str(socket.listener.address))
        writer.write(_request(socket, *call))
        await writer.drain()
        # Pi's side: stop waiting and reset the connection before the owner
        # has seen the tool start, which is what its answer waits for.
        writer.transport.abort()
        await asyncio.sleep(0.1)
        socket.tool_started(ToolExecutionStart(
            tool_call_id=ReportedText(call[0]), tool_name=ReportedText(call[1]), args=call[2]
        ))
        async with asyncio.timeout(5):
            await answered.wait()
            while socket._handlers:
                await asyncio.sleep(0.01)
    finally:
        await socket.close()
    assert "Unhandled exception" not in caplog.text
    answer = "refused" if refused else "allowed"
    warnings = [record for record in caplog.records if record.name == "agent_comms.transport.native_tool_transport"]
    assert len(warnings) == 1
    assert f"stopped waiting for a tool check before its answer ({answer})" in caplog.text


@pytest.mark.asyncio
async def test_tool_call_pi_never_started_is_cancelled_by_transport_retirement(
        tmp_path, tool_listener, undealt_gate):
    import asyncio
    import os

    class Owner(OwnerDouble):
        async def allow(self, turn, round_number, call):
            raise AssertionError("an unstarted call was checked")

    tmp_path.chmod(0o700)
    socket = CodingToolSocket(
        tool_listener(tmp_path, secrets.token_hex(32)), Owner(), undealt_gate, pid=os.getpid())
    socket.turn = object()
    call = ("never", "read", {"path": "a"})
    socket.announce(AssistantMessage(content=ReportedParts((
        ToolCallContent(id=call[0], name=call[1], arguments=call[2]),
    ))))
    await socket.start()
    reader, writer = await asyncio.open_unix_connection(str(socket.listener.address))
    try:
        writer.write(_request(socket, *call))
        await writer.drain()
        async with asyncio.timeout(5):
            while not socket._handlers or not socket.calls.require(0, call[0]).progress.started._waiters:
                await asyncio.sleep(0)
        await socket.close()
        assert await reader.read() == b""
        assert not socket._handlers
        # Retirement consumes the interrupted request; a late start is not
        # permission to replay it. Main deliberately has no ten-second timer.
        with pytest.raises(ValueError):
            await socket.handle_request(_request(socket, *call))
    finally:
        writer.close()
        await writer.wait_closed()
        await socket.close()
