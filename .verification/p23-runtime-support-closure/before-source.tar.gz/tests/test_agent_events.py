"""Nominal extension, dispatch ordering, and shared settlement contracts."""

from dataclasses import dataclass, replace

import pytest
from metaclass_registry.mro_dispatch import MroDispatch, handles

import agent_comms.agent_events as events
from agent_comms.execution.turn_failure import AuthorityChanged
from agent_comms.execution.turn_item import PiRequestKey
from agent_comms.pending_requests import PendingRequests
from agent_comms.pi_commands import SetModel, SetThinkingLevel
from agent_comms.pi_events import Response
from agent_comms.pi_wire import RequestId


async def test_mro_specific_before_shared_and_consumer_override():
    class Left(events.AgentEvent):
        pass

    class Right(events.AgentEvent):
        pass

    @dataclass(frozen=True)
    class Diamond(Left, Right):
        pass

    seen = []

    class Consumer(MroDispatch):
        @handles(Left)
        async def left(self, event):
            seen.append("left")

        @handles(Right)
        async def right(self, event):
            seen.append("right")

        @handles(events.AgentEvent)
        async def root(self, event):
            seen.append("root")

    class Override(Consumer):
        @handles(Left)
        async def left(self, event):
            seen.append("override")

    await Override().dispatch(Diamond())
    assert seen == ["override", "right", "root"]


def test_unannotated_c3_override_masks_handler_and_instance_binding_remains_live():
    @dataclass(frozen=True)
    class Value(events.AgentEvent):
        pass

    seen = []

    class Left(MroDispatch):
        @handles(Value)
        def masked(self, value):
            raise AssertionError("The unannotated override must suppress this handler")

    class Right(MroDispatch):
        @handles(Value)
        def masked(self, value):
            raise AssertionError("C3 must not fall through to another base declaration")

        @handles(Value, events.AgentEvent)
        def kept(self, value):
            seen.append("declared")

    class Consumer(Left, Right):
        masked = None

    first, second = Consumer(), Consumer()
    # Instance behavior still binds at invocation. A borrowed instance method
    # need not repeat the class's handler-membership declaration.
    first.kept = lambda value: seen.append("borrowed")
    value = Value()
    assert first.dispatch_sync(value) is value
    assert second.dispatch_sync(value) is value
    assert seen == ["borrowed", "borrowed", "declared", "declared"]


@pytest.mark.parametrize("synchronous", [False, True])
async def test_selected_handlers_preserve_replacements_and_identity(synchronous):
    @dataclass(frozen=True)
    class Value(events.AgentEvent):
        text: str

    selected = []
    seen = []
    borrowed = object()

    class SyncConsumer(MroDispatch):
        def handlers_for(self, value):
            selected.append(value)
            yield from super().handlers_for(value)

        @handles(Value)
        def specific(self, value, context):
            assert context is borrowed
            if value.text == "wrong":
                return events.Notice("wrong event")
            return replace(value, text="replacement")

        @handles(events.AgentEvent)
        def shared(self, value, context):
            assert context is borrowed
            seen.append(value.text)

    class AsyncConsumer(SyncConsumer):
        @handles(Value)
        async def specific(self, value, context):
            return super().specific(value, context)

        @handles(events.AgentEvent)
        async def shared(self, value, context):
            return super().shared(value, context)

    consumer = SyncConsumer() if synchronous else AsyncConsumer()
    value = Value("original")
    result = (consumer.dispatch_sync(value, borrowed) if synchronous
              else await consumer.dispatch(value, borrowed))
    assert selected == [value]
    assert seen == ["replacement"]
    assert result == Value("replacement")
    with pytest.raises(TypeError):
        if synchronous:
            consumer.dispatch_sync(Value("wrong"), borrowed)
        else:
            await consumer.dispatch(Value("wrong"), borrowed)


@pytest.mark.parametrize("synchronous", [False, True])
async def test_handler_can_consume_without_returning_a_publication(synchronous):
    @dataclass(frozen=True)
    class PrivateObservation(events.AgentEvent):
        pass

    seen = []

    class SyncConsumer(MroDispatch):
        @handles(PrivateObservation)
        def consume(self, value):
            seen.append("consumed")
            return self.DISCARD

        @handles(events.AgentEvent)
        def must_not_run(self, value):
            seen.append("published")

    class AsyncConsumer(SyncConsumer):
        @handles(PrivateObservation)
        async def consume(self, value):
            return super().consume(value)

        @handles(events.AgentEvent)
        async def must_not_run(self, value):
            return super().must_not_run(value)

    consumer = SyncConsumer() if synchronous else AsyncConsumer()
    value = PrivateObservation()
    result = (consumer.dispatch_sync(value) if synchronous else await consumer.dispatch(value))
    assert result is None
    assert seen == ["consumed"]


def test_done_reports_its_failure_reason_code():
    done = events.Done("failed", False, AuthorityChanged("failed"), {"elapsed_ms": 3})
    assert done.reason_code == "authority_changed"
    assert done.diagnostic == {"elapsed_ms": 3}


@pytest.mark.parametrize("ok", (True, False))
def test_done_calls_the_captured_failure_constructor_only_on_failure(ok: bool) -> None:
    terminal = events.Done("finished", ok)
    error = events.Error("provider error")
    failure = events.UnresolvedNativeTurnOutcome()
    invoked: list[events.Done] = []

    def resolve_failure(
        actual: events.Done, observed: events.Error | None,
    ) -> events.NativeTurnOutcome:
        assert actual is terminal and observed is error
        invoked.append(actual)
        return failure

    resolved = terminal.resolve(error, resolve_failure)
    assert resolved.ok is ok
    assert invoked == ([] if ok else [terminal])
    if ok:
        assert isinstance(resolved.outcome, events.SuccessfulNativeTurnOutcome)
    else:
        assert resolved.outcome is failure


async def test_request_correlation_separates_families_and_ignores_late_results():
    pending = PendingRequests()
    wire_id = "same"
    key = PiRequestKey(wire_id)
    model_command = SetModel(id=RequestId(key), provider="test", model_id="one")
    thinking_command = SetThinkingLevel(id=RequestId(key), level="off")
    model = pending.add(SetModel, key, request=model_command)
    thinking = pending.add(SetThinkingLevel, key, request=thinking_command)
    with pytest.raises(ValueError):
        pending.add(SetModel, key, request=model_command)
    refused = Response.from_wire({"type": "response", "id": wire_id, "command": "set_model",
                                  "success": False, "error": "unavailable"})
    assert pending.take(SetModel, key, refused) is model_command
    assert await model.response() is refused
    assert not thinking.future.done()
    accepted = Response.from_wire({"type": "response", "id": wire_id, "command": "set_thinking_level",
                                   "success": True})
    assert pending.take(SetThinkingLevel, key, accepted) is thinking_command
    assert await thinking.response() is accepted
    assert pending.take(SetThinkingLevel, key, refused) is None
    cancelled = pending.add(
        SetModel, PiRequestKey("cancelled"), request=SetModel(id=RequestId(PiRequestKey("cancelled")))
    )
    cancelled.future.cancel()
    assert pending.take(SetModel, PiRequestKey("cancelled"), refused) is cancelled.request
