"""A file claim in a selected turn publishes its claim and release notices to the holder only.

Real private bus, checkpoint, registry and coordination stores under /var/tmp.
"""

from __future__ import annotations

import hashlib
import os
import sys
from dataclasses import replace

import pytest

from agent_comms.attempt_start import AttemptStart
from agent_comms.attempt_states import AttemptFailedAttempt
from agent_comms.comms import Comms
from agent_comms.context_segments.native_messages import TranscriptSegment
from agent_comms.context_store import UNREAD_CONTEXT
from agent_comms.coordination.cohort import sealed_cohort_assignments
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.errors import IdentityConflict
from agent_comms.coordination.session import NativeCapture
from agent_comms.coordination.tables.executions import WireOrigin
from agent_comms.envelope_claim_transitions import ExistingFileClaim, WakeClaim
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.execution.selected.claim import (
    publish_selected_resource_claim,
    write_selected_claimed_file,
)
from agent_comms.execution.selected.source_batch import SelectedSource
from agent_comms.execution.turn_context import (
    ContextManifest,
    OwnerProvenance,
    RecordedContextTurn,
    SegmentManifest,
)
from agent_comms.messaging.channel_targets import CommandTarget
from agent_comms.messaging.message_page import ConversationMessagePageRequest, MessagePageRequest
from agent_comms.messaging.messages import ClaimMessage, ClaimNoticeKind
from agent_comms.messaging.read_basis import AllChannelDisplayScope, DMDisplayScope
from agent_comms.nominal.field_codec import ClaimId, TurnId
from agent_comms.owner_fence import prepare_fence_token
from agent_comms.projects.checkouts import Checkout
from agent_comms.reason_codes import NoReasonCode
from agent_comms.registry.thread_identity import TurnIdentity
from agent_comms.registry.threads import NativeThread
from conftest import accept_initial, publish_initial

pytestmark = pytest.mark.skipif(
    sys.platform != "linux", reason="private cohort claim_scope requires real /var/tmp"
)


def record_context(comms: Comms, name: str, generation: int) -> None:
    owner = comms.registry.require(name)
    segment = SegmentManifest(
        kind=TranscriptSegment,
        provenance=(OwnerProvenance(owner.incarnation, "input-source"),),
        sha256=hashlib.sha256(b"context").hexdigest(),
        utf8_bytes=7,
        tokens=2,
    )
    comms.contexts.record_after(
        UNREAD_CONTEXT,
        ContextManifest(
            thread=owner.incarnation,
            turn=RecordedContextTurn(
                TurnId(f"{generation:032x}"),
                TurnIdentity(owner.incarnation, generation),
            ),
            segments=(segment,),
            counter="pi.estimateTokens",
        ),
    )


@pytest.fixture
def selected_turn(private_comms, private_directory):
    """Alice runs a selected turn for one message; context rows surround it."""
    comms = private_comms
    root = comms.root
    worktree = private_directory / "work"
    worktree.mkdir(mode=0o700)
    resource = worktree / "module.py"
    resource.write_text("value = 1\n")
    for name, created in (("sender", 17021.0), ("Alice", 17022.0)):
        comms.registry.declare(NativeThread(name, frozenset({'team'}), Checkout(worktree), process_identity=ProcessIdentity.capture(os.getpid()), created_at=created))
    root_id = comms.registry.store.prepare_native_root().namespace
    record_context(comms, "Alice", 1)
    message = publish_initial(comms, "sender", "#team", "@Alice investigate")
    record_context(comms, "Alice", 2)
    initial = comms.bus.bus.delivery(message.seq)
    with Coordination(str(root / "coordination.sqlite3")) as store:
        for recipient in initial.recipients:
            store.participants.register(
                recipient.recipient_lookup, committed=True,
            )
        accept_initial(comms.bus, root_id, message.seq, store)
        lookup = comms.registry.require("Alice").incarnation.lookup
        assignment = sealed_cohort_assignments(store, lookup)[0]
        owner, generation = comms.registry.live_owner_with_claim("Alice")
        owner, generation = comms.registry.lease_live_turn_with_claim(
            owner, TurnId('088fbdccfa8d303a5026987cf37e23b8'), expected_generation=generation
        )
        person = store.participants.get(lookup)
        store.create(
            "execution", WireOrigin, lookup, 1,
            sources=(SelectedSource(assignment.assignment_id, store.assignments, initial),),
        )
        snapshot = store.get("execution")
        snapshot = store.mark_pending(
            "execution", expected_revision=snapshot.execution.revision
        ).value
        store.start(AttemptStart(
            execution_id="execution", attempt_ordinal=1, owner_lookup=lookup, owner_generation=person.owner_identity.generation, token=prepare_fence_token(),
            expected_execution_revision=snapshot.execution.revision,
            expected_pointer_revision=snapshot.pointer_revision,
        ))
        claim_scope = WakeClaim(
            wire_root_id=root_id,
            source_seq=message.seq,
            source_message_id=message.message_id,
            wake_assignment_id=assignment.assignment_id,
            wake_revision=store.assignments.get(assignment.assignment_id).revision,
            recipient_lookup=lookup,
            execution_id="execution",
            operation_id=ClaimId("f" * 32),
            owner_claimed_generation=generation,
            turn_id=owner.require_turn_lease().turn_id,
            participant_generation=person.owner_identity.generation,
            attempt_ordinal=1,
        )
        yield comms, store, claim_scope, resource


def settle_failed(store):

    with store.session.settlement() as boundary:
        snapshot = store.get("execution")
        snapshot.attempt.advance(
            store.session, type(snapshot.attempt.lifecycle), backend_done=True,
            process_dead=True, progress=False, reason_code=NoReasonCode(),
        )
        store.get("execution").settle(store.session, AttemptFailedAttempt(), NoReasonCode(), boundary)


def claim_originals(comms: Comms) -> tuple[ClaimMessage, ...]:
    records = comms.bus.bus.since(0, comms.bus.bus.revision())
    return tuple(record for record in records if isinstance(record, ClaimMessage))


def release_tool_claim(comms: Comms, claim) -> None:
    with NativeCapture(comms.bus) as boundary:
        comms.bus.publisher.release_resources(boundary, (claim,), "Finished test tool operation")


def test_claim_write_and_release_publish_claim_notices_only_to_the_holder(selected_turn) -> None:
    (comms, store, claim_scope, resource) = selected_turn
    claimed = publish_selected_resource_claim(
        comms, store, claim_scope, "Alice", ExistingFileClaim(resource)
    )
    # Asking again for the same file in the same turn returns the held claim.
    assert publish_selected_resource_claim(
        comms, store, claim_scope, "Alice", ExistingFileClaim(resource)
    ) == claimed
    write_selected_claimed_file(comms, store, claim_scope, "Alice", claimed, b"value = 2\n")
    record_context(comms, "Alice", 3)
    settle_failed(store)
    assert resource.read_bytes() == b"value = 2\n"
    # The strict whole-bus reader agrees with what the claim path left.
    assert dict(comms.bus.bus.claim_projection()) == {}
    claims = claim_originals(comms)
    displayed = tuple(message for message in MessagePageRequest(
        AllChannelDisplayScope("#any"),
    ).read_opened(comms.bus.bus).messages if isinstance(message, ClaimMessage))
    assert displayed == claims
    assert [(m.claim_transition.claims, len(m.claim_transition.releases)) for m in claims] == [
        ((str(resource),), 0), ((), 1),
    ]
    assert all(message.type is ClaimNoticeKind for message in claims)
    assert (claims[0].sender, claims[0].target, claims[0].body) == (
        "Alice", "Alice", "Claimed",
    )
    snapshot = comms.registry.snapshot()
    dm_scope = DMDisplayScope.capture("Alice", "sender", snapshot)
    assert ConversationMessagePageRequest(dm_scope).read_opened(comms.bus.bus).messages == ()
    raw_channel = comms.views.history_page(CommandTarget.named("#team")).messages
    assert [message.body for message in raw_channel] == ["@Alice investigate"]
    channel = comms.views.channel_display_page("#team").messages
    assert [message.body for message in channel] == ["@Alice investigate"]
    assert all(message.role.notification_references(message) for message in channel)
    with pytest.raises(ValueError):
        comms.messaging.send(
            "Alice", "sender", "Invented claim notice", ClaimNoticeKind
        ).message


def test_claim_operation_is_refused_after_its_claim_was_released(selected_turn) -> None:
    (comms, store, claim_scope, resource) = selected_turn
    claimed = publish_selected_resource_claim(
        comms, store, claim_scope, "Alice", ExistingFileClaim(resource)
    )
    assert dict(comms.bus.bus.claim_projection()) == {str(resource): claimed}
    release_tool_claim(comms, claimed)
    with pytest.raises(IdentityConflict):
        publish_selected_resource_claim(
            comms, store, claim_scope, "Alice", ExistingFileClaim(resource)
        )
    again = publish_selected_resource_claim(
        comms, store, replace(claim_scope, operation_id=ClaimId("e" * 32)), "Alice",
        ExistingFileClaim(resource),
    )
    assert again.generation != claimed.generation
    assert dict(comms.bus.bus.claim_projection()) == {str(resource): again}
