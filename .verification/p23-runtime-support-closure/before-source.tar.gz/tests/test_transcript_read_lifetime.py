"""The read index closes with its resources, before Python clears its modules."""
import gc
import json
import os
import sqlite3
import subprocess
import sys
import weakref
from pathlib import Path

import pytest

from agent_comms.comms import wire
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.roster_visibility import DEFAULT_ROSTER
from agent_comms.registry.threads import NativeThread
from agent_comms.session_file import RegistrySessionLocation
from agent_comms.ui_model.unread import IndexingUnread
from agent_comms.view_unread import transcript_read_state
from native_unread_fixture import native_reader


def test_collected_reader_cancels_and_joins_its_worker_then_closes_sqlite(tmp_path):
    source = tmp_path / "session.jsonl"
    source.write_text(json.dumps({"type": "message", "timestamp": "2026-10-19T05:00:00.000Z", "message": {
        "role": "assistant", "content": [{"type": "text", "text": "one reply"}],
    }}) + "\n")
    state = native_reader(tmp_path / 'read_ledger.json')
    registry = wire(tmp_path).registry
    registry.declare(NativeThread('worker', frozenset(), Checkout(tmp_path), session_file=RegistrySessionLocation.from_path(str(source), tmp_path)))
    assert state.counts('viewer', registry=registry.snapshot(), document=state.reads.read(), visibility=DEFAULT_ROSTER).counts == {"worker": IndexingUnread()}
    for future in state.watch(frozenset(), lambda _: None):
        future.result(timeout=10)
    workers = tuple(state._pool._threads)
    database, cancelled = state._connection, state._cancelled
    reference = weakref.ref(state)
    del state
    gc.collect()
    assert reference() is None
    assert cancelled.is_set()
    assert workers and all(not worker.is_alive() for worker in workers)
    with pytest.raises(sqlite3.ProgrammingError):
        database.execute("SELECT 1")


def test_database_without_worker_is_closed_when_reader_dies(tmp_path):
    state = native_reader(tmp_path / 'read_ledger.json')
    database = state._database()
    idle = state.preparation
    idle.cancel()
    idle.retire((str(tmp_path / "missing.jsonl"),))
    idle.commit(database, ())
    assert state.watch(frozenset(), lambda _: None) == frozenset()
    reference = weakref.ref(state)
    del state
    gc.collect()
    assert reference() is None
    with pytest.raises(sqlite3.ProgrammingError):
        database.execute("SELECT 1")


def test_explicit_close_is_idempotent_and_factory_replaces_closed_unused_reader(tmp_path):
    path = tmp_path / "read_ledger.json"
    state = transcript_read_state(path)
    state.close()
    state.close()
    with pytest.raises(RuntimeError):
        state.counts('viewer', registry=wire(tmp_path).registry.snapshot(), document=state.reads.read(), visibility=DEFAULT_ROSTER)
    fresh = transcript_read_state(path)
    assert fresh is not state
    fresh.close()


def test_comms_exits_before_multiprocessing_module_teardown(tmp_path):
    script = tmp_path / "exit_comms.py"
    script.write_text('''import atexit
import multiprocessing.synchronize as synchronize
from pathlib import Path
import sys

# This is the module-clearing stage that made the old destructor fail.
@atexit.register
def clear_module():
    synchronize.sys = None

from agent_comms.comms import wire
comms = wire(Path(sys.argv[1]))
print("Comms created; interpreter exits normally")
''')
    environment = os.environ.copy()
    environment.pop("AGENT_COMMS_NATIVE_CONFIG_DIR", None)
    environment["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
    result = subprocess.run([sys.executable, str(script), str(tmp_path / "wire")],
                            env=environment, capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    assert "Comms created" in result.stdout
    assert result.stderr == ""
