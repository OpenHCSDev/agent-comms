"""Durable-store thread location and history paging over a real store; no provider inputs."""
import asyncio
import subprocess
from dataclasses import replace

import pytest

from agent_comms.execution.turn_bound import LastTurns
from agent_comms.execution.turn_runner import TurnRunner
from agent_comms.nominal.field_codec import FieldCodec
from agent_comms.pi_durable_backend import DurableDatabase, Inspect, PiDurableBackend
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import NativeThread, Thread
from agent_comms.session_file import NoSessionFile, RegistrySessionLocation
from agent_comms.unstarted_runtime import UnstartedRuntime


@pytest.mark.parametrize('saved', [False, True])
def test_durable_thread_roundtrip_and_worker_selection(tmp_path, saved, *, thread_registration):
    location = DurableDatabase(str(tmp_path / 'session.sqlite3'))
    thread = thread_registration.declare(NativeThread('durable', frozenset(), Checkout(tmp_path), backend=PiDurableBackend, session_file=RegistrySessionLocation.from_path(location.read_key, tmp_path) if saved else NoSessionFile()))
    restored = FieldCodec.decode(Thread, FieldCodec.encode(thread))
    restored = replace(restored, session_file=restored.session_file.bound_to(tmp_path))
    assert restored.runtime == (location if saved else UnstartedRuntime(PiDurableBackend))
    assert restored.runtime.backend is PiDurableBackend
    class Runner:
        persistent_backends = {}
    runner = Runner()
    backend = TurnRunner.backend_for(runner, 'durable', restored)
    assert isinstance(backend, PiDurableBackend)
    assert TurnRunner.backend_for(runner, 'durable', restored) is backend


SEED = """
import { BACKGROUND_CONTEXT as context } from '@earendil-works/chord/context';
import { Harness, createRegistry } from '@earendil-works/pi-durable';
import { openNodeSqliteStorage } from '@earendil-works/pi-durable/storage/sqlite/node';
import { InMemoryCredentialStore } from '@earendil-works/pi-ai';
import { builtinModels } from '@earendil-works/pi-ai/providers/all';
const start = Number(process.argv[2]);
const harness = await Harness.open(await openNodeSqliteStorage(process.argv[1]), {
  registry: createRegistry(), models: builtinModels({credentials: new InMemoryCredentialStore()}),
}, context);
try {
  const root = await harness.root(context);
  await harness.commit(async tx => {
    for (let index = 0; index < 260; index++) {
      const role = index % 2 ? 'assistant' : 'user';
      await tx.appendEntry(root.id, {kind: `pi.${role}`, data: null,
        model: [{role, timestamp: start + index,
                 content: [{type: 'text', text: `entry ${index}`}]} ]});
    }
  }, context);
} finally { await harness.close(context); }
"""


def test_real_durable_history_pages_while_writer_owns_database(tmp_path, thread_registration, durable_home,
                                                                durable_host_packages):
    start = 1760000000000
    location = DurableDatabase(str(tmp_path / 'history.sqlite3'))
    seeded = subprocess.run(['node', '--input-type=module', '-e', SEED, location.path, str(start)],
                            cwd=durable_host_packages, capture_output=True, text=True, timeout=20)
    assert seeded.returncode == 0, seeded.stderr[-2000:]
    async def journey():
        backend = PiDurableBackend()
        thread = NativeThread('history', frozenset(), Checkout(tmp_path), backend=PiDurableBackend,
                        session_file=RegistrySessionLocation.from_path(location.path, tmp_path))
        host = await backend.open(thread)
        try:
            interrupted = await host.request(Inspect())
            def read():
                source = location.history_source(tmp_path, thread.incarnation)
                with source.reading() as reader:
                    cut = reader.cut()
                    records = tuple(reader.reverse(cut.offset))
                    assert len(records) == 260
                    assert [r.events[0].text for r in records[:4]] == ['entry 259', 'entry 258', 'entry 257', 'entry 256']
                    assert [r.events[0].timestamp for r in records[:4]] == [
                        (start + index) / 1000 for index in range(259, 255, -1)
                    ]
                    forward = tuple(reader.forward(0, cut.offset))
                    assert forward == tuple(reversed(records))
                    with reader.projection(None, None) as project:
                        assert tuple(project(iter(forward), max_records=10, max_bytes=1024))
                turns = source.turns(LastTurns(1))
                assert len(turns) == 1
                assert [event.text for event in turns[0].events] == ['entry 258', 'entry 259']
            await asyncio.to_thread(read)
            assert await host.request(Inspect()) == interrupted
        finally:
            await host.shutdown()
    asyncio.run(journey())
