"""Board review commands and judge preconditions share real orders and retained releases."""

import shlex
import time
from contextlib import chdir
from dataclasses import replace
from inspect import isabstract

import pytest

from agent_comms.errors import TodoError
from agent_comms.head_review import HeadReviewOrder, PullRequestHead
from agent_comms.nominal.field_codec import FieldCodec, GoalId
from agent_comms.planning.goal_actions import SetGoalAction
from agent_comms.planning.order_words import (
    StrikeReason,
    VerdictReason,
)
from agent_comms.planning.orders import (
    Assignment,
    ClaimOrder,
    DeliveredProblemOrder,
    NoHeadOrder,
    OrderClaim,
    OrderHeadReview,
    OrderHeadReviewRecord,
    OrderMessage,
    ProgressRead,
    RecordOrderHeadVerdict,
    RecordPullRequest,
    ReleaseTodo,
    ReviewedHeadVerdict,
    SendBackStrike,
    StoredHeadReview,
    TodoStore,
    UnderReviewHeadVerdict,
)
from agent_comms.planning.pull_requests import PullRequestLink
from agent_comms.recorded_time import RecordedEventTime
from agent_comms.registry.threads import ExternalThread, ForkThread
from agent_comms.task_attachments.team_pings import RulePing
from agent_comms.team import judge, order
from agent_comms.team.standing import DeliveryAwaitingJudgement
from agent_comms.team.standing_rules import (
    HeadReviewTimerUp,
    LinkedUnreviewedHead,
    OrderlessUnreviewedHead,
    ReviewTimerUp,
    StandingRule,
)
from agent_comms.tool_caller import ForkCaller, PeerCaller, ThreadCaller
from agent_comms_hooks import ToolRefusedError
from team_heartbeat_fixture import capture_frame
from test_held_problem_orders import merge_two_commit_fix
from test_team_notifications import beat, notifications

pytest_plugins = ("test_head_review", "test_held_problem_orders", "test_team_notifications")

REASON = VerdictReason("The existing class owns this behavior without another copy")
ROAST = "This is stupid because the same decision is written twice instead of belonging to its existing class."
FIX = "Put the shared behavior on the existing parent and delete both copies."
QUOTE = "Repair the existing owner"


@pytest.fixture
def board_review(head_bus):
    comms, github, request = head_bus
    colleague = comms.registry.require("colleague").incarnation
    worker = comms.registry.require("worker").incarnation

    def claim(problem="P2"):
        todo = comms.goals.todos.get(problem)
        original = comms.messaging.send("colleague", "worker", todo.order.instructions(todo)).message
        todo = comms.goals.todos.apply(todo.id, OrderMessage(
            todo.revision, colleague, original.message_id, at=RecordedEventTime(time.time())))
        delivery = OrderClaim.for_order(todo, worker, PullRequestLink(todo.repo, request.pr), request.head,
                                        "Review the broken duplicated decision repair",
                                        (original.reference,))
        ClaimOrder(todo.revision, worker, todo.held().generation, delivery).record(comms.goals, todo.id)
        return comms.goals.todos.get(todo.id)

    def link():
        todo = comms.goals.todos.get("P2")
        RecordPullRequest(todo.revision, worker,
                          PullRequestLink(request.repo, request.pr), todo.held().generation).record(comms.goals, todo.id)
        return comms.goals.todos.get(todo.id)

    return comms, request, claim, link


def assert_review_preconditions(rule, comms, request):
    ctx = order.Team(root=comms.root, actor=PeerCaller("colleague"))  # the reviewer, by name
    observed = rule.command_values()
    todo = comms.goals.todos.get(observed.get("problem", "P2"))
    # Supply review prose once by declared argument, not a second roster of verb requirements.
    values = {name: shlex.quote(value) for name, value in {
        **observed, "why": REASON.text, "serves": QUOTE, "roast": ROAST, "fix": FIX,
        "at": f"{todo.order.check.directory / todo.order.owner.file}:{todo.order.owner.line}",
        "by": todo.id,
    }.items()}
    judged = []
    allowed = rule.clearing_actions()
    commands = (command for action in judge.HeadVerdictVerb.members_with(judge.HeadVerdictVerb)
                if action in allowed
                for command in action.commands({entry.key: values[entry.key]
                    for entry in FieldCodec.argument_fields(action) if entry.key in values}))
    for command in commands:
        verb = judge.JudgeVerb.parse(shlex.split(command)[1:])
        assert not verb.argument_problems()
        scope = OrderHeadReview.for_request(ctx.todos(), request, verb.order_link, verb.problem)
        scope.require_reviewer(comms.goals, request, ctx.actor_identity)
        for linked in HeadReviewOrder.holding(ctx.todos(), request):
            if linked.id != verb.problem:
                continue
            operation = RecordOrderHeadVerdict(linked.revision, OrderHeadReviewRecord(
                request, ctx.actor_identity, RecordedEventTime(time.time()),
                verb.head_operation(), verb.order_link(linked)))
            operation.prepare(comms.goals, linked)
        judged.append(verb.verdict)
    assert ReviewedHeadVerdict in judged
    return judged


@pytest.mark.parametrize("claim_it", [False, True])
def test_held_board_commands_take_the_same_verdicts_as_the_order(board_review, claim_it):
    comms, request, claim, link = board_review
    todo = claim() if claim_it else link()
    rules = LinkedUnreviewedHead.scan_reviews(comms.goals, ProgressRead(()))
    rule, = rules
    assert rule.todo == todo
    assert judge.PromoteVerb not in rule.clearing_actions()
    assert UnderReviewHeadVerdict in assert_review_preconditions(rule, comms, request)
    frame = capture_frame(comms, ProgressRead(()))
    # The timer's own condition remains real: age the observed review timer in this read.
    timed = replace(todo, review_at=RecordedEventTime(time.time() - 120))
    frame = replace(frame, review_timers=TodoStore.timers_up_in(
        (timed,), time.time(), frame.pulls.progress((timed,), comms.registry)))
    timers = ReviewTimerUp.scan_observed(comms, (), frame)
    assert bool(timers) == (not claim_it)
    for timer in timers:
        assert_review_preconditions(timer, comms, request)
    for delivery in DeliveryAwaitingJudgement.read_open(
            comms.bus.bus, comms.registry.snapshot(), {todo.held().owner_identity: (todo,)},
            comms.registry.require("colleague"), ()):
        assert_review_preconditions(delivery, comms, request)


def test_standing_rule_declarations_are_encodable_or_abstract():
    members = StandingRule.members_with(StandingRule)
    assert members
    for member in members:
        encoded = FieldCodec.encode(member, type[StandingRule])
        assert FieldCodec.decode(type[StandingRule], encoded) is member

    pending = [StandingRule]
    seen = set()
    while pending:
        declaration = pending.pop()
        if declaration in seen:
            continue
        seen.add(declaration)
        pending.extend(declaration.__subclasses__())
        if declaration.declared_name is None:
            assert isabstract(declaration), declaration.__name__
            with pytest.raises(TypeError, match=declaration.__name__):
                declaration()


def test_head_review_timer_ping_round_trips_through_field_codec(board_review, notification_bus):
    comms, request, _, link = board_review
    todo = link()
    timer = HeadReviewTimerUp(
        todo.id, todo.held().owner_identity, todo.order.checked().id,
        RecordedEventTime(time.time()), request, todo=todo)
    ping = RulePing.capture(timer)
    decoded = FieldCodec.decode(RulePing, FieldCodec.encode(ping))
    assert decoded == ping
    assert decoded.rule is HeadReviewTimerUp
    assert notification_bus is comms
    beat(comms, (timer,))
    published, = notifications(comms)
    assert ping in published.task.handled


def test_shared_head_keeps_each_order_on_its_own_board_and_timer_line(board_review):
    comms, request, claim, link = board_review
    first = link()
    second = claim("P1")
    rules = LinkedUnreviewedHead.scan_reviews(comms.goals, ProgressRead(()))
    assert {rule.todo.id for rule in rules} == {first.id, second.id}
    for rule in rules:
        verdicts = assert_review_preconditions(rule, comms, request)
        assert UnderReviewHeadVerdict in verdicts
    frame = capture_frame(comms, ProgressRead(()))
    timed = replace(first, review_at=RecordedEventTime(time.time() - 120))
    frame = replace(frame, review_timers=TodoStore.timers_up_in(
        (timed,), time.time(), frame.pulls.progress((timed,), comms.registry)))
    timers = ReviewTimerUp.scan_observed(comms, (), frame)
    timer, = timers
    assert timer.todo == timed
    assert timer.problem == first.id
    assert UnderReviewHeadVerdict in assert_review_preconditions(timer, comms, request)


def test_orderless_board_commands_do_not_invent_a_problem(board_review):
    comms, request, _, _ = board_review
    rule, = OrderlessUnreviewedHead.scan_reviews(comms.goals, ProgressRead(()))
    assert judge.PromoteVerb not in rule.clearing_actions()
    assert "problem" not in rule.command_values()
    assert "--problem" not in rule.clearing_commands()
    assert UnderReviewHeadVerdict in assert_review_preconditions(rule, comms, request)


def test_claim_link_survives_sendbacks_and_explicit_release_without_editing_goal(board_review):
    comms, request, claim, _ = board_review
    original = claim()
    previous = original.held()
    assert PullRequestLink(request.repo, request.pr) in original.order.pull_requests
    for _ in range(2):
        current = comms.goals.todos.get(original.id)
        SendBackStrike(current.revision, current.creator_identity, current.held(),
                       StrikeReason(ROAST).text, RecordedEventTime(time.time()),
                       evidence=(current.order.owner,)).record(comms.goals, current.id)
    current = comms.goals.todos.get(original.id)
    ReleaseTodo(current.revision, current.held().owner_identity, current.held(), StrikeReason(
        "The holder explicitly releases this order after reviewing its work")).record(comms.goals, current.id)
    released = comms.goals.todos.get(original.id)
    assert released.current_holder.current_assignments() == ()
    assert released.order.holds_head(request)
    assert comms.goals.todos.resolve_order(released.creator_identity, previous.owner, released.id) == released
    rule, = LinkedUnreviewedHead.scan_reviews(comms.goals, ProgressRead(()))
    assert UnderReviewHeadVerdict in assert_review_preconditions(rule, comms, request)
    # A former holder can already be doing different work. A head review must not edit that goal.
    other = comms.goals.todos.get("P1")
    ReleaseTodo(other.revision, other.held().owner_identity, other.held(), StrikeReason(
        "The worker stopped this independent fixture order before starting different assigned work")).record(comms.goals, other.id)
    comms.goals.update_goal("worker", SetGoalAction(text="Different work"))
    goal = comms.registry.require("worker").goal.require()
    assert judge.OkVerb in rule.clearing_actions()
    command, = judge.OkVerb.commands({**rule.command_values(),
        "why": shlex.quote(REASON.text), "serves": shlex.quote(QUOTE)})
    judge.main(shlex.split(command)[1:], order.Team(root=comms.root, actor=PeerCaller("colleague")))
    accepted = comms.goals.todos.get(original.id)
    assert accepted.order.holds_head(request)
    assert StoredHeadReview.head_reviews(comms.goals.todos, request)[0].order.problem == original.id
    assert comms.registry.require("worker").goal.require() == goal
    proposed = Assignment.of(previous.owner_identity, previous.parent_identity, GoalId.mint())
    reassigned = accepted.assigned(proposed, accepted.order.owner, previous.owner_identity)
    assert reassigned.order.pull_requests == accepted.order.pull_requests


def test_released_merged_work_refuses_late_review_but_can_be_delivered(
        held_team, cited_source, tmp_path):
    ctx = held_team
    store = ctx.comms.goals.todos
    todo = store.get("P1")
    previous = todo.held()
    RecordPullRequest(todo.revision, todo.creator_identity,
                      PullRequestLink(todo.repo, 42), previous.generation).record(ctx.comms.goals, todo.id)
    current = store.get(todo.id)
    ReleaseTodo(current.revision, current.held().owner_identity, current.held(), StrikeReason(
        "The holder explicitly releases this order after reviewing its work")).record(ctx.comms.goals, todo.id)
    _, first, _ = merge_two_commit_fix(cited_source, tmp_path / "bin", 42)
    current = store.get(todo.id)
    request = ctx.comms.goals.todos.resolve_order(ctx.incarnation, previous.owner, todo.id)
    assert request == current
    head = cited_source.git(cited_source.checkout, "rev-parse", "refs/heads/fix/42").strip()
    quote = " ".join(current.order.instructions(current).split()[:4])
    with chdir(cited_source.checkout):
        # The fixture already merged this PR. A late source review cannot reopen it.
        with pytest.raises(TodoError):
            judge.main(["ok", "--repo", todo.repo.to_wire(), "--problem", todo.id,
                        "--pr", "42", "--head", head, "--why", REASON.text, "--serves", quote], ctx)
        assert not StoredHeadReview.head_reviews(store, PullRequestHead(todo.repo, 42, head))
        order.main(["done", previous.owner, todo.id], ctx)
    delivered = store.get(todo.id)
    assert type(delivered.order) is DeliveredProblemOrder
    assert delivered.order.delivery.delivered == first
    assert delivered.current_holder.current_assignments() == ()



def test_a_verdict_on_exactly_the_delivered_head_answers_the_delivery(board_review):
    """The delivery line names one head; only a decided verdict on that head retires it."""
    comms, request, claim, _ = board_review
    claim()
    colleague = comms.registry.require("colleague").incarnation
    opened, = DeliveryAwaitingJudgement.opened(comms, colleague)
    assert opened.request == request
    NoHeadOrder().record_review(comms.goals, replace(request, head="f" * 40),
                                ReviewedHeadVerdict(REASON), colleague)
    assert DeliveryAwaitingJudgement.opened(comms, colleague) == (opened,)
    NoHeadOrder().record_review(comms.goals, request, ReviewedHeadVerdict(REASON), colleague)
    assert DeliveryAwaitingJudgement.opened(comms, colleague) == ()


@pytest.mark.parametrize("reviewer", ("colleague", "peer", "worker"))
def test_independent_colleagues_may_review_without_rank_tags(board_review, reviewer):
    """Native and external colleagues share scope; no colleague has extra permission."""
    comms, request, _, _ = board_review
    comms.registry.declare(ExternalThread("peer", frozenset({"comms"}),
                                  comms.registry.require("colleague").worktree))
    NoHeadOrder().require_reviewer(comms.goals, request,
                                   comms.registry.require(reviewer).incarnation)


def test_in_turn_review_uses_the_actual_bound_parent_not_a_second_independent_actor(board_review):
    comms, request, _, _ = board_review
    child = comms.registry.register_child("review-child", "worker", ForkThread,
                                          comms.goals)
    with pytest.raises(ToolRefusedError):
        ThreadCaller(child.name).head_review_actor(comms, request, NoHeadOrder())
    actor = ForkCaller(child.name).head_review_actor(comms, request, NoHeadOrder())
    assert actor == child.incarnation
    assert actor.acting_identity == comms.registry.require("worker").incarnation


def test_review_scope_requires_the_actual_registered_birth(board_review):
    comms, request, _, _ = board_review
    snapshot = comms.registry.snapshot()
    original = comms.registry.require("worker").incarnation.require_recorded()
    with pytest.raises(ToolRefusedError):
        snapshot.team_project.require_scope(
            snapshot, replace(original, created_at=time.time() + 1000), request.repo)
    assert not StoredHeadReview.head_reviews(comms.goals.todos, request)


def test_unreviewed_head_line_names_each_verb_once_and_every_argument() -> None:
    from agent_comms.head_review import PullRequestHead
    from agent_comms.projects.repository_name import RepositoryName
    from agent_comms.team.standing_rules import OrderlessUnreviewedHead

    head = "a" * 40
    line = OrderlessUnreviewedHead(request=PullRequestHead(RepositoryName.from_wire("o/r"), 7, head), due_at=0).line()
    assert line.count("judge ") == 1 and all(part in line for part in ("--pr 7", f"--head {head}", "--repo o/r"))
