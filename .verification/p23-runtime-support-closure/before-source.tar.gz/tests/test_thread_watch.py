"""The real message bus and wire watcher preserve unread delivery ownership."""

import asyncio
from contextlib import aclosing


async def test_watch_emits_startup_unread_then_arrival_and_leaves_untaken_unread(wired):
    first = wired.messaging.send("PR111", "fixer", "already unread").message

    async with aclosing(wired.watch("fixer")) as watcher:
        initial = await asyncio.wait_for(anext(watcher), timeout=3)
        assert initial.message_id == first.message_id

        # The consumer awaits one arrival, without polling the inbox or wire.
        arrival = asyncio.create_task(anext(watcher))
        try:
            second = wired.messaging.send("PR111", "fixer", "new arrival").message
            emitted = await asyncio.wait_for(arrival, timeout=3)
            assert emitted.message_id == second.message_id
        finally:
            if not arrival.done():
                arrival.cancel()
                await asyncio.gather(arrival, return_exceptions=True)

        third = wired.messaging.send("PR111", "fixer", "not taken").message
        # Closing here never advances the iterator to the third message.

    unread = {message.message_id for message in wired.bus.inbox("fixer").page.messages}
    # Watching records nothing: what it emitted stays as unread as what it never reached.
    assert {first.message_id, third.message_id} <= unread
