"""Actual fsynced bus + SQLite response boundaries, default OFF outside opted-in roots."""

from __future__ import annotations

import os
from contextlib import closing
from dataclasses import dataclass, replace
from pathlib import Path

import pytest

from agent_comms.assignment_states import CompletedAssignment
from agent_comms.attempt_start import AttemptStart
from agent_comms.attempt_states import ModelRunningAttempt, PromptAcceptedAttempt, SettlingAttempt
from agent_comms.comms import Comms, wire
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.database import CoordinationStore
from agent_comms.coordination.errors import (
    IdentityConflict,
    StaleFence,
    StaleRevision,
)
from agent_comms.coordination.response import (
    LiveResponseOwner,
    PublicationAppendDispatches,
    prepare_fenced_response,
    publish_fenced_response,
)
from agent_comms.coordination.results import AlreadyApplied
from agent_comms.coordination.tables.executions import (
    ExecutionRecord,
    NoPointedExecution,
    WireOrigin,
)
from agent_comms.coordination.tables.publications import PublicationEvidence, PublicationIntents
from agent_comms.coordination.tables.responses import ResponseObligation
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.execution.selected.source_batch import SelectedSource
from agent_comms.execution_states import CompletedExecution
from agent_comms.lifecycle_capability import Active, Complete
from agent_comms.messaging.message_bus import MessageBus
from agent_comms.nominal.field_codec import AssignmentId, InputId, RootId, ThreadLookup, TurnId
from agent_comms.obligation_states import PendingResponse, PublishedResponse, PublishingResponse
from agent_comms.owner_fence import OwnerFence, prepare_fence_token
from agent_comms.projects.checkouts import Checkout
from agent_comms.publisher import ParticipantPublisher
from agent_comms.registry.registration import Registration
from agent_comms.registry.threads import NativeThread
from agent_comms.storage.typed_table import TypedTable
from bus_record_fixture import prepare_native_comms
from conftest import accept_initial, publish_initial, responder

# Private bus publication requires POSIX owner/mode ancestry; Windows stat
# emulation cannot attest this boundary or exercise its durability contract.
pytestmark = pytest.mark.skipif(os.name != "posix", reason="private bus needs POSIX ownership")


@dataclass
class Fixture:
    comms: Comms
    bus: MessageBus[ParticipantPublisher]
    store: Coordination
    root_id: RootId
    origin_seq: int
    reply_target: str
    owner_lookup: ThreadLookup
    assignment_id: AssignmentId
    fence: OwnerFence
    witness: LiveResponseOwner

    def close(self) -> None:
        self.store.close()


def _ready(tmp_path: Path, *, direct: bool = False, extra_targets: tuple[str, ...] = ()) -> Fixture:
    comms = prepare_native_comms(wire(tmp_path / "wire"))
    for name in ("sender", "owner"):
        comms.registry.declare(
            NativeThread(name, frozenset({'team'}), worktree=Checkout(tmp_path), process_identity=ProcessIdentity.capture(os.getpid()))
        )
    root_id = comms.registry.store.prepare_native_root().namespace
    target = "owner" if direct else "#team"
    original = publish_initial(comms,
        "sender", target, "Need owner to consider and reply."
    )
    original_record = comms.bus.bus.delivery(original.seq)
    assert len(original_record.recipients) == 1
    recipient = original_record.recipients[0]
    bus = responder(comms.root, comms.registry)
    store = Coordination(str(comms.root / "coordination.sqlite3"), clock_ms=lambda: 1_000)
    store.participants.register(
        recipient.recipient_lookup,
        committed=True,
    )
    (assignment,) = accept_initial(comms.bus, root_id, original.seq, store)
    sources = [SelectedSource(assignment.assignment_id, store.assignments, original_record)]
    for extra_target in extra_targets:
        message = publish_initial(comms, "sender", extra_target, "Another original question")
        delivery = comms.bus.bus.delivery(message.seq)
        (extra_assignment,) = accept_initial(comms.bus, root_id, message.seq, store)
        sources.append(SelectedSource(extra_assignment.assignment_id, store.assignments, delivery))
    reply_target = original.exact_reply_target
    assert reply_target is not None
    store.create(
        "exec",
        WireOrigin,
        recipient.recipient_lookup,
        1,
        sources=tuple(sources),
    )
    store.mark_pending("exec", expected_revision=1)
    token = prepare_fence_token()
    first = store.start(
        AttemptStart(
            execution_id="exec",
            attempt_ordinal=1,
            owner_lookup=recipient.recipient_lookup,
            owner_generation=1,
            token=token,
            expected_execution_revision=2,
            expected_pointer_revision=0,
        )
    ).value.fence
    accepted_turn = store.advance(
        first, PromptAcceptedAttempt, expected_pointer_revision=1
    ).value.fence
    model = store.advance(
        accepted_turn, ModelRunningAttempt, expected_pointer_revision=1
    ).value.fence
    final = store.advance(
        model,
        SettlingAttempt,
        expected_pointer_revision=1,
        backend_done=True,
        process_dead=True,
    ).value.fence
    owner, claim_scope = comms.registry.live_owner_with_claim("owner")
    owner, claim_scope = comms.registry.lease_live_turn_with_claim(
        owner, TurnId('005ef9d6f4a78b0d26efd11059aa75c2'), expected_generation=claim_scope
    )
    witness = LiveResponseOwner(thread=owner, claimed_generation=claim_scope)
    return Fixture(
        comms,
        bus,
        store,
        root_id,
        original.seq,
        reply_target,
        recipient.recipient_lookup,
        assignment.assignment_id,
        final,
        witness,
    )


def test_original_routes_prepare_together_and_release_one_attempt_only_after_all_receipts(tmp_path: Path):
    case = _ready(tmp_path, extra_targets=("owner",))
    try:
        batch = case.store.get("exec")
        routes = tuple(row.exact_target for row in batch.require_wire_responses())
        assert set(routes) == {"#team", "sender"}
        assert len(batch.assignments) == 2
        first = prepare_fenced_response(
            case.store, case.bus, case.fence, "Channel questions combined",
            exact_target=routes[0], owner_witness=case.witness,
        ).value
        with pytest.raises(IdentityConflict):
            publish_fenced_response(
                case.store, case.bus, case.fence,
                exact_target=routes[0], owner_witness=case.witness,
            )
        assert not case.store.get("exec").publication_evidence
        assert first.published_message(case.bus.bus) is None
        prepare_fenced_response(
            case.store, case.bus, case.fence, "Direct questions combined",
            exact_target=routes[1], owner_witness=case.witness,
        )
        partial = publish_fenced_response(
            case.store, case.bus, case.fence,
            exact_target=routes[0], owner_witness=case.witness,
        ).value
        assert partial.execution.lifecycle.items_with(Active, partial.execution) and partial.is_current
        assert len(partial.publication_evidence) == 1
        assert all(row.lifecycle.require_engagement() for row in partial.assignments)
        settled = publish_fenced_response(
            case.store, case.bus, case.fence,
            exact_target=routes[1], owner_witness=case.witness,
        ).value
        settled.execution.lifecycle.require(Complete, ValueError("execution must complete"))
        assert not settled.is_current
        assert len(settled.publication_evidence) == 2
        assert all(row.lifecycle.require_completion() for row in settled.assignments)
        assert settled.current_execution_id == NoPointedExecution()
        for route in routes:
            intent, acknowledgement = settled.require_published_evidence(route)
            message = intent.published_message(case.bus.bus)
            assert message is not None
            assert message.reference == acknowledgement.reference and message.target == route
            assert message.answers == tuple(
                assignment.source for assignment in settled.assignments
                if assignment.lifecycle.exact_target == route
            )
    finally:
        case.close()


@pytest.mark.parametrize("direct", [False, True])
def test_real_bus_sql_tx1_exact_reply_tx2_and_lost_ack_replay(tmp_path: Path, direct: bool) -> None:
    case = _ready(tmp_path, direct=direct)
    try:
        result = prepare_fenced_response(
            case.store,
            case.bus,
            case.fence,
            "Response on the original route",
            timestamp=123.5,
            exact_target=case.reply_target, owner_witness=case.witness,
        )
        intent = result.value
        assert intent.exact_target == case.reply_target
        assert type(case.store.get("exec").require_wire_response(case.reply_target).lifecycle) is PublishingResponse
        assert intent.published_message(case.bus.bus) is None
        assert case.comms.bus.bus.revision() == case.origin_seq

        def replay(store):
            return prepare_fenced_response(
                store,
                case.bus,
                case.fence,
                intent.message.body,
                timestamp=intent.message.timestamp,
                exact_target=case.reply_target, owner_witness=case.witness,
            )

        assert isinstance(replay(case.store), AlreadyApplied)
        published = publish_fenced_response(
            case.store, case.bus, case.fence, exact_target=case.reply_target, owner_witness=case.witness
        ).value
        assert type(published.execution.lifecycle) is CompletedExecution
        assert type(published.require_wire_response(case.reply_target).lifecycle) is PublishedResponse
        assert type(published.assignments[0].lifecycle) is CompletedAssignment
        assert ResponseObligation.response_record(published.publication_evidence, case.reply_target).seq == case.origin_seq + 1
        response = intent.published_message(case.bus.bus)
        assert response is not None and response.target == case.reply_target
        assert published == case.store.get("exec")
        case.store.close()
        with Coordination(str(case.comms.root / "coordination.sqlite3")) as reopened:
            assert reopened.get("exec") == published
            with pytest.raises(StaleFence):
                replay(reopened)
        assert case.comms.bus.bus.revision() == case.origin_seq + 1
    finally:
        case.close()


def test_response_requires_exact_same_root_coordinator(tmp_path: Path) -> None:
    case = _ready(tmp_path)
    try:
        with (
            Coordination(str(case.comms.root / "other.sqlite3")) as wrong_database,
            pytest.raises(IdentityConflict),
        ):
            prepare_fenced_response(
                wrong_database, case.bus, case.fence, "not allowed", exact_target=case.reply_target, owner_witness=case.witness
            )
        alien_registry = Registration(tmp_path / "foreign" / "registry.json")
        alien_bus = responder(case.comms.root, alien_registry)
        with pytest.raises(IdentityConflict):
            prepare_fenced_response(
                case.store, alien_bus, case.fence, "not allowed", exact_target=case.reply_target, owner_witness=case.witness
            )
        assert type(case.store.get("exec").require_wire_response(case.reply_target).lifecycle) is PendingResponse
        assert case.comms.bus.bus.revision() == case.origin_seq
    finally:
        case.close()


def test_stale_owner_and_conflicting_payload_cannot_publish(tmp_path: Path) -> None:
    case = _ready(tmp_path)
    try:
        intent = prepare_fenced_response(
            case.store, case.bus, case.fence, "reply", exact_target=case.reply_target, owner_witness=case.witness
        ).value
        with pytest.raises(IdentityConflict):
            prepare_fenced_response(
                case.store, case.bus, case.fence, "DIFFERENT", exact_target=case.reply_target, owner_witness=case.witness
            )
        stale = replace(case.fence, revision=case.fence.revision - 1)
        with pytest.raises(StaleRevision):
            publish_fenced_response(case.store, case.bus, stale, exact_target=case.reply_target, owner_witness=case.witness)
        assert intent.published_message(case.bus.bus) is None
        assert (
            case.store.session._connection.execute(
                "SELECT COUNT(*) FROM publication_append_dispatches"
            ).fetchone()[0]
            == 0
        )
    finally:
        case.close()


@pytest.mark.parametrize("change", ["finish", "stop", "pid", "pid_reuse", "turn", "recipient"])
def test_response_requires_current_exact_live_turn(tmp_path, change):
    """No PID-only or omitted-witness path can turn SQL finality into publication."""
    from agent_comms.coordination.errors import StaleFence

    case = _ready(tmp_path)
    try:
        witness = case.witness
        if change == "finish":
            owner = case.comms.registry.require("owner")
            case.comms.agents.finish_turn(owner.turn_lease)
        elif change == "stop":
            case.comms.registry.unregister("owner")
        elif change == "pid":
            witness = replace(witness, thread=replace(
                witness.thread, process_identity=ProcessIdentity(os.getpid() + 1, 1)
            ))
        elif change == "pid_reuse":
            process = witness.thread.process_identity
            witness = replace(witness, thread=replace(
                witness.thread, process_identity=ProcessIdentity(process.pid, process.start_time + 1)
            ))
        elif change == "turn":
            witness = replace(witness, thread=witness.thread.without_turn())
        else:
            witness = replace(witness, thread=replace(witness.thread, created_at=witness.thread.created_at + 1))
        with pytest.raises(StaleFence):
            prepare_fenced_response(
                case.store, case.bus, case.fence, "must not publish",
                exact_target=case.reply_target, owner_witness=witness,
            )
        assert case.bus.bus.revision() == case.origin_seq
        assert ResponseObligation.response_record(case.store.get("exec").publication_intents, case.reply_target) is None
    finally:
        case.close()


def test_response_answers_the_messages_its_turn_took_in(tmp_path: Path) -> None:
    from uuid import uuid4

    from agent_comms.input_disposition import InputDispositions
    from agent_comms.input_origin import WireInputOrigin

    case = _ready(tmp_path, direct=True)
    try:
        follow_up = case.comms.messaging.send("sender", "owner", "Part 2, mid-turn").message
        lease = case.witness.thread.require_turn_lease()
        inputs = InputDispositions(case.comms.root)
        key = follow_up.bus_key(case.witness.thread)
        text = "Part 2, mid-turn"
        assert inputs.record(
            key, seq=follow_up.seq, owner="owner", claim_scope=lease.claimed_generation,
            target="owner", text=text, origin=WireInputOrigin(case.root_id, follow_up.reference),
        )
        native_id = InputId(uuid4().hex)
        assert inputs.bind(
            key, claim_scope=lease.claimed_generation, turn_id=lease.turn_id,
            native_id=native_id, text=text,
        )
        assert inputs.started(key, turn_id=lease.turn_id, native_id=native_id, text=text)

        intent = prepare_fenced_response(
            case.store, case.bus, case.fence, "Answers both",
            exact_target=case.reply_target, owner_witness=case.witness,
        ).value
        publish_fenced_response(
            case.store, case.bus, case.fence, exact_target=case.reply_target, owner_witness=case.witness
        )
        response = intent.published_message(case.bus.bus)
        assert response is not None
        original = case.bus.bus.delivery(case.origin_seq)
        assert response.answers == (original.message.reference, follow_up.reference)
        with case.bus.bus.reading() as source:
            replies = tuple(source.replies((original.message.reference, follow_up.reference)))
        assert [reply.reference for reply in replies] == [response.reference]
    finally:
        case.close()


@pytest.mark.parametrize('seed', (PublicationIntents, ExecutionRecord), ids=('intent', 'execution'))
@pytest.mark.parametrize('published', (False, True), ids=('frozen-intent', 'published'))
def test_selected_publication_keeps_original_receipts_and_append_dispatches(
    tmp_path: Path, seed: type[TypedTable], published: bool,
) -> None:
    case = _ready(tmp_path)
    try:
        intent = prepare_fenced_response(
            case.store, case.bus, case.fence, 'Original retained publication',
            exact_target=case.reply_target, owner_witness=case.witness,
        ).value
        if published:
            publish_fenced_response(
                case.store, case.bus, case.fence,
                exact_target=case.reply_target, owner_witness=case.witness,
            )
        snapshot = case.store.get(intent.execution_id)
        with case.store.session.read():
            dispatches = tuple(PublicationAppendDispatches.select(
                case.store.session._connection, where='execution_id=?',
                parameters=(intent.execution_id,),
            ))
        assert len(snapshot.publication_evidence) == int(published)
        assert len(dispatches) == int(published)
        source = case.store.session.path
        before = CoordinationStore.digest(source)
        bus_revision = case.bus.bus.revision()
        destination = tmp_path / 'retained-publication' / 'coordination.sqlite3'
        with CoordinationStore.retaining_rows(
            source, destination, maximum_bytes=8 * 2**20,
        ) as original:
            original.retain_keys(seed, ({'execution_id': intent.execution_id},))
        with closing(CoordinationStore.read_snapshot(destination)) as db:
            assert tuple(PublicationIntents.select(db)) == snapshot.publication_intents
            assert tuple(PublicationEvidence.select(db)) == snapshot.publication_evidence
            assert tuple(PublicationAppendDispatches.select(db)) == dispatches
        assert CoordinationStore.digest(source) == before
        assert case.bus.bus.revision() == bus_revision
    finally:
        case.close()
