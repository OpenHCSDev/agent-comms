import sys

from agent_comms.cli_bridges.claude_transcript import RunningClaude
from agent_comms.context_segments.native_messages import TranscriptSegment

"""One query contract over the original native and external record owners."""

import asyncio
import hashlib
import io
import json
import os
from contextlib import aclosing, redirect_stdout, suppress
from datetime import datetime, timedelta

import pytest

from agent_comms.bus import Bus
from agent_comms.cli import CliInvocation
from agent_comms.cli_bridges.claude import ClaudeBridge
from agent_comms.cli_bridges.shared import Binding, Options, Serve, StoredBinding, Watch
from agent_comms.comms import wire
from agent_comms.context_segments.wake import SelectedWakeSegment
from agent_comms.context_store import ContextEntry
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.execution.native_session_reopen import PiSessionId
from agent_comms.execution.turn_context import (
    JournalProvenance,
    SegmentManifest,
    UserInputSegment,
    WireProvenance,
)
from agent_comms.execution.turn_bound import (
    LastTurns,
    TurnBound,
    TurnsBefore,
    TurnsOlderThan,
    TurnsSince,
)
from agent_comms.execution.turn_item import NativeItemId, NativeTurnId
from agent_comms.external_transcript import NoEarlierPage
from agent_comms.nominal.field_codec import FieldCodec
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import ExternalThread, NativeThread
from agent_comms.runtime_updates import FinishedItem
from agent_comms.session_file import RegistrySessionLocation
from agent_comms.transcript_events import AssistantTranscript, TurnDigest
from agent_comms.watched import FileSource
from agent_comms_hooks import ToolRefusedError
from transcript_record_fixture import transcript_record


def endpoint(comms, name, window, *, detail='activity'):
    """The comms_turns tool through the command line's dispatcher; the conftest already clears a
    managed runtime's environment, and test_cli proves the console script around it."""
    output = io.StringIO()
    with redirect_stdout(output):
        code = CliInvocation().invoke(['--root', str(comms.root), 'tool', '--tool', 'comms_turns', '--arguments',
                     json.dumps(dict(thread=name, window=FieldCodec.encode(window), detail=detail))], sys.stdout)
    assert code == 0, output.getvalue()
    return json.loads(output.getvalue())


def paged_answers(comms, name):
    window = LastTurns(100)
    seen = set()
    while True:
        answer = endpoint(comms, name, window, detail='original')
        older = FieldCodec.decode(TurnBound, answer['older'])
        if not answer['turns']:
            assert older == window
            return
        assert older != window
        assert older.count == 100
        identities = [turn['turn_id'] for turn in answer['turns']]
        assert not seen.intersection(identities)
        assert len(identities) == len(set(identities))
        seen.update(identities)
        yield answer
        window = older


def test_external_turns_preserve_interleaving_and_the_whole_selected_turn(tmp_path):
    old_turn_id = NativeTurnId('old')
    one_turn_id = NativeTurnId('one')
    two_turn_id = NativeTurnId('two')
    comms = wire(tmp_path)
    comms.registry.declare(ExternalThread('cli', frozenset(), Checkout(tmp_path)))
    source = comms.transcripts.external('cli')
    for at, (turn, item, text) in enumerate([
            (old_turn_id, 'a', 'older'), (one_turn_id, 'b', 'first'),
            (two_turn_id, 'c', 'other'), (one_turn_id, 'd', 'continued')], start=1):
        source.finish(
            turn_id=turn,
            item_id=NativeItemId(item),
            events=(
                AssistantTranscript(
                    text, position=FieldCodec.decode(int | NativeItemId, item), timestamp=float(at)
                ),
            ),
        )
    answer = endpoint(comms, 'cli', LastTurns(2))
    assert [turn['turn_id'] for turn in answer['turns']] == ['two', 'one']
    assert [event['text'] for event in answer['turns'][0]['events']] == ['other']
    assert [event['text'] for event in answer['turns'][1]['events']] == ['first', 'continued']
    first = endpoint(comms, 'cli', LastTurns(1))
    second = endpoint(comms, 'cli', FieldCodec.decode(TurnBound, first['older']))
    third = endpoint(comms, 'cli', FieldCodec.decode(TurnBound, second['older']))
    assert [page['turns'][0]['turn_id'] for page in (first, second, third)] == ['two', 'one', 'old']
    before = endpoint(comms, 'cli', TurnsBefore(at=3.0, count=2))
    assert [turn['turn_id'] for turn in before['turns']] == ['one', 'old']
    since = endpoint(comms, 'cli', TurnsSince(3.0))
    assert [turn['turn_id'] for turn in since['turns']] == ['two', 'one']


def test_native_turns_keep_original_calls_results_and_input_identity(tmp_path):
    comms = wire(tmp_path)
    source = tmp_path / 'native.jsonl'
    evidence = 'saved evidence ' + 'x' * 49648
    rows = [
        dict(type='session', id='source', version=3, timestamp='2026-10-16T12:00:00Z'),
        dict(type='message', id='u1', timestamp='2026-10-16T12:00:00Z',
             message=dict(role='user', content='old input')),
        dict(type='message', id='a1', parentId='u1', timestamp='2026-10-16T12:00:01Z', message=dict(
            role='assistant', content=[dict(type='text', text='old answer')], stopReason='stop')),
        dict(type='message', id='u2', parentId='a1', timestamp='2026-10-16T12:00:02Z',
             message=dict(role='user', content='read file')),
        dict(type='message', id='call', parentId='u2', timestamp='2026-10-16T12:00:03Z', message=dict(
            role='assistant', content=[dict(type='toolCall', id='read-1', name='read',
                                            arguments=dict(path='x.py'))], stopReason='toolUse')),
        dict(type='message', id='result', parentId='call', timestamp='2026-10-16T12:00:04Z', message=dict(
            role='toolResult', toolCallId='read-1', toolName='read', isError=False,
            content=[dict(type='text', text=evidence)])),
        dict(type='message', id='a2', parentId='result', timestamp='2026-10-16T12:00:05Z', message=dict(
            role='assistant', content=[dict(type='text', text='done')], stopReason='stop')),
    ]
    source.write_text(''.join(json.dumps(row) + '\n' for row in rows))
    source.chmod(0o600)
    comms.registry.declare(NativeThread('native', frozenset(), Checkout(tmp_path), session_file=RegistrySessionLocation.from_path(str(source), comms.root)))
    saved = source.read_bytes()
    activity = endpoint(comms, 'native', LastTurns(1))
    shown, = activity['turns']
    assert [event['kind'] for event in shown['events']] == ['user', 'assistant']
    call, = shown['calls_started']
    assert (call['tool_call_id'], call['state']) == ('read-1', 'succeeded')
    assert shown['original_event_count'] == 4
    assert evidence not in json.dumps(activity)
    answer = endpoint(comms, 'native', LastTurns(1), detail='original')
    turn, = answer['turns']
    assert turn['turn_id'] == 'u2'
    assert [event['kind'] for event in turn['events']] == ['user', 'tool_start', 'tool_end', 'assistant']
    assert turn['events'][1]['raw_input'] == dict(path='x.py')
    assert turn['events'][2]['text'] == evidence
    assert turn['events'][3]['text'] == 'done'
    assert [turn.turn_id for turn in comms.transcripts.turns('native', LastTurns(2)).turns] == ['u2', 'u1']
    older = FieldCodec.decode(TurnBound, answer['older'])
    assert [turn['turn_id'] for turn in endpoint(comms, 'native', older)['turns']] == ['u1']
    assert source.read_bytes() == saved


@pytest.mark.parametrize('original_in_body', (False, True))
def test_woken_native_turn_reads_its_selected_messages_not_the_stored_frame(tmp_path, original_in_body):
    comms = wire(tmp_path)
    source = tmp_path / 'native.jsonl'
    frame = '── comms: 1 selected ──\nselected: [...]\n── reply relevance ──\nAnswer direct requests.'
    rows = [
        dict(type='session', id='source', version=3, timestamp='2026-10-16T12:00:00Z'),
        dict(type='message', id='u1', timestamp='2026-10-16T12:00:00Z',
             message=dict(role='user', content=frame)),
        dict(type='message', id='a1', parentId='u1', timestamp='2026-10-16T12:00:01Z', message=dict(
            role='assistant', content=[dict(type='text', text='None are left.')], stopReason='stop')),
    ]
    source.write_text(''.join(json.dumps(row) + '\n' for row in rows))
    source.chmod(0o600)
    comms.registry.declare(NativeThread('colleague', frozenset(), Checkout(tmp_path)))
    comms.registry.declare(NativeThread('native', frozenset(), Checkout(tmp_path), session_file=RegistrySessionLocation.from_path(str(source), comms.root)))
    asked = comms.messaging.send('colleague', 'native', 'How many opens are left?').message
    sent_outcome = comms.messaging.send('native', 'colleague', 'An earlier answer.').message
    digest = hashlib.sha256(frame.encode()).hexdigest()
    # Historical frames own their original references; new frames leave those
    # references with the per-message body. Both reconstruct the same history.
    frame_sources = (() if original_in_body else (WireProvenance(asked.reference),))
    wake = SegmentManifest(kind=SelectedWakeSegment,
                           provenance=(*frame_sources, WireProvenance(sent_outcome.reference)), sha256=digest, utf8_bytes=1, tokens=1)
    originals = (UserInputSegment(
        provenance=(WireProvenance(asked.reference),), content=asked.body,
    ).manifest(0),) if original_in_body else ()
    entry = SegmentManifest(kind=TranscriptSegment, provenance=(JournalProvenance(str(source), ('u1',)),),
                            sha256=digest, utf8_bytes=len(frame), tokens=1, contributors=(wake, *originals))
    with comms.contexts.writing() as db:
        ContextEntry(
            PiSessionId("source"), str(source), NativeItemId("u1"), entry
        ).insert_if_absent(db)
    turn, = endpoint(comms, 'native', LastTurns(1))['turns']
    assert [(event['kind'], event['message']['text'] if 'message' in event else event['text'])
            for event in turn['events']] == [
        ('incoming', 'How many opens are left?'), ('assistant', 'None are left.')]
    assert turn['events'][0]['source'] == FieldCodec.encode(asked.reference)
    assert json.loads(source.read_text().splitlines()[1])['message']['content'] == frame


@pytest.fixture
def recorded_claude_transcript(tmp_path):
    path = tmp_path / 'home/.claude/projects/fixture/session.jsonl'
    path.parent.mkdir(parents=True)
    start = datetime.fromisoformat('2026-10-16T12:00:00+00:00')
    rows = []
    for index in range(251):
        times = [(start + timedelta(seconds=index * 4 + phase)).isoformat() for phase in range(4)]
        prompt_id, call_id = f'prompt-{index}', f'read-{index}'
        rows.extend((
            dict(type='user', uuid=transcript_record(f'prompt-record-{index}'), promptId=prompt_id, timestamp=times[0],
                 origin=dict(kind='human'), message=dict(content='read file')),
            dict(type='assistant', uuid=transcript_record(f'call-record-{index}'), timestamp=times[1],
                 message=dict(content=[dict(type='tool_use', id=call_id, name='read', input=dict(path='x.py'))])),
            dict(type='user', uuid=transcript_record(f'result-record-{index}'), promptId=prompt_id, timestamp=times[2],
                 message=dict(content=[dict(type='tool_result', tool_use_id=call_id, content='contents')])),
            dict(type='assistant', uuid=transcript_record(f'final-record-{index}'), timestamp=times[3],
                 message=dict(content=[dict(type='text', text='done')])),
        ))
        final = rows[-1]
        rows.append(dict(type='system', subtype='turn_duration',
                         uuid=transcript_record(f'end-record-{index}'), timestamp=times[3]))
    path.write_text(''.join(json.dumps(row) + '\n' for row in rows))
    return path, final


@pytest.mark.parametrize('empty_index', (152, 52))
def test_recorded_claude_transcript_pages_through_tool_without_loss(tmp_path, monkeypatch, recorded_claude_transcript, empty_index):
    undated_edge_turn_id = NativeTurnId('undated-edge')
    path, final = recorded_claude_transcript
    monkeypatch.setenv('HOME', str(tmp_path / 'home'))
    comms = wire(tmp_path / 'wire')
    comms.registry.declare(ExternalThread('claude', frozenset(), Checkout(tmp_path)))
    state = tmp_path / 'state'
    store = Binding.open(state)
    db = store.__enter__()
    binding = Binding(root=str(comms.root), owner=comms.registry.require('claude').incarnation,
                      thread='session', start=Binding.bus_head(str(comms.root)))
    with pytest.raises(ValueError):
        Watch().transcript_source()
    operation = Serve(owner=ProcessIdentity.capture(os.getpid()), transcript=path)
    bridge = ClaudeBridge(Options(operation, StoredBinding(), state, state.parent), binding.address(), db)

    async def publish():
        await operation.prepare(bridge)
        task = asyncio.create_task(bridge.publish_transcript())
        source = comms.transcripts.external('claude')
        try:
            async with asyncio.timeout(60):
                async with aclosing(Bus.watch_sources(*(
                        FileSource(item) for item in source.source_paths(comms.root)))) as changes:
                    async for _ in changes:
                        turns = await asyncio.to_thread(comms.transcripts.turns, 'claude', LastTurns())
                        if any(event == AssistantTranscript(
                                'done', position=event.position,
                                timestamp=datetime.fromisoformat(final['timestamp']).timestamp(),
                        ).with_publications(()) for turn in turns.turns for event in turn.events):
                            break
        finally:
            task.cancel()
            with suppress(asyncio.CancelledError):
                await task
            store.__exit__(None, None, None)

    asyncio.run(publish())
    # Keep the original bridge recording intact. Publish its real recorded events to
    # a second isolated transcript with one eventless harness item at the page edge.
    recorded = comms.transcripts.external('claude').turns(LastTurns(300))
    comms.registry.declare(ExternalThread('paged', frozenset(), Checkout(tmp_path)))
    items = [
        FinishedItem(turn_id=turn.turn_id, item_id=NativeItemId(turn.turn_id), events=turn.events)
        for turn in reversed(recorded)
    ]
    items.insert(empty_index, FinishedItem(turn_id=undated_edge_turn_id, item_id=NativeItemId('undated-edge'), events=()))
    comms.transcripts.external('paged').publish_page(items, NoEarlierPage())
    pages = list(paged_answers(comms, 'paged'))
    seen = [turn['turn_id'] for page in pages for turn in page['turns']]
    expected = [item.turn_id for item in reversed(items)]
    assert seen == expected
    assert len(seen) == 252
    edge = seen.index('undated-edge')
    assert edge in (99, 199)
    assert pages[edge // 100]['turns'][-1]['turn_id'] == 'undated-edge'
    assert pages[edge // 100]['turns'][-1]['events'] == []
    sizes = [len(page['turns']) for page in pages]
    assert sizes == [100, 100, 52]
    turn = pages[-1]['turns'][0]
    assert turn['turn_id'] == transcript_record('prompt-record-51')
    assert [event['kind'] for event in turn['events']] == ['user', 'tool_start', 'tool_end', 'assistant']
    assert turn['events'][1]['raw_input'] == dict(path='x.py')
    assert turn['events'][2]['text'] == 'contents'
    assert turn['events'][3]['text'] == 'done'


def test_missing_native_session_is_empty_and_nonpositive_count_is_rejected(tmp_path):
    missing_turn_id = NativeTurnId('missing')
    comms = wire(tmp_path)
    comms.registry.declare(NativeThread('new', frozenset(), Checkout(tmp_path)))
    for window in (LastTurns(), TurnsBefore(at=1.0, count=100), TurnsSince(1.0)):
        answer = comms.transcripts.turns('new', window)
        assert not answer.turns
        assert answer.older is window
    for window in (LastTurns(), TurnsBefore(at=1.0), TurnsOlderThan(turn_id=missing_turn_id)):
        with pytest.raises(ValueError):
            FieldCodec.decode(TurnBound, {**FieldCodec.encode(window), 'count': 0})
    with pytest.raises(ToolRefusedError):
        comms.transcripts.turns('new', TurnsOlderThan(turn_id=missing_turn_id))


@pytest.mark.parametrize('events', ((), (AssistantTranscript('same time', position=1, timestamp=1.0),)))
def test_undated_and_equal_time_transcripts_page_without_timestamp_assumptions(tmp_path, events):
    comms = wire(tmp_path)
    comms.registry.declare(ExternalThread('undated', frozenset(), Checkout(tmp_path)))
    items = tuple(FinishedItem(turn_id=NativeTurnId(f'undated-{index}'), item_id=NativeItemId(f'item-{index}'),
        events=events) for index in range(251))
    comms.transcripts.external('undated').publish_page(items, NoEarlierPage())
    pages = list(paged_answers(comms, 'undated'))
    seen = [turn['turn_id'] for page in pages for turn in page['turns']]
    assert seen == [item.turn_id for item in reversed(items)]
    assert [len(page['turns']) for page in pages] == [100, 100, 51]


def test_turn_windows_distinguish_first_and_last_event_time():
    crossing_turn_id = NativeTurnId('crossing')
    empty_turn_id = NativeTurnId('empty')
    turn = TurnDigest(crossing_turn_id, (
        AssistantTranscript('start', position=1, timestamp=1.0),
        AssistantTranscript('finish', position=2, timestamp=3.0),
    ))
    assert turn.starts_before(2.0)
    assert not turn.before(2.0)
    assert TurnsBefore(at=2.0, count=1).take((turn,)) == (turn,)
    assert TurnsSince(2.0).take((turn,)) == (turn,)
    assert not TurnDigest(empty_turn_id, ()).starts_before(2.0)
    assert not TurnsBefore(at=1.0, count=1).take((turn,))


def test_a_restarted_session_reads_the_transcript_claude_is_writing(tmp_path, monkeypatch):
    """A restart in another working directory leaves the session's transcript in two project
    directories; the running session is the newer one, and no match at all still refuses."""

    monkeypatch.setenv('HOME', str(tmp_path))
    projects = tmp_path / '.claude/projects'
    with pytest.raises(ValueError, match='No Claude transcript for session'):
        RunningClaude('session')
    older, newer = projects / 'before/session.jsonl', projects / 'after/session.jsonl'
    for path, written in ((older, 1_000), (newer, 2_000)):
        path.parent.mkdir(parents=True)
        path.write_text('')
        os.utime(path, (written, written))
    assert RunningClaude('session').source == newer
