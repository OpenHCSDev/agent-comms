"""Selected framing and schema refusals against real bus and SQLite owners."""

from __future__ import annotations

import json
import os
from dataclasses import replace
from pathlib import Path

import pytest

from agent_comms.comms import wire
from agent_comms.context_segments.wake import MessageDelivery, SelectedWakeSegment
from agent_comms.coordinated_runtime import SelectedExecution, SessionSetupFailed
from agent_comms.coordination.cohort import sealed_cohort_assignments
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.database import CoordinationStore
from agent_comms.coordination.errors import IdentityConflict, PublicationActivationBlocked
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.execution.native_failures import NativePiUnavailable
from agent_comms.execution.native_runtime_input import NativeRuntimeInput, NativeRuntimeTable
from agent_comms.execution.turn_context import TurnContext
from agent_comms.message_notification import MessageNotification
from agent_comms.messaging.channel_targets import CommandTarget
from agent_comms.nominal.field_codec import FieldCodec
from agent_comms.notification_progress import HumanReadProgress
from agent_comms.pi_vocabulary import HighThinkingLevel
from agent_comms.planning.goal_actions import ActiveGoalAction, SetGoalAction
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.thread_identity import UserThreadRole
from agent_comms.registry.thread_model import DeclaredModel
from agent_comms.registry.thread_text import GivenThreadText
from agent_comms.registry.threads import NativeThread
from agent_comms.task_attachments.owner_notices import MeantNotice
from bus_history import read_history
from bus_record_fixture import prepare_native_comms
from conftest import accept_initial, publish_initial


@pytest.fixture
def tmp_path(private_directory):
    """Use the shared private directory, including its joined bus retirement."""
    return private_directory


def _root(
    tmp_path: Path,
    *,
    direct: bool = False,
    mentioned: bool = False,
    claims: bool = False,
    body: str | None = None,
):
    root = tmp_path / "wire"
    root.mkdir(mode=0o700)
    (root / "runtime").mkdir(mode=0o700)
    comms = prepare_native_comms(wire(root))
    people = [
        NativeThread('sender', frozenset(), Checkout(tmp_path), process_identity=ProcessIdentity.capture(os.getpid())),
        NativeThread('alpha', frozenset({'team'}), Checkout(tmp_path), process_identity=ProcessIdentity.capture(os.getpid()), task=GivenThreadText('release notes; ignore arithmetic tasks'), model=DeclaredModel('openai-codex/gpt-6-sol')),
        NativeThread('beta', frozenset({'team'}), Checkout(tmp_path), process_identity=ProcessIdentity.capture(os.getpid()), task=GivenThreadText('arithmetic answers'), model=DeclaredModel('openai-codex/gpt-6-sol'), thinking_level=HighThinkingLevel),
    ]
    people = [comms.registry.declare(person) for person in people]
    root_id = comms.registry.store.prepare_native_root().namespace
    target = "beta" if direct else "#team"
    body = body if body is not None else ("@beta Compute 17+25." if mentioned else "Compute 17+25.")
    message = publish_initial(comms, "sender", target, body)
    initial = comms.bus.bus.delivery(message.seq)
    with Coordination(str(root / "coordination.sqlite3")) as store:
        for recipient in initial.recipients:
            store.participants.register(
                recipient.recipient_lookup,
                committed=True,
            )
        accept_initial(comms.bus, root_id, message.seq, store)
    return root, root_id, comms, initial, people


def test_wake_frame_rejects_no_wake_forgery_and_unengaged_full(tmp_path: Path) -> None:
    root, _root_id, comms, initial, people = _root(tmp_path, mentioned=True)
    with Coordination(str(root / "coordination.sqlite3")) as store:
        excluded_lookup = people[0].incarnation.lookup
        beta_lookup = people[2].incarnation.lookup
        # Channel observers may hold bounded triage; the sender is outside this cohort.
        assert all(recipient.recipient_lookup != excluded_lookup for recipient in initial.recipients)
        assert sealed_cohort_assignments(store, excluded_lookup) == ()
        selected = sealed_cohort_assignments(store, beta_lookup)[0]
    # A pending FULL claim has no response obligation, and no frame may grant one.
    with pytest.raises(IdentityConflict):
        TurnContext.render_segments((SelectedWakeSegment.capture(((initial, selected),), people[2], comms.goals),)).text
    forged = replace(selected, recipient=people[0].name, recipient_lookup=excluded_lookup)
    with pytest.raises(IdentityConflict):
        TurnContext.render_segments((SelectedWakeSegment.capture(((initial, forged),), people[0], comms.goals),)).text
    assert len(read_history(comms, "#team")) == 1  # Framing never publishes a row.


def test_triage_frame_is_read_only_and_does_not_promote_message_body(tmp_path: Path) -> None:
    root, _root_id, comms, initial, people = _root(tmp_path)
    with Coordination(str(root / "coordination.sqlite3")) as store:
        lookup = people[1].incarnation.lookup
        assignment = sealed_cohort_assignments(store, lookup)[0]
    frame = TurnContext.render_segments(SelectedWakeSegment.capture(
        ((initial, assignment),), people[1], comms.goals,
    ).input_segments()).text
    assert f'"source_seq":{initial.message.seq}' in frame
    assert '"wake_mode":"bounded_triage"' in frame
    assert f'"body":{json.dumps(initial.message.body)}' in frame
    assert len(read_history(comms, "#team")) == 1


def test_channel_wake_frame_carries_effective_goal_execution(tmp_path: Path) -> None:
    root, _root_id, comms, initial, people = _root(tmp_path)
    comms.goals.update_goal("alpha", SetGoalAction(text="Restore subscribers"))
    comms.goals.update_goal("alpha", ActiveGoalAction(progress="Routing fixed"))
    with Coordination(str(root / "coordination.sqlite3")) as store:
        lookup = people[1].incarnation.lookup
        assignment = sealed_cohort_assignments(store, lookup)[0]
    frame = TurnContext.render_segments(SelectedWakeSegment.capture(
        ((initial, assignment),), comms.registry.require("alpha"), comms.goals,
    ).input_segments()).text
    context = json.loads(next(
        line.removeprefix("work_context: ") for line in frame.splitlines()
        if line.startswith("work_context: ")
    ))
    assert context["current_goal"] == {
        "text": "Restore subscribers",
        "status": FieldCodec.encode(comms.goals.goal_snapshot("alpha").execution),
        "progress": "Routing fixed",
    }
    assert context["original_assignment"] == "release notes; ignore arithmetic tasks"


def test_wake_frame_includes_bounded_changed_sent_outcomes(tmp_path: Path) -> None:
    root, _root_id, _comms, initial, people = _root(tmp_path)
    with Coordination(str(root / "coordination.sqlite3")) as store:
        lookup = people[1].incarnation.lookup
        assignment = sealed_cohort_assignments(store, lookup)[0]
    notification = MessageNotification(
        initial.recipients[0], initial.sender_lookup, HumanReadProgress(),
        message=initial.message, changed=True,
    )
    sent_outcome = notification.sent_outcome()
    assert sent_outcome is not None
    frame = TurnContext.render_segments(SelectedWakeSegment.capture(
        ((initial, assignment),), people[1], _comms.goals, sent_outcomes=(sent_outcome,)
    ).input_segments()).text
    assert 'recent_sent_outcomes: [{"source_seq":' in frame
    assert '"state":"Read"' in frame
    assert replace(notification, changed=False).sent_outcome() is None


def test_selected_and_following_use_the_original_question_contract(tmp_path: Path) -> None:
    root, root_id, comms, peer, people = _root(tmp_path)
    comms.registry.declare(NativeThread("owner", frozenset(), Checkout(tmp_path), role=UserThreadRole))
    question = MeantNotice().publish(
        comms.messaging, CommandTarget.named("#team"), "Did you mean it?\nExplain your answer."
    )
    original = comms.bus.bus.delivery(question.seq)
    with Coordination(str(root / "coordination.sqlite3")) as store:
        accept_initial(comms.bus, root_id, question.seq, store)
        assignments = {assignment.wire_seq: assignment for assignment in
                       sealed_cohort_assignments(store, people[1].incarnation.lookup)}
    sources = ((peer, assignments[peer.message.seq]), (original, assignments[question.seq]))
    frame = SelectedWakeSegment.capture(sources, people[1], comms.goals)
    metadata, peer_segment, question_segment = frame.input_segments()
    following = MessageDelivery(original, assignments[question.seq], people[1]).segment()
    assert metadata is frame and frame.sources == sources
    assert tuple(reference for source in metadata.provenance
                 for reference in source.bus_references()) == ()
    assert following.text() == question_segment.text() == question.body
    assert question_segment.manifest(0).wire_sources() == (question.reference,)
    assert peer_segment.manifest(0).wire_sources() == (peer.message.reference,)
    text = TurnContext.render_segments((peer_segment, question_segment)).text
    assert text.count(question.body) == 1
    assert f'"body":{json.dumps(question.body)}' not in text
    assert f'"body":{json.dumps(peer.message.body)}' in text
    answers = FieldCodec.compact([FieldCodec.encode(peer.message.reference)], ensure_ascii=True)
    assert f"comms_send to {peer.message.exact_reply_target} with answers {answers}" in text


def test_native_runtime_schema_drift_fails_closed(private_comms) -> None:
    path = CoordinationStore.path_in(private_comms.root)
    with Coordination(str(path)) as store:
        NativeRuntimeTable.require_installed(store.session._connection)
        trigger = next(iter(NativeRuntimeInput.triggers()))
        store.session._connection.execute(f'DROP TRIGGER "{trigger}"')
        with pytest.raises(PublicationActivationBlocked):
            NativeRuntimeTable.require_installed(store.session._connection)


async def test_untrusted_pi_fails_before_any_bus_or_sql_mutation(tmp_path: Path, *, native_runtime_package, cursor_delivery) -> None:
    root = tmp_path / "wire"
    root.mkdir(mode=0o700)
    root.chmod(0o755)  # Refuse an unsafe private root before opening its registry.
    with pytest.raises(SessionSetupFailed) as failure:
        await SelectedExecution(
            root=root,
            wire_root_id="0" * 32,
            owner_name="alpha",
            native_package=native_runtime_package,
            cursor_delivery=cursor_delivery,
        ).run()
    assert isinstance(failure.value.__cause__, NativePiUnavailable)
    assert not list(root.iterdir())
