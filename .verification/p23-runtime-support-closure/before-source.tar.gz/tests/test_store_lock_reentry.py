"""Physical locking, not fake store objects: nesting must keep outsiders out."""

import asyncio
import fcntl
import subprocess
import sys
from contextvars import copy_context
from pathlib import Path

import pytest

from agent_comms.errors import RelationViolationError
from agent_comms.storage.store_files import (
    BoundedStoreReadBudget,
    ExclusiveLock,
    SharedLock,
    StoreGuard,
    StoreLockContention,
    _async_store_lock,
    _store_lock,
    store_lock_path,
)


def probe(path, *, shared=True):
    """A fresh interpreter cannot inherit our process-local acquisition context."""
    result = subprocess.run([
        sys.executable, '-c',
        'import fcntl,sys\n'
        'with open(sys.argv[1], "rb") as stream:\n'
        ' try: fcntl.flock(stream, int(sys.argv[2]) | fcntl.LOCK_NB)\n'
        ' except BlockingIOError: sys.exit(73)\n',
        str(store_lock_path(path)), str(fcntl.LOCK_SH if shared else fcntl.LOCK_EX),
    ], capture_output=True, text=True, timeout=5)
    assert result.returncode in (0, 73), result.stderr
    return result.returncode == 0


def test_nested_reader_reuses_descriptor_without_downgrading_or_releasing(tmp_path):
    path = tmp_path / 'wire'
    with _store_lock(path, ExclusiveLock(), StoreGuard.contention) as outer:
        with pytest.raises(ValueError):
            with _store_lock(path, SharedLock(), StoreLockContention(0)) as inner:
                assert inner.descriptor == outer.descriptor
                links = []
                for descriptor in Path('/proc/self/fd').iterdir():
                    try:
                        links.append(descriptor.readlink())
                    except FileNotFoundError:
                        pass
                assert links.count(store_lock_path(path)) == 1
                assert not probe(path)
                raise ValueError('consumer failed')
        assert not probe(path)
    assert probe(path, shared=False)


def test_shared_nesting_never_silently_upgrades(tmp_path):
    path = tmp_path / 'wire'
    with _store_lock(path, SharedLock(), StoreGuard.contention) as outer:
        with _store_lock(path, SharedLock(), StoreGuard.contention) as inner:
            assert inner.descriptor == outer.descriptor
            assert probe(path)
            assert not probe(path, shared=False)
        with pytest.raises(RelationViolationError):
            with _store_lock(path, ExclusiveLock(), StoreGuard.contention):
                pytest.fail('upgraded the enclosing read transaction')
    assert probe(path, shared=False)


def test_ended_context_does_not_reuse_its_closed_descriptor(tmp_path):
    path = tmp_path / 'wire'
    with _store_lock(path, ExclusiveLock(), StoreGuard.contention):
        retained = copy_context()
    def capture_again():
        with _store_lock(path, ExclusiveLock(), StoreGuard.contention):
            assert not probe(path)
    retained.run(capture_again)
    assert probe(path, shared=False)


def test_nested_source_still_checks_each_borrows_budget(tmp_path):
    path = tmp_path / 'wire'
    path.write_bytes(b'not within the nested budget')
    with _store_lock(path, ExclusiveLock(), StoreGuard.contention):
        with pytest.raises(RelationViolationError):
            with _store_lock(path, SharedLock(), StoreGuard.contention, read_budget=BoundedStoreReadBudget(1)):
                pytest.fail('nested source skipped its read budget')
        assert not probe(path)
    assert probe(path, shared=False)


def test_async_and_sync_nest_but_independent_tasks_and_threads_do_not(tmp_path):
    path = tmp_path / 'wire'
    async def independent():
        with pytest.raises(BlockingIOError):
            async with _async_store_lock(path, SharedLock(), StoreLockContention(0)):
                pytest.fail('another task borrowed an exclusive transaction')
    def thread_reader():
        with pytest.raises(BlockingIOError):
            with _store_lock(path, SharedLock(), StoreLockContention(0)):
                pytest.fail('another thread borrowed an exclusive transaction')
    async def run():
        async with _async_store_lock(path, ExclusiveLock(), StoreGuard.contention) as outer:
            async with _async_store_lock(path, SharedLock(), StoreGuard.contention) as inner:
                assert inner.descriptor == outer.descriptor
                with _store_lock(path, SharedLock(), StoreGuard.contention) as synchronous:
                    assert synchronous.descriptor == outer.descriptor
                assert not probe(path)
            await asyncio.create_task(independent())
            await asyncio.to_thread(thread_reader)
            assert not probe(path)
        assert probe(path, shared=False)
    asyncio.run(run())
