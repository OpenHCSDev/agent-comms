"""A new history declaration crosses real current and retained-source boundaries."""

from agent_comms.historical_views import HistoryView
from agent_comms.messaging.message_page import PageBounds
from agent_comms.nominal.field_codec import TurnId
from agent_comms.projects.checkouts import Checkout
from agent_comms.messaging.read_basis import ChannelDisplayScope, NoDisplaySelection
from agent_comms.registry.threads import NativeThread
from conftest import installed_comms


class ReviewHistory(HistoryView):
    def capture(self, snapshot):
        return ChannelDisplayScope("#review", frozenset({"#review"}))


def test_new_history_case_owns_both_source_interpretations_without_reader_dispatch(tmp_path, *, thread_registration):
    roots = [installed_comms(tmp_path / name) for name in ("prior", "current")]
    for comms in roots:
        comms.registry.declare(NativeThread('writer', frozenset({'review', 'other'}), Checkout(comms.root)))
        for number in range(3):
            comms.messaging.send("writer", "#review", f"{comms.root.name} {number}")
            comms.messaging.send("writer", "#other", f"excluded {number}")
    prior, current = roots
    original = prior.bus.bus.revision()
    current.views.attach_history(prior.root)
    view = ReviewHistory()
    page = view.page(current.views.presentation, PageBounds(limit=2))
    assert [m.body for m in page.messages] == ["current 1", "current 2"]
    backwards = list(page.messages)
    while page.has_older:
        page = view.page(current.views.presentation, PageBounds(page.oldest_cursor.older(), 2))
        backwards[0:0] = page.messages
    assert len(backwards) == 6
    forward = []
    cursor = backwards[0].view_cursor
    while True:
        page = view.page(current.views.presentation, PageBounds(cursor.newer(), 2))
        forward.extend(page.messages)
        if not page.has_newer:
            break
        cursor = page.newest_cursor
    assert [m.view_key for m in forward] == [m.view_key for m in backwards[1:]]
    assert isinstance(page.selection, NoDisplaySelection)
    assert prior.bus.bus.revision() == original
    assert current.bus.bus.revision() == 6
    assert not (prior.root / "read_ledger.json").exists()


def test_viewer_snapshot_exposes_actual_active_channel_participant(tmp_path):
    from test_coordinated_runtime import _root

    _path, _root_id, comms, _initial, _people = _root(tmp_path)
    lease = comms.agents.begin_turn("beta", TurnId('2863939642c6213365179d5204d162ce')).turn_lease
    try:
        snapshot = comms.views.viewer_snapshot(Checkout(comms.root))
        assert [person.thread.name for person in snapshot.participants("#team")] == ["beta"]
        assert snapshot.participants("#team")[0].presentation.status.working
    finally:
        comms.agents.finish_turn(lease)
    assert comms.views.viewer_snapshot(Checkout(comms.root)).participants("#team") == ()


def test_joined_declarations_decode_one_sql_snapshot_and_reject_foreign_columns():
    import sqlite3
    from dataclasses import dataclass

    import pytest

    from agent_comms.storage.typed_table import TypedRow

    @dataclass(frozen=True)
    class Label(TypedRow):
        label: str

    @dataclass(frozen=True)
    class Ready(TypedRow):
        ready: bool

    with sqlite3.connect(":memory:") as connection:
        assert Label.joined(connection.execute("SELECT 'saved' AS label,1 AS ready"), Ready) == [
            (Label("saved"), Ready(True))
        ]
        for query in (
            "SELECT 'saved' AS label,1 AS label",
            "SELECT 'saved' AS label",
            "SELECT 'saved' AS label,1 AS ready,4 AS foreign_field",
            "SELECT 'saved' AS label,2 AS ready",
        ):
            with pytest.raises((TypeError, ValueError)):
                Label.joined(connection.execute(query), Ready)
