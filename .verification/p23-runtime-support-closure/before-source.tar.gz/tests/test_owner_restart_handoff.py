"""Authored declaration controls: stopped witnesses are not live claim_scope.

No root, writer, child, native package or process launch is acquired here.
"""

import os
from dataclasses import replace
from pathlib import Path

import pytest

from agent_comms.errors import RelationViolationError
from agent_comms.execution.child_process import (
    NoProcess,
    ProcessIdentity,
)
from agent_comms.execution.native_arguments import ConfiguredBinary, InheritedArguments
from agent_comms.execution.owner_lifecycle import OwnerRestartSelection
from agent_comms.launch_runtime import LaunchRuntime, RestartEnvironment, SetVariable, UnsetVariable
from agent_comms.nominal.field_codec import FieldCodec
from agent_comms.owner_release import (
    OwnerReleaseEvidence,
    ProcessExitedOwnerCompletion,
    SessionRetiredOwnerCompletion,
)
from agent_comms.owner_restart import OwnerRestartHandoff, RetiredOwnerLaunch
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.registry_document import RegistryDocument, RegistrySnapshot, ThreadRows
from agent_comms.registry.thread_identity import (
    GenerationCounter,
    OwnerIdentity,
)
from agent_comms.registry.thread_status import StoppedThreadStatus
from agent_comms.registry.threads import NativeThread
from agent_comms.transport.owner_requests import RetainedOwnerLaunch


@pytest.mark.parametrize("source", [{}, {"PYTHONPATH": ""}, {"PYTHONPATH": "/source"}])
def test_import_path_preserves_absent_and_empty_then_removes_explicitly(source):
    configuration = RestartEnvironment.inherit(source)
    encoded = configuration.encode()
    assert {key: value for key, value in encoded.items() if key == "PYTHONPATH"} == source
    assert FieldCodec.decode(RestartEnvironment, encoded) == configuration
    assert "PYTHONPATH" not in configuration.without_pythonpath().apply_runtime(source)


@pytest.mark.parametrize(('inherited', 'expected'), [
    (UnsetVariable(), '/runtime/bin' + os.pathsep + os.defpath),
    (SetVariable(''), '/runtime/bin:'),
    (SetVariable('/usr/bin'), '/runtime/bin:/usr/bin'),
    (SetVariable('/runtime/bin:/usr/bin:/runtime/bin'), '/runtime/bin:/usr/bin'),
])
def test_runtime_path_is_idempotent_and_keeps_other_search_entries(inherited, expected):
    interpreter = Path('/runtime/bin/python')
    original = RestartEnvironment(path=inherited)
    configured = original.for_interpreter(interpreter)
    path = configured.path.otherwise('')
    entries = path.split(os.pathsep)
    assert entries[0] == '/runtime/bin'
    assert entries.count('/runtime/bin') == 1
    assert path == expected
    assert configured.for_interpreter(interpreter) == configured
    applied = configured.apply_runtime({'PATH': inherited.otherwise(''), 'AUTHORED_CREDENTIAL': 'kept'})
    assert applied['PATH'] == expected
    assert applied['AUTHORED_CREDENTIAL'] == 'kept'


def stopped():
    # A declared absent synthetic process, never a borrowed original identity.
    thread = NativeThread("authored", frozenset(), Checkout(Path("/authored")),
                    process_identity=ProcessIdentity(2147483647, 1), created_at=1.0)
    snapshot = RegistrySnapshot.capture(RegistryDocument(
        threads=ThreadRows.from_threads({thread.name: thread}), statuses={thread.name: StoppedThreadStatus()},
        last_seen={thread.name: 1.0},
        owners=GenerationCounter(4, {thread.name: 4}),
        claims=GenerationCounter(5, {thread.name: 5}),
    ))
    return thread, snapshot


def test_retired_witness_cannot_borrow_live_or_replaced_claim():
    thread, snapshot = stopped()
    launch = RetainedOwnerLaunch(thread.require_process(), "/authored/python",
                                 {"AGENT_COMMS_AGENT_BIN": "/authored/pi"})
    owner = RetiredOwnerLaunch.capture_retired(snapshot, thread, launch, ProcessExitedOwnerCompletion())
    assert owner.require_current(snapshot) is thread
    selection = OwnerRestartSelection(
        owner.authority.owner, launch.process, owner.authority.claim.claimed_generation,
        launch.interpreter,
    )
    with pytest.raises(RelationViolationError):
        selection.require_current(snapshot)
    changed = (
        replace(snapshot, owner_generations={thread.name: 6}),
        replace(snapshot, _claimed_generations={thread.name: 6}),
        replace(snapshot, threads=ThreadRows.from_threads({thread.name: replace(thread, created_at=2.0)})),
        replace(snapshot, threads=ThreadRows.from_threads({thread.name: replace(
            thread, process_identity=ProcessIdentity(2147483646, 1))})),
    )
    for substituted in changed:
        with pytest.raises(RelationViolationError):
            owner.require_current(substituted)


def test_handoff_codec_preserves_complete_stopped_witness_and_original_launch():
    thread, snapshot = stopped()
    environment = {
        "AGENT_COMMS_THREAD": thread.name, "AGENT_COMMS_AGENT_BIN": "/authored/pi",
        "AGENT_COMMS_AGENT_ARGS": "--no-tools 'authored value'",
        "PI_CODING_AGENT_DIR": "/authored/config",
        "AGENT_COMMS_NATIVE_CONFIG_DIR": "/authored/config",
        "AUTHORED_CREDENTIAL": "in-memory-only",
    }
    launch = RetainedOwnerLaunch(thread.require_process(), "/authored/python", environment)
    owner = RetiredOwnerLaunch.capture_retired(snapshot, thread, launch, ProcessExitedOwnerCompletion())
    runtime = RestartEnvironment.inherit(environment)
    original = OwnerRestartHandoff("/authored", (owner,), runtime, ConfiguredBinary(), InheritedArguments(), LaunchRuntime(Path("/target/bin/python")))
    encoded = FieldCodec.encode(original)
    decoded = FieldCodec.decode(OwnerRestartHandoff, encoded)
    assert decoded == original
    assert decoded.owners[0].require_current(snapshot) is thread
    assert decoded.owners[0].launch.arguments == ("--no-tools", "authored value")
    assert decoded.owners[0].launch.environment["AUTHORED_CREDENTIAL"] == "in-memory-only"
    unrelated = replace(launch, process=ProcessIdentity(2147483646, 1))
    with pytest.raises(RelationViolationError):
        replace(owner, launch=unrelated).require_current(snapshot)


@pytest.mark.parametrize(("environment", "arguments"), [
    ({}, ()),
    ({"AGENT_COMMS_AGENT_ARGS": ""}, ()),
    ({"AGENT_COMMS_AGENT_ARGS": "--no-tools 'authored value'"}, ("--no-tools", "authored value")),
])
def test_retained_arguments_restart_from_the_original_environment(environment, arguments):
    launch = RetainedOwnerLaunch(ProcessIdentity(2147483647, 1), "/authored/python", environment)
    assert launch.arguments == arguments
    assert InheritedArguments().restarted(launch.arguments).argv == arguments


def test_retirement_capture_refuses_changed_original_incarnation():
    thread, snapshot = stopped()
    launch = RetainedOwnerLaunch(thread.require_process(), "/authored/python",
                                 {"AGENT_COMMS_AGENT_BIN": "/authored/pi"})
    with pytest.raises(RelationViolationError):
        RetiredOwnerLaunch.capture_retired(snapshot, replace(thread, created_at=2.0), launch, ProcessExitedOwnerCompletion())


def test_a_release_naming_no_process_retires_a_thread_that_holds_none():
    # Stops before #3669 recorded a dead owner's release with no process; the thread
    # holds none either, so it is retired and may start (no "no released process").
    thread, snapshot = stopped()
    unbound = replace(thread, process_identity=NoProcess())
    snapshot = replace(snapshot, threads=ThreadRows.from_threads({thread.name: unbound}))
    release = OwnerReleaseEvidence(thread.name, thread.incarnation.wire_birth, NoProcess(), 4, 5)
    release.completion.require_loss(snapshot, release)
    release.require_retired_for(snapshot)
    held = replace(snapshot, threads=ThreadRows.from_threads({thread.name: thread}))
    with pytest.raises(RelationViolationError):
        release.require_retired_for(held)


def test_a_retired_session_is_judged_by_the_registry_not_the_stopped_copy():
    # A stop settles with the Thread it captured before the session retired, which still
    # names the live process; retirement reads the registry, which holds none.
    thread, snapshot = stopped()
    retired = OwnerIdentity(thread.incarnation, 3)
    release = OwnerReleaseEvidence(thread.name, thread.incarnation.wire_birth, thread.process_identity,
                                   4, 5, SessionRetiredOwnerCompletion(retired))
    unbound = replace(snapshot, threads=ThreadRows.from_threads(
        {thread.name: replace(thread, process_identity=NoProcess())}))
    release.require_retired_for(unbound)
    with pytest.raises(RelationViolationError, match="acquired another process"):
        release.require_retired_for(snapshot)
