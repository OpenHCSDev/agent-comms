import os
import sys
from collections.abc import Sequence
from dataclasses import dataclass
from functools import partial
from io import StringIO
from pathlib import Path
from typing import TextIO

import pytest

from agent_comms.cli import CliInvocation
from agent_comms.cli_arguments import CliArgumentParser
from agent_comms.cli_verbs.read_back import ReadBackCliCommand
from agent_comms.cli_verbs.start import StartCliCommand
from agent_comms.cli_verbs.stop import StopCliCommand
from agent_comms.comms import Comms
from agent_comms.installer.commands import InstallCommands
from agent_comms.installer.interpreter_operation import (
    ProbeReply,
    ProbeRequest,
    RuntimeProbe,
    serve,
)
from agent_comms.installer.owner_starts import OwnerStart, RefusedOwner, StartedOwner
from agent_comms.installer.probes.commands import CliCommandProbe, CliOutput, CliRefusedError
from agent_comms.installer.probes.packages import DistributionVersionsProbe
from agent_comms.installer.probes.resolution import InstalledPackagesProbe
from agent_comms.installer.refusals import InterpreterWorkerDied, UpgradeRefused
from agent_comms.installer.upgrade import Stack
from agent_comms.launch_root import LaunchRoot
from agent_comms.launch_runtime import LaunchRuntime
from agent_comms.nominal.field_codec import ClaimId, FieldCodec
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import NativeThread
from agent_comms.storage.maintenance_barrier import HOLDER_NONCE, MaintenanceClaimHolder


@pytest.mark.parametrize("command", [StartCliCommand, StopCliCommand])
def test_owner_actions_decode_in_the_selected_worker(comms, command, source_repository):
    runtime = LaunchRuntime.running()
    with InstallCommands() as commands:
        stack = Stack(source_repository.checkout, commands, runtime=runtime)
        outcomes = stack.owners(comms.root, command, ["missing-owner"])
    assert len(outcomes) == 1
    assert outcomes[0].name == "missing-owner"
    with pytest.raises(UpgradeRefused):
        outcomes[0].require_success(UpgradeRefused)


def test_cli_probes_share_worker_and_keep_roots_and_refusals_separate(
    comms: Comms, tmp_path: Path,
) -> None:
    comms.registry.declare(NativeThread("only-first-root", frozenset(), Checkout(tmp_path)))
    runtime = LaunchRuntime.running()
    with InstallCommands() as commands:
        stack = Stack(Path(__file__).resolve().parents[1], commands, runtime=runtime)
        stack.probe(DistributionVersionsProbe())
        (worker,) = commands.workers.values()
        pid = worker.child.pid
        assert stack.cli(comms.root, ReadBackCliCommand).threads == 1
        assert stack.cli(tmp_path / "other-root", ReadBackCliCommand).threads == 0
        help_output = stack.probe(CliCommandProbe(("--help",)))
        assert help_output.returncode == 0
        assert help_output.stdout
        for probe_type in CliCommandProbe.members_with(CliCommandProbe):
            with pytest.raises(UpgradeRefused) as refused:
                stack.cli_reply(probe_type(("--root", str(comms.root), "not-a-command")),
                                partial(CliOutput.decoded, result=tuple[OwnerStart, ...]))
            assert isinstance(refused.value.__cause__, CliRefusedError)
        assert stack.cli(comms.root, ReadBackCliCommand).threads == 1
        stack.probe(DistributionVersionsProbe())
        assert tuple(commands.workers.values()) == (worker,)
        assert worker.child.pid == pid


@pytest.mark.parametrize("arguments", [("read-back",), ("not-a-command",), ("--help",)])
def test_cli_invocation_restores_the_callers_root(
    comms: Comms, tmp_path: Path, arguments: tuple[str, ...],
) -> None:
    previous = LaunchRoot.from_path(tmp_path / "caller-root")
    with previous.selected():
        CliCommandProbe(("--root", str(comms.root), *arguments)).run()
        assert LaunchRoot.current() == previous


@pytest.mark.parametrize("arguments", [("--help",), ("read-back", "--help")])
def test_parser_help_uses_only_the_invocations_output(
    arguments: tuple[str, ...], capsys: pytest.CaptureFixture[str],
) -> None:
    output = StringIO()
    assert CliInvocation().invoke(arguments, output) == 0
    assert output.getvalue()
    assert capsys.readouterr() == ("", "")


def test_cli_invocation_preserves_parser_exit_status_without_console_output(
    capsys: pytest.CaptureFixture[str],
) -> None:
    class ExitingInvocation(CliInvocation):
        def execute(self, arguments: Sequence[str], output: TextIO) -> int:
            CliArgumentParser().exit(2)

    output = StringIO()
    assert ExitingInvocation().invoke((), output) == 2
    assert output.getvalue() == ""
    assert capsys.readouterr() == ("", "")


def test_cli_invocation_does_not_turn_interrupt_into_an_answer() -> None:
    class InterruptedInvocation(CliInvocation):
        def execute(self, arguments: Sequence[str], output: TextIO) -> int:
            raise KeyboardInterrupt

    with pytest.raises(KeyboardInterrupt):
        InterruptedInvocation().invoke((), StringIO())


def test_owner_reports_own_their_refusal():
    StartedOwner("ready").require_success(UpgradeRefused)
    with pytest.raises(UpgradeRefused):
        RefusedOwner("missing", "not registered").require_success(UpgradeRefused)


def test_probes_under_successive_holds_share_one_worker():
    runtime = LaunchRuntime.running()
    with InstallCommands() as commands:
        for _ in range(2):
            with MaintenanceClaimHolder(ClaimId.mint()).acting():
                commands.probe(DistributionVersionsProbe(), runtime.interpreter,
                               env=runtime.environment(os.environ))
        assert len(commands.workers) == 1
        (key,) = commands.workers
        assert HOLDER_NONCE not in dict(key.environment)


def test_worker_answers_each_request_as_that_request_s_holder(monkeypatch, tmp_path):
    # The probe is a family member only while this test runs, so later tests reading the
    # installer's probes (OutgoingWire) never see it.
    @dataclass(frozen=True)
    class HolderSeenProbe(RuntimeProbe[str]):
        def run(self) -> str:
            assert sys.stdin.read() == "", "Operations must not read the request transport"
            return os.environ.get(HOLDER_NONCE, "")

    try:
        holders = (str(ClaimId.mint()), str(ClaimId.mint()), "")
        lines = "".join(
            FieldCodec.compact(FieldCodec.encode(ProbeRequest(HolderSeenProbe(), holder))) + "\n"
            for holder in holders
        )
        # serve() owns both transport descriptors; operations inherit EOF, not requests.
        requests, answers = tmp_path / "requests", tmp_path / "answers"
        requests.write_text(lines)
        monkeypatch.setattr("sys.stdin", requests.open())
        monkeypatch.setattr("sys.stdout", answers.open("w"))
        monkeypatch.setenv(HOLDER_NONCE, str(ClaimId.mint()))
        serve()
        assert [FieldCodec.decode(HolderSeenProbe().answer_type(),
                                  FieldCodec.decode(ProbeReply, FieldCodec.parse(line)).answer)
                for line in answers.read_text().splitlines()] == list(holders)
    finally:
        HolderSeenProbe.withdraw()


def test_a_raising_probe_ends_its_worker_and_refuses_with_its_traceback():
    """The test runtime is editable, so the packages probe raises in the worker."""
    runtime = LaunchRuntime.running()
    environment = runtime.environment(os.environ)
    with InstallCommands() as commands:
        with pytest.raises(InterpreterWorkerDied) as died:
            commands.probe(InstalledPackagesProbe("agent-comms"), runtime.interpreter,
                           env=environment)
        assert not died.value.outcome.successful
        assert "ValueError: Core is editable, not a built runtime package" in died.value.errors
        assert not commands.workers
        commands.probe(DistributionVersionsProbe(), runtime.interpreter, env=environment)
        assert len(commands.workers) == 1
