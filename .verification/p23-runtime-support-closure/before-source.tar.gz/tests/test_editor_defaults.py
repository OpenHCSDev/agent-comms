"""Real command defaults retain the wire capabilities of their declarations."""
import json

import pytest

from agent_comms.cli_verbs.fork import ForkCliCommand
from agent_comms.nominal.field_codec import FieldCodec, compile_decoder
from agent_comms.pi_vocabulary import HighThinkingLevel, NoThinkingOverride, ThinkingLevelField
from agent_comms.projects.checkouts import LaunchCheckout
from agent_comms.registry.thread_model import UndeclaredModel
from agent_comms.registry.threads import ExternalThread, Thread


@pytest.mark.parametrize('annotation,value,encoded', (
    (type[Thread], ExternalThread, ExternalThread.declared_name),
    (ThinkingLevelField, NoThinkingOverride, None),
    (ThinkingLevelField, HighThinkingLevel, 'high'),
    (type(None), None, None),
    (str | None, None, None),
    (bool, True, True),
    (tuple[int, ...], (1, 2), [1, 2]),
))
def test_declared_default_editor_round_trip(annotation, value, encoded):
    decoder = compile_decoder(annotation)
    assert decoder.target == annotation
    text = decoder.encode_editor(value)
    assert text == json.dumps(encoded)
    assert FieldCodec.decode(annotation, decoder.decode_editor(text)) == value


def test_fork_default_retains_annotated_thinking_representation(source_repository):
    command = ForkCliCommand(name='', parent='saved', project=LaunchCheckout.checked(source_repository.checkout),
                             model=UndeclaredModel(), thinking_level=NoThinkingOverride)
    editable = {entry.name: entry for entry in command.editable_fields}
    decoder = compile_decoder(editable['thinking_level'].annotation)
    assert decoder.encode_editor(HighThinkingLevel) == '"high"'
    assert editable['thinking_level'].editor_default == 'null'
    payload = FieldCodec.encode(command)
    payload.update(command.editor_arguments({'thinking_level': '"high"'}))
    assert FieldCodec.decode(ForkCliCommand, payload).thinking_level is HighThinkingLevel
    assert compile_decoder(str).encode_editor('literal text') == 'literal text'
