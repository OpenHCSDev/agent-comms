"""Native claims refuse stale authority and redirected filesystem paths."""

from __future__ import annotations

import os
import sys
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory

import pytest

import agent_comms.execution.selected.claim as selected_claim
from agent_comms.assignment_states import FullPendingAssignment
from agent_comms.attempt_start import AttemptStart
from agent_comms.attempt_states import ModelRunningAttempt, PromptAcceptedAttempt, SettlingAttempt
from agent_comms.comms import wire
from agent_comms.coordination.cohort import sealed_cohort_assignments
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.errors import IdentityConflict
from agent_comms.coordination.tables.executions import WireOrigin
from agent_comms.envelope_claim_transitions import ExistingFileClaim, WakeClaim
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.execution.selected.claim import (
    publish_selected_resource_claim,
    verify_selected_wake,
    write_selected_claimed_file,
)
from agent_comms.execution.selected.source_batch import SelectedSource
from agent_comms.nominal.field_codec import ClaimId, TurnId
from agent_comms.owner_fence import prepare_fence_token
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import NativeThread
from bus_record_fixture import prepare_native_comms
from conftest import accept_initial, publish_initial

pytestmark = pytest.mark.skipif(
    sys.platform != "linux", reason="private cohort claim_scope requires real /var/tmp"
)


def test_selected_wake_verifier_refuses_no_wake_and_stale_authority(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    with TemporaryDirectory(prefix="ac-claim-verify-") as dirname:
        root = Path(dirname) / "wire"
        root.mkdir(mode=0o700)
        worktree = Path(dirname) / "work"
        worktree.mkdir(mode=0o700)
        parent = worktree / "pkg"
        parent.mkdir(mode=0o700)
        resource = parent / "module.py"
        resource.write_text("value = 1\n")
        comms = prepare_native_comms(wire(root))
        comms.channels.create_tag("team")
        for name, created in (("sender", 17021.0), ("Alice", 17022.0), ("Bob", 17023.0)):
            comms.registry.declare(
                NativeThread(name, frozenset({'team'}), Checkout(worktree), process_identity=ProcessIdentity.capture(os.getpid()), created_at=created)
            )
        root_id = comms.registry.store.prepare_native_root().namespace
        message = publish_initial(comms, "sender", "#team", "@Alice investigate")
        initial = comms.bus.bus.delivery(message.seq)
        with Coordination(str(root / "coordination.sqlite3")) as store:
            for recipient in initial.recipients:
                store.participants.register(
                    recipient.recipient_lookup,
                    committed=True,
                )
            accept_initial(comms.bus, root_id, message.seq, store)
            alice_lookup = comms.registry.require("Alice").incarnation.lookup
            bob_lookup = comms.registry.require("Bob").incarnation.lookup
            assignment = sealed_cohort_assignments(store, alice_lookup)[0]
            assert type(assignment.lifecycle) is FullPendingAssignment
            owner, claimed_generation = comms.registry.live_owner_with_claim("Alice")
            owner, claimed_generation = comms.registry.lease_live_turn_with_claim(
                owner,
                TurnId('088fbdccfa8d303a5026987cf37e23b8'),
                expected_generation=claimed_generation,
            )
            person = store.participants.get(alice_lookup)
            execution_id = "verifier-execution"
            store.create(
                execution_id,
                WireOrigin,
                alice_lookup,
                1,
                sources=(SelectedSource(assignment.assignment_id, store.assignments, initial),),
            )
            snapshot = store.get(execution_id)
            snapshot = store.mark_pending(
                execution_id, expected_revision=snapshot.execution.revision
            ).value
            started = store.start(AttemptStart(
                execution_id=execution_id,
                attempt_ordinal=1,
                owner_lookup=alice_lookup,
                owner_generation=person.owner_identity.generation,
                token=prepare_fence_token(),
                expected_execution_revision=snapshot.execution.revision,
                expected_pointer_revision=snapshot.pointer_revision,
            ))
            engaged = store.assignments.get(assignment.assignment_id)
            claim_scope = WakeClaim(
                wire_root_id=root_id,
                source_seq=message.seq,
                source_message_id=message.message_id,
                wake_assignment_id=assignment.assignment_id,
                wake_revision=engaged.revision,
                recipient_lookup=alice_lookup,
                execution_id=execution_id,
                operation_id=ClaimId("f" * 32),
                owner_claimed_generation=claimed_generation,
                turn_id=owner.require_turn_lease().turn_id,
                participant_generation=person.owner_identity.generation,
                attempt_ordinal=1,
            )
            verify_selected_wake(comms, store, claim_scope, owner.name)
            with pytest.raises(IdentityConflict):
                publish_selected_resource_claim(
                    comms,
                    store,
                    replace(claim_scope, recipient_lookup=bob_lookup),
                    "Bob",
                    ExistingFileClaim(Path(resource)),
                )
            assert str(resource) not in comms.bus.bus.claim_projection()
            publish_selected_resource_claim(
                comms, store, claim_scope, owner.name, ExistingFileClaim(Path(resource))
            )
            selected_owner = wire(root).bus.bus.claim_projection()[str(resource)]
            assert selected_owner.resource_scope == claim_scope
            assert selected_owner.resource == str(resource)
            assert (
                publish_selected_resource_claim(
                    comms, store, claim_scope, owner.name, ExistingFileClaim(Path(resource))
                )
                == selected_owner
            )
            assert len(comms.bus.bus.scoped_page("1", (), limit=100)) == 2
            outside = Path(dirname) / "outside"
            outside.mkdir(mode=0o700)
            external = outside / "module.py"
            external.write_bytes(b"outside untouched\n")
            displaced = worktree / "displaced-pkg"
            actual_open = os.open

            def swap_after_open(path, flags, *args, **kwargs):
                fd = actual_open(path, flags, *args, **kwargs)
                if path == "module.py" and kwargs.get("dir_fd") is not None:
                    parent.rename(displaced)
                    parent.symlink_to(outside, target_is_directory=True)
                return fd

            # A parent rename after obtaining the leaf fd but before truncate
            # must be detected against the pinned chain and must not mutate.
            with monkeypatch.context() as patch:
                patch.setattr(selected_claim.os, "open", swap_after_open)
                with pytest.raises(IdentityConflict):
                    write_selected_claimed_file(
                        comms, store, claim_scope, "Alice", selected_owner, b"late escape\n"
                    )
            assert external.read_bytes() == b"outside untouched\n"
            assert (displaced / "module.py").read_bytes() == b"value = 1\n"
            parent.unlink()
            displaced.rename(parent)
            write_selected_claimed_file(
                comms, store, claim_scope, "Alice", selected_owner, b"value = 2\n"
            )
            assert resource.read_bytes() == b"value = 2\n"
            with pytest.raises(IdentityConflict):
                write_selected_claimed_file(
                    comms,
                    store,
                    claim_scope,
                    "Alice",
                    replace(selected_owner, generation=ClaimId("0" * 32)),
                    b"forged\n",
                )
            assert resource.read_bytes() == b"value = 2\n"
            foreign_root = Path(dirname) / "foreign"
            foreign_root.mkdir(mode=0o700)
            with Coordination(str(foreign_root / "coordination.sqlite3")) as foreign:
                store.session._connection.backup(foreign.session._connection)
                with pytest.raises(IdentityConflict):
                    verify_selected_wake(comms, foreign, claim_scope, owner.name)
            for candidate, name in (
                (replace(claim_scope, recipient_lookup=bob_lookup), "Bob"),
                (replace(claim_scope, wake_revision=engaged.revision + 1), "Alice"),
                (replace(claim_scope, owner_claimed_generation=claimed_generation + 1), "Alice"),
                (replace(claim_scope, turn_id=TurnId('310c74d7ac243239a928d4021c709acb')), "Alice"),
            ):
                with pytest.raises(IdentityConflict):
                    verify_selected_wake(comms, store, candidate, name)
            fence = started.value.fence
            for phase in (PromptAcceptedAttempt, ModelRunningAttempt):
                fence = store.advance(
                    fence, phase, expected_pointer_revision=started.value.snapshot.pointer_revision
                ).value.fence
            store.advance(
                fence,
                SettlingAttempt,
                expected_pointer_revision=started.value.snapshot.pointer_revision,
                backend_done=True,
                process_dead=True,
            )
            with pytest.raises(IdentityConflict):
                verify_selected_wake(comms, store, claim_scope, "Alice")
            with pytest.raises(IdentityConflict):
                write_selected_claimed_file(
                    comms, store, claim_scope, "Alice", selected_owner, b"after settlement\n"
                )
            assert resource.read_bytes() == b"value = 2\n"
            with pytest.raises(IdentityConflict):
                publish_selected_resource_claim(
                    comms,
                    store,
                    replace(claim_scope, operation_id=ClaimId("e" * 32)),
                    "Alice",
                    ExistingFileClaim(Path(resource)),
                )
            comms.registry.unregister("Alice")
            with pytest.raises(IdentityConflict):
                verify_selected_wake(comms, store, claim_scope, "Alice")
            with pytest.raises(IdentityConflict):
                publish_selected_resource_claim(
                    comms, store, claim_scope, "Alice", ExistingFileClaim(Path(resource))
                )
            assert len(comms.bus.bus.scoped_page("1", (), limit=100)) == 2
