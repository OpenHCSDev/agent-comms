"""The installer publishes and undoes its own route, leaving other publishers alone."""


import errno
import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from threading import Event

import pytest

from agent_comms.active_route import (
    ActiveRoute,
    ActiveRouteFile,
    NoRouteSelection,
    PublishedRouteSelection,
    RoutePublicationUnknownError,
    active_route_path,
    read_active_route,
    route_new_bus,
)
from agent_comms.bus import Bus
from agent_comms.comms import Comms, wire
from agent_comms.execution.child_process import SpawnedProcess
from agent_comms.installer.backup import StoreBackup
from agent_comms.installer.commands import InstallCommands
from agent_comms.installer.interpreter_operation import InstalledProgram
from agent_comms.installer.native_build_inputs import DetachedChildStdio
from agent_comms.installer.probes.publication import SelectedRouteProbe
from agent_comms.installer.refusals import UpgradeRefused
from agent_comms.launch_runtime import LaunchRuntime
from agent_comms.projects.checkouts import Checkout
from agent_comms.recorded_bus import RecordedBusIdentity
from agent_comms.registry.threads import ExternalThread
from agent_comms.storage.maintenance_barrier import MaintenanceHeldError, MaintenanceOperator
from bus_record_fixture import prepare_native_comms


@pytest.fixture
def route_bus(tmp_path, pinned_native):
    """Publishing a route validates its launch, which acquires the pinned native build."""
    root = tmp_path / "wire"
    prepare_native_comms(wire(root))
    return ActiveRoute(root, RecordedBusIdentity.capture(Bus.path_in(root)))


def old_route(path, route):
    """The retired writer's stored v2 shape; the incoming reader must still refuse it."""
    path.parent.mkdir(mode=0o700, parents=True)
    path.write_text(json.dumps({
        "version": 2, "root": str(route.root),
        "wire_root_id": route.launch().wire_root_id,
    }))
    path.chmod(0o600)
    return path.read_bytes()


@pytest.mark.parametrize("had_route", (False, True))
def test_route_publication_and_rollback_with_no_sql_changes(tmp_path, route_bus, had_route):
    path = tmp_path / "state" / "active-route.json"
    original = old_route(path, route_bus) if had_route else None
    backup = StoreBackup.take(route_bus.root, path, (), tmp_path / "spill")

    selected = PublishedRouteSelection(route_bus.root) if had_route else NoRouteSelection()
    backup.rebind_route(route_bus, selected)
    assert read_active_route(path) == route_bus
    assert not backup.original()
    backup.restore(lambda: None)
    assert backup.original()
    if had_route:
        assert path.read_bytes() == original
    else:
        assert not path.exists()


def test_install_of_another_bus_keeps_the_published_selection(tmp_path, route_bus):
    other_root = tmp_path / "other"
    prepare_native_comms(wire(other_root))
    other = ActiveRoute(other_root, RecordedBusIdentity.capture(Bus.path_in(other_root)))
    path = tmp_path / "state" / "active-route.json"
    route_new_bus(other, path)
    original = path.read_bytes()
    backup = StoreBackup.take(route_bus.root, path, (), tmp_path / "spill")
    backup.rebind_route(route_bus, PublishedRouteSelection(other_root))
    assert read_active_route(path) == other
    assert path.read_bytes() == original
    assert backup.original()


def test_concurrent_publication_before_rebind_is_preserved_on_rollback(tmp_path, route_bus):
    path = tmp_path / "state" / "active-route.json"
    old_route(path, route_bus)
    backup = StoreBackup.take(route_bus.root, path, (), tmp_path / "spill")
    route_new_bus(route_bus, path)
    concurrent = path.read_bytes()
    with pytest.raises(UpgradeRefused, match="route changed"):
        backup.rebind_route(route_bus, PublishedRouteSelection(route_bus.root))
    backup.restore(lambda: None)
    assert path.read_bytes() == concurrent
    assert read_active_route(path) == route_bus


def test_concurrent_publication_after_rebind_is_preserved_on_rollback(tmp_path, route_bus):
    path = tmp_path / "state" / "active-route.json"
    old_route(path, route_bus)
    backup = StoreBackup.take(route_bus.root, path, (), tmp_path / "spill")
    backup.rebind_route(route_bus, PublishedRouteSelection(route_bus.root))

    # A replaced bus permits the existing route owner to publish another selection.
    database = Bus.path_in(route_bus.root)
    replacement = route_bus.root / "replacement.sqlite3"
    Bus.copy_file(database, replacement)
    os.replace(replacement, database)
    other_root = tmp_path / "other"
    prepare_native_comms(wire(other_root))
    other = ActiveRoute(other_root, RecordedBusIdentity.capture(Bus.path_in(other_root)))
    route_new_bus(other, path)
    concurrent = path.read_bytes()
    backup.restore(lambda: None)
    assert path.read_bytes() == concurrent
    assert read_active_route(path) == other


@pytest.mark.parametrize("had_route", (False, True))
def test_unknown_publication_is_still_owned_by_rollback(tmp_path, route_bus, had_route, monkeypatch):
    path = tmp_path / "state" / "active-route.json"
    original = old_route(path, route_bus) if had_route else None
    backup = StoreBackup.take(route_bus.root, path, (), tmp_path / "spill")
    directory = path.parent.stat()
    fsync = os.fsync
    failed = False

    def fail_directory_once(fd):
        nonlocal failed
        current = os.fstat(fd)
        if not failed and (current.st_dev, current.st_ino) == (directory.st_dev, directory.st_ino):
            failed = True
            raise OSError(errno.EIO, "directory durability failed after route publication")
        return fsync(fd)

    monkeypatch.setattr(os, "fsync", fail_directory_once)
    with pytest.raises(RoutePublicationUnknownError):
        selected = PublishedRouteSelection(route_bus.root) if had_route else NoRouteSelection()
        backup.rebind_route(route_bus, selected)
    assert failed
    assert read_active_route(path) == route_bus
    backup.restore(lambda: None)
    assert backup.original()
    if had_route:
        assert path.read_bytes() == original
    else:
        assert not path.exists()


def test_staged_probe_reads_the_published_route(tmp_path, route_bus):
    runtime = LaunchRuntime.running()
    home = tmp_path / "outgoing-home"
    root = route_bus.root
    environment = {
        **runtime.environment(os.environ), "HOME": str(home),
    }
    path = home / ".local/state/agent-comms/active-route.json"
    old_route(path, route_bus)
    with InstallCommands() as commands:
        selected = commands.probe(
            SelectedRouteProbe(), runtime.interpreter, env=environment, cwd=tmp_path,
            program=InstalledProgram(),
        )
        assert selected == NoRouteSelection()
        current = ActiveRoute(root, RecordedBusIdentity.capture(Bus.path_in(root)))
        path.write_text(json.dumps(current.to_record()))
        assert commands.probe(
            SelectedRouteProbe(), runtime.interpreter, env=environment, cwd=tmp_path,
            program=InstalledProgram(),
        ) == PublishedRouteSelection(root)
        root.rename(root.with_name("retired"))
        assert commands.probe(
            SelectedRouteProbe(), runtime.interpreter, env=environment, cwd=tmp_path,
            program=InstalledProgram(),
        ) == NoRouteSelection()
        path.unlink()
        assert commands.probe(
            SelectedRouteProbe(), runtime.interpreter, env=environment, cwd=tmp_path,
            program=InstalledProgram(),
        ) == NoRouteSelection()


def test_failure_after_backup_link_restores_a_single_private_route(tmp_path, route_bus, monkeypatch):
    path = tmp_path / "state" / "active-route.json"
    original = old_route(path, route_bus)
    backup = StoreBackup.take(route_bus.root, path, (), tmp_path / "spill")
    replace = os.replace
    failed = False

    def fail_route_replace(source, destination, **directories):
        nonlocal failed
        if destination == path.name and not failed:
            failed = True
            raise OSError(errno.EIO, "replace failed after retaining the old route")
        return replace(source, destination, **directories)

    monkeypatch.setattr(os, "replace", fail_route_replace)
    with pytest.raises(RoutePublicationUnknownError):
        backup.rebind_route(route_bus, PublishedRouteSelection(route_bus.root))
    assert path.read_bytes() == original
    assert path.stat().st_nlink == 2
    assert not backup.original()
    backup.restore(lambda: None)
    assert backup.original()
    assert path.read_bytes() == original
    assert path.stat().st_nlink == 1


def test_a_client_call_never_holds_publication_and_the_bus_refuses_writes_held_by_install(
    tmp_path, route_bus, monkeypatch,
):
    """Toad is a client: an open call no longer stalls the installer's route step, and the
    store itself refuses writes once maintenance holds the root, under its write lock."""
    monkeypatch.setenv("HOME", str(tmp_path))
    path = active_route_path()
    path.parent.mkdir(parents=True)
    route_new_bus(route_bus, path)
    with Comms.client(route_bus) as comms:
        for name in ("sender", "recipient"):
            comms.registry.declare(ExternalThread(
                name, frozenset(), Checkout(tmp_path)))
        ActiveRouteFile(path).update(lambda: None, lambda original, directory: None)
        # A publisher never waits on an open client call.
        bus = comms.bus.bus
        entered, release = Event(), Event()

        def in_flight():
            with bus.writing():
                entered.set()
                assert release.wait(5)

        def drain():
            with Bus.writers_drained(bus.path):
                pass

        gate = comms.owners.maintenance
        with ThreadPoolExecutor(max_workers=2) as workers:
            writing = workers.submit(in_flight)
            assert entered.wait(5)
            hold = gate.begin(MaintenanceOperator.current())
            draining = workers.submit(drain)
            try:
                with pytest.raises(TimeoutError):
                    draining.result(timeout=0.2)
            finally:
                release.set()
            writing.result(timeout=5)
            draining.result(timeout=5)
        with pytest.raises(MaintenanceHeldError):
            with bus.writing():
                pytest.fail("A write began under the hold")
        gate.clear(hold)
        sent = comms.messaging.send("sender", "recipient", "after the hold").message
    assert sent.body == "after the hold"


ROUTE_HOLDER = """import ctypes, fcntl, os, sys, time
ctypes.CDLL(None).prctl(15, sys.argv[2].encode())  # PR_SET_NAME: the comm the kernel reports
fcntl.flock(os.open(sys.argv[1], os.O_RDONLY | os.O_DIRECTORY), fcntl.LOCK_SH)
print("held", flush=True)
time.sleep(60)
"""


def test_route_publication_neither_waits_for_nor_ends_an_old_toad_holding_the_directory(
    tmp_path,
):
    """An old runtime's Toad still flocks the route directory; publishers no longer do."""
    directory = tmp_path / "state"
    directory.mkdir(mode=0o700)
    with SpawnedProcess.launch((sys.executable, "-c", ROUTE_HOLDER, str(directory), "toad"),
                               stdio=DetachedChildStdio(stdout=subprocess.PIPE)) as holder:
        assert holder.process.stdout.readline() == b"held\n"
        ActiveRouteFile(directory / "active-route.json").update(
            lambda: None, lambda original, held: None)
        assert holder.process.poll() is None


@pytest.mark.parametrize("concurrent_change", ("publish", "replace-directory"))
def test_preparation_lends_no_route_lock_and_commits_only_its_current_directory(
    tmp_path, route_bus, monkeypatch, concurrent_change,
):
    """Pause actual staging I/O; a real publisher wins, or a replaced directory refuses."""
    path = tmp_path / "state" / "active-route.json"
    other_root = tmp_path / "other"
    prepare_native_comms(wire(other_root))
    preparing, released = Event(), Event()
    fsync = os.fsync

    def wait_for_other_publisher(fd):
        held = os.readlink(f"/proc/self/fd/{fd}")
        if not preparing.is_set() and held.startswith(str(path.parent) + "/") and held.endswith(".tmp"):
            preparing.set()
            assert released.wait(10), "route preparation was not released"
        return fsync(fd)

    monkeypatch.setattr(os, "fsync", wait_for_other_publisher)
    with ThreadPoolExecutor(max_workers=1) as workers:
        pending = workers.submit(route_new_bus, route_bus, path)
        try:
            assert preparing.wait(5)
            if concurrent_change == "publish":
                child = subprocess.run([
                    sys.executable, "-c",
                    "from pathlib import Path; import sys; "
                    "from agent_comms.active_route import ActiveRoute, route_new_bus; "
                    "from agent_comms.bus import Bus; "
                    "from agent_comms.recorded_bus import RecordedBusIdentity; "
                    "root=Path(sys.argv[1]); "
                    "print(route_new_bus(ActiveRoute(root, "
                    "RecordedBusIdentity.capture(Bus.path_in(root))), Path(sys.argv[2])))",
                    str(other_root), str(path),
                ], capture_output=True, text=True, timeout=8)
                assert child.returncode == 0, child.stdout + child.stderr
            else:
                path.parent.rename(tmp_path / "retired-directory")
                path.parent.mkdir(mode=0o700)
                (path.parent / "keep").write_text("other owner")
        finally:
            released.set()
        if concurrent_change == "publish":
            assert pending.result(timeout=5).startswith("kept ")
            assert read_active_route(path).root == other_root
            assert path.stat().st_nlink == 1
        else:
            with pytest.raises(ValueError, match="directory changed"):
                pending.result(timeout=5)
            assert not path.exists()
            assert (path.parent / "keep").read_text() == "other owner"
            assert not (tmp_path / "retired-directory" / path.name).exists()
        assert not tuple(tmp_path.rglob("*.tmp"))
