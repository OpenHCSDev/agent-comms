"""Every declared SQL store can read before its first write without filesystem work."""

import sqlite3
from concurrent.futures import ThreadPoolExecutor

import pytest

from agent_comms.errors import RelationViolationError
from agent_comms.external_transcript import ExternalTranscript
from agent_comms.input_disposition import InputDispositionRow, InputDispositions
from agent_comms.input_key import BusInputKey
from agent_comms.owner_release import OwnerReleaseStore
from agent_comms.registry.thread_identity import RecordedThreadIncarnation
from agent_comms.storage.maintenance_barrier import MaintenanceNotHeldError
from agent_comms.storage.typed_table import HeldBusFile
from conftest import maintenance_held


@pytest.mark.parametrize("make_store", (
    InputDispositions,
    OwnerReleaseStore,
    lambda root: ExternalTranscript(root, RecordedThreadIncarnation("cli", 1.0)),
), ids=("inputs", "releases", "transcript"))
def test_missing_snapshot_has_declared_read_only_schema_without_creating_root(tmp_path, make_store):
    root = tmp_path / "never-written"
    store = make_store(root)
    assert not root.exists()
    with store.snapshot() as connection:
        assert connection.in_transaction
        assert connection.execute("PRAGMA query_only").fetchone()[0] == 1
        assert connection.execute("PRAGMA foreign_keys").fetchone()[0] == 1
        assert connection.execute("PRAGMA database_list").fetchone()[2] == ""
        store.require_schema(connection)
        for row in store.schema_rows():
            assert row.select(connection) == []
        with pytest.raises(sqlite3.OperationalError):
            store.schema_rows()[0].delete(connection, where="1")
    assert not root.exists()
    with pytest.raises(sqlite3.ProgrammingError):
        connection.execute("SELECT 1")


def test_first_write_does_not_change_the_opened_empty_snapshot(tmp_path):
    store = InputDispositions(tmp_path / "new")
    with ThreadPoolExecutor(max_workers=1) as writer:
        with store.snapshot() as connection:
            recorded = writer.submit(store.record, BusInputKey(1), seq=1, owner="kid",
                                     claim_scope=1, target="kid", text="first")
            assert recorded.result(timeout=2)
            assert InputDispositionRow.select(connection) == []
    assert store.lookup(BusInputKey(1)).source_text == "first"


def test_change_marker_publishes_only_committed_row_changes(tmp_path):
    store = InputDispositions(tmp_path)
    marker, = store.source_paths(tmp_path)
    with store.writing() as connection:
        assert connection.execute("PRAGMA journal_mode").fetchone()[0] == "wal"
        assert connection.execute("PRAGMA foreign_keys").fetchone()[0] == 1
    assert not marker.exists()
    store.record(BusInputKey(1), seq=1, owner="kid", claim_scope=1, target="kid", text="first")
    changed = marker.stat().st_mtime_ns
    with store.snapshot() as connection:
        assert InputDispositionRow.select(connection)
    with store.writing() as connection:
        InputDispositionRow.delete(connection, where="0")
    assert marker.stat().st_mtime_ns == changed
    with pytest.raises(ValueError):
        with store.writing() as connection:
            InputDispositionRow.delete(connection)
            raise ValueError("rollback")
    assert marker.stat().st_mtime_ns == changed
    assert store.lookup(BusInputKey(1)).source_text == "first"
    store.record(BusInputKey(2), seq=2, owner="kid", claim_scope=1, target="kid", text="second")
    assert marker.stat().st_mtime_ns != changed


def test_existing_undeclared_schema_is_not_treated_as_missing(tmp_path):
    store = InputDispositions(tmp_path)
    store.path.touch(mode=0o600)
    with pytest.raises(RelationViolationError):
        with store.snapshot():
            pytest.fail("An existing invalid file must not become an empty store")
    assert store.path.stat().st_size == 0


def test_the_carry_derives_declared_objects_and_refuses_an_undeclared_column(tmp_path):
    """A writer refuses a store missing a declared index, even under maintenance; the
    carry restores it while preserving rows, and an undeclared column remains a refusal
    because its meaning is unknown."""
    store = InputDispositions(tmp_path)
    assert store.record(
        BusInputKey(1), seq=1, owner="kid", claim_scope=1, target="kid", text="first")
    declared = store.declared_schema()
    with store.writing() as connection:
        for name, sql in declared.items():
            if not sql.lstrip().upper().startswith("CREATE TABLE"):
                connection.execute(f'DROP INDEX IF EXISTS "{name}"')
    with maintenance_held(tmp_path), pytest.raises(RelationViolationError,
                                                   match=HeldBusFile.carry_verb):
        with store.writing():
            pytest.fail("Opening a store never restores its index")
    with pytest.raises(MaintenanceNotHeldError):
        InputDispositions.reconcile_at(store.path)
    with maintenance_held(tmp_path):
        assert InputDispositions.reconcile_at(store.path)
    assert store.lookup(BusInputKey(1)).source_text == "first"
    with store.writing() as connection:
        connection.execute(
            f'ALTER TABLE "{InputDispositionRow.declared_name}" ADD COLUMN extra TEXT DEFAULT "kept"')
    with maintenance_held(tmp_path), pytest.raises(RelationViolationError):
        InputDispositions.reconcile_at(store.path)


def test_a_schema_changed_after_its_check_is_refused_on_the_next_read(tmp_path):
    """Readers compare the stored SQL once per schema version; a change in place raises the
    version, so a verified file that loses a declared index is refused again."""
    store = InputDispositions(tmp_path)
    store.record(BusInputKey(1), seq=1, owner="kid", claim_scope=1, target="kid", text="first")
    with store.snapshot() as connection:
        store.require_schema(connection)
    index = next(name for name, sql in store.declared_schema().items()
                 if not sql.lstrip().upper().startswith("CREATE TABLE"))
    with store.writing() as connection:
        connection.execute(f'DROP INDEX "{index}"')
    with pytest.raises(RelationViolationError), store.snapshot():
        pytest.fail("A schema changed in place must be compared again")


def test_in_memory_schema_checks_remember_nothing():
    """An in-memory database has no file identity, so its checks compare again and keep no
    record: one remembered entry per read was an unbounded set on the reader path."""
    import sqlite3

    from agent_comms.storage.typed_table import (
        FiledSchema,
        SchemaRevision,
        TableSchema,
        UnfiledSchema,
    )

    connection = sqlite3.connect(":memory:")
    before = len(FiledSchema.verified_schemas)
    for _ in range(50):
        revision = SchemaRevision.read(connection)
        assert isinstance(revision, UnfiledSchema)
        revision.remember(TableSchema, ())
    assert len(FiledSchema.verified_schemas) == before
