"""Idle observations avoid repeated work without becoming delivery authority."""

import asyncio
import os
import sqlite3
import threading
from contextlib import AsyncExitStack
from pathlib import Path

import pytest

import agent_comms.agent_events as events
from agent_comms.coordination.coordinator import Coordination
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.execution.owned_turn import OwnedTurn
from agent_comms.execution.turn_input_source import NoTurnAcceptance
from agent_comms.messaging.messages import AlertKind, InfoKind, Message, NoticeRole
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import NativeThread
from agent_comms.storage.private_path import FileRevision
from agent_comms.transport.owner_requests import RetainedOwnerLaunch
from bus_history import read_history
from conftest import publish_initial
from delivery_owner_fixture import qualified_owner_launch, start_headless_owner
from test_acp_private_nk_delivery import _session
from test_coordinated_runtime import _root, tmp_path  # noqa: F401


@pytest.mark.asyncio
async def test_observation_waits_for_the_held_coordinator_snapshot(tmp_path):
    comms, agent, root_id, _ = _session(tmp_path)
    held, release = threading.Event(), threading.Event()

    def holder():
        with sqlite3.connect(comms.root / "coordination.sqlite3", isolation_level=None) as db:
            db.execute("BEGIN EXCLUSIVE")
            held.set()
            assert release.wait(5)
            db.execute("ROLLBACK")

    owner = threading.Thread(target=holder)
    owner.start()
    assert held.wait(2)
    # A busy original source is pending, not an unavailable inbox. Cancelling
    # one waiter must leave the holder and the other observations intact.
    tasks = [asyncio.create_task(agent.inputs._observe_private_revision("beta", root_id))
             for _ in range(3)]
    try:
        await asyncio.sleep(0.08)
        assert not any(task.done() for task in tasks)
        tasks[0].cancel()
        await asyncio.sleep(0.04)
        assert not any(task.done() for task in tasks[1:])
    finally:
        release.set()
        owner.join(5)
    with pytest.raises(asyncio.CancelledError):
        await tasks[0]
    observed = await asyncio.wait_for(asyncio.gather(*tasks[1:]), 5)
    assert observed[0] == observed[1]


@pytest.mark.asyncio
async def test_empty_delivery_recovery_does_not_wait_for_wire_writer(tmp_path):
    from agent_comms.queued_input import DeliveredInput

    comms, agent, root_id = _covered_session(tmp_path)
    entered, release = threading.Event(), threading.Event()

    def writer():
        with comms.bus.bus.writing():
            entered.set()
            assert release.wait(5)

    writer_thread = threading.Thread(target=writer)
    writer_thread.start()
    assert entered.wait(2)
    task = asyncio.create_task(DeliveredInput.recover_interrupted(
        agent.inputs, agent.inputs.state("beta"), comms.registry.entry("beta").entry, root_id,
    ))
    try:
        # The real write lock is held; an empty recovery must finish without it.
        done, _ = await asyncio.wait({task}, timeout=1)
        assert task in done
        assert task.result() == 0
    finally:
        release.set()
        writer_thread.join(5)
        await task


@pytest.mark.asyncio
async def test_turn_publication_joins_cancellation_before_lease_release(
    tmp_path: Path, qualified_owner_launch: RetainedOwnerLaunch,
) -> None:
    comms, agent, _root_id, _ = _session(tmp_path)
    origin = Message("user", "#team", "publication ownership", InfoKind)
    execution = OwnedTurn(
        agent.turns, "beta", "beta", "publication ownership", origins=(origin,),
        acceptance=NoTurnAcceptance(),
    )
    async with AsyncExitStack() as resources:
        resources.push_async_callback(agent.shutdown)
        await start_headless_owner(agent, "beta", qualified_owner_launch)
        async with AsyncExitStack() as permits:
            assert await execution.acquire(resources, permits)
            progress = execution.progress
            # Only native events are supplied. Registry, original input,
            # wire notices, diagnostic and final checkpoint use real owners.
            await progress.chunk(events.Chunk("committed progress"))
            await progress.committed_progress(events.CommittedProgress("committed progress"))
            assert progress.reply_parts == []
            assert [(row.body, isinstance(row.role, NoticeRole)) for row in read_history(comms)] == [
                ("committed progress", True),
            ]
            await progress.done(events.Done("refused", False))
            # The committed bus writer holds SQL while the publication is cancelled.
            with comms.bus.bus.writing():
                task = asyncio.create_task(progress.publish_result())
                await asyncio.sleep(0.04)
                task.cancel()
                await asyncio.sleep(0.04)
                assert not task.done()
                assert comms.registry.require("beta").turn_lease == execution.turn_lease
            with pytest.raises(asyncio.CancelledError):
                await task
            rows = read_history(comms)
            assert len(rows) == 2 and isinstance(rows[-1].role, NoticeRole)
            assert rows[-1].type is AlertKind
            assert comms.registry.require("beta").turn_lease == execution.turn_lease
    assert not comms.registry.require("beta").executing


@pytest.mark.asyncio
async def test_original_turn_keeps_cleanup_lease_after_owner_fence(
    tmp_path: Path, qualified_owner_launch: RetainedOwnerLaunch,
) -> None:
    from functools import partial

    from agent_comms.coordination.errors import StaleFence
    from agent_comms.execution.turn_phase import CancellingPhase

    comms, agent, _root_id, session_id = _session(tmp_path)
    execution = OwnedTurn(
        agent.turns, session_id, "beta", "fenced cleanup",
        acceptance=NoTurnAcceptance(),
    )
    async with AsyncExitStack() as resources:
        resources.push_async_callback(agent.shutdown)
        await start_headless_owner(agent, "beta", qualified_owner_launch)
        async with AsyncExitStack() as permits:
            assert await execution.acquire(resources, permits)
            original = execution.turn_lease
            await Coordination.run_worker(partial(comms.owners.fence_stop, "beta"))
            assert execution.turn_lease == original
            with pytest.raises(StaleFence):
                execution.registry_owner.require_running_turn(comms.registry)
            await agent.turns.transition_turn(session_id, execution.turn_lease, CancellingPhase())
            assert not comms.registry.require("beta").executing
    assert not comms.registry.require("beta").executing


def _covered_session(tmp_path):
    comms, agent, root_id, _ = _session(tmp_path)
    other = NativeThread('alpha', frozenset(), Checkout(tmp_path), process_identity=ProcessIdentity.capture(os.getpid()))
    comms.registry.declare(other)
    with Coordination(comms.root / "coordination.sqlite3") as store:
        store.participants.register(
            other.incarnation.lookup, committed=True,
        )
    publish_initial(comms, "sender", other.name, "another recipient's original source")
    return comms, agent, root_id


def test_coordination_read_preserves_revision_and_repairs_exposed_mode(tmp_path):
    path = tmp_path / "coordination.sqlite3"
    with Coordination(path):
        pass
    revision = FileRevision.capture(path)
    with Coordination(path):
        pass
    assert FileRevision.capture(path) == revision
    path.chmod(0o644)
    with Coordination(path):
        assert path.stat().st_mode & 0o777 == 0o600
