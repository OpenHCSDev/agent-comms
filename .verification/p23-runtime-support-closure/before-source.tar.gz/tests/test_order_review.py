"""The colleague's first review of an order is measured from retained deliveries."""

from dataclasses import replace

import pytest

from agent_comms.planning.orders import (
    MeasuredReview,
    TodoStore,
)
from agent_comms.recorded_time import RecordedEventTime
from test_team_problem_orders import order


@pytest.mark.parametrize('rates', ((), (15.0,)))
def test_measured_review_rounds_up_and_keeps_two_minute_floor(tmp_path, rates, source_repository):
    measured = MeasuredReview(rates)
    checked = replace(order(source_repository, 'new-order'), at=RecordedEventTime(100))
    assert measured.review_at(checked).at == 240


def test_empty_measurement_does_not_create_a_store(tmp_path):
    store = TodoStore(tmp_path)
    measured = MeasuredReview.read(store)
    assert measured.rates == ()
    assert not store.path.exists()
