"""Strict stored reads are refused in scope without killing the observer.

No provider input, retry or live bus write. The fixture is a canonical saved
manifest whose declaration name is intentionally unavailable in this reader.
"""


import asyncio
import pickle
from dataclasses import dataclass

import pytest

from agent_comms.context_segments.response import SelectedResponseSegment
from agent_comms.context_store import UNREAD_CONTEXT, ContextRequest
from agent_comms.coordination.errors import (
    CoordinationReadUnavailable,
    DeferredRead,
    SchemaVersionError,
    StaleRevision,
    TranscriptChanged,
)
from agent_comms.errors import (
    RelationViolationError,
    StoredHistoryUnreadable,
)
from agent_comms.execution.turn_context import RecordedContextManifest
from agent_comms.nominal.field_codec import FieldCodec
from agent_comms.notification_reads import LiveNotificationRead
from agent_comms.owner_connection import OwnerIdentityChangedError, OwnerReplyLostError
from agent_comms.presentation import WireRevision
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import NativeThread
from agent_comms.ui_model.observation import (
    LocalRouteObservation,
    ObservationProcess,
    ObserveSidebar,
    ObserveThreads,
    OwnerRead,
    ReadBusy,
    ReadNotifications,
    ReadRefused,
    ReadRequest,
    SidebarObserved,
    SidebarPreparing,
    SidebarReading,
    SidebarReadStage,
    ThreadsObserved,
    ThreadUnavailable,
    UnreadableHistory,
)
from agent_comms.ui_model.status import OpenThreadStatus
from agent_comms_hooks import ToolRefusedError
from observed_queue import ObservedQueue
from test_turn_context_wire import corrupt_context_kind, manifest


@dataclass(frozen=True)
class ReadRecordedContext(ReadRequest):
    thread: str

    def read(self, comms):
        return comms.contexts.page(self.thread, comms.registry)


def saved_row(comms):
    owner = NativeThread('saved', frozenset(), Checkout(comms.root.parent), created_at=17003.0)
    comms.registry.declare(owner)
    comms.contexts.record_after(UNREAD_CONTEXT, manifest(owner))
    with comms.contexts.snapshot() as db:
        request, = ContextRequest.select(db)
        return FieldCodec.encode(request.recorded(db))


def test_recorded_selected_response_remains_a_strict_codec_member(comms):
    row = saved_row(comms)
    segment = row["segments"][0]["manifest"]
    segment["kind"] = "selected_response"
    recorded = FieldCodec.decode(RecordedContextManifest, row)
    assert recorded.segments[0].manifest.kind is SelectedResponseSegment
    assert FieldCodec.encode(recorded) == row
    # Unknown names still fail, not skipped, substituted or rendered as a
    # guessed current producer. The saved declaration is the real decoder.
    segment["kind"] = "unavailable_future_segment"
    with pytest.raises(ValueError):
        FieldCodec.decode(RecordedContextManifest, row)


def test_read_failure_and_thread_status_keep_the_explanation_across_the_pipe(comms):
    saved_row(comms)
    corrupt_context_kind(comms, "saved", "unavailable_future_segment")
    answer = ReadRecordedContext(str(comms.root), "saved", request_id=7).answer(comms)
    assert isinstance(answer, ReadRefused)
    assert isinstance(answer.error, StoredHistoryUnreadable)
    assert "unavailable_future_segment" in str(answer.error)
    round_trip = pickle.loads(pickle.dumps(answer))
    assert str(round_trip.error) == str(answer.error)
    failure = UnreadableHistory.capture(answer.error)
    assert UnreadableHistory.capture(failure) is failure
    observed = ThreadsObserved(WireRevision.empty(), {"saved": ThreadUnavailable(failure)}, frozenset({"saved"}), {})
    status = OpenThreadStatus(lambda callback: callback())
    status.observed(observed)
    assert status.rows.rows["saved"].status.details == (str(failure),)
    assert "unavailable_future_segment" in status.rows.rows["saved"].lines[0]


@pytest.mark.parametrize(
    "error_type", [SchemaVersionError, CoordinationReadUnavailable, StaleRevision, RelationViolationError]
)
def test_store_read_only_retains_the_named_busy_state(comms, error_type):
    @dataclass(frozen=True)
    class FailingRead(ReadRequest):
        error: Exception

        def read(self, comms):
            raise self.error

    error = error_type("original store read explanation")
    if error_type is SchemaVersionError:
        with pytest.raises(error_type):
            FailingRead(str(comms.root), error).answer(comms)
        return
    answer = FailingRead(str(comms.root), error).answer(comms)
    if error_type is CoordinationReadUnavailable:
        assert isinstance(answer, ReadBusy)
        assert answer.title == "History loading"
        assert pickle.loads(pickle.dumps(answer)) == answer
    else:
        assert isinstance(answer, ReadRefused)
        assert answer.error is error


@pytest.mark.parametrize("error, answered", [
    (StaleRevision("inputs changed during preparation"), ReadBusy),
    (TranscriptChanged(), ReadRefused),
])
def test_a_read_that_defers_staleness_answers_a_reload(comms, error, answered):
    # Retrying bounds that name a replaced source never succeeds; deferring it
    # left an agent tab blank with no error.
    @dataclass(frozen=True)
    class DeferringRead(ReadRequest):
        deferred_reads = (DeferredRead,)

        def read(self, comms):
            raise error

    assert isinstance(DeferringRead(str(comms.root)).answer(comms), answered)


@pytest.mark.parametrize("error_type, refused", [
    (SchemaVersionError, True), (CoordinationReadUnavailable, True), (StaleRevision, True),
    (ToolRefusedError, True), (RelationViolationError, True),
    (ConnectionError, True), (TimeoutError, True),
    (OwnerIdentityChangedError, True), (OwnerReplyLostError, True),
    (RuntimeError, False), (ValueError, False), (TypeError, False),
])
async def test_owner_reply_preserves_its_own_failure_type(comms, error_type, refused):
    @dataclass(frozen=True)
    class FailingOwnerRead(OwnerRead):
        async def read(self, owner):
            raise NotImplementedError

        async def ask(self, comms):
            raise error_type("original owner read explanation")

    saved_row(comms)
    request = FailingOwnerRead(str(comms.root), comms.registry.require("saved").incarnation)
    if not refused:
        with pytest.raises(error_type):
            await request.answer(comms)
        return
    answer = await request.answer(comms)
    assert isinstance(answer, ReadRefused)
    assert isinstance(answer.error, error_type)
    assert not isinstance(answer.error, UnreadableHistory)


def failing(error):
    def read(*args, **kwargs):
        raise error
    return read


DEFERRED, MALFORMED = StaleRevision("source moved during the read"), ValueError("Unknown ContextSegment kind")


@dataclass(frozen=True)
class PreparingStage(SidebarReadStage):
    cause: CoordinationReadUnavailable

    def unavailable(self, *args):
        raise self.cause

    def read(self, request, comms, revision):
        return request._answer(revision, self.unavailable, request.worktree)


@pytest.mark.parametrize("cause", [
    CoordinationReadUnavailable("original sidebar read deferred"),
    StaleRevision("source moved"),
])
def test_sidebar_prepares_once_then_publishes_and_keeps_real_rows(comms, cause):
    request = ObserveSidebar(Checkout(comms.root.parent), True, True)
    revision = comms.views.revision()
    reading = SidebarReading(request)
    reading.stage = stage = PreparingStage(cause)
    first = list(reading.read(comms, revision))
    assert isinstance(first[0], SidebarPreparing)
    assert first[0].cause is cause
    transmitted = pickle.loads(pickle.dumps(first[0]))
    assert type(transmitted.cause) is type(cause)
    assert transmitted.cause.args == cause.args
    assert reading.request is request and reading.stage is stage
    assert not any(isinstance(result, SidebarPreparing) for result in reading.read(comms, revision))
    reading.stage = SidebarReadStage()
    completed = list(reading.read(comms, revision))
    assert len(completed) == 1 and isinstance(completed[0], SidebarObserved)
    assert reading.published is completed[0]
    assert list(reading.read(comms, revision)) == []
    reading.stage = stage
    assert not any(isinstance(result, SidebarPreparing) for result in reading.read(comms, revision))
    assert reading.published is completed[0]


async def test_unknown_saved_member_does_not_kill_the_real_observation_process(comms, durable_home):
    saved_row(comms)
    corrupt_context_kind(comms, "saved", "unavailable_future_segment")
    original = comms.contexts.path.read_bytes()
    original_bus = comms.bus.bus.path.read_bytes()
    delivered = ObservedQueue()
    async with ObservationProcess(LocalRouteObservation(comms.route)) as process:
        process.start_receiving(delivered.observed, delivered.failed)
        process.request(ObserveSidebar(Checkout(comms.root.parent), True, True))
        await delivered.until(lambda result: isinstance(result, SidebarObserved))
        assert process.peer.process.is_alive()
        process.request(ObserveThreads(frozenset({"saved"})))
        threads = await delivered.until(lambda result: isinstance(result, ThreadsObserved))
        assert not isinstance(threads.results["saved"], ThreadUnavailable)
        # Only the request needing the damaged payload is refused, over the
        # same actual child/pipe that served the sidebar and thread reads.
        with pytest.raises(StoredHistoryUnreadable):
            async with asyncio.timeout(30):
                await process.read(ReadRecordedContext(str(comms.root), "saved"))
        # Serve a separate, readable request using the same actual pipe/child.
        async with asyncio.timeout(30):
            assert (await process.read(ReadNotifications(str(comms.root), LiveNotificationRead(())))).outcomes == {}
        assert process.peer.process.is_alive()
        assert comms.contexts.path.read_bytes() == original
        assert comms.bus.bus.path.read_bytes() == original_bus


def test_a_reload_reads_afresh_once_and_answers_reload_only_when_its_bounds_stay_stale():
    """A read derives its bounds when it runs: one reload re-reads at once and answers its
    value; a read whose own bounds are stale reloads again, and that is its answer, after
    exactly two reads, never a pending wait on someone else's write."""
    from agent_comms.coordination.errors import ReloadRequired
    from agent_comms.ui_model.observation import ReadReload, ReadValue, UnreadableHistory

    reads = []

    def moved_once():
        reads.append("moved")
        if len(reads) == 1:
            raise ReloadRequired("source moved during the read")
        return "fresh"

    assert UnreadableHistory.outcome(moved_once) == ReadValue("fresh")
    assert reads == ["moved", "moved"]

    reads.clear()

    def stale_bounds():
        reads.append("stale")
        raise ReloadRequired("witness belongs to another page window")

    outcome = UnreadableHistory.outcome(stale_bounds)
    assert isinstance(outcome, ReadReload)
    assert reads == ["stale", "stale"]
    assert outcome.answer(
        lambda value: "value", lambda error: "deferred", lambda error: "unreadable",
        lambda error: f"reload: {error}",
    ) == "reload: witness belongs to another page window"
