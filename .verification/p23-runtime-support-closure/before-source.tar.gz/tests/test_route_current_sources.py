"""Current delivery queries skip retired sender incarnations."""

import pytest

from agent_comms.page_traversal import OlderTraversal
from agent_comms.projects.checkouts import Checkout
from agent_comms.messaging.read_basis import NamedViewer
from agent_comms.registry.threads import NativeThread
from agent_comms.routing import DeliveryScope


@pytest.mark.parametrize('rebound', [False, True])
def test_discovery_ignores_retired_source_history(tmp_path, rebound, comms):
    c = comms
    c.registry.declare(NativeThread('sender', frozenset(), Checkout(tmp_path)))
    viewer = c.messaging.user_identity(Checkout(tmp_path)).name
    original = c.messaging.send('sender', viewer, 'current source').message

    def measured():
        with c.bus.snapshot(viewer=NamedViewer(viewer)) as (basis, source):
            scope = DeliveryScope.capture(viewer, basis.registry, basis.catalog)
            with source.observing() as db:
                steps = []
                db.set_progress_handler(lambda: steps.append(1) and 0, 1)
                try:
                    assert source.unseen_counts(
                        basis.registry, {viewer: scope}, {viewer: basis.seen(source)},
                    ) == {viewer: {'sender': 1}}
                    listed = [r.seq for r in source.unseen_deliveries(
                        basis.registry, scope, basis.seen(source), traversal=OlderTraversal())]
                    assert listed == [original.seq]
                finally:
                    db.set_progress_handler(None, 0)
                return len(steps)

    initial = measured()
    for phase in range(2):
        for number in range(32):
            name = 'sender' if rebound else f'past-{phase}-{number}'
            if rebound:
                c.registry.unregister(name)
                c.registry.remove(name)
            c.registry.declare(NativeThread(name, frozenset(), Checkout(tmp_path)))
            published = c.messaging.send(name, viewer, 'current source').message
            if rebound:
                original = published
            else:
                c.registry.unregister(name)
                c.registry.remove(name)
        assert measured() <= initial + 32
