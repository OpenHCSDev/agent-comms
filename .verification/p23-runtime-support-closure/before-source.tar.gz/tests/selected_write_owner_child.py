"""Real ACP owner/native fixture; explicit auto-wake policy holds operator dispatch."""
from __future__ import annotations

import asyncio
import json
import os
import signal
import sys
from pathlib import Path

from agent_comms.active_route import ActiveRoute
from agent_comms.comms import wire
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.database import CoordinationStore
from agent_comms.execution.native_arguments import GivenArguments, GivenBinary
from agent_comms.launch_root import LaunchRoot
from agent_comms.nominal.field_codec import AcpSessionId
from delivery_owner_fixture import canonical_agent, reply_turn_finished, start_headless_owner
from native_backend_fixture import NativeBackendFixture


async def wait_for(path: Path):
    async with asyncio.timeout(30):
        while not path.exists():
            await asyncio.sleep(0.01)


async def main(base: Path) -> None:
    root = LaunchRoot.startup(sys.argv, ActiveRoute.published_launch)
    comms = wire(root.path)
    await wait_for(base / "registered")
    stopped = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, stopped.set)
    async with Coordination.worker(CoordinationStore.path_in(comms.root)):
        agent = canonical_agent(
            comms, auto_wake=False,
            agent_bin=GivenBinary("pi"), agent_args=GivenArguments(NativeBackendFixture.native_arguments()),
        )
        try:
            await start_headless_owner(agent, "beta", agent.inputs.configuration.launch)
            print(json.dumps({"event": "ready", "pid": os.getpid()}), flush=True)
            await wait_for(base / "dispatch")
            agent.inputs.auto_wake = True
            # The session start_owner published: the drain types it, and its cursor scope encodes it.
            session = AcpSessionId("beta")
            count = await agent._drain_private_nk(
                session, comms.owners.require_private_launch().wire_root_id,
            )
            await reply_turn_finished(agent, session)
            print(json.dumps({"event": "terminal", "pid": os.getpid(), "drained": count}), flush=True)
            await stopped.wait()
        finally:
            await agent.shutdown()
            assert not agent.turns.persistent_backends
            print(json.dumps({"event": "retired", "pid": os.getpid()}), flush=True)


if __name__ == "__main__":
    asyncio.run(main(Path(sys.argv[1])))
