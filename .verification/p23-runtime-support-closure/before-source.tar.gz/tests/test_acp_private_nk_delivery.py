"""A private ACP owner keeps its coordination identity across rename and schema loss."""

from __future__ import annotations

import os

import pytest

from agent_comms.acp import CommsAgent
from agent_comms.acp_extension import CursorAdvancedUpdate, decode_updates
from agent_comms.comms import wire
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.errors import PublicationActivationBlocked
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.nominal.field_codec import AcpSessionId
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.thread_model import DeclaredModel
from agent_comms.registry.threads import NativeThread
from agent_comms.tool_caller import ThreadCaller
from bus_record_fixture import prepare_native_comms
from test_coordinated_runtime import tmp_path as private_root_fixture

tmp_path = private_root_fixture


def _private_comms(tmp_path):
    root = tmp_path / "wire"
    comms = prepare_native_comms(wire(root))
    comms.registry.declare(
        NativeThread('sender', frozenset(), Checkout(tmp_path), process_identity=ProcessIdentity.capture(os.getpid()))
    )
    owner = comms.registry.declare(NativeThread('beta', frozenset({'team'}), Checkout(tmp_path), process_identity=ProcessIdentity.capture(os.getpid()), model=DeclaredModel('test/model')))
    root_id = comms.registry.store.prepare_native_root().namespace
    with Coordination(str(root / "coordination.sqlite3")) as store:
        store.participants.register(
            owner.incarnation.lookup, committed=True
        )
    return comms, root_id


def _session(tmp_path):
    comms, root_id = _private_comms(tmp_path)
    agent = CommsAgent(comms, auto_wake=True)
    session_id = AcpSessionId("beta")
    agent.sessions.publish(session_id, comms.registry.require("beta"))
    return comms, agent, root_id, session_id


def cursor_envelope(metadata):
    """The decoded cursor-advanced update's envelope; the metadata is foreign until decoded."""
    [fact] = [update for update in decode_updates(metadata) if isinstance(update, CursorAdvancedUpdate)]
    return fact.envelope


@pytest.mark.parametrize("managed", [False, True])
def test_private_owner_rename_during_active_attempt_can_complete(tmp_path, managed):
    from agent_comms.attempt_start import AttemptStart
    from agent_comms.attempt_states import SucceededAttempt
    from agent_comms.coordination.tables.executions import AcpOrigin
    from agent_comms.owner_fence import prepare_fence_token
    from test_coordination_store import final_evidence

    comms, _ = _private_comms(tmp_path)
    lookup = comms.registry.require("beta").incarnation.lookup
    with Coordination(str(comms.root / "coordination.sqlite3")) as store:
        before = store.participants.get(lookup)
        store.create("rename-active", AcpOrigin, lookup, 1)
        store.mark_pending("rename-active", expected_revision=1)
        fence = store.start(AttemptStart(
            "rename-active", 1, lookup, 1, prepare_fence_token(),
            expected_execution_revision=2, expected_pointer_revision=0,
        )).value.fence
        active = store.participants.get(lookup)
    if managed:
        comms.threads.rename_managed_thread(comms.registry.require("beta").incarnation, "gamma", owner=ProcessIdentity.capture(os.getpid()))
    else:
        comms.threads.rename_self("gamma", caller=ThreadCaller("beta"))
    assert comms.registry.require("beta").name == "gamma"
    with Coordination(str(comms.root / "coordination.sqlite3")) as store:
        after = store.participants.get(lookup)
        assert after.owner_identity == before.owner_identity
        assert after.owner_identity.generation == before.owner_identity.generation
        assert after.pointer == active.pointer
        fence = final_evidence(store, fence)
        settled = store.settle_nonpublication(
            fence, expected_pointer_revision=1, outcome=SucceededAttempt(),
        ).value
        assert isinstance(settled.attempt.lifecycle, SucceededAttempt)
        assert not settled.is_current


def test_private_rename_preserves_independent_sql_generation(tmp_path):
    comms, _ = _private_comms(tmp_path)
    lookup = comms.registry.require("beta").incarnation.lookup
    with Coordination(str(comms.root / "coordination.sqlite3")) as store:
        store.participants.advance_generation(lookup, expected_generation=1)
    comms.threads.rename_self("gamma", caller=ThreadCaller("beta"))
    assert comms.registry.require("beta").name == "gamma"
    with Coordination(str(comms.root / "coordination.sqlite3")) as store:
        assert store.participants.get(lookup).owner_identity.generation == 2
    assert comms.bus.bus.revision() == 0


async def test_missing_native_schema_refuses_cursor_metadata(tmp_path, native_runtime_package):
    comms, agent, _, session_id = _session(tmp_path)
    try:
        await agent.sessions.bind_owned(comms.registry.require("beta"), session_id)
        assert cursor_envelope(await agent.sessions.metadata("beta", session_id=session_id)) is not None
        with Coordination(str(comms.root / "coordination.sqlite3")) as store:
            store.session._connection.execute("DROP TABLE native_runtime_triage_members")
        with pytest.raises(PublicationActivationBlocked):
            await agent.sessions.metadata("beta", session_id=session_id)
    finally:
        await agent.shutdown()
