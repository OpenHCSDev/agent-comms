"""Only the native project's declared repositories supply order-check directories."""
from pathlib import Path

import pytest

from agent_comms.planning.goals import OrderCheck
from agent_comms.projects.repo import Repo
from agent_comms.registry.registry_document import RegisteredTeamProject
from agent_comms.projects.repository_name import RepositoryName


@pytest.fixture
def configured_repositories(tmp_path: Path) -> tuple[Repo, ...]:
    repos = tuple(
        Repo(checkout=tmp_path / name, github=RepositoryName.from_wire(f"example/{name}"))
        for name in ("agent-comms", "toad")
    )
    for repo in repos:
        repo.checkout.mkdir()
    return repos


def test_configured_name_and_checkout_select_the_same_repository(configured_repositories):
    repositories = configured_repositories
    for repo in repositories:
        assert Repo.selected(repositories, repo.github.name).checkout == repo.checkout
        assert Repo.selected(repositories, str(repo.checkout)).checkout == repo.checkout
        assert Repo.selected(repositories, repo.github.to_wire()).checkout == repo.checkout
        assert Repo.selected(repositories, f"Example/{repo.github.name.upper()}").checkout == repo.checkout
    with pytest.raises(ValueError):
        Repo.selected(repositories, "other/agent-comms")


def test_existing_unconfigured_worktree_is_refused_with_configured_choices(
    configured_repositories, tmp_path,
):
    repositories = configured_repositories
    worktree = tmp_path / "fork-records--P408"
    worktree.mkdir()
    with pytest.raises(ValueError) as refusal:
        Repo.selected(repositories, str(worktree))
    message = str(refusal.value)
    assert str(worktree) in message
    for repo in repositories:
        assert repo.github.name in message
        assert str(repo.checkout) in message


def test_order_check_named_by_repository_binds_its_checkout_from_any_directory(
    configured_repositories, tmp_path, monkeypatch,
):
    elsewhere = tmp_path / "elsewhere"
    elsewhere.mkdir()
    monkeypatch.chdir(elsewhere)
    agent_comms, _ = configured_repositories
    written = OrderCheck(Path("agent-comms"), "grep -c x src")
    with pytest.raises(ValueError):
        written.require_writable()
    bound = written.bound_in(RegisteredTeamProject(repos=configured_repositories))
    assert bound.directory == agent_comms.checkout
    bound.require_writable()
    with pytest.raises(ValueError):
        OrderCheck(Path("unregistered"), "grep -c x src").bound_in(
            RegisteredTeamProject(repos=configured_repositories))
