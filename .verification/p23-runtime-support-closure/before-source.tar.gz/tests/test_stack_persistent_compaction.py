"""A manual /compact runs Pi's own engine in the retained child, which keeps serving."""
import asyncio
import json
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from tempfile import TemporaryDirectory
from uuid import uuid4

import pytest
from acp.schema import TextContentBlock

from agent_comms.acp import CommsClient
from agent_comms.acp_extension import (
    CompactionChangedUpdate,
    CompactionCommittedUpdate,
    CompactRequest,
    TranscriptChangedUpdate,
    decode_updates,
    encode_request,
)
from agent_comms.agent_events import CompactionEnd
from agent_comms.comms import wire
from agent_comms.controller import SessionUpdateSink
from agent_comms.execution.native_arguments import GivenArguments, GivenBinary
from agent_comms.launch_runtime import RestartEnvironment
from agent_comms.nominal.field_codec import AcpSessionId, InputId
from agent_comms.owner_connection import socket_path
from agent_comms.pi_vocabulary import ManualCompactionReason
from agent_comms.queued_input import InitialInput
from delivery_owner_fixture import canonical_agent


def _history(session: Path, project: Path) -> None:
    timestamp = "2026-09-24T00:00:00.000Z"
    rows = [
        {
            "type": "session",
            "version": 3,
            "id": str(uuid4()),
            "timestamp": timestamp,
            "cwd": str(project),
        }
    ]
    parent = None
    for index in range(12):
        for role in ("user", "assistant"):
            entry_id = f"{len(rows):08x}"
            message = {
                "role": role,
                "content": [
                    {
                        "type": "text",
                        "text": (
                            ("LEGACY_DISCARDED_HISTORY " if index == 0 else f"HISTORY_{index} ")
                            + "Recorded experimental observation. " * 400
                            if role == "user"
                            else "Recorded."
                        ),
                    }
                ],
                "timestamp": 1790290000000 + len(rows),
            }
            if role == "assistant":
                message.update(
                    api="openai-completions",
                    provider="openrouter",
                    model="z-ai/glm-5.3-flash",
                    stopReason="stop",
                    usage={
                        "input": 40000,
                        "output": 2,
                        "cacheRead": 0,
                        "cacheWrite": 0,
                        "totalTokens": 40002,
                        "cost": {
                            "input": 0,
                            "output": 0,
                            "cacheRead": 0,
                            "cacheWrite": 0,
                            "total": 0,
                        },
                    },
                )
            rows.append(
                {
                    "type": "message",
                    "id": entry_id,
                    "parentId": parent,
                    "timestamp": timestamp,
                    "message": message,
                }
            )
            parent = entry_id
    session.write_text("".join(json.dumps(row) + "\n" for row in rows))
    session.chmod(0o600)


async def test_manual_compaction_keeps_the_retained_child_serving(monkeypatch, native_runtime_package):
    native = os.environ.get("AC_NATIVE_STACK_BIN")
    if not native:
        pytest.skip("Requires prepared native Pi stack")
    with TemporaryDirectory(prefix="ac-persistent-compact-", dir="/var/tmp") as directory:
        root = Path(directory)
        requests = []
        summary_entered = threading.Event()
        release_summary = threading.Event()
        summary = "COMPACTED_HISTORY_SENTINEL: Earlier experimental observations were recorded."

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                request = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                requests.append(request)
                is_summary = len(requests) == 3
                if is_summary:
                    summary_entered.set()
                    assert release_summary.wait(15), "Test did not release native summary"
                chunk = {
                    "id": f"response-{len(requests)}",
                    "object": "chat.completion.chunk",
                    "created": 1,
                    "model": "z-ai/glm-5.3-flash",
                    "choices": [
                        {
                            "index": 0,
                            "delta": {
                                "role": "assistant",
                                "content": summary if is_summary else "RECEIVED",
                            },
                            "finish_reason": "stop",
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 40000,
                        "completion_tokens": 10,
                        "total_tokens": 40010,
                    },
                }
                body = f"data: {json.dumps(chunk)}\n\ndata: [DONE]\n\n".encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                self.wfile.flush()

            def log_message(self, *_args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        serving = threading.Thread(target=server.serve_forever, daemon=True)
        serving.start()
        config = root / "agent"
        config.mkdir(mode=0o700)
        (config / "auth.json").write_text("{}")
        (config / "auth.json").chmod(0o600)
        (config / "settings.json").write_text(
            json.dumps(
                {
                    "compaction": {"enabled": False},
                    "retry": {"enabled": False, "maxRetries": 0, "provider": {"maxRetries": 0}},
                }
            )
        )
        (config / "models.json").write_text(json.dumps({"providers": {"openrouter": {
            "baseUrl": f"http://127.0.0.1:{server.server_port}/v1",
        }}}))
        for key in (
            "PI_PARENT_ID",
            "PI_WORKTREE",
            "AGENT_COMMS_THREAD",
            "AGENT_COMMS_MANAGED",
            "AGENT_COMMS_DEBUG_LOG",
        ):
            monkeypatch.delenv(key, raising=False)
        for key, value in {
            **RestartEnvironment(native_config=config, agent_directory=config).encode_native(),
            "AGENT_COMMS_NATIVE_ORIGIN": f"http://127.0.0.1:{server.server_port}",
            "PI_OFFLINE": "1",
            "PI_TELEMETRY": "0",
            "OPENROUTER_API_KEY": "local-only",
            "AGENT_COMMS_ROOT": str(root / "wire"),
            "AGENT_COMMS_AGENT_MODELS": "openrouter/z-ai/glm-5.3-flash",
            # Core's task brief: Pi adds it to every compaction's instructions.
            "PI_TASK": "TASK_BRIEF_SENTINEL keep the experiment ledger",
        }.items():
            monkeypatch.setenv(key, value)
        project = root / "worker"
        project.mkdir()
        session = root / "saved.jsonl"
        _history(session, project)
        comms = wire(root / "wire")
        owner = canonical_agent(
            comms,
            agent_bin=GivenBinary(native),
            agent_args=GivenArguments(("--provider", "openrouter", "--model", "z-ai/glm-5.3-flash", "--thinking", "off",)),
            
            auto_wake=False,
        )
        updates = []

        class Client(SessionUpdateSink):
            async def publish_update(self, **kwargs):
                updates.append(kwargs["update"].model_dump(by_alias=True))
                return True

        owner.on_connect(Client())
        attachment = CommsClient(
            comms,
            agent_bin=GivenBinary(native),
            auto_wake=False,
        )
        attached_facts = []

        class AttachedClient(SessionUpdateSink):
            async def publish_update(self, **kwargs):
                attached_facts.extend(decode_updates(kwargs["update"].field_meta))
                return True

        attachment.on_connect(AttachedClient())
        retained = resumed = None
        compact_task = None
        try:
            await owner.new_session(str(project))
            worker_session = AcpSessionId("worker")
            comms.threads.attach_session((attachment_owner := comms.registry.require("worker")), str(session), process=attachment_owner.process_identity)
            await asyncio.wait_for(
                InitialInput.run(
                    owner.inputs, worker_session, "worker", "WARMUP", input_id=InputId.mint()
                ),
                20,
            )
            retained = owner.turns.persistent_backends["worker"].child_state.idle().child.proc
            assert retained is not None and retained.returncode is None, json.dumps(
                updates, indent=2
            )
            await asyncio.wait_for(
                InitialInput.run(
                    owner.inputs, worker_session, "worker", "REUSE", input_id=InputId.mint()
                ),
                20,
            )
            assert owner.turns.persistent_backends["worker"].child_state.idle().child.proc is retained
            assert retained.returncode is None
            assert len(requests) == 2
            assert "LEGACY_DISCARDED_HISTORY" in json.dumps(requests[-1]["messages"])
            before = session.read_bytes()
            runtime_path = socket_path(comms.root, os.getpid())
            assert runtime_path.exists()
            await attachment.load_session(cwd=str(project), session_id="worker")
            assert attachment.sessions.proxies["worker"].path == runtime_path
            assert not attachment.turns.persistent_backends
            attached_facts.clear()
            compact_task = asyncio.create_task(
                attachment.prompt(
                    "worker",
                    [TextContentBlock(type="text", text="")],
                    _meta=encode_request(CompactRequest()),
                )
            )
            entered = await asyncio.to_thread(summary_entered.wait, 15)
            if not entered and compact_task.done():
                pytest.fail(f"Native compaction did not request summary: {compact_task.result()}")
            assert entered, "Native compaction did not reach localhost summary"
            # Pi's engine runs in the retained child; nothing is written until it places the summary.
            assert retained.returncode is None
            assert owner.turns.persistent_backends["worker"].child_state.idle().child.proc is retained
            assert session.read_bytes() == before
            assert "LEGACY_DISCARDED_HISTORY" in json.dumps(requests[2]["messages"])
            assert "TASK_BRIEF_SENTINEL" in json.dumps(requests[2]["messages"])
            release_summary.set()
            result = await asyncio.wait_for(compact_task, 20)
            assert result.stop_reason == "end_turn"
            committed = [
                fact
                for fact in decode_updates(result.field_meta)
                if isinstance(fact, CompactionCommittedUpdate)
            ]
            assert len(committed) == 1 and summary in committed[0].summary
            async with asyncio.timeout(10):
                while True:
                    facts = attached_facts
                    if any(isinstance(fact, TranscriptChangedUpdate) for fact in facts) and any(
                        isinstance(fact, CompactionChangedUpdate)
                        and isinstance(fact.event, CompactionEnd)
                        for fact in facts
                    ):
                        break
                    await asyncio.sleep(0.01)
            terminal = [
                fact.event
                for fact in facts
                if isinstance(fact, CompactionChangedUpdate)
                and isinstance(fact.event, CompactionEnd)
            ]
            assert len(terminal) == 1
            assert terminal[0].reason is ManualCompactionReason
            assert not attachment.turns.persistent_backends
            # The child that compacted stays retained and current; nothing reopens it.
            assert retained.returncode is None
            assert owner.turns.persistent_backends["worker"].available
            assert owner.turns.persistent_backends["worker"].child_state.idle().child.proc is retained
            rows = [json.loads(line) for line in session.read_text().splitlines()]
            compactions = [row for row in rows if row.get("type") == "compaction"]
            assert len(compactions) == 1
            assert summary in compactions[0]["summary"]
            await asyncio.wait_for(
                InitialInput.run(
                    owner.inputs, worker_session, "worker", "AFTER_COMPACT", input_id=InputId.mint()
                ),
                20,
            )
            resumed = owner.turns.persistent_backends["worker"].child_state.idle().child.proc
            assert resumed is retained and resumed.returncode is None
            assert len(requests) == 4
            context = json.dumps(requests[-1]["messages"])
            assert "COMPACTED_HISTORY_SENTINEL" in context
            assert "AFTER_COMPACT" in context
            assert "LEGACY_DISCARDED_HISTORY" not in context
            await attachment.shutdown()
            await owner.shutdown()
            assert not runtime_path.exists()
            assert resumed.returncode is not None
            assert not owner.turns.persistent_backends
        finally:
            release_summary.set()
            if compact_task is not None and not compact_task.done():
                compact_task.cancel()
                await asyncio.gather(compact_task, return_exceptions=True)
            await attachment.shutdown()
            await owner.shutdown()
            for process in (retained, resumed):
                if process is not None:
                    assert process.returncode is not None
            server.shutdown()
            server.server_close()
            serving.join(timeout=2)
