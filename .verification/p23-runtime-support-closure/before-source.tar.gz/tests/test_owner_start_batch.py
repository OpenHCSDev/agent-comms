"""Real shared-host owner starts, with no new input or provider execution."""
from __future__ import annotations

from pathlib import Path

import pytest

from agent_comms.cli_verbs.restore_owner import RestoreOwnerCliCommand
from agent_comms.cli_verbs.start import StartCliCommand
from agent_comms.comms import Comms
from agent_comms.errors import UnregisteredThreadError
from agent_comms.installer.native_package import VerifiedNativePackage
from agent_comms.nominal.field_codec import FieldCodec
from agent_comms.owner_connection import OwnerConnection
from agent_comms.pi_rule_gate import PiRedeal
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import NativeThread
from agent_comms.transport.owner_requests import (
    ReadOwnerLaunchRuntimeRequest,
    RetainedOwnerLaunch,
)
from bus_record_fixture import prepare_native_comms


def attached_launch(comms: Comms, name: str) -> RetainedOwnerLaunch:
    snapshot = comms.registry.snapshot()
    process = snapshot.require(name).require_process()
    return FieldCodec.decode(RetainedOwnerLaunch, OwnerConnection.exchange(
        comms.root, process,
        ReadOwnerLaunchRuntimeRequest(thread=name, owner=snapshot.owner_identity(name)),
    ))


@pytest.mark.parametrize("command", (RestoreOwnerCliCommand, StartCliCommand))
def test_start_batch_attaches_every_owner_to_one_host(
    tmp_path: Path, native_runtime_package: VerifiedNativePackage,
    command: type[RestoreOwnerCliCommand], comms: Comms,
) -> None:
    prepare_native_comms(comms)
    names = ("first", "second")
    for name in names:
        comms.registry.declare(NativeThread(name, frozenset(), Checkout(tmp_path)))
    try:
        results = command.apply_together(comms, tuple(command(name=name) for name in names))
        assert tuple(result.thread for result in results) == names
        assert all(result.launched for result in results)
        first, second = (attached_launch(comms, name) for name in names)
        assert first.process == second.process and first.process.alive()
        assert {result.pid for result in results} == {first.process.pid}
        assert all(not command(name=name).apply(comms).launched for name in names)
    finally:
        comms.owners.stop(*names)
    assert all(not comms.registry.require(name).process_alive for name in names)


def test_later_selection_failure_joins_the_already_dispatched_start(
    tmp_path: Path, native_runtime_package: VerifiedNativePackage, comms: Comms,
) -> None:
    prepare_native_comms(comms)
    comms.registry.declare(NativeThread("first", frozenset(), Checkout(tmp_path)))
    try:
        with pytest.raises(UnregisteredThreadError):
            comms.owners.start_many(("first", "missing"))
        # The first request was sent once. Failure of another selection must
        # join its attachment, not close the reply pipe or roll it back.
        launch = attached_launch(comms, "first")
        assert launch.process == comms.registry.require("first").require_process()
        assert not comms.owners.start_many(("first",))[0].launched
    finally:
        comms.owners.stop("first")


def test_failed_binding_retires_without_stopping_its_shared_host(
    tmp_path: Path, native_runtime_package: VerifiedNativePackage, comms: Comms,
) -> None:
    prepare_native_comms(comms)
    for name in ("healthy", "failed"):
        comms.registry.declare(NativeThread(name, frozenset(), Checkout(tmp_path)))
    gate = PiRedeal.of(comms, comms.registry.require("failed"))
    # Malformed JSON is deliberately renewed as an undealt session. An unreadable
    # record path fails at the same real read boundary, before ACP publication.
    gate.record.mkdir(parents=True)
    try:
        comms.owners.start_many(("healthy",))
        host = attached_launch(comms, "healthy").process
        with pytest.raises(RuntimeError):
            comms.owners.start_many(("failed",))
        assert comms.registry.require("failed").require_process() == host

        comms.owners.stop("failed")

        assert not comms.registry.require("failed").process_alive
        assert attached_launch(comms, "healthy").process == host
        assert host.alive()
        gate.record.rmdir()
        comms.owners.start_many(("failed",))
        assert attached_launch(comms, "failed").process == host
    finally:
        comms.owners.stop("failed", "healthy")
