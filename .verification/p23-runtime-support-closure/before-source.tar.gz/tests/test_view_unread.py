import os
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest

from agent_comms.comms import wire
from agent_comms.coordination.errors import DMPaintedBoundChanged
from agent_comms.projects.checkouts import Checkout
from agent_comms.messaging.read_basis import NamedViewer
from agent_comms.registry.threads import NativeThread
from agent_comms.storage.private_path import FileRevision
from agent_comms.view_unread import Counted, ReplyIndex
from conftest import installed_comms


def team_channel(root, *outsiders):
    """alice and bob in #team; each outsider registered with no tags."""
    comms = installed_comms(root)
    for name in ("alice", "bob"):
        comms.registry.declare(NativeThread(name, frozenset({'team'}), Checkout(root)))
    for name in outsiders:
        comms.registry.declare(NativeThread(name, frozenset(), Checkout(root)))
    return comms


def test_reply_suffix_counts_only_its_revision_or_a_fully_read_source(tmp_path):
    source = tmp_path / "native.jsonl"
    source.write_bytes(b"first reply\n")
    indexed = FileRevision.capture(source)
    index = ReplyIndex(revision=indexed, records=1, source=str(source), start=0,
                       complete=indexed.size)

    with source.open("ab") as stream:
        stream.write(b"another reply\n")
    growing = FileRevision.capture(source)
    assert index.counts(indexed, 0)
    assert not index.counts(growing, 0)  # A changed source needs a fresh suffix.
    assert index.counts(growing, growing.size)  # The read mark itself proves zero unread.
    assert index.counted(1, 0) == Counted(1)

    source.write_bytes(b"")
    truncated = FileRevision.capture(source)
    assert not index.continues(truncated)
    assert index.counts(truncated, 0)  # Empty and fully read, independently of the old index.


def test_an_appended_source_keeps_its_stored_replies_while_the_delta_prepares(tmp_path):
    """An agent appending to its transcript must not flip its sidebar row to indexing and
    back on every write: the indexed replies all remain, so they still answer."""
    source = tmp_path / "native.jsonl"
    source.write_bytes(b"first reply\n")
    indexed = FileRevision.capture(source)
    index = ReplyIndex(revision=indexed, records=1, source=str(source), start=0,
                       complete=indexed.size)
    with source.open("ab") as stream:
        stream.write(b"another reply\n")
    growing = FileRevision.capture(source)
    assert not index.counts(growing, 0)  # The delta still needs preparing...
    assert index.presents(growing, 0)  # ...while the stored replies answer meanwhile.

    replaced = tmp_path / "replacement.jsonl"
    replaced.write_bytes(b"first reply\nanother reply\nthird\n")
    os.replace(replaced, source)
    assert not index.presents(FileRevision.capture(source), 0)  # A new file has no replies yet.
    assert not ReplyIndex(source=str(source)).presents(FileRevision.capture(source), 0)


def test_any_mode_expansion_keeps_unpainted_dm_unread(tmp_path):
    comms = team_channel(tmp_path)
    comms.messaging.send("alice", "bob", "hidden until any-mode")
    assert comms.views.viewer_snapshot(Checkout(tmp_path)).channel_unread["#team"].count == 0
    comms.views.mark_user_view_read("#team", worktree=Checkout(tmp_path))
    comms.channels.set_channel_any_mode("#team", True)
    assert comms.views.viewer_snapshot(Checkout(tmp_path)).channel_unread["#team"].count == 1
    assert wire(tmp_path).views.viewer_snapshot(Checkout(tmp_path)).channel_unread["#team"].count == 1


def test_any_mode_ack_covers_only_the_painted_participant_basis(tmp_path):
    comms = team_channel(tmp_path, "carol", "dave")
    comms.channels.set_channel_any_mode("#team", True)
    comms.messaging.send("carol", "dave", "unpainted older DM")
    comms.messaging.send("alice", "bob", "painted DM")
    assert comms.views.viewer_snapshot(Checkout(tmp_path)).channel_unread["#team"].count == 1
    comms.views.mark_user_view_read("#team", worktree=Checkout(tmp_path))
    assert comms.views.viewer_snapshot(Checkout(tmp_path)).channel_unread["#team"].count == 0

    # Carol's old DM becomes visible only after joining the channel. The
    # previous painted basis cannot acknowledge this newly included history.
    comms.channels.update_tags("carol", add=frozenset({"team"}))
    assert wire(tmp_path).views.viewer_snapshot(Checkout(tmp_path)).channel_unread["#team"].count >= 1


def test_any_mode_rejects_stale_painted_page_after_participant_joins(tmp_path):
    comms = team_channel(tmp_path, "carol", "dave")
    comms.channels.set_channel_any_mode("#team", True)
    comms.messaging.send("carol", "dave", "hidden old DM")
    comms.messaging.send("alice", "bob", "painted DM")
    painted = comms.views.channel_display_page("#team", viewer=NamedViewer(comms.messaging.user_identity(Checkout(tmp_path)).name))
    assert [message.seq for message in painted.messages] == [2]

    comms.channels.update_tags("carol", add=frozenset({"team"}))
    unread_after_join = wire(tmp_path).views.viewer_snapshot(Checkout(tmp_path)).channel_unread["#team"].count
    with pytest.raises(DMPaintedBoundChanged):
        comms.views.mark_page_read(painted, worktree=Checkout(tmp_path))
    assert (
        wire(tmp_path).views.viewer_snapshot(Checkout(tmp_path)).channel_unread["#team"].count == unread_after_join
    )


@pytest.mark.skipif(os.name != "posix", reason="real /var/tmp crash durability")
def test_crashed_sender_reopen_does_not_hide_unpainted_any_mode_dm():
    with tempfile.TemporaryDirectory(dir="/var/tmp") as directory:
        root = Path(directory)
        comms = team_channel(root)
        comms.messaging.send("alice", "bob", "hidden before crash")
        comms.views.mark_user_view_read("#team", worktree=Checkout(root))
        child = subprocess.run(
            [
                sys.executable,
                "-c",
                "import os, sys\nfrom agent_comms.comms import wire\nwire(sys.argv[1]).messaging.send('alice', 'bob', 'hidden before exit')\nos._exit(9)",
                str(root),
            ],
            check=False,
        )
        assert child.returncode == 9
        reopened = wire(root)
        reopened.channels.set_channel_any_mode("#team", True)
        assert [message.seq for message in list(reopened.views.channel_display_page("#team").messages)] == [1, 2]
        assert reopened.views.viewer_snapshot(Checkout(root)).channel_unread["#team"].count == 2


def test_pending_counts_between_snapshots_count_only_the_appended_rows(tmp_path):
    """Every viewer snapshot asks for the viewer's pending counts. With the same cursor, scope
    and registry, a row already counted cannot change (its audience is frozen at append), so
    the second snapshot counts only what was appended since the first, and still agrees with
    a whole count."""
    comms = team_channel(tmp_path)
    bus = comms.views.bus
    for index in range(3):
        comms.messaging.send("alice", "bob", f"waiting {index}")
    with bus.snapshot(NamedViewer("bob")) as (basis, source):
        first = bus.pending_counts_opened(source, basis)
        counted_through = source.revision()
    comms.messaging.send("alice", "bob", "new")
    queries = []
    with bus.snapshot(NamedViewer("bob")) as (basis, source), source.observing() as db:
        db.set_trace_callback(queries.append)
        second = bus.pending_counts_opened(source, basis)
    counted = [query for query in queries if "GROUP BY actor,target,sender" in query]
    assert len(counted) == 1 and f"{counted_through} AS after" in counted[0]
    assert sum(second.values()) == sum(first.values()) + 1
    fresh = wire(tmp_path).views.bus
    with fresh.snapshot(NamedViewer("bob")) as (basis, source):
        assert fresh.pending_counts_opened(source, basis) == second
