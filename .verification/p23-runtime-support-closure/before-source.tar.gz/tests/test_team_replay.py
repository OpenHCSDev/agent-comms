"""Replay a small fleet written through Core's own writers: each covered incident is raised once.

Git is real (a temporary repository, origin remote, unit homes and allocated order checkouts);
only forge answers come from the external gh fixture, through the unmodified reader.
"""

import json
import os
import subprocess
import time
from abc import ABC, abstractmethod
from collections import Counter
from dataclasses import dataclass, field, replace
from datetime import UTC, datetime
from pathlib import Path
from typing import ClassVar

import pytest

from agent_comms.cli_bridges.codex_connection import CodexConnection
from agent_comms.comms import Comms
from agent_comms.execution.turn_item import (
    NativeItemId,
    NativeTurnId,
)
from agent_comms.external_transcript import ExternalTranscript
from agent_comms.launch_runtime import LaunchRoot
from agent_comms.nominal.field_codec import ToolCallId
from agent_comms.order_runs import ApplicationOrderRun, MechanicalOrderRun
from agent_comms.planning.goal_actions import CreateProblemGoalAction
from agent_comms.planning.goals import (
    CountCheckResult,
    OrderCheck,
)
from agent_comms.planning.orders import (
    ClaimOrder,
    DraftListedPullRequest,
    OperationDelivery,
    OrderClaim,
    OrderMessage,
    PendingProblemOrder,
    ProgressRead,
    Todo,
    UnmergedListedPullRequest,
)
from agent_comms.planning.pull_requests import PullRequestLink
from agent_comms.projects.checkouts import (
    Checkout,
    RepositoryReads,
    UnpushedHead,
)
from agent_comms.projects.repo import Repo
from agent_comms.recorded_time import RecordedEventTime
from agent_comms.registry.thread_identity import (
    ReportedTools,
    ToolName,
)
from agent_comms.registry.thread_text import ForkedParent
from agent_comms.registry.threads import NativeThread, Thread
from agent_comms.projects.repository_name import RepositoryName
from agent_comms.team.publication_rules import EmptyPullRequest, UnpushedBranch
from agent_comms.team.spinning import SpinningTeammate, StaleUncommittedEdits
from agent_comms.team.standing_rules import (
    BranchBehindMain,
    BranchGrowth,
    ConflictingBranches,
    DeliveredHeadReview,
    HeldBranchRule,
    LostTools,
    StandingRule,
    TeamInputs,
    UnparsedBranch,
)
from agent_comms.team_heartbeat import TeamObservation
from agent_comms.transcript_events import ToolStartTranscript
from agent_comms.ui_model.teammate_state import Unreadable
from agent_comms.work_branches import SourceGrowth, WorkBranchError
from conftest import declare_test_bus
from fixture_git import IDENTITY
from github_fixture import GitHubFixture
from source_revision_fixture import SourceRepository
from team_heartbeat_fixture import LIVE_PLAN_READINGS, current_hud, observe_team
from test_watch_git_preparation import GitPreparation

pytest_plugins = ("github_fixture",)


@dataclass
class Team:
    """One teammate, one repository and the units its seeds add."""

    comms: Comms
    source: SourceRepository
    worktrees: Path
    old_main: str
    request: str
    github: GitHubFixture
    problems: dict[str, str] = field(default_factory=dict)
    teammate: ClassVar[str] = "colleague"

    @property
    def repository(self) -> RepositoryName:
        return self.source.github

    @property
    def main(self) -> str:
        return self.git(self.source.checkout, "rev-parse", "refs/remotes/origin/main")

    @staticmethod
    def git(checkout: Path, *arguments: str, at: float | None = None) -> str:
        """Real Git; a past ``at`` dates the commit and the HEAD reflog entry it writes."""
        environment = {
            key: value for key, value in os.environ.items() if not key.startswith("GIT_")
        }
        if at is not None:
            environment["GIT_AUTHOR_DATE"] = environment["GIT_COMMITTER_DATE"] = f"@{int(at)}"
        return subprocess.run(
            ("git", *IDENTITY, "-C", str(checkout), *arguments),
            env=environment,
            capture_output=True,
            text=True,
            check=True,
            timeout=30,
        ).stdout.strip()

    def observe(self) -> TeamObservation:
        return observe_team(
            self.comms, ProgressRead()
        )

    def thread(self, name: str) -> Thread:
        return self.comms.registry.require(name)

    def worktree(self, branch: str, *, base: str, at: float | None = None) -> Path:
        path = self.worktrees / branch
        self.git(
            self.source.checkout, "worktree", "add", "-q", "-b", branch, str(path), base, at=at
        )
        return path

    def commit(self, worktree: Path, name: str, text: str, *, at: float | None = None) -> str:
        (worktree / name).parent.mkdir(parents=True, exist_ok=True)
        (worktree / name).write_text(text)
        self.git(worktree, "add", name, at=at)
        self.git(worktree, "commit", "-q", "-m", f"Change {name}", at=at)
        return self.git(worktree, "rev-parse", "HEAD")

    def push(self, worktree: Path) -> None:
        self.git(worktree, "push", "-q", "-u", "origin", "HEAD")

    def unit(self, name: str, worktree: Path, *, at: float | None = None) -> Todo:
        """Register a home, publish its order and populate the allocated order checkout."""
        declare_test_bus(
            self.comms,
            threads=(NativeThread(name=name, tags=frozenset({"comms"}), worktree=Checkout(worktree)),),
        )
        todo = self.order(name, worktree, at=time.time() if at is None else at)
        rule = self.comms.registry.storage_rule
        checkout = rule.order_checkout(rule.initial_roots(name), todo.id)
        branch = self.git(worktree, 'rev-parse', '--abbrev-ref', 'HEAD')
        self.git(worktree, 'switch', '--detach', at=at)
        self.git(worktree, 'worktree', 'add', '-q', str(checkout), branch, at=at)
        return todo

    def order(self, name: str, worktree: Path, *, at: float) -> Todo:
        problem = self.problems.setdefault(name, f"P{len(self.problems) + 1}")
        scope = SourceRepository.scope()
        self.comms.goals.update_goal(
            name,
            CreateProblemGoalAction(
                problem=problem,
                request=self.request,
                assigner=self.thread(self.teammate).incarnation,
                repo=self.repository,
                text=f"Repair {name}",
                review_at=RecordedEventTime(time.time() + 3600),
                order=PendingProblemOrder(
                    owner=scope.shape.parents[0],
                    scope=scope,
                    run=MechanicalOrderRun(),
                    check=OrderCheck(worktree, "printf 0", CountCheckResult(1)),
                    edits=("Repair the existing owner",),
                    banned=("No second store",),
                    report="Report the result",
                    at=RecordedEventTime(at),
                    first_call_deadline=RecordedEventTime(time.time() + 3600),
                ),
            ),
        )
        return self.comms.goals.todos.get(problem)

    def claim(self, todo: Todo, number: int, head: str, *, at: float) -> OrderClaim:
        """The unit delivers through the claim writer, linking its pull request to the order."""
        colleague = self.thread(self.teammate).incarnation
        unit = self.thread(todo.held().owner).incarnation
        original = self.comms.messaging.send(
            self.teammate, unit.name, todo.order.instructions(todo)
        ).message
        todo = self.comms.goals.todos.apply(
            todo.id, OrderMessage(todo.revision, colleague, original.message_id, at=RecordedEventTime(time.time()))
        )
        claimed = OrderClaim.for_order(
            todo,
            unit,
            PullRequestLink(self.repository, number),
            head,
            "Delivered the repair",
            (original.reference,),
        )
        claimed = replace(claimed, message=replace(claimed.message, timestamp=at))
        ClaimOrder(todo.revision, unit, todo.held().generation, claimed).record(
            self.comms.goals, todo.id
        )
        return claimed

    def pull_request(self, number: int, branch: str, head: str, *,
                     kind: type[UnmergedListedPullRequest] = UnmergedListedPullRequest,
                     queued: bool = False) -> None:
        stamp = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
        self.github.put(self.repository, kind(
            number, branch, head, stamp, "main", reviewable_times=(stamp,), queued=queued,
        ))


class IncidentSeed(ABC):
    """One covered standing rule: the fleet it needs and the single rule the replay must raise."""

    seeds: ClassVar[dict[type[StandingRule], type[IncidentSeed]]] = {}
    rule: ClassVar[type[StandingRule]]

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        IncidentSeed.seeds[cls.rule] = cls

    @classmethod
    @abstractmethod
    def seed(cls, fleet: Team) -> StandingRule: ...


class BranchBehindMainSeed(IncidentSeed):
    rule = BranchBehindMain

    @classmethod
    def seed(cls, fleet: Team) -> StandingRule:
        worktree = fleet.worktree("behind", base=fleet.old_main)
        fleet.commit(worktree, "behind.py", "behind = 1\n")
        fleet.push(worktree)
        todo = fleet.unit("behind", worktree)
        return BranchBehindMain(
            holder=todo.held().owner_identity,
            problem=todo.id,
            repository=fleet.repository,
            branch="behind",
            behind=1,
        )


class ConflictingBranchesSeed(IncidentSeed):
    rule = ConflictingBranches

    @classmethod
    def seed(cls, fleet: Team) -> StandingRule:
        held = []
        for branch in ("shared-left", "shared-right"):
            worktree = fleet.worktree(branch, base=fleet.main)
            fleet.commit(worktree, "shared.py", f"side = {branch!r}\n")
            fleet.push(worktree)
            held.append(fleet.unit(branch, worktree))
        left, right = held
        return ConflictingBranches(
            holder=left.held().owner_identity,
            problem=left.id,
            repository=fleet.repository,
            branch="shared-left",
            other_problem=right.id,
            other_holder=right.held().owner_identity,
            other_branch="shared-right",
            paths=("shared.py",),
        )


class BranchGrowthSeed(IncidentSeed):
    rule = BranchGrowth

    @classmethod
    def seed(cls, fleet: Team) -> StandingRule:
        worktree = fleet.worktree("growing", base=fleet.main)
        fleet.commit(
            worktree, "src/agent_comms/grown.py",
            "".join(f"v{i} = {i}\n" for i in range(SourceGrowth.limit + 1)),
        )
        fleet.push(worktree)
        todo = fleet.unit("growing", worktree)
        return BranchGrowth(
            holder=todo.held().owner_identity, problem=todo.id, repository=fleet.repository,
            branch="growing",
            growth=SourceGrowth((("src/agent_comms/grown.py", SourceGrowth.limit + 1),)),
        )


class UnparsedBranchSeed(IncidentSeed):
    rule = UnparsedBranch

    @classmethod
    def seed(cls, fleet: Team) -> StandingRule:
        worktree = fleet.worktree("unparsed", base=fleet.main)
        fleet.commit(worktree, "src/agent_comms/unparsed.py", "<<<<<<< HEAD\n")
        fleet.push(worktree)
        todo = fleet.unit("unparsed", worktree)
        return UnparsedBranch(holder=todo.held().owner_identity, problem=todo.id,
                              repository=fleet.repository, branch="unparsed", unparsed=())


class UnpushedBranchSeed(IncidentSeed):
    rule = UnpushedBranch

    @classmethod
    def seed(cls, fleet: Team) -> StandingRule:
        worktree = fleet.worktree("unpushed", base=fleet.main)
        head = fleet.commit(worktree, "unpushed.py", "unpushed = 1\n")
        todo = fleet.unit("unpushed", worktree)
        unit = fleet.thread("unpushed")
        return UnpushedBranch(
            holder=unit.incarnation,
            problem=todo.id,
            order=todo.order.checked().id,
            worktree=fleet.comms.registry.storage_rule.order_checkout(
                fleet.comms.registry.storage_rule.initial_roots(unit.name), todo.id),
            unpublished=UnpushedHead(head, 1, ""),
        )


class EmptyPullRequestSeed(IncidentSeed):
    rule = EmptyPullRequest

    @classmethod
    def seed(cls, fleet: Team) -> StandingRule:
        worktree = fleet.worktree("empty", base=fleet.main)
        fleet.commit(worktree, "empty.py", "empty = 1\n")
        fleet.push(worktree)
        todo = fleet.unit("empty", worktree)
        # The PR's head is main itself; a fresh claim is not yet owed a head review.
        fleet.pull_request(11, "empty", fleet.main)
        fleet.claim(todo, 11, fleet.main, at=time.time())
        return EmptyPullRequest(
            holder=todo.held().owner_identity,
            problem=todo.id,
            order=todo.order.checked().id,
            pull_request=PullRequestLink(fleet.repository, 11),
            base=fleet.main,
            head=fleet.main,
        )


class DeliveredHeadReviewSeed(IncidentSeed):
    rule = DeliveredHeadReview

    @classmethod
    def seed(cls, fleet: Team) -> StandingRule:
        worktree = fleet.worktree("delivered", base=fleet.main)
        head = fleet.commit(worktree, "delivered.py", "delivered = 1\n")
        fleet.push(worktree)
        todo = fleet.unit("delivered", worktree)
        fleet.pull_request(12, "delivered", head)
        claimed = fleet.claim(
            todo, 12, head, at=time.time() - DeliveredHeadReview.minutes * 60 - 60
        )
        return DeliveredHeadReview(
            holder=todo.held().owner_identity,
            problem=todo.id,
            order=todo.order.checked().id,
            repo=fleet.repository,
            pr=12,
            head=head,
            due_at=claimed.message.timestamp + DeliveredHeadReview.minutes * 60,
        )


class SpinningTeammateSeed(IncidentSeed):
    rule = SpinningTeammate

    @classmethod
    def seed(cls, fleet: Team) -> StandingRule:
        spinning_turn_id = NativeTurnId('spinning')
        moved = time.time() - 30 * 60
        worktree = fleet.worktree("spinning", base=fleet.main, at=moved)
        fleet.commit(worktree, "spinning.py", "spinning = 1\n", at=moved)
        fleet.push(worktree)
        todo = fleet.unit("spinning", worktree, at=moved - 60)
        transcript = ExternalTranscript(fleet.comms.root, todo.held().owner_identity)
        for call in range(SpinningTeammate.calls):
            transcript.finish(
                turn_id=spinning_turn_id,
                item_id=NativeItemId(f"call-{call}"),
                events=(
                    ToolStartTranscript(
                        position=0,
                        tool_call_id=ToolCallId(f"call-{call}"),
                        tool_name="bash",
                        timestamp=moved + 60 + call,
                    ),
                ),
            )
        return SpinningTeammate(holder=todo.held().owner_identity, problem=todo.id,
                                call_count=SpinningTeammate.calls)


class StaleUncommittedEditsSeed(IncidentSeed):
    rule = StaleUncommittedEdits

    @classmethod
    def seed(cls, fleet: Team) -> StandingRule:
        edited = time.time() - 3 * 3600
        home = fleet.worktree("uncommitted", base=fleet.main)
        todo = fleet.unit("uncommitted", home, at=edited - 60)
        storage = fleet.comms.registry.storage_rule
        path = storage.order_checkout(storage.initial_roots("uncommitted"), todo.id) / "repair.py"
        path.write_text("repair = 1\n")
        os.utime(path, (edited, edited))
        return StaleUncommittedEdits(holder=todo.held().owner_identity, problem=todo.id,
                                     order=todo.order.checked().id, edited_at=edited,
                                     now=time.time())


class LostToolsSeed(IncidentSeed):
    rule = LostTools

    @classmethod
    def seed(cls, fleet: Team) -> StandingRule:
        registry = fleet.comms.registry
        declare_test_bus(
            fleet.comms,
            threads=(
                NativeThread(
                    name="restarted",
                    tags=frozenset({"comms"}),
                    worktree=Checkout(fleet.source.checkout),
                    parent=ForkedParent(fleet.teammate)),
            ),
        )
        registry.observe_offered_tools(
            registry.require("restarted").incarnation,
            ReportedTools(
                "1", frozenset({ToolName("comms_send"), ToolName("comms_order_deliver")})
            ),
        )
        registry.register(registry.require("restarted"), new_owner=True)
        registry.observe_offered_tools(
            registry.require("restarted").incarnation,
            ReportedTools("1", frozenset({ToolName("comms_send")})),
        )
        return LostTools(
            registry.require("restarted").incarnation,
            ("missing tools comms_order_deliver; runtime 1",),
        )


@pytest.fixture
def fleet(comms, tmp_path, configured_repository, installed_runtime, github_cli):
    source = SourceRepository.create(tmp_path / "source")
    declare_test_bus(
        comms,
        channels=("comms",),
        threads=(
            NativeThread(name=Team.teammate, tags=frozenset({"comms"}), worktree=Checkout(source.checkout)),
        ),
    )
    request = comms.goals.todos.add_request(
        comms.registry.require(Team.teammate).incarnation, "Keep the team on its plans"
    ).id
    project = configured_repository(comms)
    github_cli.configure(source.github, *(repo.github for repo in project.repos))
    old_main = source.main_commit
    built = Team(comms, source, tmp_path / "worktrees", old_main, request, github_cli)
    # One commit on main already puts the oldest branch behind.
    built.commit(source.checkout, "main.py", "count = 0\n")
    built.git(source.checkout, "push", "-q", "origin", "main")
    expected = tuple(
        IncidentSeed.seeds[member].seed(built)
        for member in StandingRule.members_with(StandingRule)
        if member in IncidentSeed.seeds
    )
    return built, expected


def test_every_held_branch_rule_has_a_seed():
    assert set(HeldBranchRule.members_with(HeldBranchRule)) <= set(IncidentSeed.seeds)


def test_a_queued_request_is_not_told_to_merge_main_into_its_locked_branch(fleet):
    built, _ = fleet

    def behind(name, number, queued):
        worktree = built.worktree(name, base=built.old_main)
        head = built.commit(worktree, f"{name}.py", f"{name} = 1\n")
        built.push(worktree)
        todo = built.unit(name, worktree)
        built.pull_request(number, name, head, queued=queued)
        built.claim(todo, number, head, at=time.time())
        return todo

    queued, unqueued = behind("in-queue", 31, True), behind("not-queued", 32, False)
    told = {rule.problem for rule in built.observe().rules if isinstance(rule, BranchBehindMain)}
    assert unqueued.id in told
    assert queued.id not in told


@pytest.mark.parametrize("outstanding", (False, True))
def test_rebase_notice_requires_outstanding_branch_changes(fleet, outstanding):
    built, _ = fleet
    home = built.worktree("retained-history", base=built.old_main)
    if outstanding:
        built.commit(home, "repair.py", "repair = 1\n")
    built.push(home)
    todo = built.unit("history-worker", home)
    storage = built.comms.registry.storage_rule
    checkout = storage.order_checkout(storage.initial_roots("history-worker"), todo.id)
    original = built.git(checkout, "rev-parse", "HEAD")

    for index in range(2):
        built.commit(built.source.checkout, "main.py", f"count = {index + 1}\n")
        built.git(built.source.checkout, "push", "-q", "origin", "main")
        told = {rule.problem for rule in built.observe().rules
                if isinstance(rule, BranchBehindMain)}
        assert (todo.id in told) is outstanding
        assert built.git(checkout, "rev-parse", "HEAD") == original


def test_branch_rules_read_the_order_checkout_instead_of_the_behind_home(fleet):
    built, _ = fleet
    home = built.worktree('old-home', base=built.old_main)
    todo = built.unit('order-worker', home)
    rule = built.comms.registry.storage_rule
    checkout = rule.order_checkout(rule.initial_roots('order-worker'), todo.id)
    built.git(built.source.checkout, 'worktree', 'remove', str(checkout))
    assert not any(isinstance(rule, BranchBehindMain) and rule.problem == todo.id
                   for rule in built.observe().rules)

    built.git(built.source.checkout, 'worktree', 'add', '-q', '-b', 'current-order',
              str(checkout), built.main)
    assert not any(isinstance(rule, BranchBehindMain) and rule.problem == todo.id
                   for rule in built.observe().rules)
    growth = SourceGrowth.limit + 1
    built.commit(checkout, 'src/agent_comms/order_growth.py',
                 ''.join(f'order_value_{index} = {index}\n' for index in range(growth)))
    assert built.git(home, 'rev-parse', 'HEAD') == built.old_main
    assert BranchGrowth(
        holder=todo.held().owner_identity, problem=todo.id, repository=built.repository,
        branch='current-order', growth=SourceGrowth((('src/agent_comms/order_growth.py', growth),)),
    ) in built.observe().rules


@pytest.mark.parametrize('mutation', ('switch', 'delete', 'advance', 'retire'))
def test_held_branch_rules_consume_the_complete_cut_after_worktree_mutation(
    fleet, mutation, tmp_path, monkeypatch,
):
    built, expected = fleet
    todo = built.comms.goals.todos.get(built.problems['unpushed'])
    storage = built.comms.registry.storage_rule
    path = storage.order_checkout(storage.roots_of(built.thread('unpushed')), todo.id)
    plans = LIVE_PLAN_READINGS
    with LaunchRoot.from_path(built.comms.root).selected():
        pulls = ProgressRead()
        with pytest.raises(WorkBranchError) as unprepared:
            pulls.require_branch_difference(path)
        assert str(path) in str(unprepared.value)
        inputs = TeamInputs.prepare(built.comms, built.comms.registry.snapshot().team_project.require(), pulls, plans)
        difference = inputs.pulls.require_branch_difference(path)
        assert difference.branch == 'unpushed'
        (publication,) = difference.unpublished
        assert (publication.head, publication.commits, publication.upstream) == (
            difference.head, 1, '')
        if mutation == 'retire':
            Checkout(path).retire()
            assert not path.exists()
        elif mutation == 'advance':
            new_head = built.commit(path, 'after_prepare.py', 'later = 1\n')
        else:
            built.git(path, 'switch', '-c', 'after-prepare', built.main)
            if mutation == 'delete':
                built.git(path, 'branch', '-D', difference.branch)
        git_case = GitPreparation(built.source, built.source)
        prepared = git_case.snapshot()
        trace = tmp_path / 'prepared-observation.trace2.jsonl'
        monkeypatch.setenv('GIT_TRACE2_EVENT', str(trace))
        observed = TeamObservation.read(built.comms,
                                             inputs, plans=plans)
        monkeypatch.delenv('GIT_TRACE2_EVENT')
        assert inputs.pulls.require_branch_difference(path) == difference
        held = set(HeldBranchRule.members_with(HeldBranchRule))
        assert Counter(rule for rule in observed.rules if type(rule) in held) == Counter(
            rule for rule in expected if type(rule) in held)
        (captured_rule,) = (rule for rule in observed.rules
                            if isinstance(rule, UnpushedBranch) and rule.problem == todo.id)
        assert (captured_rule.unpublished.head, captured_rule.unpublished.commits,
                captured_rule.unpublished.upstream) == (difference.head, 1, '')
        assert git_case.snapshot() == prepared
        events = tuple(json.loads(line) for line in trace.read_text().splitlines())
        assert not any(event.get('event') == 'child_start' and
                       any('upload-pack' in argument for argument in event.get('argv', ()))
                       for event in events)
        fresh = observe_team(built.comms,
                                 ProgressRead(), plans=plans)
        if mutation == 'retire':
            assert path.resolve() not in fresh.frame.pulls.captured_branch_paths
            assert not any(isinstance(rule, UnpushedBranch) and rule.problem == todo.id
                           for rule in fresh.rules)
        else:
            current = fresh.frame.pulls.require_branch_difference(path)
            if mutation == 'advance':
                assert (current.branch, current.head) == ('unpushed', new_head)
                (publication,) = current.unpublished
                assert (publication.head, publication.commits, publication.upstream) == (
                    new_head, 2, '')
            else:
                assert (current.branch, current.head, current.unpublished) == (
                    'after-prepare', built.main, ())


def test_allocated_clone_owns_its_custom_upstream_not_the_primary(fleet, configured_repository):
    built, _ = fleet
    configured_repository(built.comms, built.source)
    todo = built.comms.goals.todos.get(built.problems['unpushed'])
    storage = built.comms.registry.storage_rule
    path = storage.order_checkout(storage.roots_of(built.thread('unpushed')), todo.id)
    Checkout(path).retire()
    built.git(built.source.checkout, 'clone', '--no-local', str(built.source.remote_path), str(path))
    branch = 'only-in-allocated-clone'
    built.git(path, 'switch', '-c', branch)
    built.git(path, 'remote', 'add', 'publication', str(built.source.remote_path))
    built.git(path, 'fetch', 'publication', 'main')
    built.git(path, 'config', f'branch.{branch}.remote', 'publication')
    built.git(path, 'config', f'branch.{branch}.merge', 'refs/heads/main')
    head = built.commit(path, 'clone_only.py', 'clone_work = 1\n')
    assert Repo.of(path).github == built.repository
    assert storage.owns_present_checkout(built.thread('unpushed'), path, RepositoryReads())
    assert built.git(path, 'rev-parse', '--path-format=absolute', '--git-common-dir') != (
        built.git(built.source.checkout, 'rev-parse', '--path-format=absolute', '--git-common-dir'))
    plans = LIVE_PLAN_READINGS
    with LaunchRoot.from_path(built.comms.root).selected():
        pulls = ProgressRead()
        primary = pulls.checkout(todo.order.checked().check.directory).branches
        primary.prepare_upstreams()
        assert branch not in primary.upstreams
        inputs = TeamInputs.prepare(built.comms, built.comms.registry.snapshot().team_project.require(), pulls, plans)
        observed = TeamObservation.read(built.comms,
                                             inputs, plans=plans)
        assert not any(isinstance(card, Unreadable) and card.unit.name == 'unpushed'
                       for card in observed.states)
        difference = pulls.require_branch_difference(path)
        assert (difference.branch, difference.head) == (branch, head)
        (publication,) = difference.unpublished
        assert (publication.head, publication.commits, publication.upstream) == (
            head, 1, 'refs/remotes/publication/main')
        (found,) = (rule for rule in observed.rules
                   if isinstance(rule, UnpushedBranch) and rule.problem == todo.id)
        assert (found.unpublished.head, found.unpublished.commits, found.unpublished.upstream) == (
            head, 1, 'refs/remotes/publication/main')


def test_replay_raises_each_incident_once(fleet):
    built, expected = fleet
    first = built.observe()
    seeded = {type(rule) for rule in expected}
    assert seeded == set(IncidentSeed.seeds)
    assert Counter(rule for rule in first.rules if type(rule) in seeded) == Counter(expected)
    assert all(count == 1 for count in Counter(expected).values())

    second = built.observe()
    assert {rule.observation_key() for rule in first.rules} == {
        rule.observation_key() for rule in second.rules
    }


def test_holders_in_one_plain_directory_share_no_worktree(fleet, tmp_path):
    built, _ = fleet
    home = tmp_path / "plain-project"
    # Like /home/ts: an empty .git folder that Git itself refuses as a repository.
    (home / ".git").mkdir(parents=True)
    declare_test_bus(
        built.comms,
        threads=tuple(
            NativeThread(name=name, tags=frozenset({"comms"}), worktree=Checkout(home))
            for name in ("first-home", "second-home")
        ),
    )
    # Before `checkout add` both units run in the plain directory; the order checks in a real one.
    checked_in = built.thread("behind").project_path
    ordered = (built.order("first-home", checked_in, at=time.time()),
               built.order("second-home", checked_in, at=time.time()))
    assert [todo.id for todo in ordered] == [
        built.problems["first-home"], built.problems["second-home"]]


def test_an_empty_draft_is_the_first_commit_not_an_empty_pr(fleet):
    built, _ = fleet
    worktree = built.worktree("draft", base=built.main)
    built.push(worktree)
    todo = built.unit("draft", worktree)
    built.pull_request(21, "draft", built.main, kind=DraftListedPullRequest)
    built.claim(todo, 21, built.main, at=time.time())
    assert not any(isinstance(rule, EmptyPullRequest) and rule.problem == todo.id
                   for rule in built.observe().rules)


def test_an_empty_commit_does_not_reset_spinning_and_a_src_change_ends_it(fleet):
    """2026-10-25: unit-signal made 92 calls on P681 behind its empty draft commit, unflagged.
    A non-Python file under src is a source change too."""
    built, _ = fleet
    storage = built.comms.registry.storage_rule
    worktree = storage.order_checkout(storage.initial_roots("spinning"), built.problems["spinning"])
    built.commit(worktree, "notes.txt", "moved HEAD, changed nothing\n")
    assert any(type(rule) is SpinningTeammate for rule in built.observe().rules)
    built.commit(worktree, "src/stack/owner.mjs", "export const owner = 1;\n")
    assert not any(type(rule) is SpinningTeammate for rule in built.observe().rules)


def test_a_merged_order_running_its_proof_is_not_spinning(fleet):
    """2026-10-25: RESHAPE pi-mi P734 while P734 sat merged as 2bfa16ca8 and its unit ran the
    application proof; a merged order owes no source."""
    built, _ = fleet
    store = built.comms.goals.todos
    todo = store.get(built.problems["spinning"])
    assert any(type(rule) is SpinningTeammate for rule in built.observe().rules)
    proof = ApplicationOrderRun("Open the installed application and run the merged order's proof")
    with store.writing() as db:
        replace(todo, order=replace(todo.order, run=proof).merged("0" * 40),
                revision=todo.revision + 1).upsert(db)
    # This fixture's repository is no installed package: the HUD line says so, never raises.
    observed = built.observe()
    assert not any(type(rule) is SpinningTeammate for rule in observed.rules)
    hud = current_hud(built.comms, Team.teammate, observed.frame, observed.states,
                      CodexConnection.usage())
    assert any(order.state == "Merged, no runtime install, waiting on the run"
               for unit in hud.units for order in unit.orders)


@pytest.mark.parametrize("age_hours, expected", ((3, True), (1, False)))
def test_uncommitted_notice_uses_the_latest_captured_edit(fleet, age_hours, expected):
    built, _ = fleet
    todo = built.comms.goals.todos.get(built.problems["uncommitted"])
    storage = built.comms.registry.storage_rule
    checkout = storage.order_checkout(storage.initial_roots("uncommitted"), todo.id)
    edited = time.time() - age_hours * 3600
    os.utime(checkout / "repair.py", (edited, edited))
    observed = built.observe()
    found = tuple(rule for rule in observed.rules
                  if isinstance(rule, StaleUncommittedEdits) and rule.problem == todo.id)
    assert bool(found) is expected
    assert built.comms.goals.todos.get(todo.id) == todo
    if expected:
        (notice,) = found
        assert notice.edited_at == edited
        assert notice.line().startswith(f"COMMIT uncommitted {todo.id}:")
        assert "commit and push it, or say why it stays local" in notice.line()
        assert replace(notice, now=notice.now + 60).observation_key() == notice.observation_key()


def test_a_stopped_unit_is_not_spinning(fleet):
    """2026-10-24: the heartbeat called a unit stopped with comms_stop SPINNING on its old calls."""
    built, _ = fleet
    assert any(type(rule) is SpinningTeammate for rule in built.observe().rules)
    built.comms.registry.unregister("spinning")
    assert not any(type(rule) is SpinningTeammate for rule in built.observe().rules)


def test_a_finished_order_has_no_branch_lines(fleet):
    """2026-10-25: P729 merged, its branch deleted, and the heartbeat still said RESHAPE for the
    run's 108 calls and MERGE MAIN for the branch 40 commits behind."""
    built, _ = fleet
    finished = {built.problems["spinning"], built.problems["behind"]}
    lines = (SpinningTeammate, BranchBehindMain)
    assert {type(rule) for rule in built.observe().rules if type(rule) in lines} == set(lines)
    todos = built.comms.goals.todos
    with todos.writing() as db:
        for problem in finished:
            todo = todos.get(problem)
            delivered = todo.order.delivered(OperationDelivery(at=RecordedEventTime(time.time())))
            replace(todo, order=delivered, revision=todo.revision + 1).upsert(db)
    assert not any(type(rule) in lines for rule in built.observe().rules)
