"""Declaration families round-trip through real SQLite without a schema roster."""

import gc
import json
import sqlite3
import sys
from contextlib import closing, nullcontext
from dataclasses import dataclass, field, replace
from enum import Enum, IntFlag
from time import perf_counter
from typing import Annotated, ClassVar, Literal, Type

import pytest

from agent_comms.messaging.messages import InfoKind, MessageKind
from agent_comms.nominal.field_codec import (
    AttemptId,
    BoundedText,
    FieldCodec,
    GitCommitText,
    GoalId,
    Id128Text,
    MalformedRecord,
    NoAttemptId,
    NullMember,
)
from agent_comms.storage.store_files import DEFAULT_STORE_CONTENTION
from agent_comms.storage.typed_table import (
    FULL_SCHEMA_REBUILD,
    Column,
    DurableTables,
    ExactStorage,
    ForeignKey,
    Generated,
    Index,
    IntegerStorage,
    JsonStorage,
    RowNotFoundError,
    SQLiteSchemaObject,
    SqlStorage,
    SqlValue,
    TypedRow,
    TypedTable,
    WriterOwnedFile,
)


@dataclass(frozen=True)
class TableParentRow(TypedTable):
    key: Annotated[str, Column(primary_key=True)]
    count: int = 0
    unique = (("key", "count"),)


@dataclass(frozen=True)
class TableChildRow(TypedTable):
    key: Annotated[str, Column(primary_key=True)]
    parent: str
    enabled: bool
    detail: tuple[str, ...]
    weight: float | None
    parent_count: int = 3
    indexes = (Index(("parent", "enabled")),)
    without_rowid = True

    @classmethod
    def references(cls):
        return (ForeignKey(columns=("parent", "parent_count"), target=TableParentRow, target_columns=("key", "count")),)


def test_spelled_text_family_is_enforced_by_sqlite():
    @dataclass(frozen=True)
    class SpelledTextRow(TypedTable):
        key: Annotated[str, Id128Text, Column(primary_key=True)]
        label: Annotated[str, BoundedText]
        plain: str
        optional: GoalId | None = None
        attempt: AttemptId | NoAttemptId = field(default_factory=NoAttemptId)

    with sqlite3.connect(":memory:") as db:
        SpelledTextRow.create(db)
        statement = f'INSERT INTO "{SpelledTextRow.declared_name}" VALUES (?, ?, ?, ?, ?)'
        key = "a" * Id128Text.digits
        db.execute(statement, (key, "identity", "", None, None))
        assert SpelledTextRow.select(db) == [SpelledTextRow(key, "identity", "")]
        db.execute(f'DELETE FROM "{SpelledTextRow.declared_name}"')
        for malformed in ("P5:0", key.upper(), key[:-1], key + "a", key + "\0not-hex"):
            with pytest.raises(sqlite3.IntegrityError):
                db.execute(statement, (malformed, "identity", "", None, None))
            with pytest.raises(sqlite3.IntegrityError):
                db.execute(statement, (key, "identity", "", malformed, None))
            with pytest.raises(sqlite3.IntegrityError):
                db.execute(statement, (key, "identity", "", None, malformed))
        for malformed in ("", "x" * (BoundedText.max_length + 1),
                          "\0" + "x" * BoundedText.max_length, "\0", "x\0y"):
            with pytest.raises(sqlite3.IntegrityError):
                db.execute(statement, (key, malformed, "", None, None))
            with pytest.raises(MalformedRecord):
                FieldCodec.decode(Annotated[str, BoundedText], malformed)
        db.execute(statement, (key, "λ" * BoundedText.max_length, "", key, key))


def test_sqlite_uses_declared_choices_and_inherited_spelling():
    class Flavor(str, Enum):
        FIRST = "don't"
        SECOND = "λ"

    class Access(IntFlag):
        READ = 1
        WRITE = 2

    class InheritedCommit(GitCommitText):
        pass

    @dataclass(frozen=True)
    class DeclaredChoicesRow(TypedTable):
        key: Annotated[str, Column(primary_key=True)]
        commit: Annotated[str, InheritedCommit]
        flavor: Flavor
        optional: Literal["left", "right"] | None
        access: Access
        kind: type[MessageKind]
        label: Literal["alpha", "o'brien"]

    record = DeclaredChoicesRow(
        "row", "a" * 7, Flavor.FIRST, None, Access.READ | Access.WRITE, InfoKind, "o'brien",
    )
    with sqlite3.connect(":memory:") as db:
        DeclaredChoicesRow.create(db)
        record.insert(db)
        assert DeclaredChoicesRow.select(db) == [record]
        DeclaredChoicesRow.delete(db)
        statement = f'INSERT INTO "{DeclaredChoicesRow.declared_name}" VALUES (?, ?, ?, ?, ?, ?, ?)'
        values = ("row", "a" * 7, "don't", None, 3, InfoKind.declared_name, "o'brien")
        for position, malformed in ((1, "a" * 6), (2, "bogus"), (3, "bogus"),
                                    (5, "bogus"), (6, "bogus")):
            refused = (*values[:position], malformed, *values[position + 1:])
            with pytest.raises(sqlite3.IntegrityError):
                db.execute(statement, refused)
        db.execute(statement, values)
        assert DeclaredChoicesRow.select(db) == [record]


def test_spelling_checks_follow_json_storage_and_reject_bytes_in_exact_storage():
    @dataclass(frozen=True)
    class StoredSpellingRow(TypedTable):
        key: Annotated[int, Column(primary_key=True)]
        exact: Annotated[GoalId, Column(storage=ExactStorage)]
        json_value: Annotated[GoalId, Column(storage=JsonStorage)]

    value = "a" * Id128Text.digits
    with sqlite3.connect(":memory:") as db:
        StoredSpellingRow.create(db)
        statement = f'INSERT INTO "{StoredSpellingRow.declared_name}" VALUES (?, ?, ?)'
        db.execute(statement, (1, value, json.dumps(value)))
        assert StoredSpellingRow.select(db) == [StoredSpellingRow(1, GoalId(value), GoalId(value))]
        for malformed in (value.encode(), value.upper(), value[:-1]):
            with pytest.raises(sqlite3.IntegrityError):
                db.execute(statement, (2, malformed, json.dumps(value)))
        for malformed in (json.dumps(value.upper()), json.dumps(value[:-1]), json.dumps(32)):
            with pytest.raises(sqlite3.IntegrityError):
                db.execute(statement, (2, value, malformed))


def test_required_row_distinguishes_absence_from_duplicate_results():
    with sqlite3.connect(":memory:") as db:
        TableParentRow.create(db)
        with pytest.raises(RowNotFoundError):
            TableParentRow.require(db, key="missing")
        first, second = TableParentRow("first", 3), TableParentRow("second", 3)
        first.insert(db)
        second.insert(db)
        assert TableParentRow.require(db, key=first.key) == first
        with pytest.raises(MalformedRecord) as duplicate:
            TableParentRow.require(db, count=3)
        assert type(duplicate.value) is MalformedRecord


def test_declared_table_family(tmp_path):
    db_path = tmp_path / "family.sqlite3"
    with sqlite3.connect(db_path) as db:
        db.execute("PRAGMA foreign_keys=ON")
        for member in TypedTable.members_with(TypedTable):
            if member.__module__ == __name__:
                member.create(db)
                columns = db.execute(f'PRAGMA table_info("{member.declared_name}")').fetchall()
                assert tuple(column[1] for column in columns) == member.columns()
        parent = TableParentRow("p", 3)
        child = TableChildRow("c", "p", True, ("one", "two"), None)
        for row in (parent, child):
            row.insert(db)
            assert type(row).select(db) == [row]
        # Requested keys join under IS, so a null key selects the null row, once.
        null_key = {"key": "c", "weight": None}
        assert TableChildRow.select_keys(db, (null_key, null_key)) == [child]
        assert TableChildRow.select_keys(db, ({"key": "c", "weight": 3.25},)) == []
        with pytest.raises(sqlite3.IntegrityError):
            replace(child, key="bad", parent="missing").insert(db)
        with pytest.raises(TypeError):
            replace(parent, key="bool", count=True).insert(db)
        replace(child, weight=3.25).upsert(db)
        assert TableChildRow.one(db, key="c").weight == 3.25
        assert TableChildRow.select_keys(db, (null_key,)) == []
        assert TableChildRow.select_keys(db, ({"key": "c", "weight": 3.25},)) == [
            replace(child, weight=3.25)]
        child.upsert(db)
        assert TableChildRow.one(db, key="c") == child
        TableChildRow.update(db, where="key=?", parameters=("c",), enabled=False)
        assert TableChildRow.select(db, where="enabled=?", parameters=(False,),
                                    order_by=("key",)) == [replace(child, enabled=False)]
        assert TableChildRow.one(db) == replace(child, enabled=False)
        with pytest.raises(ValueError):
            TableChildRow.select(db, missing=1)
        with pytest.raises(ValueError):
            TableChildRow.update(db, where="key=?", parameters=("c",))
        with pytest.raises(ValueError):
            TableChildRow._column_list(())
        with pytest.raises(ValueError):
            TableChildRow.update(db, where="key=?", parameters=("c",), missing=1)
        with pytest.raises(TypeError):
            TableChildRow.update(db, where="key=?", parameters=("c",), enabled=1)
    with sqlite3.connect(db_path) as db:
        db.row_factory = sqlite3.Row
        assert TableChildRow.select(db) == [replace(child, enabled=False)]
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("UPDATE table_child SET enabled=2")
        db.rollback()
        db.execute("BEGIN")
        TableChildRow.update(db, where="key=?", parameters=("c",), weight=2.5)
        db.rollback()
        assert TableChildRow.select(db)[0].weight is None


def test_rebuild_converts_a_field_and_preserves_the_declared_rows_and_constraints():
    with sqlite3.connect(':memory:') as db:
        db.execute('PRAGMA foreign_keys=ON')
        TableParentRow.create(db)
        TableChildRow.create(db)
        TableParentRow('p', 3).insert(db)
        rows = (TableChildRow('first', 'p', True, ('one',), 125.0),
                TableChildRow('second', 'p', False, ('two',), 250.0))
        for row in rows:
            row.insert(db)
        db.execute(f'ALTER TABLE "{TableChildRow.declared_name}" RENAME COLUMN weight TO retired_weight')
        TableChildRow.rebuild(db, {'weight': 'retired_weight / 100.0'})
        assert TableChildRow.select(db, order_by=('key',)) == [
            replace(row, weight=row.weight / 100) for row in rows]
        assert not SQLiteSchemaObject.differences(
            TableChildRow.stored_objects(db), TableChildRow.schema_objects())
        assert db.execute('PRAGMA foreign_key_check').fetchall() == []
        with pytest.raises(sqlite3.IntegrityError):
            replace(rows[0], key='invalid', parent='missing').insert(db)
        db.execute(f'ALTER TABLE "{TableChildRow.declared_name}" DROP COLUMN weight')
        TableChildRow.rebuild(db)
        assert TableChildRow.select(db, order_by=('key',)) == [replace(row, weight=None) for row in rows]


@pytest.mark.parametrize("changed", ({}, {"key": '"key" + 1'}),
                         ids=("preserve-children", "reject-orphan"))
def test_schema_carry_preserves_foreign_children_and_rolls_back_orphans(tmp_path, changed):
    class CarrySchema(DurableTables):
        @classmethod
        def carry_schema(cls, db, sharing=(), *, rebuild=FULL_SCHEMA_REBUILD):
            CarryParent.rebuild(db, changed)
            cls.require_schema(db, sharing)

    @dataclass(frozen=True)
    class CarryParent(CarrySchema, TypedTable, declared_name=f"carry_parent_{len(changed)}"):
        key: Annotated[int, Column(primary_key=True)]
        checks = ("key >= 0",)

    @dataclass(frozen=True)
    class CarryChild(CarrySchema, TypedTable, declared_name=f"{CarryParent.declared_name}_child"):
        key: Annotated[int, Column(primary_key=True)]
        parent: int
        cascade_parent: int

        @classmethod
        def references(cls):
            return (
                ForeignKey(target=CarryParent, target_columns=("key",), columns=("parent",)),
                ForeignKey(target=CarryParent, target_columns=("key",),
                           columns=("cascade_parent",), on_delete="CASCADE"),
            )

    parents = [CarryParent(key) for key in range(2000)]
    children = [CarryChild(row.key, row.key, row.key) for row in parents]
    with sqlite3.connect(tmp_path / "relations.sqlite3") as db:
        db.execute("PRAGMA foreign_keys = ON")
        previous = CarryParent.ddl()[0].replace("CHECK (key >= 0)", "CHECK (key > -1)")
        assert previous != CarryParent.ddl()[0]
        db.execute(previous)
        CarryChild.create(db)
        for row in (*parents, *children):
            row.insert(db)
        db.commit()
        stored = CarrySchema.stored_schema(db)
        outcome = pytest.raises(
            CarrySchema.schema_error,
            match=f"table={CarryChild.declared_name}, parent={CarryParent.declared_name}, fkid=0",
        ) if changed else nullcontext()
        started = perf_counter()
        with outcome:
            assert CarrySchema.reconcile_schema(db, WriterOwnedFile())
        assert perf_counter() - started < 2
        assert not db.in_transaction
        assert db.execute("PRAGMA foreign_keys").fetchone() == (1,)
        assert CarryChild.select(db, order_by=("key",)) == children
        assert CarryParent.select(db, order_by=("key",)) == parents
        if changed:
            assert CarrySchema.stored_schema(db) == stored
        else:
            CarrySchema.require_schema(db)


def test_writer_derives_missing_nullable_fields_but_refuses_unclaimed_data():
    from agent_comms.planning.goal_history import (
    BaselineRevision,
    CommittedEntry,
    GoalHistoryEntry,
    GoalHistoryError,
)
    from agent_comms.planning.goals import NoGoal
    from agent_comms.storage.typed_table import WriterOwnedFile

    entry = GoalHistoryEntry(1, BaselineRevision, 1.0, NoGoal(), NoGoal(),
                             owner_created_at=1.0, state=CommittedEntry)
    with sqlite3.connect(':memory:') as db:
        GoalHistoryEntry.create(db)
        entry.insert(db)
        for column in ('request_before', 'request_after'):
            db.execute(f'ALTER TABLE "{GoalHistoryEntry.declared_name}" DROP COLUMN {column}')
        db.commit()
        GoalHistoryEntry.reconcile_schema(db, WriterOwnedFile())
        restored = GoalHistoryEntry.require(db, sequence=1)
        assert restored == entry
        assert restored.kind is BaselineRevision
        assert restored.state is CommittedEntry
        db.execute(f'ALTER TABLE "{GoalHistoryEntry.declared_name}" ADD COLUMN unclaimed TEXT')
        db.execute(f'UPDATE "{GoalHistoryEntry.declared_name}" SET unclaimed=?', ('preserve this',))
        db.commit()
        with pytest.raises(GoalHistoryError):
            GoalHistoryEntry.reconcile_schema(db, WriterOwnedFile())
        assert db.execute(f'SELECT unclaimed FROM "{GoalHistoryEntry.declared_name}"').fetchall() == [('preserve this',)]


def test_durable_writer_relaxes_not_null_without_losing_rows():
    from agent_comms.storage.typed_table import DurableTables, WriterOwnedFile

    @dataclass(frozen=True)
    class RelaxedValueRow(DurableTables, TypedTable, declared_name="relaxed_values"):
        key: Annotated[str, Column(primary_key=True)]
        value: str | None

    rows = [RelaxedValueRow("first", "one"), RelaxedValueRow("second", "two")]
    with sqlite3.connect(":memory:") as db:
        db.execute(
            'CREATE TABLE "relaxed_values" ("key" TEXT NOT NULL, "value" TEXT NOT NULL, '
            'PRIMARY KEY ("key")) STRICT'
        )
        for row in rows:
            row.insert(db)
        db.commit()

        RelaxedValueRow.reconcile_schema(db, WriterOwnedFile())

        assert RelaxedValueRow.select(db, order_by=("key",)) == rows
        RelaxedValueRow("empty", None).insert(db)
        assert RelaxedValueRow.require(db, key="empty").value is None
        assert RelaxedValueRow.count(db) == len(rows) + 1


def test_durable_writer_fills_a_missing_field_from_its_declared_default():
    from agent_comms.storage.typed_table import DurableTables, WriterOwnedFile

    @dataclass(frozen=True)
    class DefaultedRow(DurableTables, TypedTable, declared_name="defaulted_row"):
        key: str
        enabled: bool = False

    with sqlite3.connect(":memory:") as db:
        db.execute('CREATE TABLE "defaulted_row" ("key" TEXT NOT NULL) STRICT')
        db.execute('INSERT INTO "defaulted_row" VALUES (?)', ("retained",))
        db.commit()

        DefaultedRow.reconcile_schema(db, WriterOwnedFile())

        assert DefaultedRow.select(db) == [DefaultedRow("retained", enabled=False)]


def test_durable_writer_drops_a_declared_dropped_field_and_keeps_rows():
    from agent_comms.storage.typed_table import DurableTables, WriterOwnedFile

    @dataclass(frozen=True)
    class LeanBoardLine(DurableTables, TypedTable, declared_name="lean_board_line"):
        dropped_fields = ("locks_at",)
        text: str
        since: float
        urgent: bool = False

    with sqlite3.connect(":memory:") as db:
        db.execute(
            'CREATE TABLE "lean_board_line" ("text" TEXT NOT NULL, "since" REAL NOT NULL, '
            '"locks_at" REAL NOT NULL, "urgent" INTEGER NOT NULL CHECK ("urgent" IN (0, 1))) STRICT'
        )
        db.execute('INSERT INTO "lean_board_line" VALUES (?, ?, ?, ?)', ("IDLE #1", 1.0, 2.0, 1))
        db.commit()

        LeanBoardLine.reconcile_schema(db, WriterOwnedFile())

        assert LeanBoardLine.select(db) == [LeanBoardLine("IDLE #1", 1.0, urgent=True)]
        LeanBoardLine.require_schema(db)


def test_atomic_creation_preserves_declared_indexes_triggers_and_strict_creation():
    from agent_comms.execution.native_input_proof import NativeContextJournal

    with sqlite3.connect(':memory:') as db:
        NativeContextJournal.create(db, if_not_exists=True)
        NativeContextJournal.create(db, if_not_exists=True)
        actual = SQLiteSchemaObject.read(db.execute(
            "SELECT name, sql FROM sqlite_master WHERE sql IS NOT NULL"))
        assert SQLiteSchemaObject.differences(actual, NativeContextJournal.schema_objects()) == ()
        with pytest.raises(sqlite3.OperationalError):
            NativeContextJournal.create(db)


def test_index_owns_unique_partial_creation():
    with sqlite3.connect(':memory:') as db:
        TableParentRow.create(db)
        index = Index(('count',), unique=True, where='count > 0')
        statement = index.sql(TableParentRow, if_not_exists=True)
        db.execute(statement)
        db.execute(statement)
        TableParentRow('first', 1).insert(db)
        with pytest.raises(sqlite3.IntegrityError):
            TableParentRow('duplicate', 1).insert(db)
        TableParentRow('zero-one', 0).insert(db)
        TableParentRow('zero-two', 0).insert(db)
        with pytest.raises(sqlite3.OperationalError):
            db.execute(index.sql(TableParentRow))


def test_adding_an_index_renames_no_other_index():
    @dataclass(frozen=True)
    class IndexedRow(TypedTable):
        name: Annotated[str, Column(primary_key=True)]
        count: int = field()
        indexes = (Index(('count',)), Index(('name', 'count'), where='count > 0'))

    @dataclass(frozen=True)
    class MoreIndexedRow(TypedTable, declared_name=IndexedRow.declared_name + '_more'):
        name: Annotated[str, Column(primary_key=True)]
        count: int = field()
        indexes = (Index(('name',), unique=True), *IndexedRow.indexes)

    def names(row):
        return {index.term_sql(row): index.name(row) for index in row.indexes}

    before, after = names(IndexedRow), names(MoreIndexedRow)
    assert {sql: name.replace(IndexedRow.declared_name, '', 1) for sql, name in before.items()} == {
        sql: after[sql].replace(MoreIndexedRow.declared_name, '', 1) for sql in before}
    assert len(set(after.values())) == len(MoreIndexedRow.indexes)


def test_new_row_declaration_needs_no_other_edit():
    @dataclass(frozen=True)
    class AddedTableRow(TypedTable):
        label: Annotated[str, Column(unique=True, index=True)]
        child: TableChildRow
        event: Type[MessageKind] = InfoKind
        representation: type[SqlStorage] = IntegerStorage
        exact: Annotated[int, Column(storage=ExactStorage)] = 7
        ordinal: Annotated[int | None, Column(primary_key=True, auto_increment=True)] = field(default=None, compare=False)
        label_size: ClassVar[Generated] = Generated(int, Column(generated="length(label)"))

    @dataclass(frozen=True)
    class Projection(TypedRow):
        label: str
        enabled: bool

    with sqlite3.connect(":memory:") as db:
        AddedTableRow.create(db)
        value = AddedTableRow("new", TableChildRow("a", "b", True, (), 1.25))
        value.insert(db)
        assert AddedTableRow.select(db) == [value]
        stored = AddedTableRow.one(db, label="new")
        assert stored.ordinal == 1 and AddedTableRow.count(db, label_size=3) == 1
        with pytest.raises(AttributeError):
            stored.label_size
        assert stored.representation is IntegerStorage and stored.event is InfoKind
        assert AddedTableRow.count(db, exact=7) == 1
        with pytest.raises(ValueError):
            AddedTableRow.insertion_statement(("label_size",))
        with pytest.raises(ValueError):
            AddedTableRow.update(db, where="label=?", parameters=("new",), label_size=4)
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("UPDATE added_table SET event='invented'")
        db.execute("UPDATE added_table SET exact='7'")
        with pytest.raises(ValueError):
            AddedTableRow.one(db, label="new")
        AddedTableRow.update(db, where="label=?", parameters=("new",), exact=7)
        assert Projection.read(db.execute("SELECT 1 AS enabled, 'new' AS label")) == [
            Projection("new", True)
        ]
        with pytest.raises(ValueError):
            Projection.read(db.execute("SELECT 2 AS enabled, 'new' AS label"))
        with pytest.raises(ValueError):
            Projection.read(db.execute("SELECT 'new' AS label"))
        with pytest.raises(ValueError):
            Projection.read(db.execute("SELECT 'a' AS label, 'b' AS label"))
        with pytest.raises(MalformedRecord):
            AddedTableRow.update(db, where="1", child=FieldCodec.decode(
                TableChildRow, {TableChildRow.family_discriminator: TableChildRow.declared_name}
            ))


@dataclass(frozen=True)
class NoTableNote(NullMember):
    """The row was stored without a note."""


def test_null_member_column_stores_sql_null():
    @dataclass(frozen=True)
    class NotedTableRow(TypedTable):
        key: Annotated[str, Column(primary_key=True)]
        note: str | NoTableNote = field(default_factory=NoTableNote)

    with sqlite3.connect(":memory:") as db:
        NotedTableRow.create(db)
        assert '"note" TEXT,' in NotedTableRow.ddl()[0] + ","
        NotedTableRow("silent").insert(db)
        NotedTableRow("said", "hello").insert(db)
        assert db.execute("SELECT key FROM noted_table WHERE note IS NULL").fetchall() == [("silent",)]
        assert NotedTableRow.one(db, key="silent") == NotedTableRow("silent")
        assert NotedTableRow.one(db, key="said").note == "hello"


def test_generated_column_is_declared_by_the_table_not_a_record_field():
    @dataclass(frozen=True)
    class FieldGeneratedTableRow(TypedTable, declared_name=None):
        label: str
        label_size: Annotated[int, Column(generated="length(label)")] = field(init=False)

    with pytest.raises(TypeError):
        FieldGeneratedTableRow.ddl()


def test_declared_values_and_partial_insertions_share_the_sqlite_boundary():
    with sqlite3.connect(":memory:") as db:
        assert not TableParentRow.present(db)
        TableParentRow.create(db)
        assert TableParentRow.present(db)
        assert not TableParentRow.exists(db)
        TableParentRow.insert_values(db, key="parent", count=3)
        assert TableParentRow.exists(db, where="key=?", parameters=("parent",))
        assert TableParentRow("parent", 4).insert_if_absent(db).rowcount == 0
        assert TableParentRow.one(db, key="parent").count == 3
        assert SqlValue.for_annotation(int).read(db.execute("SELECT count(*) FROM table_parent")) == [1]
        assert SqlValue.for_annotation(int | None).read(db.execute("SELECT NULL")) == [None]
        assert SqlValue.for_annotation(int).read(db.execute("SELECT 1 WHERE 0")) == []
        assert SqlValue.for_annotation(bool).read(db.execute("SELECT 1")) == [True]
        cursor = db.execute("SELECT 2")
        with pytest.raises(ValueError):
            SqlValue.for_annotation(bool).read(cursor)
        with pytest.raises(sqlite3.ProgrammingError):
            cursor.fetchone()
        with pytest.raises(ValueError):
            SqlValue.for_annotation(int).read(db.execute("SELECT 1, 2"))
        with pytest.raises(ValueError):
            TableParentRow.insert_values(db, invented="field")


def test_streamed_query_decodes_only_consumed_rows_and_releases_cursor():
    @dataclass(frozen=True)
    class StreamProjection(TypedRow):
        enabled: bool

    with sqlite3.connect(":memory:") as db:
        cursor = db.execute("SELECT 1 AS enabled UNION ALL SELECT 2 AS enabled")
        rows = StreamProjection.iterate(cursor)
        assert next(rows) == StreamProjection(True)
        rows.close()
        with pytest.raises(sqlite3.ProgrammingError):
            cursor.fetchone()
        rows = StreamProjection.iterate(db.execute("SELECT 2 AS enabled"))
        with pytest.raises(ValueError):
            next(rows)


def test_store_connection_releases_streams_its_scope_outlives(monkeypatch):
    @dataclass(frozen=True)
    class StreamProjection(TypedRow):
        enabled: bool

    unraisable = []
    monkeypatch.setattr(sys, "unraisablehook", unraisable.append)
    with closing(DEFAULT_STORE_CONTENTION.writer(":memory:")) as db:
        rows = StreamProjection.iterate(db.execute("SELECT 1 AS enabled UNION ALL SELECT 2"))
        assert next(rows) == StreamProjection(True)
    del rows
    gc.collect()
    assert unraisable == []
