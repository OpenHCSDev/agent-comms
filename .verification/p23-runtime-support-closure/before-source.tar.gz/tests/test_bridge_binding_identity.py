"""An enrolled address becomes a registered reader without changing its journal."""
from dataclasses import replace
from pathlib import Path

import pytest

from agent_comms.cli_bridges.claude import ClaudeBridge
from agent_comms.cli_bridges.session_watch import LiveWatch, WatchClaim
from agent_comms.cli_bridges.shared import (
    Binding,
    BindingAddress,
    ChannelsFrom,
    Enrol,
    Options,
    StoredBinding,
    Watch,
)
from agent_comms.errors import UnregisteredThreadError
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.threads import NativeThread
from agent_comms_hooks.watch import WatchRecord


@pytest.mark.asyncio
@pytest.mark.parametrize('operation,tags', [
    (Watch(ChannelsFrom('colleague')), frozenset({'comms'})),
    (Watch(), frozenset()),
])
async def test_enrol_register_rename_and_rebind_preserve_reader(comms, tmp_path, operation, tags):
    comms.registry.declare(NativeThread('colleague', frozenset({'comms'}), Checkout(tmp_path)))
    state = tmp_path / 'journal'
    address = BindingAddress(root=str(comms.root), bus='new-reader', thread='session',
                             start=Binding.bus_head(str(comms.root)))
    with Binding.open(state) as db:
        bridge = ClaudeBridge(Options(Enrol(), StoredBinding(), state, state.parent), address, db)
        await bridge.options.operation.prepare(bridge)
        await bridge.options.operation.execute(bridge)
        assert WatchClaim('session').bindings()[0].bus == 'new-reader'
        assert not comms.registry.snapshot().taken('new-reader')
        assert Binding.select(db) == []

        bridge = ClaudeBridge(Options(operation, StoredBinding(), state, state.parent), address, db)
        await operation.prepare(bridge)
        original, = Binding.select(db)
        reader = comms.registry.require('new-reader')
        assert original.owner == reader.incarnation
        assert reader.tags == tags
        assert tuple(reader.parent.names()) == ()
        assert reader.acting_identity == reader.incarnation
        assert reader.worktree == Checkout(Path.cwd())

        comms.registry.rename('new-reader', 'renamed-reader')
        bridge = ClaudeBridge(bridge.options, StoredBinding().bind(db), db)
        await operation.prepare(bridge)
        renamed, = Binding.select(db)
        assert renamed.bus == 'renamed-reader'
        assert renamed.owner == original.owner
        assert renamed.start == original.start
        with pytest.raises(ValueError, match='another Core/CLI conversation'):
            replace(renamed, root=str(tmp_path / 'different-root')).bind(db)
        assert Binding.select(db) == [renamed]

        # A reused address is not the old reader, even in the same bus root.
        comms.registry.unregister('renamed-reader')
        comms.registry.remove('renamed-reader')
        comms.registry.declare(NativeThread('renamed-reader', frozenset(), Checkout(tmp_path)))
        replacement = replace(address, bus='renamed-reader', thread='other-session')
        bridge = ClaudeBridge(bridge.options, replacement, db)
        with pytest.raises(ValueError, match='another Core/CLI conversation'):
            await operation.prepare(bridge)
        assert Binding.select(db) == [renamed]
        comms.messaging.send('colleague', 'renamed-reader', 'new incarnation only')
        with pytest.raises(UnregisteredThreadError, match='lookup .* is not registered'):
            renamed.recipient(comms)
        assert comms.bus.pending_count('renamed-reader') == 1


def test_a_record_naming_an_unregistered_thread_commands_nothing(comms, tmp_path):
    """2026-10-30: a connect that crashed before registering left this record, and every hook of
    that session raised UnregisteredThreadError at watch.py."""
    record = WatchRecord('never-registered', str(comms.root), ('watch',), tmp_path / 'inbox')
    assert not LiveWatch(WatchClaim('session'), record).commands()
