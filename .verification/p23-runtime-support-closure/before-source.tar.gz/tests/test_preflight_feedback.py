"""Failure diagnostics and durable delivery projection remain independent authorities."""
import pytest

from agent_comms.execution.turn_failure import (
    InputIdUnavailable,
    NativePreflightExit,
    NativePreflightTimeout,
    PromptSendFailed,
)
from agent_comms.execution.turn_output import TurnOutput
from agent_comms.input_attempt import NotSentInput, ReservedInput
from agent_comms.input_disposition import InputDocument
from agent_comms.input_key import AcpInputKey
from agent_comms.nominal.field_codec import InputId, TurnId
from stored_inputs import stored_inputs

PARTIAL_WRITE_KEY = AcpInputKey(InputId.mint())


@pytest.mark.parametrize('kind', [NativePreflightExit, NativePreflightTimeout])
def test_preflight_diagnostics_keep_original_phase(kind):
    output = TurnOutput()
    output.record_failure(kind('Original preflight phase and timing'))
    output.startup_error('Native startup cause\n')
    assert output.failure_text == 'Original preflight phase and timing\nBackend startup reported:\nNative startup cause'
    output = TurnOutput(sensitive=True)
    output.record_failure(kind('Private phase'))
    output.startup_error('private image bytes')
    assert 'Private phase' not in output.failure_text
    assert 'private image bytes' not in output.failure_text
    assert type(output.failure) is kind
    assert 'Private phase' not in repr(output)
    assert 'private image bytes' not in repr(output)
    ordinary = TurnOutput(failure=PromptSendFailed('Transport cause'))
    ordinary.startup_error('unrelated startup text')
    assert ordinary.failure_text == 'Transport cause'

def test_delivery_projection_requires_complete_homogeneous_actual_rows():
    key, missing = AcpInputKey(InputId.mint()), AcpInputKey(InputId.mint())
    reserved = ReservedInput(key, None, 'owner', 1, 'owner', 'input')
    unsent = reserved.finish_unbound().require_moved('Reserved input stayed reserved').state
    assert isinstance(unsent, NotSentInput)
    document = InputDocument(rows={key: unsent})
    assert document.shared_state((key,)) is NotSentInput
    assert document.shared_state((key, missing)) is None
    assert document.shared_state(()) is None
    assert document.shared_state(('missing',)) is None


def test_post_dispatch_failure_preserves_bound_uncertainty(tmp_path):
    from agent_comms.acp_failure import ACPFailure
    from agent_comms.input_attempt import BoundUnknownInput, SentInput
    from agent_comms.input_disposition import InputDispositions

    store = InputDispositions(tmp_path)
    store.record(PARTIAL_WRITE_KEY, seq=None, owner='owner', claim_scope=1,
                 target='owner', text='original input')
    assert store.bind(
        PARTIAL_WRITE_KEY,
        claim_scope=1,
        turn_id=TurnId('9b473845f684444f80a26586ae298d2b'),
        native_id=InputId('a' * 32),
        text='original input',
    )
    before = stored_inputs(store.root).lookup(PARTIAL_WRITE_KEY)
    assert isinstance(before, SentInput)
    assert isinstance(before, BoundUnknownInput)
    output = TurnOutput(failure=InputIdUnavailable('Native prompt write failed after dispatch'))
    output.startup_error('BrokenPipeError: pipe closed during write')
    assert 'not sent' not in output.failure_text.lower()
    assert 'BrokenPipeError' in output.failure_text
    after = store.settle_unbound((PARTIAL_WRITE_KEY,))
    assert after.lookup(PARTIAL_WRITE_KEY) == before
    from dataclasses import replace
    feedback = replace(ACPFailure.from_detail(-32603, output.failure_text),
                       input_state=after.shared_state((PARTIAL_WRITE_KEY,)))
    assert feedback.input_state is BoundUnknownInput
    assert 'Unknown' in feedback.feedback
    assert 'not sent' not in feedback.feedback.lower()
