"""Bounded, read-only awareness of sealed private work for one selected owner.

The candidate WAL locates changed bus rows. It never proves a claim, response
obligation, native input, or permission to act. The caller supplies the already
verified current original, selected claim, and live owner-turn snapshot; the
native send boundary must recheck that owner after this optional read.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import sqlite3
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import ClassVar

from agent_comms.context_segments.optional_awareness import (
    CompleteAwareness,
    OmittedAwareness,
    OptionalAwarenessResult,
    _OpenObligation,
    _SelectedDecision,
)
from agent_comms.coordination.cohort import _claim_record
from agent_comms.coordination.cohort_schema import (
    AwarenessClaimGenerations,
    ClaimBatchAcknowledgements,
    ClaimBatchMembers,
    CohortDeliveries,
    CohortTable,
)
from agent_comms.coordination.errors import CoordinationError
from agent_comms.coordination.tables.assignments import ExecutionAssignmentLink, WakeAssignment
from agent_comms.coordination.tables.executions import ExecutionRecord
from agent_comms.coordination.tables.participants import OwnerGenerations
from agent_comms.coordination.tables.responses import ResponseObligation
from agent_comms.errors import RelationViolationError
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.execution.native_input_owner import RegistryOwner
from agent_comms.execution.turn_context import (
    ContextSegment,
    InstructionFile,
    ResourceProvenance,
    WireProvenance,
)
from agent_comms.messaging.bus_publication import Delivered
from agent_comms.messaging.message_reference import MessageReference
from agent_comms.nominal.field_codec import FieldCodec, RootId, ThreadLookup
from agent_comms.registry.private_registry_guard import RegistryPrivacy
from agent_comms.registry.registration import Registration
from agent_comms.registry.threads import NativeThread, Thread
from agent_comms.storage.store_files import StoreBusy
from agent_comms.storage.typed_table import TypedRow
from agent_comms.waking.errors import ProjectionUnavailableError
from agent_comms.waking.wake_candidate_index import WakeCandidateIndex


@dataclass(frozen=True)
class _ParticipantOwner(TypedRow):
    generation: int
    committed: bool


@dataclass(frozen=True, slots=True)
class OptionalAwarenessProjection:
    """Project one stable recipient window without a bus scan or write lock.

    ``after_seq`` and ``through_seq`` must come from the caller's trusted
    current-owner/native-cursor and bus high-water snapshots. Passing zero for
    ``after_seq`` is conservative: it can omit an oversized history, never skip
    a binding decision. The foreground runner still gates the result to 250 ms.
    """

    index: WakeCandidateIndex
    registry: Registration = field(kw_only=True)
    after_seq: int
    through_seq: int
    expected_participant_generation: int
    expected_claimed_generation: int
    max_rows: int = 100
    max_text_bytes: int = 16 * 1024
    build_seconds: ClassVar[float] = 0.25
    # Completion alone releases the single reader. Timed-out reads must not
    # queue a daemon fleet or occupy the default executor used by native work.
    _build_slot: ClassVar[threading.BoundedSemaphore] = threading.BoundedSemaphore(1)
    _reader: ClassVar[ThreadPoolExecutor] = ThreadPoolExecutor(
        max_workers=1, thread_name_prefix="agent-comms-optional-awareness"
    )

    @classmethod
    def for_selected(
        cls,
        index: WakeCandidateIndex,
        *,
        registry: Registration,
        through_seq: int,
        generation: int,
        claimed_generation: int,
    ) -> OptionalAwarenessProjection:
        # No native cursor is supplied here: include the unstarted prefix,
        # never infer recipient progress from a sender's resource claim.
        return cls(index, 0, through_seq, generation, claimed_generation,
                   registry=registry)

    async def segments(
        self,
        initial: Delivered,
        assignment: WakeAssignment,
        owner: NativeThread,
    ) -> tuple[ContextSegment, ...]:
        deadline = time.monotonic() + self.build_seconds
        if not self._build_slot.acquire(blocking=False):
            return OmittedAwareness.capture(reason="builder busy").segments(self.max_text_bytes)
        try:
            reading = self._reader.submit(self, initial, assignment, owner)
        except RuntimeError:
            self._build_slot.release()
            raise
        # The executor's Future owns both the value and the original defect.
        # Cancellation of the waiter cannot release a still-running read's slot.
        reading.add_done_callback(lambda _: self._build_slot.release())
        try:
            result = await asyncio.wait_for(
                asyncio.wrap_future(reading), max(0.0, deadline - time.monotonic())
            )
        except TimeoutError:
            return OmittedAwareness.capture(reason="TimeoutError").segments(self.max_text_bytes)
        if time.monotonic() > deadline:
            return OmittedAwareness.capture(reason="TimeoutError").segments(self.max_text_bytes)
        return result.segments(self.max_text_bytes)

    def __post_init__(self) -> None:
        # These are typed internal snapshots. External rows are decoded by
        # TypedTable/FieldCodec once, where they enter below.
        if not 0 <= self.after_seq < self.through_seq:
            raise ValueError("optional awareness requires a bounded trusted source window")
        if min(self.expected_participant_generation, self.expected_claimed_generation) < 1:
            raise ValueError("optional awareness requires positive captured generations")
        if not 1 <= self.max_rows <= 100:
            raise ValueError("optional awareness row budget is outside the bounded read")
        if not 1 <= self.max_text_bytes <= 16 * 1024:
            raise ValueError("optional awareness text budget is outside the bounded read")

    def __call__(
        self, initial: Delivered, assignment: WakeAssignment, owner: NativeThread
    ) -> OptionalAwarenessResult:
        """Return complete SQL-backed rows, or omit the entire supplement.

        No selected decision or open obligation is ranked away. A stale WAL,
        unsealed candidate, different owner, excess row count, or resource budget
        exhausts the optional path without changing original delivery.
        """
        try:
            return self._build(initial, assignment, owner)
        except (
            CoordinationError,
            ProjectionUnavailableError,
            RelationViolationError,
            BlockingIOError,
        ) as error:
            # Busy, stale, changed-owner and pending-rename are this read's
            # named unavailable states. Anything else is a defect and raises.
            return OmittedAwareness.capture(reason=type(error).__name__)

    def _build(
        self, initial: Delivered, assignment: WakeAssignment, owner: NativeThread
    ) -> OptionalAwarenessResult:
        if owner.process_identity != ProcessIdentity.capture(os.getpid()):
            raise ProjectionUnavailableError("selected owner is not this process")
        owner.role.require_executable(
            ProjectionUnavailableError("selected owner is not executable")
        )
        turn = owner.turn_record.read()
        if not turn.has_claim(self.expected_claimed_generation):
            raise ProjectionUnavailableError("selected owner turn changed")
        if assignment.recipient_lookup != owner.incarnation.lookup:
            raise ProjectionUnavailableError("selected recipient changed")
        if (assignment.wire_seq, assignment.message_id) != (
            initial.message.seq,
            initial.message.message_id,
        ):
            raise ProjectionUnavailableError("selected source changed")
        if not self.after_seq < initial.message.seq <= self.through_seq:
            raise ProjectionUnavailableError("selected source is outside the captured window")
        # Each selected row must now carry immutable same-transaction owner
        # generation provenance. An incomplete join omits the whole read.
        privacy = self.registry.store.privacy_now()
        root_id = privacy.namespace
        lookup = assignment.recipient_lookup
        page = self.index.page(
            recipient_lookup=lookup,
            after_seq=self.after_seq,
            required_through_seq=self.through_seq,
            limit=self.max_rows,
        )
        if page.has_more:
            raise ProjectionUnavailableError("binding candidate decisions exceed the row budget")

        path = self.registry.store.coordinator_reader.path
        with self.registry.store.coordinator_reader.reader_snapshot() as db:
            self._verify_schema_and_owner(db, initial, assignment, owner, privacy)
            decisions = self._selected_decisions(db, root_id, lookup, page.through_seq)
            candidates = tuple(
                (row.source_seq, row.message_id, row.wake_mode, row.target) for row in page.entries
            )
            accepted = tuple(row.candidate for row in decisions)
            if candidates != accepted:
                raise ProjectionUnavailableError("candidate rows differ from sealed decisions")
            obligations = self._open_obligations(db, lookup)
            expected = OwnerGenerations(
                owner_lookup=lookup,
                generation=self.expected_participant_generation,
            )
            selected = [row for row in decisions if row.generation.current(expected)]
            if not any(
                row.assignment.assignment_id == assignment.assignment_id for row in selected
            ):
                raise ProjectionUnavailableError("current selected claim has no owner generation")
            current_obligations = [row for row in obligations if row.generation.current(expected)]
            historical_omitted = (len(decisions) - len(selected)) + (
                len(obligations) - len(current_obligations)
            )

        # The SQL read above is an immutable snapshot, not a live-owner lease.
        # Do not hold the SQL read lock while consulting the registry. A newer
        # SQL generation or owner turn omits awareness rather than borrowing
        # a stale result; the native sender checks permission again before writing.
        self._verify_live_inclusion(lookup, owner)
        instruction = InstructionFile.read("selected-awareness.md")
        content_instruction = InstructionFile.read("selected-awareness-content.md")
        # This digest names the captured typed SQL projection, not the whole file
        # or a refreshed permission. The original rows remain in their owner.
        digest = hashlib.sha256(
            json.dumps(
                FieldCodec.encode((tuple(selected), tuple(current_obligations))), sort_keys=True
            ).encode()
        ).hexdigest()
        result = CompleteAwareness(
            lookup,
            page.through_seq,
            tuple(selected),
            tuple(current_obligations),
            historical_omitted,
            instruction,
            content_instruction,
            provenance=(
                instruction.source,
                content_instruction.source,
                ResourceProvenance(str(path), digest, "captured typed optional awareness rows"),
                *(
                    WireProvenance(
                        MessageReference(row.assignment.wire_seq, row.assignment.message_id)
                    )
                    for row in selected
                ),
            ),
        )
        result.require_resource_budget(self.max_text_bytes)
        return result

    def _verify_live_inclusion(self, lookup: ThreadLookup, owner: NativeThread) -> None:
        registry = self.registry
        snapshot = registry.store.snapshot_now()
        RegistryOwner(
            thread=owner,
            claimed_generation=self.expected_claimed_generation,
        ).require_snapshot(snapshot, "current registry owner turn changed")
        # A new read transaction, not the earlier candidate/decision snapshot,
        # observes a supported SQL generation advance during the optional read.
        with registry.store.coordinator_reader.reader_snapshot(StoreBusy()) as db:
            rows = _ParticipantOwner.read(
                db.execute(
                    "SELECT g.generation,p.committed FROM owner_generations g "
                    "JOIN participants p ON p.participant_lookup=g.owner_lookup "
                    "WHERE g.owner_lookup=?",
                    (lookup,),
                )
            )
            if rows != [_ParticipantOwner(self.expected_participant_generation, True)]:
                raise ProjectionUnavailableError("current participant generation changed")

    def _verify_schema_and_owner(
        self,
        db: sqlite3.Connection,
        initial: Delivered,
        assignment: WakeAssignment,
        owner: Thread,
        privacy: RegistryPrivacy,
    ) -> None:
        privacy.coordinator_schema().require_schema(db)
        CohortTable.require_installed(db)
        people = _ParticipantOwner.read(
            db.execute(
                "SELECT p.committed,g.generation FROM participants p "
                "JOIN owner_generations g ON g.owner_lookup=p.participant_lookup "
                "WHERE p.participant_lookup=?",
                (assignment.recipient_lookup,),
            )
        )
        if people != [_ParticipantOwner(self.expected_participant_generation, True)]:
            raise ProjectionUnavailableError("selected participant owner changed")
        acknowledgement = _claim_record(db, initial, privacy)
        if not any(current == assignment for current in acknowledgement.assignments):
            raise ProjectionUnavailableError("current selected claim lost its sealed acknowledgement")

    def _selected_decisions(
        self, db: sqlite3.Connection, root_id: RootId, lookup: ThreadLookup, through_seq: int
    ) -> list[_SelectedDecision]:
        assignments = WakeAssignment.select(
            db,
            where="recipient_lookup=? AND wire_seq>? AND wire_seq<=? ORDER BY wire_seq LIMIT ?",
            parameters=(lookup, self.after_seq, through_seq, self.max_rows + 1),
        )
        if len(assignments) > self.max_rows:
            raise ProjectionUnavailableError("binding decisions exceed the row budget")
        if not assignments:
            return []
        # Each bounded query decodes the canonical record at the SQLite boundary.
        # Assignments anchor completeness: a missing joined proof raises KeyError,
        # omitting the whole supplement rather than silently dropping its source.
        sequences = tuple(row.wire_seq for row in assignments)
        claims = tuple(row.assignment_id for row in assignments)
        marks = ",".join("?" for _ in assignments)
        handled = {
            row.wire_seq: row
            for row in ClaimBatchAcknowledgements.select(
                db,
                where=f"wire_root_id=? AND wire_seq IN ({marks})",
                parameters=(root_id, *sequences),
            )
        }
        members = {
            row.claim_id: row
            for row in ClaimBatchMembers.select(
                db,
                where=f"claim_id IN ({marks})",
                parameters=claims,
            )
        }
        deliveries = {
            row.wire_seq: row
            for row in CohortDeliveries.select(
                db,
                where=f"wire_root_id=? AND recipient_lookup=? AND wire_seq IN ({marks})",
                parameters=(root_id, lookup, *sequences),
            )
        }
        generations = {
            row.claim_id: row
            for row in AwarenessClaimGenerations.select(
                db,
                where=f"claim_id IN ({marks})",
                parameters=claims,
            )
        }
        proof_domains = (
            (set(handled), set(sequences)),
            (set(deliveries), set(sequences)),
            (set(members), set(claims)),
            (set(generations), set(claims)),
        )
        if any(actual != expected for actual, expected in proof_domains):
            raise ProjectionUnavailableError("selected decision proof is incomplete")
        return [
            _SelectedDecision.capture(
                row,
                handled[row.wire_seq],
                members[row.assignment_id],
                deliveries[row.wire_seq],
                generations[row.assignment_id],
            )
            for row in assignments
        ]

    def _open_obligations(
        self, db: sqlite3.Connection, lookup: ThreadLookup
    ) -> list[_OpenObligation]:
        obligations = ResponseObligation.select(
            db,
            where="execution_id IN (SELECT execution_id FROM executions "
            "WHERE owner_lookup=?) AND state IN ('pending','publishing','deferred') "
            "ORDER BY created_at_ms,execution_id LIMIT ?",
            parameters=(lookup, self.max_rows + 1),
        )
        if len(obligations) > self.max_rows:
            raise ProjectionUnavailableError("open obligations exceed the row budget")
        if not obligations:
            return []
        executions = tuple(dict.fromkeys(row.execution_id for row in obligations))
        marks = ",".join("?" for _ in executions)
        owners = {
            row.execution_id: row
            for row in ExecutionRecord.select(
                db,
                where=f"execution_id IN ({marks})",
                parameters=executions,
            )
        }
        links = ExecutionAssignmentLink.select(
            db,
            where=f"execution_id IN ({marks}) ORDER BY execution_id,ordinal LIMIT ?",
            parameters=(*executions, self.max_rows + 1),
        )
        if len(links) > self.max_rows:
            raise ProjectionUnavailableError("open obligation sources exceed the row budget")
        claims = tuple(row.assignment_id for row in links)
        if not claims:
            raise ProjectionUnavailableError("open obligation has no original sources")
        assignments = {
            row.assignment_id: row for row in WakeAssignment.select(
                db, where=f"assignment_id IN ({','.join('?' for _ in claims)})", parameters=claims,
            )
        }
        generations = {
            row.claim_id: row
            for row in AwarenessClaimGenerations.select(
                db,
                where=f"claim_id IN ({','.join('?' for _ in claims)})",
                parameters=claims,
            )
        }
        return [
            _OpenObligation.capture(
                row,
                owners[row.execution_id],
                link,
                generations[link.assignment_id],
                assignments[link.assignment_id],
            )
            for row in obligations
            for link in links
            if link.execution_id == row.execution_id
            and assignments[link.assignment_id].lifecycle.exact_target == row.exact_target
        ]
