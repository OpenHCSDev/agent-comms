"""Captured registry and participant ownership at irreversible native boundaries.

These are distinct generation domains. Neither capture grants authority: callers
recheck the canonical registry/SQLite snapshot under their operation's locks.
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, ClassVar

from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.errors import StaleFence
from agent_comms.coordination.tables.participants import OwnerGenerations
from agent_comms.errors import RelationViolationError, UnregisteredThreadError
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.execution.private_send_rules import (
    GoalRegistryClaimCheck,
    GoalRegistryIdentityCheck,
    RegistryIdentityCheck,
    RunningTurnRegistryCheck,
)
from agent_comms.execution.reservation_rules import ReservationViolationError
from agent_comms.execution.turn_goal_permission import GoalPermission, OwnerGoalPermission
from agent_comms.nominal.field_codec import GoalId, ThreadLookup
from agent_comms.registry.threads import NativeThread, Thread

if TYPE_CHECKING:
    from agent_comms.execution.turn_lease import TurnLeaseFence
    from agent_comms.planning.goals import Goal
    from agent_comms.registry.registration import Registration
    from agent_comms.registry.registry_document import RegistrySnapshot


class NativeOwnerRegistry(ABC):
    """The original locked namespace reads needed to capture local executable authority."""

    __slots__ = ()

    @abstractmethod
    def require_active(self, name: str) -> Thread: ...

    @abstractmethod
    def require_member[Kind: Thread](self, name: str, kind: type[Kind]) -> Kind: ...

    @abstractmethod
    def claim_generation(self, name: str) -> int: ...


@dataclass(frozen=True, kw_only=True)
class RegistryOwner:
    check_type: ClassVar[type[RegistryIdentityCheck]] = GoalRegistryClaimCheck
    thread: NativeThread
    claimed_generation: int

    @property
    def goal_permission(self) -> GoalPermission:
        return OwnerGoalPermission(self.thread.goal.authority)

    @property
    def turn_lease(self) -> TurnLeaseFence:
        """The authorized owner declaration determines its exact original lease."""
        return self.thread.require_turn_lease()

    @classmethod
    def capture_local(cls, snapshot: NativeOwnerRegistry, name: str) -> RegistryOwner:
        """Read local executable authority from this single locked snapshot."""
        snapshot.require_active(name)
        thread = snapshot.require_member(name, NativeThread)
        thread.require_local_process(ProcessIdentity.capture(os.getpid()))
        claim_scope = snapshot.claim_generation(thread.name)
        thread.turn_record.read().require_current(claim_scope, thread.turn_generation)
        return cls(thread=thread, claimed_generation=claim_scope)

    def require_claim(self, expected: Thread, claim_scope: int) -> None:
        try:
            GoalRegistryIdentityCheck(
                expected=expected, actual=self.thread,
                expected_claim=claim_scope, claim_generation=self.claimed_generation,
                process=ProcessIdentity.capture(os.getpid()),
                goal_permission=OwnerGoalPermission(expected.goal.authority),
            ).require_valid()
        except ReservationViolationError as error:
            raise RelationViolationError(f"live owner changed before turn claim: {error}") from error
        self.thread.turn_record.read().require_idle()

    def require_active_turn(self):
        """Return the captured executable turn if its process and input generation still match."""
        self.thread.role.require_executable(StaleFence("registry owner is not executable"))
        try:
            turn = self.thread.turn_record.read().require_active()
        except RelationViolationError as error:
            raise StaleFence("registry owner is not executable") from error
        if not turn.owned_by(self.thread.require_process(), self.claimed_generation):
            raise StaleFence("registry owner turn witness is invalid")
        return turn

    @classmethod
    def capture(cls, snapshot: RegistrySnapshot, name: str, reason: str) -> RegistryOwner:
        try:
            thread = snapshot.require_member(name, NativeThread)
        except (UnregisteredThreadError, RelationViolationError) as error:
            raise StaleFence(reason) from error
        owner = cls(thread=thread, claimed_generation=snapshot.claim_generation(name))
        owner.require_snapshot(snapshot, reason)
        return owner

    def _require_current(
        self, actual: Thread, claim_scope: int | None, reason: str,
        check: type[RegistryIdentityCheck],
    ) -> None:
        try:
            check(
                expected=self.thread,
                actual=actual,
                expected_claim=self.claimed_generation,
                claim_generation=claim_scope,
                process=ProcessIdentity.capture(os.getpid()),
                goal_permission=self.goal_permission,
            ).require_valid()
        except (ReservationViolationError, RelationViolationError) as error:
            raise StaleFence(f"{reason}: {error}") from error

    def require_snapshot(self, snapshot: RegistrySnapshot, reason: str) -> None:
        self._snapshot_owner(snapshot, reason, self.check_type)

    def _snapshot_owner(
        self, snapshot: RegistrySnapshot, reason: str,
        check: type[RegistryIdentityCheck],
    ) -> Thread:
        try:
            actual = snapshot.require_active(self.thread.name)
        except RelationViolationError as error:
            raise StaleFence(reason) from error
        self._require_current(actual, snapshot.claim_generation(self.thread.name), reason, check)
        return actual

    def require_source_snapshot(self, snapshot: RegistrySnapshot) -> Thread:
        """Observe this authorized turn's source without allowing another input.

        Check the goal when accepting input. A legitimate goal change
        during this turn does not revoke its source observation; the exact
        lease, process, input generation and session must still match. The running
        turn retains its captured project/model/thinking while the document
        may select the next turn's configuration. This observes only the
        session that started this turn; new input still requires current configuration.
        """
        self.require_active_turn()
        return self._snapshot_owner(
            snapshot, "Native source owner changed before publication", RunningTurnRegistryCheck,
        )

    def require_running_turn(self, registry: Registration) -> None:
        """This owner's started turn may still record its result and replies.

        A project or goal chosen during the turn belongs to the next turn.
        """
        self.require_active_turn()
        self._require_live(registry, RunningTurnRegistryCheck)

    def require_registry(self, registry: Registration) -> None:
        self._require_live(registry, self.check_type)

    def _require_live(
        self, registry: Registration, check: type[RegistryIdentityCheck],
    ) -> None:
        try:
            actual, claim_scope = registry.live_owner_with_claim(self.thread.name)
        except (RelationViolationError, ValueError) as error:
            raise StaleFence("recipient registry owner stopped or changed") from error
        self._require_current(
            actual, claim_scope, "recipient registry owner stopped or changed", check,
        )


class GoalLaunchOwner(RegistryOwner):
    """Recover unused READY grants by owner identity and input generation, not old goal revision."""

    check_type = RegistryIdentityCheck

    def require_ready(self, snapshot: RegistrySnapshot, goal_id: GoalId) -> Goal:
        self.require_snapshot(snapshot, "Goal launch owner changed")
        current = snapshot.require_active(self.thread.name)
        snapshot.status(current.name).require_running()
        return current.goal.require().require_id(goal_id).require_active()


@dataclass(frozen=True)
class ParticipantOwner:
    thread: Thread
    generation: int

    def coordinator_identity(self, lookup: ThreadLookup) -> OwnerGenerations:
        return OwnerGenerations(
            owner_lookup=lookup, generation=self.generation
        )

    def require(self, store: Coordination, lookup: ThreadLookup) -> None:
        participant = store.participants.get(lookup)
        if not participant.committed or participant.owner_identity != self.coordinator_identity(lookup):
            raise StaleFence("cohort participant generation changed")
        if self.thread.incarnation.lookup != lookup:
            raise StaleFence("cohort participant incarnation changed")
        if self.thread.process_identity != ProcessIdentity.capture(os.getpid()):
            raise StaleFence("cohort recipient is not this live registered owner generation")
        self.thread.role.require_executable(StaleFence("cohort participant is not executable"))
