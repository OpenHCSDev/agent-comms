"""What an agent runtime reports about its thread, and where those reports land in Core.

A runtime (an external CLI's transcript, an owned runtime's events) yields RuntimeUpdate records.
ThreadOutput is their sink: it assembles item drafts per (turn, item), coalesces superseded
previews, and publishes finished items, drafts and activity to the thread's transcript.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING, ClassVar, Self

from agent_comms.agent_events import RuntimeInfoObservation
from agent_comms.cli_bridges.cli_protocol import EarlierItems
from agent_comms.execution.transcript_sources import ExternalTranscript
from agent_comms.execution.turn_item import NativeItemId, NativeTurnId, NoSourceTurn, TurnItem
from agent_comms.execution.turn_phase import IdlePhase, ModelWaitPhase, TurnPhase
from agent_comms.messaging.message_reference import MessageReference
from agent_comms.messaging.sending import Messaging
from agent_comms.registry import activity
from agent_comms.registry.agent_activity import AgentActivity
from agent_comms.registry.thread_identity import OfferedTools
from agent_comms.registry.thread_text import NoThreadText, ThreadText
from agent_comms.storage.recorded_time import EventTime, UnrecordedEventTime
from agent_comms.transcript.external_transcript_rows import ExternalPage
from agent_comms.transcript.transcript_events import (
    LiveTextTranscript,
    ToolStartTranscript,
    TranscriptEvent,
)

if TYPE_CHECKING:
    from agent_comms.cli_bridges.shared import TranscriptBridge
    from agent_comms.comms import Comms
    from agent_comms.importing import ImportBuffer
    from agent_comms.registry.thread_status import ThreadStatus


@dataclass
class DraftAccumulator:
    """One subscription's item prefix; the shared output owns its lifetime."""

    started_at: EventTime

    def staged(self) -> Self:
        """Share accumulators whose operations do not mutate their stored value."""
        return self

    def restarted(self, replacement: DraftAccumulator) -> DraftAccumulator:
        return replacement

    def started(self, update: StartedItem) -> tuple[RuntimeUpdate, ...]:
        return (
            *self.activity(ActiveItem(update.turn_id, update.item_id, update.phase)),
            *self.snapshot(update.turn_id, update.item_id),
        )

    def activity(self, update: ActiveItem) -> tuple[RuntimeUpdate, ...]:
        return (update,)

    def snapshot(self, turn_id: NativeTurnId, item_id: NativeItemId) -> tuple[DraftItem, ...]:
        return ()

    def append(self, update: AppendDraftItem) -> tuple[RuntimeUpdate, ...]:
        raise ValueError("Received a text delta for a non-text item")

    def finish(self, update: CompletedItem) -> tuple[ClosedDraft, FinishedItem]:
        """Close with the completed record's own already decoded event times."""
        return ClosedDraft(self.started_at), FinishedItem(turn_id=update.turn_id, item_id=update.item_id, events=update.events)


class NoPrefixDraft(DraftAccumulator):
    """No observed prefix; retain no per-item state so the instance can be shared."""

    def __init__(self) -> None:
        super().__init__(UnrecordedEventTime())

    def append(self, update: AppendDraftItem) -> tuple[RuntimeUpdate, ...]:
        """Drop the suffix: without an observed prefix it cannot form a whole item."""
        return ()


NO_PREFIX = NoPrefixDraft()


class PresentableDraft(DraftAccumulator, ABC):
    """A recorded prefix that can be projected as a live transcript row."""

    @property
    @abstractmethod
    def events(self) -> tuple[TranscriptEvent, ...]: ...

    def snapshot(self, turn_id: NativeTurnId, item_id: NativeItemId) -> tuple[DraftItem, ...]:
        return (DraftItem(turn_id, item_id, self),)


@dataclass
class ToolDraft(PresentableDraft):
    prefix: tuple[ToolStartTranscript, ...]

    @property
    def events(self) -> tuple[TranscriptEvent, ...]:
        return self.prefix

    def snapshot(self, turn_id: NativeTurnId, item_id: NativeItemId) -> tuple[DraftItem, ...]:
        return super().snapshot(turn_id, item_id) if self.prefix else ()


@dataclass
class TextDraft(PresentableDraft):
    event_type: type[LiveTextTranscript]
    sections: dict[int, list[str]]
    position: int | NativeItemId
    separator: ClassVar[str] = ""

    @classmethod
    def from_parts(
        cls,
        event_type: type[LiveTextTranscript],
        parts: Iterable[str],
        started_at: EventTime,
        position: int | NativeItemId,
    ) -> Self:
        return cls(
            started_at, event_type, {index: [text] for index, text in enumerate(parts)}, position
        )

    def staged(self) -> Self:
        return replace(self, sections={index: parts.copy() for index, parts in self.sections.items()})

    def append(self, update: AppendDraftItem) -> tuple[RuntimeUpdate, ...]:
        self.sections.setdefault(update.section, []).append(update.text)
        return self.snapshot(update.turn_id, update.item_id)

    @property
    def events(self) -> tuple[TranscriptEvent, ...]:
        text = self.separator.join(
            text for index in sorted(self.sections) if (text := "".join(self.sections[index]))
        )
        return (
            (self.event_type(text, position=self.position,
                             timestamp=self.started_at.recorded_at("A transcript event")),) if text else ()
        )


class ParagraphDraft(TextDraft):
    separator = "\n\n"


class ClosedDraft(DraftAccumulator):
    """Completed snapshots reject overlapping older starts and late suffixes."""

    def restarted(self, replacement: DraftAccumulator) -> DraftAccumulator:
        return self

    def started(self, update: StartedItem) -> tuple[RuntimeUpdate, ...]:
        return ()

    def activity(self, update: ActiveItem) -> tuple[RuntimeUpdate, ...]:
        return ()

    def append(self, update: AppendDraftItem) -> tuple[RuntimeUpdate, ...]:
        return ()


@dataclass
class ThreadOutput(activity.ThreadOutput):
    """Where a CLI's output lands in Core: finished items and current activity."""

    transcript: ExternalTranscript
    agents: AgentActivity
    drafts: dict[TurnItem, DraftAccumulator] = field(default_factory=dict)

    @classmethod
    def for_comms(cls, transcript: ExternalTranscript, comms: Comms) -> ThreadOutput:
        return cls(transcript, comms.agents)

    def delivered(self, turn_id: NativeTurnId, references: tuple[MessageReference, ...]) -> None:
        """Every external turn records the original deliveries that opened it."""
        self.transcript.delivered(turn_id, references)

    def publish_item(self, item: FinishedItem) -> None:
        self.transcript.finish(turn_id=item.turn_id, item_id=item.item_id, events=item.events)

    def publish_draft(self, item: DraftItem) -> None:
        self.transcript.draft(turn_id=item.turn_id, item_id=item.item_id, events=item.events)

    def publish_pending(self, pending: list[RuntimeUpdate]) -> None:
        for update in RuntimeUpdate.coalesced(pending):
            update.publish(self)
        pending.clear()

    def staged(self) -> Self:
        return replace(self, drafts={key: draft.staged() for key, draft in self.drafts.items()})

    def commit(self, staged: Self) -> None:
        self.drafts = staged.drafts

    def publish_batch(self, updates: list[RuntimeUpdate]) -> None:
        """A batch refused partway, by a maintenance hold or a CoordinationBeginUnavailable, is
        published again whole from the committed drafts. Its stored writes are keyed, so what
        already landed lands once; a sent reply is remembered by the replying output."""
        staged = self.staged()
        pending: list[RuntimeUpdate] = []
        for update in updates:
            update.accumulate_into(staged, pending)
        staged.publish_pending(pending)
        self.commit(staged)

    def draft(self, key: TurnItem) -> DraftAccumulator:
        return self.drafts.get(key, NO_PREFIX)

    def start_item(self, update: StartedItem) -> tuple[RuntimeUpdate, ...]:
        current = self.draft(update.key).restarted(update.accumulator.staged())
        self.drafts[update.key] = current
        return current.started(update)

    def active_item(self, update: ActiveItem) -> tuple[RuntimeUpdate, ...]:
        return self.draft(update.key).activity(update)

    def append_item(self, update: AppendDraftItem) -> tuple[RuntimeUpdate, ...]:
        current = self.draft(update.key)
        return current.append(update)

    def finish_item(self, update: CompletedItem) -> FinishedItem:
        self.drafts[update.key], finished = self.draft(update.key).finish(update)
        return finished

    def end_turn(self, turn_id: NativeTurnId) -> None:
        self.transcript.finish_replies(turn_id)
        for key in tuple(self.drafts):
            if key.turn_id == turn_id:
                del self.drafts[key]

    def end_all_turns(self) -> None:
        self.transcript.transition_replies(lambda window: window.finished())
        self.drafts.clear()

    def cancel_all_turns(self) -> None:
        self.transcript.transition_replies(lambda window: window.cancelled())
        self.drafts.clear()

    @property
    def activity_thread(self) -> str:
        return self.transcript.incarnation.name


@dataclass
class ReplyingThreadOutput(ThreadOutput):
    """The last finished assistant item replies only to deliveries that opened its turn."""

    messaging: Messaging = field(kw_only=True)
    pending: dict[TurnItem, FinishedItem] = field(default_factory=dict)
    # Sent is sent: staging shares this one map, so a refused batch never sends a reply again.
    sent: dict[tuple[TurnItem, str], tuple[MessageReference, ...]] = field(default_factory=dict)

    def staged(self) -> Self:
        return replace(super().staged(), pending=self.pending.copy())

    def commit(self, staged: Self) -> None:
        super().commit(staged)
        self.pending = staged.pending
        for sent in tuple(self.sent):
            if sent[0] not in self.pending:
                del self.sent[sent]

    @classmethod
    def for_comms(cls, transcript: ExternalTranscript, comms: Comms) -> Self:
        """Every live external endpoint follows the delivered message's reply policy."""
        return cls(transcript, comms.agents, messaging=comms.messaging)

    def flush_before(self, key: TurnItem) -> None:
        for previous in tuple(self.pending):
            if previous != key:
                super().publish_item(self.pending.pop(previous))

    def publish_item(self, item: FinishedItem) -> None:
        self.flush_before(item.key)
        if item.assistant_text:
            self.pending[item.key] = item
            self.transcript.draft(turn_id=item.turn_id, item_id=item.item_id, events=item.events)
        else:
            super().publish_item(item)

    def publish_draft(self, item: DraftItem) -> None:
        self.flush_before(item.key)
        super().publish_draft(item)

    def end_turn(self, turn_id: NativeTurnId) -> None:
        opening = self.messaging.bus.bus.messages_for_references(self.transcript.opening_for(turn_id))
        replies: dict[str, list[MessageReference]] = {}
        for message in opening:
            for target in message.automatic_reply_targets():
                replies.setdefault(target, []).append(message.reference)
        recipients: dict[str, ThreadStatus] = {}
        if replies:
            registry = self.messaging.registry.snapshot()
            recipients = {target: registry.status(target) for target in replies}
        for key in tuple(self.pending):
            if key.turn_id != turn_id:
                continue
            item = self.pending[key]
            for target, references in sorted(replies.items()):
                if (key, target) not in self.sent:
                    self.sent[key, target] = recipients[target].reply(
                        self.messaging, sender=self.activity_thread, target=target,
                        body=item.assistant_text, answers=tuple(references),
                        source_turn=NoSourceTurn(),
                    )
            published = tuple(publication for target in sorted(replies)
                              for publication in self.sent[key, target])
            super().publish_item(replace(item, events=tuple(
                event.with_publications(published) for event in item.events
            )))
            del self.pending[key]
        super().end_turn(turn_id)

    def end_all_turns(self) -> None:
        for turn_id in dict.fromkeys(key.turn_id for key in self.pending):
            self.end_turn(turn_id)
        super().end_all_turns()

    def cancel_all_turns(self) -> None:
        self.pending.clear()
        super().cancel_all_turns()


class ReadingPhase(ABC):
    """Where a reader is in its source: catching up on what was already written, or following it."""

    @abstractmethod
    def status(self, update: StatusUpdate) -> tuple[RuntimeUpdate, ...]:
        """Current activity now, or held until the reader has caught up."""

    def offered(self, update: OfferedToolsObserved) -> tuple[RuntimeUpdate, ...]:
        return (update,)

    def runtime_info(self, update: RuntimeInfoObserved) -> tuple[RuntimeUpdate, ...]:
        return (update,)


@dataclass(frozen=True)
class RuntimeUpdate(ABC):
    """One change a runtime reports about its thread."""

    def trail_events(self) -> tuple[object, ...]:
        return ()

    def during(self, phase: ReadingPhase) -> tuple[RuntimeUpdate, ...]:
        return (self,)

    @abstractmethod
    def publish(self, output: ThreadOutput) -> None: ...

    def accumulate(self, output: ThreadOutput) -> tuple[RuntimeUpdate, ...]:
        return (self,)

    def accumulate_into(self, output: ThreadOutput, pending: list[RuntimeUpdate]) -> None:
        pending.extend(self.accumulate(output))

    async def observed(self, bridge: TranscriptBridge) -> RuntimeUpdate:
        """Carry source-owned confirmation into the ordered publication stream."""
        return self

    def retain_before(self, later: set[TurnItem]) -> bool:
        """Whether this update still needs publication before later updates."""
        return True

    def page_record(self, turn_id: NativeTurnId, item_id: NativeItemId) -> FinishedItem:
        """Even an invisible item owns a source position and its page continuation."""
        return FinishedItem(turn_id=turn_id, item_id=item_id, events=())

    def add_to(self, history: ImportBuffer) -> None:  # noqa: B027 - default hook
        """What this update adds to an imported conversation; activity adds nothing."""

    @staticmethod
    def coalesced(updates: list[RuntimeUpdate]) -> list[RuntimeUpdate]:
        later: set[TurnItem] = set()
        kept = [update for update in reversed(updates) if update.retain_before(later)]
        return list(reversed(kept))


class StatusUpdate(RuntimeUpdate):
    """Reader phases decide when current activity is published."""

    def during(self, phase: ReadingPhase) -> tuple[RuntimeUpdate, ...]:
        return phase.status(self)


@dataclass(frozen=True)
class OfferedToolsObserved(RuntimeUpdate):
    offered: OfferedTools

    def during(self, phase: ReadingPhase) -> tuple[RuntimeUpdate, ...]:
        return phase.offered(self)

    def publish(self, output: ThreadOutput) -> None:
        output.agents.registry.observe_offered_tools(output.transcript.incarnation, self.offered)


@dataclass(frozen=True)
class RuntimeInfoObserved(RuntimeUpdate):
    """A CLI runtime's observation, recorded by the same runtime-info owner native threads use."""

    observation: RuntimeInfoObservation

    def during(self, phase: ReadingPhase) -> tuple[RuntimeUpdate, ...]:
        return phase.runtime_info(self)

    def publish(self, output: ThreadOutput) -> None:
        output.agents.observe_runtime_info(output.activity_thread, self.observation)


@dataclass(frozen=True)
class TurnStarted(StatusUpdate):
    detail: str = ""

    def publish(self, output: ThreadOutput) -> None:
        output.enter(ModelWaitPhase(self.detail))


@dataclass(frozen=True)
class TurnEnded(StatusUpdate):
    def accumulate_into(self, output: ThreadOutput, pending: list[RuntimeUpdate]) -> None:
        output.publish_pending(pending)
        self.publish(output)

    def retire(self, output: ThreadOutput) -> None:
        """An idle status snapshot retires nothing: saved completions refuse their replay."""

    def publish(self, output: ThreadOutput) -> None:
        self.retire(output)
        output.transcript.end_turn()
        output.enter(IdlePhase())


@dataclass(frozen=True)
class ActiveItem(TurnItem, StatusUpdate):
    """An item the CLI started producing: what it is doing now."""

    phase: TurnPhase

    def publish(self, output: ThreadOutput) -> None:
        output.enter(self.phase)

    def accumulate(self, output: ThreadOutput) -> tuple[RuntimeUpdate, ...]:
        return output.active_item(self)


@dataclass(frozen=True)
class FinishedItem(TurnItem, RuntimeUpdate):
    """One CLI item's complete presentation, identified by its producer."""

    events: tuple[TranscriptEvent, ...]

    @property
    def assistant_text(self) -> str:
        return "".join(part for event in self.events for part in event.assistant_parts())

    def trail_events(self) -> tuple[object, ...]:
        return self.events

    def publish(self, output: ThreadOutput) -> None:
        output.publish_item(self)

    def retain_before(self, later: set[TurnItem]) -> bool:
        later.add(self.key)
        return True

    def page_record(self, turn_id: NativeTurnId, item_id: NativeItemId) -> FinishedItem:
        return self

    def add_to(self, history: ImportBuffer) -> None:
        history.add(self.events)


@dataclass(frozen=True)
class PageItem(TurnItem):
    """An item-list identity survives even when its update is invisible in the live view."""

    update: RuntimeUpdate


@dataclass(frozen=True)
class PublishedPage(RuntimeUpdate):
    """A bounded harness snapshot publishes items, never current activity or drafts."""

    items: tuple[PageItem, ...]
    earlier: ExternalPage

    def publish(self, output: ThreadOutput) -> None:
        records = tuple(item.update.page_record(item.turn_id, item.item_id) for item in self.items)
        self.write(output.transcript, records)

    def write(self, transcript: ExternalTranscript, records: tuple[FinishedItem, ...]) -> None:
        transcript.publish_page(records, self.earlier)

    def add_to(self, history: ImportBuffer) -> None:
        for item in self.items:
            item.update.add_to(history)


@dataclass(frozen=True)
class EarlierPublishedPage(PublishedPage):
    request: EarlierItems

    def write(self, transcript: ExternalTranscript, records: tuple[FinishedItem, ...]) -> None:
        transcript.prepend(self.request, records, self.earlier)


@dataclass(frozen=True)
class HiddenItem(RuntimeUpdate):
    """Conversation the live view does not show, because the thread shows it another way
    (a bus delivery) or because only the person's own prompts are shown; history keeps it."""

    events: tuple[TranscriptEvent, ...]

    def publish(self, output: ThreadOutput) -> None:
        pass

    def add_to(self, history: ImportBuffer) -> None:
        history.add(self.events)


@dataclass(frozen=True)
class Summarized(RuntimeUpdate):
    """The harness replaced everything before this point with a summary (compaction)."""

    text: str

    def publish(self, output: ThreadOutput) -> None:
        pass

    def add_to(self, history: ImportBuffer) -> None:
        history.summarize(self.text)


@dataclass(frozen=True)
class SessionFacts(RuntimeUpdate):
    """Which session this is, where it ran and its title; a later fact replaces an earlier one."""

    source_id: str = ""
    project: str = ""
    title: ThreadText = NoThreadText()

    def publish(self, output: ThreadOutput) -> None:
        pass

    def add_to(self, history: ImportBuffer) -> None:
        history.describe(self)


@dataclass(frozen=True)
class EarlierRequest(RuntimeUpdate):
    """The newest request before the selected history, looked up only if that history has none."""

    find: Callable[[], str] = field(compare=False)

    def publish(self, output: ThreadOutput) -> None:
        pass

    def add_to(self, history: ImportBuffer) -> None:
        if not history.latest_request:
            history.latest_request = self.find()[: history.limits.per_message]


@dataclass(frozen=True)
class HistoryNotice(RuntimeUpdate):
    """Something about the source that an imported conversation should say it left out."""

    text: str

    def publish(self, output: ThreadOutput) -> None:
        pass

    def add_to(self, history: ImportBuffer) -> None:
        history.notices.add(self.text)


@dataclass(frozen=True)
class DraftItem(TurnItem, RuntimeUpdate):
    """A pending item's events, materialized only if this preview survives coalescing."""

    accumulator: PresentableDraft

    @property
    def events(self) -> tuple[TranscriptEvent, ...]:
        return self.accumulator.events

    def publish(self, output: ThreadOutput) -> None:
        output.publish_draft(self)

    def retain_before(self, later: set[TurnItem]) -> bool:
        keep = self.key not in later
        later.add(self.key)
        return keep


class DraftUpdate(RuntimeUpdate):
    """Part decoding enters the same accumulation path even for direct publication."""

    @abstractmethod
    def accumulate(self, output: ThreadOutput) -> tuple[RuntimeUpdate, ...]: ...

    def publish(self, output: ThreadOutput) -> None:
        output.publish_batch([self])


@dataclass(frozen=True)
class CompletedItem(DraftUpdate, FinishedItem):
    def accumulate(self, output: ThreadOutput) -> tuple[RuntimeUpdate, ...]:
        return (output.finish_item(self),)


@dataclass(frozen=True)
class StartedItem(DraftUpdate, ActiveItem):
    accumulator: DraftAccumulator

    def accumulate(self, output: ThreadOutput) -> tuple[RuntimeUpdate, ...]:
        return output.start_item(self)


@dataclass(frozen=True)
class AppendDraftItem(TurnItem, DraftUpdate):
    text: str
    section: int = 0

    def accumulate(self, output: ThreadOutput) -> tuple[RuntimeUpdate, ...]:
        return output.append_item(self)


@dataclass(frozen=True)
class FinishedTurn(TurnEnded):
    turn_id: NativeTurnId

    def retire(self, output: ThreadOutput) -> None:
        output.end_turn(self.turn_id)


@dataclass(frozen=True)
class AllTurnsEnded(TurnEnded):
    """The source ended every open turn; publication owns their retirement."""

    def retire(self, output: ThreadOutput) -> None:
        output.end_all_turns()


class AllTurnsCancelled(TurnEnded):
    """Interrupted output is retained context, not a completed answer."""

    def retire(self, output: ThreadOutput) -> None:
        output.cancel_all_turns()
