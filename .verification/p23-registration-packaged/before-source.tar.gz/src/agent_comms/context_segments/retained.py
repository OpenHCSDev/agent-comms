"""Original authored retained context, independent of its export producer."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from agent_comms.execution.turn_context import ContextSegment, OwnerProvenance, WireProvenance
from agent_comms.messaging.exporting import (
    AuthoredSourceScope,
    FullLimit,
    WireExportBoundary,
    WireExportProvenance,
    WireTranscriptExporter,
)
from agent_comms.messaging.retained_task_facts import RetainedTaskFacts


@dataclass(frozen=True, kw_only=True)
class RetainedSegment(ContextSegment):
    retained: RetainedTaskFacts
    scope: AuthoredSourceScope
    boundary: WireExportBoundary

    @classmethod
    def capture(cls, retained: RetainedTaskFacts, owner, registry,
                boundary: WireExportBoundary) -> "RetainedSegment":
        source = OwnerProvenance(owner.incarnation, retained.source_digest.value)
        sources = {message.reference: message for fact in retained.facts
                   for message in fact.wire_sources()}
        wording_sources = tuple(message.task.original_wording_context_source(
            retained.original_text_source(message.reference)) for message in sources.values())
        return cls(provenance=tuple(dict.fromkeys((source,
                       *(WireProvenance(ref) for ref in sources), *wording_sources))),
                   retained=retained, boundary=boundary,
                   scope=AuthoredSourceScope(tuple(message.reference for message in
                       retained.current_authored_sources(owner, registry))))

    def text(self) -> str:
        return self.retained.text

    def inspection(self) -> dict[str, object]:
        """Authored constraints retain their exact source and narrower export scope."""
        return dict(kind=type(self), text=self.text(),
                    provenance=self.provenance, input_supplied=False,
                    authored=dict(scope="authored declarations and their original pinned inputs only",
                                  sources=self.scope.sources,
                                  facts=self.retained),
                    export_scope="current authored declarations only; never goal, unpinned input, native artifact or failure state")

    def export(self, destination: Path | str, *, overwrite: bool = False) -> WireExportProvenance:
        """Publish this immutable read's selection through the original writer."""
        from agent_comms.context_segments.retained_context import RetainedFormat

        selected = sorted((source for fact in self.retained.facts
                           for source in fact.wire_sources()
                           if source.reference in self.scope.sources), key=lambda source: source.seq)
        return WireTranscriptExporter(format=RetainedFormat(self), scope=self.scope,
                                      limit=FullLimit(), boundary=self.boundary).export(
            selected, Path(destination).expanduser(), overwrite=overwrite)
