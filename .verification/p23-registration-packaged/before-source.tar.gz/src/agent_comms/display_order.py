"""Persisted display choices own ordering; adapters never interpret their names."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import ClassVar

from agent_comms.messaging.display_sources import (
    ChannelOrderSource,
    ChannelSortView,
    SentHistorySource,
)
from agent_comms.nominal.declared_choice import DeclaredChoice, TitledChoice
from agent_comms.nominal.declared_family import DeclaredFamily

type ChannelOrders = ChannelOrderSource[type[ThreadSort], type[ChannelSort]]
type ChannelDisplay = ChannelSortView[type[ChannelSort]]


class DisplayOrder(TitledChoice, DeclaredChoice, ABC):
    title: ClassVar[str]

    @classmethod
    def label(cls) -> str:
        return cls.title

    @classmethod
    @abstractmethod
    def store_channel_order(cls, channels: ChannelOrders, channel: str | None) -> type[DisplayOrder]: ...


class ThreadSort(DisplayOrder, DeclaredFamily, affix="ThreadSort"):
    """Newest chosen clock, then creation time and case-folded name."""

    @classmethod
    def key(
        cls, name: str, created: float, activity: float, sent: float
    ) -> tuple[float, float, str]:
        return -cls.timestamp(created, activity, sent), -created, name.casefold()

    @staticmethod
    @abstractmethod
    def timestamp(created: float, activity: float, sent: float) -> float: ...

    @classmethod
    def store_channel_order(cls, channels: ChannelOrders, channel: str | None) -> type[ThreadSort]:
        if channel is None:
            raise ValueError("Member ordering requires a channel")
        return channels.set_channel_sort(channel, cls).order

    @staticmethod
    def sent_timestamps[Registry](
        views: SentHistorySource[Registry], *, registry: Registry,
    ) -> dict[str, float]:
        """Only ordering by sent messages requires this source."""
        return {}


class LastMessageThreadSort(ThreadSort, declared_name="last_message_sent"):
    title = "Sent"

    @staticmethod
    def timestamp(created: float, activity: float, sent: float) -> float:
        return sent

    @staticmethod
    def sent_timestamps[Registry](
        views: SentHistorySource[Registry], *, registry: Registry,
    ) -> dict[str, float]:
        with views.bus.opened_activity() as clocks:
            return views.last_sent_timestamps(clocks.sent.items(), registry=registry)


class CreatedThreadSort(ThreadSort, declared_name="created_at"):
    title = "Created"

    @staticmethod
    def timestamp(created: float, activity: float, sent: float) -> float:
        return created


class LastActivityThreadSort(ThreadSort):
    title = "Active"

    @staticmethod
    def timestamp(created: float, activity: float, sent: float) -> float:
        return activity


class ChannelSort(DisplayOrder, DeclaredFamily, affix="ChannelSort"):
    """Pins partition every order; builtins keep their declared order in each partition."""

    @classmethod
    def key(cls, view: ChannelDisplay) -> tuple[int, int, float, float, str]:
        return view.channel.sort_key(cls, view)

    @classmethod
    def store_channel_order(cls, channels: ChannelOrders, channel: str | None) -> type[ChannelSort]:
        return channels.set_channel_order(cls)

    @classmethod
    @abstractmethod
    def sort_fields(cls, view: ChannelDisplay) -> tuple[float, float, str]: ...


class NameChannelSort(ChannelSort):
    title = "Name"

    @classmethod
    def sort_fields(cls, view: ChannelDisplay) -> tuple[float, float, str]:
        return 0, 0, view.channel.name.casefold()


class RecentChannelSort(ChannelSort):
    """Clock-based channel orders share creation/name tie-breaks, not name ordering."""

    @classmethod
    def sort_fields(cls, view: ChannelDisplay) -> tuple[float, float, str]:
        return -cls.timestamp(view), -view.channel.created_at, view.channel.name.casefold()

    @staticmethod
    @abstractmethod
    def timestamp(view: ChannelDisplay) -> float: ...


class CreatedChannelSort(RecentChannelSort, declared_name="created_at"):
    title = "Created"

    @staticmethod
    def timestamp(view: ChannelDisplay) -> float:
        return view.channel.created_at


class LastActivityChannelSort(RecentChannelSort):
    title = "Active"

    @staticmethod
    def timestamp(view: ChannelDisplay) -> float:
        return view.last_activity


class LastUserInputChannelSort(RecentChannelSort):
    title = "Input"

    @staticmethod
    def timestamp(view: ChannelDisplay) -> float:
        return view.last_user_input
