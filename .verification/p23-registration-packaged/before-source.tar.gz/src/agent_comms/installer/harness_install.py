"""What `agent-comms install` writes for each coding harness found on this machine.

Each harness declares where it reads skills and what it needs to reach the bus;
runtime publication links and configures it, and install registers its bus threads.
"""

from __future__ import annotations

import json
import os
import pkgutil
import shutil
import subprocess
import sys
from abc import abstractmethod
from dataclasses import dataclass
from importlib import import_module
from importlib.metadata import EntryPoints, entry_points
from importlib.resources import files
from pathlib import Path
from typing import ClassVar, Self

import agent_comms_hooks
from agent_comms.errors import RelationViolationError
from agent_comms.execution.child_process import Platform, ResidentManager
from agent_comms.host_services import SystemdUserService
from agent_comms.host_services.codex_inbox import CodexInboxService
from agent_comms.nominal.declared_family import DeclaredFamily
from agent_comms.nominal.field_codec import ScratchName
from agent_comms_hooks import ClaudeHookProgram


def replace_link(link: Path, target: Path) -> None:
    """Point `link` at `target` atomically; a regular file there is someone's own and is refused."""
    if link.exists() and not link.is_symlink():
        raise FileExistsError(f"Install cannot replace a regular file: {link}")
    link.parent.mkdir(parents=True, exist_ok=True)
    temporary = link.with_name(f".{link.name}.{ScratchName.mint()}")
    temporary.symlink_to(target)
    try:
        os.replace(temporary, link)
        Platform.current().sync_directory(link.parent)
    finally:
        temporary.unlink(missing_ok=True)


def json_config(path: Path) -> dict:
    """A harness's config file decoded once; one that isn't a JSON object is refused by name,
    and it is left as it is, since rewriting it would lose whatever the owner has in there."""
    if not path.exists():
        return {}
    try:
        document = json.loads(path.read_text())
    except json.JSONDecodeError as error:
        raise ValueError(f"{path} isn't valid JSON ({error}): fix or move it; nothing changed") from error
    if not isinstance(document, dict):
        raise ValueError(f"{path} isn't a JSON object: fix or move it; nothing changed")
    return document


def merge_json(path: Path, merge) -> None:
    """Rewrite a harness's JSON config through its owner, keeping unrelated settings."""
    document = json_config(path)
    merge(document)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(document, indent=2) + "\n")


@dataclass(frozen=True)
class Harness(DeclaredFamily, affix="Harness"):
    """A coding agent whose stored sessions a thread can be imported from; install finds, links
    and configures the ones present on this machine."""

    home: Path

    # External threads install registers for this harness; a harness that registers itself has none.
    bus_threads: ClassVar[tuple[str, ...]] = ()

    @classmethod
    def found(cls) -> bool:
        """Whether install finds this harness on this machine."""
        return False

    @classmethod
    def present(cls, home: Path) -> tuple[Self, ...]:
        return tuple(member(home) for member in cls.members_with(cls) if member.found())

    @classmethod
    def retire_session(cls, session: str) -> SystemdUserService:
        """Stop the bridge delivering to ``session`` before its thread moves to native Pi."""
        raise RelationViolationError(
            f"{cls.declared_name} sessions have no declared bridge to retire; re-home refused.")

    def links(self) -> dict[Path, Path]:
        """Every packaged skill, linked where this harness looks for skills."""
        return {}

    def configure(self) -> tuple[Path, ...]:
        """Write this harness's own config in its own format; returns the files written."""
        return ()

    @classmethod
    def published_links(cls, home: Path) -> dict[Path, Path]:
        """Refresh present harnesses and retain links of previously installed harnesses."""
        available = {type(harness) for harness in cls.present(home)}
        return {
            link: target
            for member in cls.members_with(cls)
            for link, target in member(home).links().items()
            if member in available or link.is_symlink()
        }


@dataclass(frozen=True)
class PiHarness(Harness, declared_name="pi"):
    """agent-comms' own native Pi: its sessions are already the format every thread runs, so an
    import keeps one byte for byte. Install builds Pi as the native package and never finds,
    links or configures it as a harness."""


@dataclass(frozen=True)
class InstalledHarness(Harness):
    """A harness CLI install finds on PATH, links skills into and configures."""

    executable: ClassVar[str]
    skills_dir: ClassVar[str]

    @classmethod
    def found(cls) -> bool:
        return bool(shutil.which(cls.executable))

    @staticmethod
    def bin(name: str) -> Path:
        return Path(sys.executable).parent / name

    def links(self) -> dict[Path, Path]:
        skills = Path(str(files("agent_comms") / "skills"))
        return {
            self.home / self.skills_dir / skill.name: skill
            for skill in skills.iterdir()
            if skill.is_dir()
        }

    @abstractmethod
    def configure(self) -> tuple[Path, ...]: ...


class ConnectorClientHarness(InstalledHarness):
    """A harness whose MCP client can reach the connector as its bus threads."""

    @abstractmethod
    def connector_registered(self) -> bool: ...

    @abstractmethod
    def register_connector(self, url: str, token: str) -> None: ...


@dataclass(frozen=True)
class ClaudeCodeHarness(ConnectorClientHarness):
    """Claude Code reads the bus through a Monitor on `agent-comms-claude-bridge watch`;
    no config holds it."""

    executable: ClassVar[str] = "claude"
    skills_dir: ClassVar[str] = ".claude/skills"
    bus_threads: ClassVar[tuple[str, ...]] = ("claude-code",)

    def connector_registered(self) -> bool:
        return subprocess.run(
            (self.executable, "mcp", "get", "comms"), capture_output=True,
        ).returncode == 0

    def register_connector(self, url: str, token: str) -> None:
        if self.connector_registered():
            subprocess.run(
                (self.executable, "mcp", "remove", "--scope", "user", "comms"), check=True,
            )
        subprocess.run(
            (self.executable, "mcp", "add-json", "--scope", "user", "comms", json.dumps({
                "type": "http", "url": url,
                "headers": {"Authorization": f"Bearer {token}"},
            })),
            check=True,
        )

    @staticmethod
    def hook_programs() -> tuple[type[ClaudeHookProgram], ...]:
        """Discover installation declarations here, never inside a running hook."""
        for module in pkgutil.iter_modules(agent_comms_hooks.__path__):
            import_module(f"{agent_comms_hooks.__name__}.{module.name}")
        return tuple(
            installed
            for program in ClaudeHookProgram.descendants()
            if not program.__abstractmethods__
            for installed in program.installation_members()
        )

    @staticmethod
    def command(program: type[ClaudeHookProgram], scripts: EntryPoints) -> str:
        """Installed metadata owns the shell command, not the program's RPC identity."""
        (name,) = {point.name for point in scripts if point.value == program.entrypoint()}
        return name

    def configure(self) -> tuple[Path, ...]:
        settings = self.home / ".claude/settings.json"
        scripts = entry_points(group="console_scripts")
        programs = self.hook_programs()
        installed_hooks = tuple(program.hook(self.command(program, scripts)) for program in programs)

        def reconcile_hooks(document: dict) -> None:
            events = document.setdefault("hooks", {})
            for event, entries in events.items():
                events[event] = [
                    entry for entry in entries
                    if not ClaudeHookProgram.owns_entry(entry, installed_hooks)
                ]
            for program in programs:
                for event in program.events:
                    events.setdefault(event, []).append(program.entry(self.command(program, scripts)))

        merge_json(settings, reconcile_hooks)
        return (settings, self.home / ".claude.json")


@dataclass(frozen=True)
class CodexHarness(InstalledHarness):
    """Codex is pushed to by a user service; the user starts it after binding a conversation."""

    executable: ClassVar[str] = "codex"
    skills_dir: ClassVar[str] = ".codex/skills"

    def configure(self) -> tuple[Path, ...]:
        ResidentManager.current().install(CodexInboxService, home=self.home)
        return (CodexInboxService.unit_file(self.home),)

    @classmethod
    def retire_session(cls, session: str) -> CodexInboxService:
        if not session:
            raise RelationViolationError("Codex reported no session id; cannot retire its inbox.")
        inbox = CodexInboxService(session)
        inbox.retire()
        return inbox


@dataclass(frozen=True)
class OpenCodeHarness(InstalledHarness, declared_name="opencode"):
    """OpenCode loads the TUI plugin, which attaches its session to the bus itself;
    run `opencode-comms`."""

    executable: ClassVar[str] = "opencode"
    skills_dir: ClassVar[str] = ".config/opencode/skills"

    @property
    def plugin(self) -> Path:
        return self.home / ".local/share/agent-comms/opencode_tui.ts"

    def links(self) -> dict[Path, Path]:
        return super().links() | {
            self.plugin: Path(str(files("agent_comms.cli_bridges") / "opencode_tui.ts"))
        }

    def configure(self) -> tuple[Path, ...]:
        tui = self.home / ".config/opencode/tui.json"
        url = self.plugin.as_uri()

        def add_plugin(document: dict) -> None:
            plugins = document.setdefault("plugin", [])
            if url not in plugins:
                plugins.append(url)

        merge_json(tui, add_plugin)
        return (tui,)


class HarnessSession(DeclaredFamily, affix="History", discovery_package="agent_comms.cli_bridges"):
    """A harness session's declared readers and bridges, selected by their capabilities.

    The root sits beside its harnesses, below the coordinator tables, so a coordinator row
    can name the bridge that made a delivery attempt by this declaration."""

    harness: ClassVar[type[Harness]]
