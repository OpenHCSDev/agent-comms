"""Shared Core inbox delivery and process lifetime for external CLI adapters."""
from __future__ import annotations

import argparse
import asyncio
import io
import json
import os
import secrets
import signal
import socket
import sqlite3
import sys
import time
import traceback
from abc import ABC, abstractmethod
from collections import deque
from collections.abc import Awaitable, Callable, Iterable, Iterator, Mapping
from contextlib import (
    AbstractContextManager,
    ExitStack,
    aclosing,
    closing,
    contextmanager,
    suppress,
)
from dataclasses import dataclass, field, replace
from datetime import datetime
from functools import cached_property, partial
from pathlib import Path
from typing import TYPE_CHECKING, Annotated, ClassVar, Generic, Literal, Self, TextIO, TypeVar, cast

from pydantic import Field, InstanceOf, PlainSerializer, PlainValidator, model_validator

from agent_comms.agent_runtime import ExternalRuntime, PublishesTranscript
from agent_comms.cli_bridges.cli_arguments import CliArguments
from agent_comms.cli_bridges.cli_protocol import CoreError, EarlierItems, TaggedWire
from agent_comms.cli_bridges.harness_delivery_states import (
    DeliveredOutcome,
    EmittedOutcome,
    FilteredOutcome,
    MismatchedMonitor,
    MonitorEvidence,
    ObservedMonitor,
    Outcome,
    TakingLedger,
    UnconfirmedOutcome,
)
from agent_comms.cli_bridges.monitor import (
    BRIDGE_FAILURES,
    BridgeExit,
    InspectSession,
    MonitorPeer,
    PauseSession,
    PeerGone,
    RequestFailure,
    SessionInformation,
    SessionReady,
    SessionRefused,
    SessionReply,
    SessionRequest,
    VerifySession,
    read_monitor,
)
from agent_comms.cli_bridges.runtime_updates import (
    HiddenItem,
    ReplyingThreadOutput,
    RuntimeUpdate,
    ThreadOutput,
)
from agent_comms.cli_bridges.session_watch import (
    HeldClaim,
    SessionConnectionClosed,
    SessionFailure,
    SessionRequestTimeout,
    WatchClaim,
    WatchRecord,
)
from agent_comms.cli_bridges.wire_models import WireModel
from agent_comms.cli_verbs.declared_verb import DeclaredOptions
from agent_comms.cli_verbs.send_request import SendRequest
from agent_comms.comms import Comms, wire
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.database import CoordinationStore
from agent_comms.coordination.errors import (
    CoordinationBeginUnavailable,
    CoordinationReadUnavailable,
    DeferredRead,
)
from agent_comms.coordination.tables.harness_deliveries import HarnessDelivery, HarnessObservedPart
from agent_comms.errors import RelationViolationError, UnregisteredThreadError
from agent_comms.execution.child_process import (
    OutlivesLauncherLifetime,
    Platform,
    ProcessIdentity,
    SpawnedProcess,
)
from agent_comms.execution.delivers_input import DeliversInput
from agent_comms.execution.launch_runtime import LaunchRuntime, RunningSource
from agent_comms.execution.turn_item import NoSourceTurn, SourceTurn
from agent_comms.installer.harness_install import HarnessSession
from agent_comms.installer.native_build_inputs import DetachedChildStdio
from agent_comms.installer.refusals import UpgradeRefused
from agent_comms.messaging.bus import Bus
from agent_comms.messaging.bus_tables import MessageIdentitySource
from agent_comms.messaging.message_reference import (
    BridgeBeginning,
    BridgePosition,
    BridgeStart,
    InboxStart,
    MessageReference,
)
from agent_comms.messaging.messages import Message
from agent_comms.messaging.send_result import SendResult
from agent_comms.nominal import field_codec
from agent_comms.nominal.declared_family import DeclaredFamily
from agent_comms.nominal.field_codec import (
    FieldCodec,
    MalformedRecord,
    MessageId,
    PathText,
    SubclassUnion,
    ThreadLookup,
)
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.registration import Registration
from agent_comms.registry.thread_identity import ThreadIncarnation
from agent_comms.registry.thread_status import (
    ConnectedThreadStatus,
    PausedBridgeThreadStatus,
    ThreadStatus,
)
from agent_comms.registry.thread_text import AbsentText, GivenText, TextChoice
from agent_comms.registry.threads import ExternalThread
from agent_comms.storage.locked_store import FilesRequest, RegistryFile, SQLiteFile
from agent_comms.storage.maintenance_barrier import MaintenanceHeldError
from agent_comms.storage.private_path import (
    PrivateDirectoryRole,
    PrivateFileRole,
    TrustedAncestorRole,
)
from agent_comms.storage.store_files import ExclusiveDirectoryAtomicFile
from agent_comms.storage.typed_table import (
    DerivedColumn,
    DurableTables,
    ExternalStore,
    StoredRowDerivation,
    TableSchema,
    TypedTable,
    WriterOwnedFile,
    WriterOwnedResource,
    WriterOwnedStore,
)
from agent_comms.task_attachments.team_pings import TeamUpdate
from agent_comms.transcript.transcript_publication import PublishesToBus, WaitsOnBusyStore
from agent_comms_hooks.watch import SessionCommandError

if TYPE_CHECKING:
    from agent_comms.cli_bridges.claude_protocol import ReadResultObserved
    from agent_comms.coordination.assignment_store import AssignmentStore


class ReaderState:
    async def prepare_delivery(self, bridge: LineMonitorBridge) -> AttachedReader:
        async with bridge.reader_changed:
            await bridge.reader_changed.wait_for(lambda: bridge.reader is not self)
        return await bridge.reader.prepare_delivery(bridge)

    async def deliver(self, bridge: LineMonitorBridge, message: Message) -> type[Outcome]:
        reader = await self.prepare_delivery(bridge)
        return await reader.deliver(bridge, message)

    async def confirm_probe(self, bridge: LineMonitorBridge, probe: MonitorProbe) -> None:
        """Only an unproven attachment consumes a probe."""

    async def part_observed(self, message_id: MessageId, number: int) -> None:
        """Only an attached reader has a flow-control window."""

    async def attach(self, service: MonitorService, peer: MonitorPeer) -> SessionReply:
        return SessionRefused(error="This session already has a Monitor reader")


class NoReader(ReaderState):
    async def attach(self, service: MonitorService, peer: MonitorPeer) -> SessionReply:
        bridge = service.bridge
        attachment = bridge.new_attachment(peer, secrets.token_hex(24))
        async with bridge.reader_changed:
            bridge.reader = UnreadyReader(attachment)
        try:
            await SessionReady().publish(peer)
            await peer.write(attachment.probe.model_dump_json())
            await peer.reader.read()
            # Only a reader leaving a bridge that keeps serving is declared. A stopping bridge
            # skips this registry write: its install pause is acknowledged only once teardown
            # ends, and a successor declares its own reader state when it starts serving.
            async with bridge.reader_changed:
                bridge.reader = NoReader()
                await bridge.declare_reader(PausedBridgeThreadStatus())
            return PeerGone()
        finally:
            async with bridge.reader_changed:
                bridge.reader = NoReader()
                bridge.reader_changed.notify_all()
            async with attachment.window_changed:
                attachment.window_changed.notify_all()
            bridge.log(f"Monitor detached; exception={sys.exception()!r} "
                       "(None means reader EOF); delivery paused.")


@dataclass
class MonitorAttachment:
    peer: MonitorPeer
    probe: MonitorProbe
    pending_parts: dict[tuple[MessageId, int], int] = field(default_factory=dict)
    window_changed: asyncio.Condition = field(default_factory=asyncio.Condition)

    async def emit(self, message_id: MessageId, number: int, line: str, window_bytes: int) -> None:
        size = len((line + "\n").encode("utf-16-le"))
        async with self.window_changed:
            await self.window_changed.wait_for(
                lambda: self.peer.writer.is_closing()
                or not self.pending_parts
                or sum(self.pending_parts.values()) + size <= window_bytes
            )
            self.pending_parts[message_id, number] = size
            await self.peer.write(line)

    async def observed(self, message_id: MessageId, number: int) -> None:
        async with self.window_changed:
            self.pending_parts.pop((message_id, number), None)
            self.window_changed.notify_all()


@dataclass
class UnreadyReader(ReaderState):
    attachment: MonitorAttachment

    async def confirm_probe(self, bridge: LineMonitorBridge, probe: MonitorProbe) -> None:
        if probe == self.attachment.probe:
            async with bridge.reader_changed:
                if bridge.reader is not self:
                    return
                await bridge.declare_reader(ConnectedThreadStatus())
                bridge.reader = AttachedReader(self.attachment)
                bridge.reader_changed.notify_all()
            bridge.log("Fresh Monitor probe observed; delivery enabled.")


@dataclass
class AttachedReader(UnreadyReader):
    async def prepare_delivery(self, bridge: LineMonitorBridge) -> AttachedReader:
        return self

    async def confirm_probe(self, bridge: LineMonitorBridge, probe: MonitorProbe) -> None:
        """Overlapping observations cannot prove a different attachment."""

    async def part_observed(self, message_id: MessageId, number: int) -> None:
        await self.attachment.observed(message_id, number)

    async def deliver(self, bridge: LineMonitorBridge, message: Message) -> type[Outcome]:
        return await bridge.deliver_to(self.attachment, message)


@dataclass
class MonitorService:
    bridge: LineMonitorBridge
    owner: ProcessIdentity
    stop: Callable[[], None]

    async def accept(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer = MonitorPeer(reader, writer)
        try:
            try:
                reply: SessionReply
                try:
                    request = await asyncio.to_thread(SessionRequest.from_wire_line, await peer.read())
                    reply = await request.handle(self, peer)
                except (MalformedRecord, TimeoutError, SessionFailure) as error:
                    reply = SessionRefused(error=str(error))
                except BRIDGE_FAILURES as error:
                    # Refuse this request without cancelling every client in the TaskGroup.
                    reply = RequestFailure(error).reply(self.bridge.log)
                await reply.publish(peer)
            finally:
                await peer.close()
        except (BrokenPipeError, ConnectionResetError) as error:
            await self.bridge.report_failure(f"Monitor connection ended: {error}")

    async def run(self) -> None:
        await self.bridge.declare_reader(PausedBridgeThreadStatus())
        path = WatchClaim(self.bridge.binding.thread).socket_path
        path.unlink(missing_ok=True)
        try:
            server = await asyncio.start_unix_server(
                lambda reader, writer: clients.create_task(self.accept(reader, writer)),
                str(path), start_serving=False,
            )
            async with server:
                try:
                    async with asyncio.TaskGroup() as clients:
                        await server.start_serving()
                        self.bridge.log(f"Session bridge ready for Claude PID {self.owner.pid}.")
                        try:
                            await self.owner.wait_exited()
                        finally:
                            # The listener stops before the clients retire, so no new
                            # connection reaches a group that is shutting down.
                            server.close()
                            self.stop()
                finally:
                    # A connection accepted in the same loop step as close has no client
                    # task; closing it keeps Server.wait_closed from waiting forever.
                    server.close_clients()
        finally:
            path.unlink(missing_ok=True)


class BridgeStateTable(DurableTables):
    """The bridge's delivery.sqlite3: its binding and every delivery attempt.

    The bus holds the messages, not whether this harness was sent them, so
    nothing rebuilds these rows: a stored schema that differs is carried onto the
    declaration where it says how, keeping every row, and refused where it cannot.
    """

    __slots__ = ()
    filename = 'delivery.sqlite3'
    retired_tables: ClassVar[tuple[str, ...]] = ('board_line', 'board_delivery', 'delivery', 'observed_part')


class BindingRequest(ABC):
    """What the command line asks of the state directory's one binding."""

    @abstractmethod
    def bind(self, db: sqlite3.Connection) -> SessionBinding: ...


class BindingSession(ABC):
    """The command line or the harness owns this session's identity."""

    @classmethod
    @abstractmethod
    def add_arguments(cls, parser: argparse._ActionsContainer) -> None: ...

    @abstractmethod
    def resolve(self, bridge: type[CliBridge]) -> str: ...

    @abstractmethod
    def supplied(self) -> dict[str, str]: ...


@dataclass(frozen=True)
class SuppliedSession(BindingSession):
    session: str

    @classmethod
    def add_arguments(cls, parser: argparse._ActionsContainer) -> None:
        parser.add_argument('--session', dest='binding_session', type=cls, required=True)

    def resolve(self, bridge: type[CliBridge]) -> str:
        return self.session

    def supplied(self) -> dict[str, str]:
        return {FieldCodec.record_key(BindingIdentity, 'thread'): self.session}


@dataclass(frozen=True)
class EnvironmentSession(BindingSession):
    @classmethod
    def add_arguments(cls, parser: argparse._ActionsContainer) -> None:
        parser.add_argument(
            '--session', dest='binding_session', type=SuppliedSession, default=cls())

    def resolve(self, bridge: type[CliBridge]) -> str:
        return bridge.environment_session()

    def supplied(self) -> dict[str, str]:
        return {}


@dataclass(frozen=True)
class StoredBinding(BindingRequest):
    """No binding given: the directory's own, read without taking the writer."""

    def bind(self, db: sqlite3.Connection) -> SessionBinding:
        return Binding.require(db)


@dataclass(frozen=True)
class GivenBinding(BindingRequest):
    """Some binding fields given: each overrides the stored binding's field, and a field
    missing from both is refused by name when the merged fields decode."""

    given: dict[str, str]

    @classmethod
    def from_arguments(cls, arguments: CliArguments, bridge: type[CliBridge]) -> Self:
        keys = {key for _, key in FieldCodec.record_fields(BindingAddress)}
        values = {key: value for key, value in vars(arguments).items() if key in keys}
        arguments.base_state = arguments.state
        arguments.state = arguments.state / arguments.binding_thread.thread
        return cls({**values, **arguments.binding_session.supplied(),
                    FieldCodec.record_key(BindingAddress, 'bus'): arguments.binding_thread.thread})

    def bind(self, db: sqlite3.Connection) -> BindingAddress:
        stored = Binding.select(db)
        root = FieldCodec.record_key(BindingAddress, 'root')
        defaults: dict[str, object] = (FieldCodec.encode_fields(stored[0].address()) if stored else {
            'start': FieldCodec.encode(Binding.bus_head(self.given[root])),
        } if root in self.given else {})
        return FieldCodec.decode_record(BindingAddress, {**defaults, **self.given})


class ResolvedBinding(GivenBinding):
    """A bare command resolves its reader from the harness session's enrolment."""

    @classmethod
    def from_arguments(cls, arguments: CliArguments, bridge: type[CliBridge]) -> Self:
        session = arguments.binding_session.resolve(bridge)
        bindings = WatchClaim(session).bindings()
        if len(bindings) != 1:
            raise ValueError(
                f'Expected one enrolled binding for session {session}; '
                f'found {[record.bus for record in bindings]}'
            )
        record, = bindings
        arguments.root = record.root
        arguments.binding_thread = GivenThread(record.bus)
        arguments.state = record.base_state
        arguments.binding_session = SuppliedSession(session)
        return super().from_arguments(arguments, bridge)


class BindingThread(ABC):
    """The bus flag's binding request and its resolved thread answer."""

    @property
    @abstractmethod
    def request(self) -> type[GivenBinding]: ...

    @property
    @abstractmethod
    def thread(self) -> str: ...


@dataclass(frozen=True, slots=True)
class GivenThread(BindingThread):
    """An explicit bus flag selects the explicit binding request."""

    thread: str = field()
    request = GivenBinding


@dataclass(frozen=True, slots=True)
class ResolvedThread(BindingThread):
    """Without a bus flag, the operation owns how its reader is resolved."""

    request: type[GivenBinding] = field()

    @property
    def thread(self) -> str:
        raise ValueError('Resolve the enrolled binding before reading its thread')


@dataclass(frozen=True, kw_only=True)
class SessionBinding(ABC):
    """The session and start shared by a requested address and a registered reader."""

    root: str
    thread: Annotated[str, field_codec.WireName("session")]
    start: BridgePosition

    @property
    @abstractmethod
    def bus(self) -> str: ...

    @abstractmethod
    def recipient(self, comms: Comms) -> ThreadIncarnation: ...

    def registered(self, comms: Comms) -> Binding:
        return Binding(root=self.root, owner=self.recipient(comms),
                       thread=self.thread, start=self.start)

    def address(self) -> BindingAddress:
        """Project this session's recipient address without replacing its stored identity."""
        return BindingAddress(root=self.root, thread=self.thread,
                              start=self.start, bus=self.bus)


@dataclass(frozen=True, kw_only=True, slots=True)
class BindingAddress(SessionBinding):
    """A command-line address, resolved only after the operation registers its thread."""

    bus: Annotated[str, field_codec.WireName("bus_thread")] = field()

    def recipient(self, comms: Comms) -> ThreadIncarnation:
        return comms.registry.require(self.bus).incarnation


@dataclass(frozen=True, kw_only=True)
class RegisteredReader(BindingAddress, StoredRowDerivation):
    """The registered incarnation derived from a stored reader address."""

    def derived_value(self) -> ThreadIncarnation:
        try:
            return Registration(RegistryFile.path_in(Path(self.root))).require(self.bus).incarnation
        except UnregisteredThreadError as error:
            raise RelationViolationError(
                f'cannot bind unregistered reader {self.bus!r} in {self.root}'
            ) from error


@dataclass(frozen=True, kw_only=True)
class BindingIdentity(SessionBinding):
    owner: Annotated[ThreadIncarnation, DerivedColumn(source=RegisteredReader)]

    @property
    def bus(self) -> str:
        return self.owner.name

    def recipient(self, comms: Comms) -> ThreadIncarnation:
        current = comms.registry.require_lookup(self.owner.require_recorded().lookup)
        return current.incarnation

@dataclass(frozen=True)
class Binding(BindingIdentity, BridgeStateTable, TypedTable):
    dropped_fields = ('bus',)

    @staticmethod
    def bus_head(root: str) -> BridgePosition:
        bus = Bus(Bus.path_in(Path(root)))
        if not bus.path.is_file():
            raise FileNotFoundError(bus.path)
        with bus.observing() as db:
            latest = MessageIdentitySource.select(
                db, order_by=('seq',), descending=True, limit=1)
            return (BridgeStart(MessageReference(latest[0].seq, latest[0].message_id))
                    if latest else BridgeBeginning())

    @classmethod
    def add_arguments(cls, parser: argparse.ArgumentParser,
                      session: type[BindingSession], request: type[GivenBinding]) -> None:
        group = parser.add_argument_group(
            'Core/CLI binding (each given field overrides the stored binding)')
        group.add_argument('--root', default=argparse.SUPPRESS)
        group.add_argument('--bus-thread', dest='binding_thread', type=GivenThread,
                           default=ResolvedThread(request))
        session.add_arguments(group)

    @classmethod
    @contextmanager
    def open(cls, state: Path):
        state.mkdir(parents=True, exist_ok=True, mode=0o700)
        with closing(SQLiteFile.writer(state / BridgeStateTable.filename)) as db:
            db.execute('PRAGMA synchronous=FULL')
            BridgeStateTable.install_schema(db, WriterOwnedFile())
            yield db

    def bind(self, db: sqlite3.Connection) -> Binding:
        """Rebind the reader's transport without replacing its delivery progress."""
        with SQLiteFile.write_transaction(db):
            if not Binding.select(db):
                self.insert(db)
            stored = Binding.require(db)
            if stored.root != self.root or stored.owner != self.owner:
                raise ValueError('This state directory belongs to another Core/CLI conversation')
            Binding.update(db, where='1', thread=self.thread, owner=self.owner)
            return replace(stored, thread=self.thread, owner=self.owner)


@dataclass
class Options:
    operation: Operation
    binding: BindingRequest
    state: Path
    base_state: Path

    @classmethod
    def parse(cls, description: str | None, state: Path, bridge_type: type[CliBridge]) -> Self:
        common = argparse.ArgumentParser(add_help=False)
        common.add_argument('--state', type=Path, default=state)
        bridge_type.add_arguments(common)
        parser = argparse.ArgumentParser(description=description)
        commands = parser.add_subparsers(required=True)
        for operation in Operation.offered(bridge_type):
            command = commands.add_parser(
                operation.command_name(), parents=[common],
                help=operation.help, description=operation.help)
            Binding.add_arguments(command, operation.binding_session, operation.binding_request)
            operation.add_arguments(command)
            command.set_defaults(operation=operation)
        arguments = parser.parse_args(namespace=CliArguments())
        arguments.operation = arguments.operation.from_arguments(arguments)
        arguments.binding = arguments.binding_thread.request.from_arguments(arguments, bridge_type)
        return cls(**{declared.name: vars(arguments)[key]
                      for declared, key in FieldCodec.record_fields(cls)})


BridgeOptions = TypeVar("BridgeOptions", bound=Options)
OperationBridge = TypeVar("OperationBridge", bound="CliBridge")


@dataclass(frozen=True)
class Operation(DeclaredOptions, ABC, Generic[OperationBridge]):
    """A decoded CLI command owns its execution."""

    help: ClassVar[str]
    """The one line `--help` shows; every offered command declares it."""

    binding_session: ClassVar[type[BindingSession]] = EnvironmentSession
    binding_request: ClassVar[type[GivenBinding]] = ResolvedBinding

    @classmethod
    def command_name(cls) -> str:
        return cls.__name__.lower()

    @abstractmethod
    async def execute(self, bridge: OperationBridge) -> None: ...

    async def register(self, bridge: CliBridge) -> None:
        """Most operations require an already registered reader."""

    async def prepare(self, bridge: CliBridge) -> None:
        await self.register(bridge)
        bridge.binding = bridge.address.registered(bridge.comms).bind(bridge.db)

    def transcript_source(self) -> Path:
        raise ValueError('This command does not own a live transcript subscription')

    def retired(self, bridge: OperationBridge) -> None:
        """Most operations have no runtime successor."""

    @classmethod
    def serves(cls, bridge: type[CliBridge]) -> bool:
        """Whether this command runs on that bridge; every bridge sends."""
        return True

    @classmethod
    def offered(cls, bridge: type[CliBridge]) -> tuple[type[Operation], ...]:
        """The commands a bridge's CLI takes, derived from what the bridge can do."""
        pending, offered = list(cls.__subclasses__()), []
        while pending:
            operation = pending.pop(0)
            pending.extend(operation.__subclasses__())
            if operation.serves(bridge):
                offered.append(operation)
        return tuple(offered)










@dataclass(frozen=True, kw_only=True)
class Send(SendRequest, Operation[OperationBridge]):
    async def execute(self, bridge: OperationBridge) -> None:
        request = replace(self, sender=bridge.binding.bus)
        await bridge.show_sent(await bridge.comms.bus.when_open(
            partial(request.sent, bridge.comms)))


class Inbox(Operation[OperationBridge]):
    help = "Deliver this binding's bus messages to its harness until stopped"
    @classmethod
    def serves(cls, bridge: type[CliBridge]) -> bool:
        """Delivery alone, without the transcript that confirms it on some bridges."""
        return not issubclass(bridge, TranscriptConfirmsDelivery)

    async def start(self, bridge: OperationBridge, tasks: asyncio.TaskGroup,
                    endpoint: ExitStack) -> None:
        registry = await asyncio.to_thread(
            Registration, RegistryFile.path_in(Path(bridge.binding.root)))
        await bridge.comms.bus.when_open(lambda: endpoint.enter_context(
            registry.external_process(bridge.binding.bus, bridge.session_process())))
        tasks.create_task(bridge.watch())

    def claimed(self, claim: WatchClaim,
                record: WatchRecord) -> AbstractContextManager[HeldClaim]:
        return claim.held(record)

    def keep(self, bridge: OperationBridge, held: HeldClaim) -> None:
        """Only a session-owned serve has a successor to keep its claim for."""

    async def execute(self, bridge: OperationBridge) -> None:
        await bridge.registered_watch(self)


class BindingChannels(SubclassUnion, TextChoice, affix="BindingChannels"):
    """Optional initial channel source for a new independent external endpoint."""

    @abstractmethod
    async def register(self, bridge: CliBridge) -> None: ...


@dataclass(frozen=True, slots=True)
class ChannelsFrom(GivenText, BindingChannels):
    text: str

    async def register(self, bridge: CliBridge) -> None:
        worktree = await bridge.session_worktree()
        await bridge.comms.bus.when_open(partial(
            bridge.comms.registry.register_bound_thread,
            bridge.address.bus, self.text, worktree, bridge.session_process(),
        ))


@dataclass(frozen=True, slots=True)
class NoChannelSource(AbsentText, BindingChannels):
    """An independent endpoint starts without copied channel membership."""

    async def register(self, bridge: CliBridge) -> None:
        thread = ExternalThread(
            bridge.address.bus, frozenset(), await bridge.session_worktree(),
            process_identity=bridge.session_process())
        await bridge.comms.bus.when_open(partial(bridge.comms.registry.declare, thread))


@dataclass(frozen=True)
class Watch(Inbox):
    help = "Deliver this binding's bus messages and publish its harness transcript to the bus"

    channels_from: Annotated[
        BindingChannels, field_codec.Argument(flags=("--channels-from",))
    ] = NoChannelSource()

    @classmethod
    def serves(cls, bridge: type[CliBridge]) -> bool:
        return issubclass(bridge, PublishesTranscript)

    async def execute(self, bridge: OperationBridge) -> None:
        await bridge.watch_operation(self)

    async def register(self, bridge: CliBridge) -> None:
        if not bridge.comms.registry.snapshot().taken(bridge.address.bus):
            await self.channels_from.register(bridge)

    async def start(self, bridge: TranscriptBridge, tasks: asyncio.TaskGroup,
                    endpoint: ExitStack) -> None:
        await super().start(bridge, tasks, endpoint)
        tasks.create_task(bridge.publish_transcript())


@dataclass(frozen=True, kw_only=True)
class Serve(Watch):
    help = "The session bridge process that connect and the SessionStart hook launch; not run by hand"
    owner: Annotated[
        ProcessIdentity,
        field_codec.Argument(flags=("--owner",), options={"type": FieldCodec.parse}),
    ]
    transcript: Annotated[Path, PathText, field_codec.Argument(flags=("--transcript",))]

    @classmethod
    def serves(cls, bridge: type[CliBridge]) -> bool:
        return issubclass(bridge, LineMonitorBridge)

    def transcript_source(self) -> Path:
        return self.transcript

    def command(self, record: WatchRecord, runtime: LaunchRuntime) -> tuple[str, ...]:
        return (
            str(runtime.interpreter.with_name(Path(record.command[0]).name)),
            self.command_name(), *record.command[2:], *self.arguments(),
        )

    def arguments(self) -> tuple[str, ...]:
        return ('--owner', json.dumps(FieldCodec.encode_record(self.owner)),
                '--transcript', str(self.transcript))

    def successor(self, claim: int) -> ResumedServe:
        """The same owner's serve, holding this one's claim across exec."""
        return ResumedServe(owner=self.owner, transcript=self.transcript, claim=claim)

    def keep(self, bridge: LineMonitorBridge, held: HeldClaim) -> None:
        bridge.retirement = bridge.retirement.keeping(held)

    @classmethod
    def launch(cls, claim: WatchClaim, owner: Callable[[], ProcessIdentity],
               transcript: Path) -> None:
        """The session hook supplies its identity; Serve owns launch and readiness."""
        claim.state().connect(
            lambda: cls(owner=owner(), transcript=transcript),
            lambda operation: VerifySession(owner=operation.owner),
        )

    @classmethod
    def relaunch(cls, claim: WatchClaim, session: SessionInformation) -> None:
        """The reader's way back from a dead bridge: the session it last saw, through launch."""
        cls.launch(claim, lambda: session.owner, session.transcript)

    def launch_record(self, claim: WatchClaim, record: WatchRecord,
                      request: SessionRequest) -> None:
        runtime = LaunchRuntime.installed()
        command = self.command(record, runtime)
        log = claim.path.with_suffix('.log')
        offset = log.stat().st_size if log.exists() else 0
        with log.open('ab') as output:
            child = SpawnedProcess.launch(
                command, env=runtime.environment(os.environ),
                stdio=DetachedChildStdio(stdout=output), runtime=runtime,
                lifetime=OutlivesLauncherLifetime)
        announced = False
        while child.alive():
            try:
                request.exchange(claim.socket_path)
                return
            except (FileNotFoundError, ConnectionRefusedError):
                if not announced:
                    print(
                        f'Waiting for session bridge PID {child.pid} to answer; log {log}',
                        file=sys.stderr, flush=True,
                    )
                    announced = True
                time.sleep(.05)
        summary = child.reap().summary
        with log.open('rb') as recorded:
            recorded.seek(offset)
            appended = recorded.read().decode(errors='replace').strip()
        raise SessionCommandError(
            f'Session bridge PID {child.pid} exited before answering ({summary}): {appended}'
        )

    @staticmethod
    def running(home: Path) -> tuple[SessionBridge, ...]:
        bridges = []
        for endpoint in WatchClaim.endpoints(home):
            try:
                observed = InspectSession().information(endpoint)
            except (FileNotFoundError, ConnectionRefusedError):
                # A bridge may exit after enumeration, leaving its old socket behind.
                continue
            claim = WatchClaim(observed.transcript.stem, home)
            if claim.socket_path != endpoint:
                raise ValueError('Session endpoint reported a different claim identity')
            bridges.append(SessionBridge(claim, observed))
        return tuple(sorted(bridges, key=lambda bridge: bridge.claim.thread))

    def retired(self, bridge: LineMonitorBridge) -> None:
        bridge.retirement.finish(self, bridge.watch_record(bridge.binding))

    async def execute(self, bridge: LineMonitorBridge) -> None:
        if self.transcript.stem != bridge.binding.thread:
            raise ValueError('The live transcript belongs to another Claude session')
        self.owner.require_alive()
        await bridge.registered_watch(self)

    async def start(self, bridge: LineMonitorBridge, tasks: asyncio.TaskGroup,
                    endpoint: ExitStack) -> None:
        await super().start(bridge, tasks, endpoint)
        tasks.create_task(MonitorService(bridge, self.owner, bridge.stop).run())


@dataclass(frozen=True, kw_only=True)
class ResumedServe(Serve):
    """A serve exec'd in place by an install: it adopts the claim its predecessor kept."""

    help = "A session bridge an install resumes in place, adopting its predecessor's claim"

    claim: Annotated[int, field_codec.Argument(flags=("--claim",), options={"type": int})]

    def arguments(self) -> tuple[str, ...]:
        return (*super().arguments(), '--claim', str(self.claim))

    def claimed(self, claim: WatchClaim,
                record: WatchRecord) -> AbstractContextManager[HeldClaim]:
        return claim.adopted(self.claim, record)


class ConfirmableBridge(ABC):
    @abstractmethod
    def confirm(self) -> BridgeResume: ...


class ResumableBridge(ABC):
    @abstractmethod
    def release(self) -> ConfirmableBridge: ...

    def require_paused(self) -> None:  # noqa: B027 - default hook
        """A pause the bridge acknowledged, or one with nothing left to pause, refuses nothing."""


@dataclass(frozen=True)
class BridgeResume(ResumableBridge, ConfirmableBridge, DeclaredFamily, affix="Bridge"):
    name: str

    def release(self) -> Self:
        return self

    def confirm(self) -> Self:
        return self

    def failures(self) -> tuple[UnresumedBridge, ...]:
        """A bridge that came back, or whose owner left, fails nothing."""
        return ()

    @abstractmethod
    def lines(self) -> tuple[str, ...]: ...


class UnresumedBridge(BridgeResume, ValueError):
    """A bridge that should have come back on the new runtime and did not."""

    def failures(self) -> tuple[UnresumedBridge, ...]:
        return (self,)

    def __str__(self) -> str:
        return "\n".join(self.lines())


@dataclass(frozen=True)
class ResumedBridge(BridgeResume):
    from_runtime: LaunchRuntime
    to_runtime: LaunchRuntime

    def lines(self) -> tuple[str, ...]:
        return (f"Session bridge {self.name}: {self.from_runtime.prefix} -> "
                f"{self.to_runtime.prefix}",)


@dataclass(frozen=True)
class UnacknowledgedPause(UnresumedBridge):
    """A bridge that never answered pause may still hold bus resources: install refuses."""

    socket: Path
    timeout: float
    paused: PausedSessionBridge = field(compare=False, repr=False)

    def require_paused(self) -> None:
        raise UpgradeRefused(str(self))

    def release(self) -> Self:
        """The bridge may still be closing its bus resources; its runtime waits in the socket
        for the ready it writes once they close, so it resumes instead of staying stopped.
        The refusal stands."""
        self.paused.release()
        return self

    def lines(self) -> tuple[str, ...]:
        return (f"Session bridge {self.name} at {self.socket} did not acknowledge pause "
                f"within {self.timeout:g} s",)


class StoppedBridge(BridgeResume):
    """Nothing is left serving the claim, which is all a pause asks: no failure."""


@dataclass(frozen=True)
class StartingBridge(BridgeResume):
    """Handed its runtime and not serving yet: it resumes on its own, or at its session's next
    start. An install never waits on a peer; the team and the bus stay behind it otherwise."""

    runtime: LaunchRuntime

    def lines(self) -> tuple[str, ...]:
        return (f"Session bridge {self.name}: handed {self.runtime.prefix}; resumes on its own",)


@dataclass(frozen=True)
class OwnerExitedBridge(StoppedBridge):
    def lines(self) -> tuple[str, ...]:
        return (f"Session bridge {self.name}: owner exited; left stopped",)


@dataclass(frozen=True)
class ExitedBridge(StoppedBridge):
    """Its socket closed unanswered and its own process has exited."""

    def lines(self) -> tuple[str, ...]:
        return (f"Session bridge {self.name}: bridge exited during pause; left stopped",)


@dataclass(frozen=True)
class ReplacedBridge(UnresumedBridge):
    observed: ProcessIdentity
    current: ProcessIdentity

    def lines(self) -> tuple[str, ...]:
        return (f"Session bridge {self.name}: process or owner changed "
                f"({self.observed} -> {self.current}); re-arm this bridge",)


@dataclass(frozen=True)
class UnobservedBridge(UnresumedBridge):
    reason: str

    def lines(self) -> tuple[str, ...]:
        return (f"Session bridge {self.name}: new runtime was not observed "
                f"({self.reason}); re-arm this bridge",)


@dataclass(frozen=True)
class SessionBridge:
    """A live endpoint's own description, captured before install stops anything."""

    claim: WatchClaim
    observed: SessionInformation

    def pause(self, resources: ExitStack) -> ResumableBridge:
        if not self.observed.owner.alive():
            if self.observed.process.alive():
                self.observed.process.signal(signal.SIGTERM)
            return OwnerExitedBridge(self.claim.thread)
        self.observed.owner.require_alive()
        request = PauseSession(owner=self.observed.owner, process=self.observed.process)
        peer = resources.enter_context(request.connection(self.claim.socket_path))
        stream = resources.enter_context(peer.makefile('rb'))
        paused = PausedSessionBridge(self, peer)
        try:
            request.read_reply(stream)
        except SessionRequestTimeout:
            return UnacknowledgedPause(self.claim.thread, self.claim.socket_path,
                                       request.reply_timeout, paused)
        except SessionConnectionClosed:
            return self.closed(paused, request.reply_timeout)
        return paused

    def closed(self, paused: PausedSessionBridge, timeout: float) -> ResumableBridge:
        """A socket closed unanswered: stopped once its own process has exited, otherwise the
        live process may still hold bus resources and the pause stays unacknowledged."""
        Platform.current().wait_any_exited((self.observed.process,), timeout)
        if self.observed.process.alive():
            return UnacknowledgedPause(self.claim.thread, self.claim.socket_path, timeout, paused)
        return ExitedBridge(self.claim.thread)


@dataclass
class SessionBridgeResumes:
    """Every bridge an install paused. One failed resume cancels neither another resume nor
    the install steps after it: each outcome is reported, then the install exits non-zero."""

    paused: deque[ResumableBridge] = field(default_factory=deque)
    released: deque[ConfirmableBridge] = field(default_factory=deque)
    outcomes: list[BridgeResume] = field(default_factory=list)

    @contextmanager
    def holding(self, bridges: Iterable[SessionBridge]) -> Iterator[None]:
        """Each paused peer keeps its socket until released. Every exit releases and confirms
        what is still paused, so no bridge waits on a runtime that never comes."""
        with ExitStack() as resources:
            try:
                for bridge in bridges:
                    self.paused.append(bridge.pause(resources))
                    self.paused[-1].require_paused()
                yield
            finally:
                self.release()
                self.confirm()

    def release(self) -> None:
        """Give every paused peer its selected runtime before waiting for any successor."""
        while self.paused:
            self.released.append(self.paused[0].release())
            self.paused.popleft()

    def confirm(self) -> None:
        """Consume each released peer once, retaining outcomes for the terminal report."""
        while self.released:
            self.outcomes.append(self.released[0].confirm())
            self.released.popleft()

    @property
    def failures(self) -> tuple[UnresumedBridge, ...]:
        return tuple(error for outcome in self.outcomes for error in outcome.failures())

    def lines(self) -> tuple[str, ...]:
        return tuple(line for outcome in self.outcomes for line in outcome.lines())

    def require_resumed(self) -> None:
        failures = self.failures
        if failures:
            raise ExceptionGroup('Session bridges not resumed', failures)


@dataclass(frozen=True)
class PausedSessionBridge(ResumableBridge):
    bridge: SessionBridge
    peer: socket.socket

    def release(self) -> ConfirmableBridge:
        runtime = LaunchRuntime.installed()
        observed = self.bridge.observed
        name = self.bridge.claim.thread
        if not observed.owner.alive():
            return OwnerExitedBridge(name)
        try:
            self.peer.sendall((json.dumps(FieldCodec.encode(runtime)) + '\n').encode())
        except OSError as error:
            return UnobservedBridge(name, f"{type(error).__name__}: {error}")
        return ReleasedSessionBridge(self.bridge, runtime)


@dataclass(frozen=True)
class ReleasedSessionBridge(ConfirmableBridge):
    """A peer already given its runtime; its successor can start while install continues."""

    bridge: SessionBridge
    runtime: LaunchRuntime

    def confirm(self) -> BridgeResume:
        """The claim says whether the successor is still starting: its lock outlives the exec
        and is released only when the process exits, so no deadline guesses it."""
        observed = self.bridge.observed
        claim = self.bridge.claim
        runtime = self.runtime
        try:
            current = InspectSession().information(claim.socket_path)
        except (FileNotFoundError, ConnectionRefusedError):
            if claim.claim.held_elsewhere():
                return StartingBridge(claim.thread, runtime)
            return UnobservedBridge(claim.thread, f"process exited before serving {runtime.prefix}")
        except (OSError, SessionCommandError) as error:
            return UnobservedBridge(claim.thread, f"{type(error).__name__}: {error}")
        if current.process != observed.process or current.owner != observed.owner:
            return ReplacedBridge(claim.thread, observed.process, current.process)
        if current.runtime.prefix != runtime.prefix:
            return UnobservedBridge(
                claim.thread, f"observed {current.runtime.prefix}, expected {runtime.prefix}")
        return ResumedBridge(claim.thread, observed.runtime, current.runtime)


class Enrol(Operation):
    help = "Record this session's binding without starting its bridge; the next SessionStart starts it"
    reported: ClassVar[str] = (
        'Session binding enrolled; the next SessionStart starts the bridge. Monitor runs watch.')

    @classmethod
    def serves(cls, bridge: type[CliBridge]) -> bool:
        return issubclass(bridge, LineMonitorBridge)

    async def prepare(self, bridge: CliBridge) -> None:
        """Enrolment leaves registration and the durable binding to SessionStart."""

    async def execute(self, bridge: LineMonitorBridge) -> None:
        WatchClaim(bridge.address.thread).enrol(bridge.watch_record(bridge.address))
        self.begin(bridge)
        print(self.reported, flush=True)

    def begin(self, bridge: LineMonitorBridge) -> None:
        """Enrolment alone starts nothing."""


@dataclass(frozen=True)
class IncomingFrame(ABC):
    message: Message

    @property
    def text(self) -> str:
        return (f'Comms in · {self.message.sender_label}\n'
                f'{self.message.body}\nMessage ID: {self.message.message_id}')

class BridgeLog(io.TextIOBase):
    """The bridge process's stderr, including tracebacks and partial print writes."""

    def __init__(self, stream: TextIO):
        self.stream = stream
        self.at_line_start = True

    def write(self, text: str) -> int:
        for line in text.splitlines(keepends=True):
            if self.at_line_start:
                self.stream.write(datetime.now().astimezone().isoformat(timespec='milliseconds') + ' ')
            self.stream.write(line)
            self.at_line_start = line.endswith('\n')
        return len(text)

    def flush(self) -> None:
        self.stream.flush()

    def fileno(self) -> int:
        return self.stream.fileno()


class HarnessDeliveryRecords(WaitsOnBusyStore, ABC):
    """The attempts one harness route records for its recipient, and every step that settles them.

    A bridge beside the session and a watch socket for a session on another machine both record
    through this parent: neither can store an outcome the other would have had to prove."""

    comms: Comms

    @property
    @abstractmethod
    def recipient_lookup(self) -> ThreadLookup: ...

    @property
    @abstractmethod
    def delivery_kind(self) -> type[HarnessSession]:
        """The harness route an attempt is keyed by."""

    def attempt(self, message: Message, outcome: type[Outcome]) -> HarnessDelivery:
        reference = message.reference
        return HarnessDelivery(self.delivery_kind, self.recipient_lookup, reference.message_id,
                               reference.seq, outcome)

    async def coordinator_write[Result](
        self, operation: Callable[[AssignmentStore, sqlite3.Connection], Result],
    ) -> Result:
        """Attempts and their claim steps share the coordinator's one write, under the bus hold.

        A busy store while the coordinator and its transaction are still being acquired is
        CoordinationBeginUnavailable: the operation and its commit never ran. Once acquired,
        the operation, its commit and close keep their own errors; none is relabelled."""
        def write() -> Result:
            with ExitStack() as held:
                try:
                    store = held.enter_context(
                        Coordination(str(CoordinationStore.path_in(self.comms.root))))
                    db = held.enter_context(store.session.writing())
                except CoordinationBeginUnavailable:
                    raise
                except CoordinationReadUnavailable as error:
                    raise CoordinationBeginUnavailable(
                        CoordinationBeginUnavailable.busy_message) from error
                return operation(store.assignments, db)
        return await self.comms.bus.when_open(write)

    async def coordinator_read[Result](self, operation: Callable[[sqlite3.Connection], Result]) -> Result:
        def read() -> Result:
            with self.comms.registry.store.coordinator_reader.reader_snapshot() as db:
                return operation(db)
        return await self.comms.bus.when_open(read)

    async def attempts(self, message_id: MessageId) -> tuple[HarnessDelivery, ...]:
        return await self.coordinator_read(lambda db: tuple(HarnessDelivery.select(
            db, bridge=self.delivery_kind, recipient_lookup=self.recipient_lookup, message_id=message_id)))

    async def message(self, reference: MessageReference) -> Message:
        message, = await self.comms.bus.when_open(
            partial(self.comms.bus.bus.messages_for_references, (reference,)))
        return message

    @contextmanager
    def uncertain_on_contention(self, message_id: MessageId) -> Iterator[None]:
        """An exhausted store wait inside a confirmation leaves its attempt as stored: uncertain,
        never replayed, and the transport keeps serving. Every other error propagates."""
        try:
            yield
        except DeferredRead as error:
            self.log(f'Message {message_id} remains uncertain; not replayed: {error}')

    async def finish(self, delivery: HarnessDelivery,
                     change: Callable[[HarnessDelivery], HarnessDelivery]) -> None:
        with self.uncertain_on_contention(delivery.message_id):
            stored = await self.coordinator_write(partial(delivery.apply, change))
            self.log(f'{stored.outcome.declared_name}: {delivery.message_id}')


@dataclass(eq=False, repr=False)
class CliBridge(
    HarnessDeliveryRecords,
    ExternalRuntime,
    DeliversInput[Message],
    HarnessSession,
    Generic[BridgeOptions],
    declared_name=None,
):
    """Core delivery and lifetime shared by CLI-specific transports."""

    state_directory: ClassVar[Path]

    @classmethod
    def state_path(cls) -> Path:
        """This bridge's default state directory in the live filesystem."""
        return Path.home() / cls.state_directory

    @classmethod
    def add_arguments(cls, parser: argparse.ArgumentParser) -> None:
        """Declare the options this harness's transport needs."""

    @classmethod
    def environment_session(cls) -> str:
        raise ValueError('Supply --session or a complete bus binding')

    options: BridgeOptions
    address: SessionBinding
    db: sqlite3.Connection
    binding: Binding = field(init=False)
    comms: Comms = field(init=False)
    running_source: RunningSource = field(default_factory=RunningSource.current, kw_only=True)
    """Where this bridge's code came from: an install can replace an installed runtime's."""

    def __post_init__(self) -> None:
        """The bus this bridge's address names; resolving it creates no store."""
        self.comms = wire(Path(self.address.root))

    def watch_record(self, binding: SessionBinding) -> WatchRecord:
        return WatchRecord(binding.bus, binding.root,
                           (Path(sys.argv[0]).name, *sys.argv[1:]), self.options.base_state)

    def session_process(self) -> ProcessIdentity:
        """A line-monitor endpoint lives in the session-owned bridge process."""
        return ProcessIdentity.capture(os.getpid())

    async def session_worktree(self) -> Checkout:
        """Only a thread not yet registered asks, before any binding exists: the session runs
        where its bridge was started."""
        return Checkout(Path.cwd())

    async def registered_watch(self, operation: Inbox) -> None:
        with ExitStack() as endpoint:
            with operation.claimed(WatchClaim(self.binding.thread), self.watch_record(self.binding)) as held:
                try:
                    async with asyncio.TaskGroup() as tasks:
                        await operation.start(self, tasks, endpoint)
                finally:
                    # A pause ends the tasks by cancellation; the claim is kept either way.
                    operation.keep(self, held)

    async def watch_operation(self, operation: Watch) -> None:
        await self.registered_watch(operation)

    @abstractmethod
    async def show_sent(self, result: SendResult) -> None:
        """Display a completed send without publishing it again."""

    async def report_failure(self, text: str) -> None:
        self.log(text)

    def sent_text(self, result: SendResult) -> str:
        message = result.message
        return '\n'.join((f'Comms out · {message.sender} → {message.target}',
                          message.body, f'Message ID: {message.message_id}', *result.notices))

    @property
    def recipient_lookup(self) -> ThreadLookup:
        return self.binding.owner.require_recorded().lookup

    @property
    def delivery_kind(self) -> type[HarnessSession]:
        return type(self)

    async def resume_after(self) -> InboxStart:
        """The binding and the attempts own progress, including uncertain emissions."""
        latest = await self.coordinator_read(
            lambda db: HarnessDelivery.latest(db, self.delivery_kind, self.recipient_lookup))
        return max((self.binding.start, *(BridgeStart(reference) for reference in latest)),
                   key=lambda point: point.cursor())

    async def prepare_delivery(self) -> None:
        """A transport may prepare its harness after the operation bound its reader."""

    async def deliver_board(self, update: TeamUpdate, message: Message) -> type[Outcome]:
        """Every transport honors the packet's wake decision; passive display is not input."""
        return await update.wake(self, message)

    async def wake(self, message: Message) -> type[Outcome]:
        """The packet already owns its HUD text; every harness receives that original message."""
        return await self.deliver(message)

    async def accept(self, message: Message) -> None:
        """Before its durable begin the message is held, never skipped: a store busy while the
        begin is still being acquired waits and reacquires for the same message. After the
        begin, the attempt is exactly as stored; contention leaves it uncertain, never re-sent."""
        conversation = message.type.conversation_message
        outcome = UnconfirmedOutcome if conversation else FilteredOutcome

        async def begin() -> bool:
            # A detached reader creates no attempt for a message it has not reached.
            await self.prepare_delivery()
            return await self.coordinator_write(self.attempt(message, outcome).begin)

        if not await self.once_available(f'Message {message.message_id}', begin):
            return
        with self.uncertain_on_contention(message.message_id):
            result = await message.task.delivered_by(self, message) if conversation else outcome
            await self.finish(self.attempt(message, result), partial(replace, outcome=result))

    async def watch(self) -> None:
        await self.prepare_delivery()
        self.log(f'Watching {self.binding.bus} → {self.binding.thread}; unconfirmed attempts retained without replay')
        while True:
            await self.comms.bus.when_open(self.watch_current_bus)

    async def watch_current_bus(self) -> None:
        """when_open runs this again after every maintenance hold, and every install holds
        maintenance: a bridge whose runtime the install replaced stops instead of reading on
        with the old code (on 2026-11-06 the host's bridge watch did, through three installs)."""
        self.running_source.require_current()
        await self.watch_bus()

    async def watch_bus(self) -> None:
        """The message read in this process: one line at a time reaches delivery, so the attempts
        keep owning the resume position and a bridge restart reads from the same place."""
        lines: asyncio.Queue[Callable[[], Awaitable[None]]] = asyncio.Queue()
        try:
            async with asyncio.TaskGroup() as tasks:
                tasks.create_task(self.read_messages(lines))
                tasks.create_task(self.read_requests(lines))
                tasks.create_task(self.deliver_lines(lines))
        except* MaintenanceHeldError as held:  # the bus owns waiting and its next attempt
            raise held.exceptions[0] from None

    async def read_messages(self, lines: asyncio.Queue[Callable[[], Awaitable[None]]]) -> None:
        """A busy store repeats the whole subscription: every message already read has its
        attempt, because the next read waits for its delivery, so the resume position skips it."""
        async def subscription() -> None:
            arrived = self.comms.watch(self.binding.bus, after=await self.resume_after())
            async with aclosing(arrived) as messages:
                async for message in messages:
                    lines.put_nowait(partial(self.accept, message))
                    await lines.join()

        with core_watch_failure(lines):
            await self.once_available('Watch read', subscription)
            # Nothing else would say so: delivery alone would keep the session deaf and silent.
            raise CoreWatchEnded('The bus read ended on its own')

    async def read_requests(self, lines: asyncio.Queue[Callable[[], Awaitable[None]]]) -> None:
        async def subscription() -> None:
            source = await Coordination.run_worker(
                partial(self.comms.history_source, self.binding.bus))
            await source.watch_requests(lambda row: lines.put_nowait(
                partial(EarlierItems.from_row(row).handle, self)))

        with core_watch_failure(lines):
            await self.once_available('Watch requests', subscription)

    @staticmethod
    async def deliver_lines(lines: asyncio.Queue[Callable[[], Awaitable[None]]]) -> None:
        while True:
            line = await lines.get()
            await line()
            lines.task_done()

    async def run(self) -> None:
        current = asyncio.current_task()
        assert current is not None
        self.stop = current.cancel
        try:
            await self.options.operation.execute(self)
        except* (BlockingIOError, SessionFailure):
            raise
        except* BRIDGE_FAILURES as group:
            failure = 'Comms bridge stopped:\n' + ''.join(
                traceback.TracebackException.from_exception(
                    group, max_group_width=sys.maxsize, max_group_depth=sys.maxsize,
                ).format()
            )
            self.log(failure)
            await self.report_failure(failure + '\nNo message was retried.')
            raise


class CoreWatchEnded(OSError):
    """The bus read stopped for a reason other than maintenance; no message was retried."""


async def raised(error: Exception) -> None:
    raise error


@contextmanager
def core_watch_failure(lines: asyncio.Queue[Callable[[], Awaitable[None]]]) -> Iterator[None]:
    """A read failure takes its turn in the delivery line, so a delivery under way finishes
    before the group stops. A hold reaches the bus's own wait; every other failure stops the
    bridge loudly through its one report, and anything outside that family crashes."""
    try:
        yield
    except MaintenanceHeldError as held:
        lines.put_nowait(partial(raised, held))
    except BRIDGE_FAILURES as error:
        ended = CoreWatchEnded(f'Core watch ended\n{CoreError.from_exception(error).error}')
        ended.__cause__ = error
        lines.put_nowait(partial(raised, ended))


class BridgeDeliveryStore(WriterOwnedStore):
    """Every binding's delivery.sqlite3. A binding's state directory is its bridge's state
    directory joined with its bus thread (``GivenBinding.from_arguments``), so the children of
    each bridge's directory are its bindings."""

    @classmethod
    def path(cls) -> Path:
        return Path.home()

    @classmethod
    def journals(cls, files: FilesRequest) -> tuple[tuple[type[CliBridge], WriterOwnedResource], ...]:
        """Each binding's journal with the bridge member whose state directory holds it."""
        root = files.location(cls.resource(cls.retained_filename()))
        return tuple((bridge, cls.resource(cls.retained_filename() / path.relative_to(root)))
                     for bridge in cast(tuple[type[CliBridge], ...], HarnessSession.members_with(CliBridge))
                     for path in sorted((root / bridge.state_directory).glob(f"*/{BridgeStateTable.filename}")))

    @classmethod
    def resources(cls, files: FilesRequest) -> tuple[WriterOwnedResource, ...]:
        return tuple(resource for _bridge, resource in cls.journals(files))

    @classmethod
    def table_schema(cls) -> type[TableSchema]:
        return BridgeStateTable


class WatchRecordStore(ExternalStore):
    """Every session's watch claim (``WatchClaim.directory``). A claim lock holds only its
    flock; its re-arm record is published whole beside it. The lock bytes are retained so a
    copy can read what an older runtime saved in them, but a lock is never content: changing
    or restoring it would replace the inode its holder's flock lives on."""

    @classmethod
    def path(cls) -> Path:
        return WatchClaim.directory(Path.home())

    @classmethod
    def resources(cls, files: FilesRequest) -> tuple[WriterOwnedResource, ...]:
        directory = files.location(cls.resource(cls.retained_filename()))
        return tuple(cls.resource(cls.retained_filename() / claim.name)
                     for claim in WatchClaim.claims_in(directory))

    @staticmethod
    def files(path: Path) -> tuple[Path, ...]:
        return (path, WatchClaim.record_beside(path))

    @classmethod
    def content_members(cls, path: Path) -> frozenset[Path]:
        return frozenset(member for member in cls.files(path) if member.is_file())

    @classmethod
    def snapshot_members(cls, path: Path, observed: Mapping[Path, os.stat_result]) -> frozenset[Path]:
        record = WatchClaim.record_beside(path)
        return frozenset((record,)) if record in observed else frozenset()

    @classmethod
    def file_matches(cls, path: Path, name: Path, saved: Mapping[Path, str]) -> bool:
        record = WatchClaim.record_beside(path)
        retained = cls.relocated(path, name, record)
        if retained not in saved:
            return not record.exists()
        return record.is_file() and cls.digest(record) == saved[retained]

    @classmethod
    def restore_file(cls, path: Path, name: Path, directory: Path, saved: Mapping[Path, str]) -> None:
        record = WatchClaim.record_beside(path)
        retained = cls.relocated(path, name, record)
        if retained in saved:
            cls._restore_member(directory / retained, record)
        else:
            record.unlink(missing_ok=True)
        Platform.current().sync_directory(path.parent)


class TranscriptBridge(PublishesToBus, CliBridge[BridgeOptions]):
    """A CLI with an event subscription also publishes whole transcript items."""

    @property
    def transcript_thread(self) -> str:
        return self.binding.bus


WireReference = InstanceOf[
    Annotated[
        MessageReference,
        PlainValidator(partial(FieldCodec.decode, MessageReference)),
        PlainSerializer(FieldCodec.encode),
    ]
]
"""A message reference on our wire lines, in the one spelling FieldCodec gives it."""


class MonitorFrame(TaggedWire, ABC, affix=""):
    """Our line protocol inside the harness's task-notification envelope."""
    async def confirm(
        self, bridge: TranscriptConfirmsDelivery, record: ObservedMonitor,
    ) -> tuple[MessageReference, ...]:
        return ()

    def delivered(self) -> tuple[MessageReference, ...]:
        """The bus messages this frame put in front of the model; only a message carries one."""
        return ()

    def continued(
        self, line: str, decode: Callable[[str], MonitorFrame],
    ) -> tuple[MonitorFrame, ...]:
        """This frame and the next line of its event; only a frame with a body takes the line."""
        return self, decode(line)


class MonitorProtocolFrame(MonitorFrame, declared_name=None):
    """A line the monitor writes itself; the transcript scan knows it by its protocol prefix."""
    protocol: Literal['agent-comms-monitor'] = 'agent-comms-monitor'
    wire_prefix: ClassVar[str] = '{"protocol":' + json.dumps(protocol) + ','

    def emit(self) -> None:
        sys.stdout.write(self.model_dump_json() + '\n')
        sys.stdout.flush()


class MonitorProbe(MonitorProtocolFrame, declared_name='probe'):
    session: str
    token: str

    async def confirm(self, bridge: TranscriptConfirmsDelivery, record: ObservedMonitor) -> tuple[MessageReference, ...]:
        await bridge.confirm_probe(self)
        return ()


class MonitorReadFile(MonitorProtocolFrame, declared_name='read-file'):
    """The one bounded event for a message no single Monitor event holds.

    Claude cuts each event line at 500 UTF-16 units and flushes a joined batch after 200 ms,
    so a message spread over several lines can reach the model in pieces, one turn apart.
    The message is instead the private file this notice names, read whole. Seeing the notice
    proves only that the notice arrived; a visible Read of the file confirms the body."""

    reference: WireReference
    path: str
    instruction: Literal['This is one message. Read this complete file before acting on it.'] = (
        'This is one message. Read this complete file before acting on it.')
    reservation: ClassVar[int] = 0
    """The notice's own window reservation; body parts number from one."""

    @classmethod
    def naming(cls, directory: Path, reference: MessageReference) -> Self:
        return cls.model_validate(dict(
            reference=reference, path=str(directory / f'{reference.name}.txt')))

    @classmethod
    def exported_at(cls, directory: Path, path: str) -> tuple[Self, ...]:
        """The notice whose export is exactly this path; any other path names none."""
        try:
            reference = MessageReference.named(Path(path).name.removesuffix('.txt'))
        except field_codec.MalformedRecord:
            return ()
        notice = cls.naming(directory, reference)
        return (notice,) if notice.path == path else ()

    @contextmanager
    def directory(self) -> Iterator[int]:
        """The export directory, checked private and pinned by descriptor, under trusted
        ancestors: a swapped or foreign parent refuses instead of receiving the message."""
        parent = Path(self.path).parent
        refusal = RelationViolationError(f'Message export directory {parent} is not private')
        PrivateDirectoryRole.make_parents(parent)
        TrustedAncestorRole.require_path(parent.parent, refusal)
        directory = PrivateDirectoryRole.read(parent, refusal)
        try:
            yield directory
        finally:
            os.close(directory)

    def export(self, lines: tuple[str, ...]) -> None:
        """Publish the message's lines once. A file already at this path must
        hold exactly these bytes: the bus message stays the source, never the file."""
        data = ''.join(line + '\n' for line in lines).encode()
        path = Path(self.path)
        refusal = RelationViolationError(f'Message export {path} is not this message')
        with self.directory() as directory:
            try:
                ExclusiveDirectoryAtomicFile(path, directory=directory).write_bytes(data)
            except FileExistsError:
                with os.fdopen(PrivateFileRole.read(path.name, refusal, dir_fd=directory),
                               'rb') as existing:
                    if existing.read() != data:
                        raise refusal from None

    def retire(self) -> None:
        """A consumed body's export is evidence nobody reads again."""
        with self.directory() as directory, suppress(FileNotFoundError):
            os.unlink(Path(self.path).name, dir_fd=directory)

    def delivered(self) -> tuple[MessageReference, ...]:
        return (self.reference,)

    async def confirm(self, bridge: TranscriptConfirmsDelivery, record: ObservedMonitor) -> tuple[MessageReference, ...]:
        """The notice frees only its own reservation; it confirms no body."""
        await bridge.part_observed(self.reference.message_id, self.reservation)
        return ()


class MonitorBridgeStopped(MonitorProtocolFrame, declared_name='bridge-stopped'):
    """The reader's notice that no bridge holds its claim, so nothing is delivered until one starts."""
    notice: str

    @classmethod
    def announce(cls, claim: WatchClaim) -> None:
        """One Monitor event: the bridge is gone, so nothing arrives until it starts again."""
        stopped = cls(notice=(
            'Comms bridge stopped: no messages are delivered until it starts again. '
            f'{claim.path.with_suffix(".log")} names why; '
            'agent-comms-claude-bridge connect restarts it and this Monitor resumes.'))
        stopped.emit()


class MonitorBridgeSwapping(MonitorProtocolFrame, declared_name='bridge-swapping'):
    notice: str

    @classmethod
    def announce(cls, claim: WatchClaim) -> None:
        cls(notice=(
            f'Waiting for the session bridge of {claim.thread}: '
            'an install holds its claim and is replacing it.'
        )).emit()


class MonitorPart(MonitorFrame, declared_name='part'):
    id: InstanceOf[
        Annotated[
            MessageId,
            PlainValidator(partial(FieldCodec.decode, MessageId)),
            PlainSerializer(FieldCodec.encode),
        ]
    ]
    sender: str
    number: int = Field(ge=1)
    total: int = Field(ge=1)
    body: str

    @model_validator(mode='after')
    def valid_number(self):
        if self.number > self.total:
            raise ValueError('Monitor part number exceeds total')
        return self

    async def confirm(self, bridge: TranscriptConfirmsDelivery, record: ObservedMonitor) -> tuple[MessageReference, ...]:
        """The whole confirmation (attempt read, observed parts, mismatch, final outcome) is one
        contention boundary: a busy coordinator cannot tear down the monitor mid-confirmation."""
        references: list[MessageReference] = []
        with bridge.uncertain_on_contention(self.id):
            for delivery in await bridge.attempts(self.id):
                references.extend(await delivery.monitor.confirm(bridge, delivery, self, record))
        return tuple(references)


class ForeignMonitorFrame(MonitorFrame, declared_name='foreign'):
    text: str


MONITOR_FRAME = WireModel.adapter(MonitorFrame.declared_union())


@dataclass(frozen=True)
class DeliveredInput(RuntimeUpdate):
    """The observed original references, bound by their source turn."""

    references: tuple[MessageReference, ...] = field(default=(), kw_only=True)
    source_turn: SourceTurn = field(default_factory=NoSourceTurn, kw_only=True)

    def publish(self, output: ThreadOutput) -> None:
        output.delivered(self.source_turn.require_id(), self.references)

    async def observed(self, bridge: TranscriptBridge) -> DeliveredInput:
        return self


class ConfirmedDelivery(DeliveredInput):
    """An observation confirmed through the session's monitor protocol."""

    async def observed(self, bridge: TranscriptBridge) -> ConfirmedDelivery:
        return await bridge.confirm_delivery(self)

    @abstractmethod
    async def confirmed_by(self, bridge: TranscriptConfirmsDelivery) -> ConfirmedDelivery:
        """This observation with the original references its delivery confirms."""


@dataclass(frozen=True)
class BridgeInputObserved(DeliveredInput, HiddenItem):
    """A harness echoes our exact client input in its own ordered transcript."""

    message_id: MessageId
    text: str

    async def observed(self, bridge: TranscriptBridge) -> DeliveredInput:
        attempts = await bridge.attempts(self.message_id)
        if not attempts:
            raise RelationViolationError("Observed bus input has no original delivery attempt")
        references: list[MessageReference] = []
        for delivery in attempts:
            message = await bridge.message(delivery.reference)
            if self.text != IncomingFrame(message).text:
                raise RelationViolationError("Observed bus input differs from its original delivery")
            await bridge.finish(delivery, partial(replace, outcome=DeliveredOutcome))
            references.extend(message.opening_references(bridge.transcript_thread))
        return replace(self, references=tuple(references))


@dataclass(frozen=True)
class MonitorObservation(ConfirmedDelivery):
    frame: MonitorFrame
    record: ObservedMonitor

    async def confirmed_by(self, bridge: TranscriptConfirmsDelivery) -> ConfirmedDelivery:
        return replace(self, references=await self.frame.confirm(bridge, self.record))


class TranscriptConfirmsDelivery(PublishesToBus, HarnessDeliveryRecords):
    """Delivery is confirmed only by observing it in the route's own transcript subscription:
    a bridge reading the session's file and a watch socket receiving its lines confirm alike."""

    async def confirm_delivery(self, update: ConfirmedDelivery) -> ConfirmedDelivery:
        return await update.confirmed_by(self)

    async def observe_part(self, delivery: HarnessDelivery, notification: MonitorPart,
                           record: ObservedMonitor) -> tuple[HarnessObservedPart, ...]:
        """Record one transcript part as observed; every observed part of its message, in order."""
        part = HarnessObservedPart(delivery.bridge, delivery.recipient_lookup, delivery.message_id,
                                   notification.number, notification.sender, notification.body,
                                   record.record_id, record.timestamp)

        def observe(assignments: AssignmentStore, db: sqlite3.Connection) -> tuple[HarnessObservedPart, ...]:
            part.insert_if_absent(db)
            return HarnessObservedPart.of(db, delivery)
        parts = await self.coordinator_write(observe)
        await self.part_observed(delivery.message_id, notification.number)
        return parts

    async def record_mismatch(self, delivery: HarnessDelivery, reason: str) -> None:
        await self.coordinator_write(
            partial(delivery.apply, partial(replace, monitor=MismatchedMonitor(reason))))
        self.log(f'Monitor parts mismatch; message remains pending: {delivery.message_id}')

    async def part_observed(self, message_id: MessageId, number: int) -> None:
        """Only a route that holds a window frees part of it."""

    async def confirm_probe(self, probe: MonitorProbe) -> None:
        """Only a bridge that sent a probe waits on one; an old probe in a replayed window is
        history."""

    incoming_frame: ClassVar[type[MonitorIncomingFrame]]

    def exported(self, path: str) -> tuple[MonitorReadFile, ...]:
        """The notice whose export a Read showed; a route that exported no file names none."""
        return ()

    async def retire_read(self, exact: HarnessDelivery, read: ReadResultObserved,
                          notice: MonitorReadFile) -> None:
        """A route that does not hold the export leaves it where it is."""

    async def read_export(self, read: ReadResultObserved) -> tuple[MessageReference, ...]:
        """A visible Read of this session's own export confirms the parts it shows, through the
        same all-parts gate a Monitor event uses. The export names an exact reference: only the
        attempt at that reference takes its parts, so a file at another sequence with the same
        message id confirms nothing. The parts are judged against the bus message, never the
        file: a read showing anything but the original's own lines confirms nothing."""
        references: list[MessageReference] = []
        for notice in self.exported(read.path):
            identity = notice.reference.message_id
            rows = read.rows()
            with self.uncertain_on_contention(identity):
                for exact in (attempt for attempt in await self.attempts(identity)
                              if attempt.reference == notice.reference):
                    message = await self.message(exact.reference)
                    for part in self.incoming_frame(message).read_parts(rows):
                        references.extend(await part.confirm(self, read.record))
                    await self.retire_read(exact, read, notice)
        return tuple(references)


class MonitorIncomingFrame(IncomingFrame):
    @property
    @abstractmethod
    def parts(self) -> tuple[str, ...]: ...

    def shown_evidence(self, ledger: TakingLedger) -> MonitorEvidence:
        """What an attempt waits for, under the ledger that took it: every part, whether one
        event shows the message whole or a Read of its export shows its slices."""
        return ledger.receiving(len(self.parts))

    @abstractmethod
    async def emit_to(self, attachment: MonitorAttachment, window_bytes: int, exports: Path) -> None:
        """Put the whole message on the reader as one event."""

    @abstractmethod
    def read_parts(self, rows: tuple[tuple[int, str], ...]) -> tuple[MonitorPart, ...]:
        """The parts a visible Read of this message's export showed."""


class LineMonitorBridge(TranscriptConfirmsDelivery, TranscriptBridge[Options]):
    """Session-owned subscription and delivery journal, with replaceable readers."""

    output_type: ClassVar[type[ThreadOutput]] = ReplyingThreadOutput
    window_bytes: ClassVar[int]

    def __init__(self, options: Options, address: SessionBinding, db: sqlite3.Connection) -> None:
        super().__init__(options, address, db)
        self.reader: ReaderState = NoReader()
        self.reader_changed = asyncio.Condition()
        self.retirement: BridgeExit = BridgeExit()

    async def declare_reader(self, status: ThreadStatus) -> None:
        await self.comms.bus.when_open(lambda: self.comms.registry.register(
            self.comms.registry.require(self.binding.bus), status))

    def watch_record(self, binding: SessionBinding) -> WatchRecord:
        command = (str(Path(sys.argv[0]).absolute()), Watch.command_name(),
                   '--state', str(self.options.state.absolute()))
        return WatchRecord(binding.bus, binding.root, command, self.options.base_state)

    async def watch_operation(self, operation: Watch) -> None:
        await read_monitor(
            WatchClaim(self.binding.thread), MonitorBridgeStopped.announce,
            MonitorBridgeSwapping.announce, Serve.relaunch,
        )

    async def accept(self, message: Message) -> None:
        try:
            await super().accept(message)
        except (BrokenPipeError, ConnectionResetError) as error:
            await self.report_failure(
                f'Monitor failed during {message.message_id}: {error}; '
                'the recorded attempt stays uncertain and will not be replayed.')

    async def prepare_delivery(self) -> None:
        await super().prepare_delivery()
        await self.reader.prepare_delivery(self)

    async def confirm_probe(self, probe: MonitorProbe) -> None:
        await self.reader.confirm_probe(self, probe)

    async def part_observed(self, message_id: MessageId, number: int) -> None:
        await self.reader.part_observed(message_id, number)

    @staticmethod
    def encode(text: str) -> str:
        # One reversible JSON string per line; no truncation or lost line breaks.
        return json.dumps(text, ensure_ascii=False)

    @property
    def exports(self) -> Path:
        """Where this session's messages too large for one event are read whole."""
        return self.options.state.absolute() / 'messages'

    def exported(self, path: str) -> tuple[MonitorReadFile, ...]:
        """Only this session's own export directory holds a file this bridge wrote."""
        return MonitorReadFile.exported_at(self.exports, path)

    async def retire_read(self, exact: HarnessDelivery, read: ReadResultObserved,
                          notice: MonitorReadFile) -> None:
        """The export goes once its attempt, reread, is consumed and no other Read of it is
        still running."""
        for unread in read.closing(notice):
            for stored in await self.coordinator_read(exact.stored):
                stored.monitor.finished_with(unread)

    def new_attachment(self, peer: MonitorPeer, token: str) -> MonitorAttachment:
        return MonitorAttachment(peer, MonitorProbe(session=self.binding.thread, token=token))

    async def deliver(self, message: Message) -> type[Outcome]:
        return await self.reader.deliver(self, message)

    async def deliver_to(self, attachment: MonitorAttachment, message: Message) -> type[Outcome]:
        frame = self.incoming_frame(message)
        receiving = partial(replace, monitor=frame.shown_evidence(TakingLedger()))
        attempt = self.attempt(message, UnconfirmedOutcome)
        await self.coordinator_write(partial(attempt.apply, receiving))
        await frame.emit_to(attachment, self.window_bytes, self.exports)
        return EmittedOutcome

    async def show_sent(self, result: SendResult) -> None:
        print(self.encode(self.sent_text(result)), flush=True)


def run_bridge(bridge_type: type[CliBridge[BridgeOptions]], options: BridgeOptions) -> None:
    sys.stderr = BridgeLog(sys.stderr)
    os.umask(0o077)
    try:
        with Binding.open(options.state) as db, asyncio.Runner() as runner:
            bridge = bridge_type(options, options.binding.bind(db), db)
            runner.run(options.operation.prepare(bridge))
            with suppress(asyncio.CancelledError):
                runner.run(bridge.run())
        options.operation.retired(bridge)
    except* BlockingIOError:
        sys.exit('Another watcher owns this conversation')
    except* SessionFailure as failure:
        sys.exit('\n'.join(str(error) for error in failure.exceptions))
