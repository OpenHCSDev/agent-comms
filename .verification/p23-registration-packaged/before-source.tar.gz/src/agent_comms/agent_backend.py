"""Agent runtimes behind one interface: the AgentBackend family and its records.

A thread names its backend (``Thread.backend``). Core asks that backend for
everything that touches the agent runtime -- running turns, steering, context
size, compaction, history, forks, model choice and crash recovery -- and only
ever sees the records declared here. A backend converts its runtime's own
types to these records; no consumer outside a backend reads runtime types.

Capabilities are mixin roles composed through the MRO. Thread-serving backends
inherit ``ThreadServingBackend``; new-thread selection uses ``NewThreadBackend``.
Their inherited abstract methods enforce the required behavior. Sealing binds
each concrete backend to its location and freezes the registry.

This module is deliberately light: it is imported by ``threads`` and must not
import any runtime implementation at module level.
"""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import TYPE_CHECKING, ClassVar, Self

from agent_comms.execution.history_view import OwnHistory
from agent_comms.execution.native_input_proof import NativeContextProof
from agent_comms.execution.pi_commands import NativeQuery
from agent_comms.execution.pi_vocabulary import CompactionReason
from agent_comms.execution.session_revision import NoSessionObservation, SessionObservation
from agent_comms.execution.turn_inbox import InputContent
from agent_comms.execution.turn_outcome import TurnOutcome
from agent_comms.nominal.declared_family import DeclaredFamily
from agent_comms.nominal.field_codec import AcpSessionId, InputId
from agent_comms.pi_counts import PiCount
from agent_comms.pi_payloads import PiResponseData
from agent_comms.registry.thread_model import ThreadModel, UndeclaredModel
from agent_comms.team.rule_deal import DealDelivery
from agent_comms.transport.tool_result import DeclaredReply

if TYPE_CHECKING:
    from agent_comms.execution.agent_event import AgentEvent
    from agent_comms.execution.launch_runtime import LaunchRuntime
    from agent_comms.execution.owned_turn import TurnDelivery
    from agent_comms.execution.transcript_sources import TranscriptSource
    from agent_comms.execution.turn_runner import TurnRunner
    from agent_comms.registry.threads import Thread


class BackendDeclarationError(TypeError):
    """A backend declaration is incomplete; the message names every missing piece."""


class RuntimeLocation(DeclaredFamily, affix="Runtime"):
    """Runtime behavior derived once by the owning thread record."""

    path: str
    _backend: ClassVar[type[AgentBackend]]
    resumable: ClassVar[bool] = True

    @property
    def backend(self):
        return self._backend

    def require_forkable(self):
        pass

    def last_written(self) -> float:
        """When the native transcript last grew; one never written grew at the epoch."""
        transcript = Path(self.path)
        return transcript.stat().st_mtime if transcript.exists() else 0.0

    async def compact(self, operation):
        return await operation()

    def new_location(self, root, worktree):
        return self

    def arguments(self):
        return {"session_file": self.read_key}

    def read_keys(self):
        return (self.read_key,)

    def transcript_cursor(self, frontier, cut, *, source):
        return frontier.cursor(source.read_key, cut.offset, file=cut.file_identity())

    def history_locations(self, thread, registry, visited):
        yield self, OwnHistory()
        yield from thread.inherited_history(registry, visited)

    def view_from_fork(self, view, fork_birth):
        """A saved session holds its owner's records, so a fork sees them only up to the fork."""
        return view.seen_from_fork(fork_birth)

    def external_records(self, root, incarnation):
        raise ValueError("A native session cannot publish an external transcript")

    def select_session(self, directory, execution, source_reads, *, participant):
        raise BackendDeclarationError('Runtime cannot select native sessions')

    @abstractmethod
    def history_source(self, root, incarnation) -> TranscriptSource: ...

    def imported_sources(self):
        return ()

    @property
    def read_key(self) -> str:
        return self.path

    @abstractmethod
    def storage_files(self): ...

    def session_observation(self, root: Path, thread: Thread) -> SessionObservation:
        return NoSessionObservation()

    def deal_delivery(self) -> DealDelivery:
        """How a session on this runtime receives its deal: through the strongest channel its
        launcher has. A runtime whose launcher puts nothing in the system prompt reads it."""
        return DealDelivery()

    @property
    def saved_model(self) -> ThreadModel:
        """A runtime without a saved session file selects no model."""
        return UndeclaredModel()


# ---------------------------------------------------------------------------
# Records Core owns. Every backend converts its runtime's values to these.
# ---------------------------------------------------------------------------


class CompactionOutcome(DeclaredFamily, DeclaredReply, TurnOutcome, affix="Compaction"):
    """The result of one requested compaction."""

    def completion_event[T](self, end: Callable[..., T], abort: Callable[..., T],
                            reason: type[CompactionReason]) -> T:
        return abort(reason=reason)


@dataclass(frozen=True)
class PlacedCompaction(CompactionOutcome):
    """A summary now replaces the entries Pi's compaction entry names."""

    summary: str
    tokens_before: PiCount

    def completion_event[T](self, end: Callable[..., T], abort: Callable[..., T],
                            reason: type[CompactionReason]) -> T:
        return end(reason=reason)


@dataclass(frozen=True)
class NothingToCompaction(CompactionOutcome):
    """There was nothing to summarize."""


@dataclass(frozen=True)
class FailedCompaction(CompactionOutcome):
    """The runtime refused or failed; ``message`` is its text, unchanged."""

    message: str


@dataclass(frozen=True)
class StaleCompaction(CompactionOutcome):
    """The transcript moved past the summary's cut before it was placed."""


# ---------------------------------------------------------------------------
# Capability roles.
# ---------------------------------------------------------------------------


class InputStartListener(ABC):
    """The listener owns acknowledgement and the corresponding start notification."""

    started_events: tuple[AgentEvent, ...]

    @abstractmethod
    def original(self, native_id: InputId, text: str) -> bool: ...

    @abstractmethod
    def following(self, public_id: InputId, native_id: InputId, text: str) -> bool: ...

    async def original_context_committed(self, sent_text: str, context: NativeContextProof) -> None:
        """An unowned input has no durable ordinary disposition to acknowledge."""
        return None

    async def following_context_committed(
        self,
        public_id: InputId,
        sent_text: str,
        context: NativeContextProof,
    ) -> None:
        """An unowned following input has no durable ordinary disposition."""
        return None


class NoInputStartListener(InputStartListener):
    started_events = ()

    def original(self, native_id: InputId, text: str) -> bool:
        return True

    def following(self, public_id: InputId, native_id: InputId, text: str) -> bool:
        return True


NO_INPUT_START_LISTENER = NoInputStartListener()


class RunsTurns(ABC):
    """Runs one input to settlement and reports what happened as AgentEvents.

    The final event of a turn is ``agent_events.Done``.
    """

    @abstractmethod
    def run_turn(
        self, thread: Thread, content: InputContent, delivery: TurnDelivery
    ) -> AsyncIterator[AgentEvent]:
        """Run ``content`` as ``thread``'s next input and yield its events."""

    @abstractmethod
    async def abort[Result](self, owner: asyncio.Task[Result]) -> None:
        """Stop the runtime work owned by this turn task."""

    @abstractmethod
    async def close_idle(self) -> None:
        """Retire the runtime process this backend holds once no turn is using it."""


class Steers(RunsTurns):
    """Accepts :class:`InputRequest` with ``SteerInputPolicy`` while a run is going."""


class Interrupts(Steers):
    """Accepts :class:`SendNow`: ends the current tool round and places queued steers now."""


class Compacts(ABC):
    """The backend owns when and how to compact. Core only asks for a manual one."""

    @abstractmethod
    async def compact(self, thread: Thread, instructions: str | None) -> CompactionOutcome:
        """Compact ``thread`` now, guided by ``instructions``."""


class Forks(ABC):
    """Creates a child runtime location from a parent thread's history."""

    @classmethod
    @abstractmethod
    async def fork(
        cls, parent: Thread, launcher: str, runtime: LaunchRuntime, root: Path,
    ) -> RuntimeLocation:
        """Copy ``parent``'s history into a new location for a child thread under ``root``.

        ``runtime`` is the same selected installation that will start the child.
        """


# ---------------------------------------------------------------------------
# The family.
# ---------------------------------------------------------------------------


class AgentBackend(DeclaredFamily, affix="Backend"):
    """One agent runtime, keyed by ``declared_name`` ("pi_native", ...).

    A backend declares its location type, capabilities through inheritance,
    and the event kinds its runtime protocol emits. One
    instance holds one thread session's runtime process.
    """

    location_type: ClassVar[type[RuntimeLocation]]
    event_kinds: ClassVar[frozenset[str]]
    _sealed: ClassVar[bool] = False

    async def context_for_input(self, thread, context):
        return context

    async def abort[Result](self, owner: asyncio.Task[Result]) -> None:
        """Backends without RunsTurns have no turn work to interrupt."""

    async def close_idle(self) -> None:
        """A backend without a retained process has nothing to retire."""

    async def inspect(self, thread: Thread, request: NativeQuery) -> PiResponseData:
        """A runtime without native queries refuses this capability explicitly."""
        raise BackendDeclarationError(f"{type(self).__name__} does not support native inspection")

    def __init_subclass__(cls, **options: str | None) -> None:
        if AgentBackend._sealed:
            raise BackendDeclarationError(
                f"{cls.__name__}: the AgentBackend registry is sealed; declare backends "
                "before the Thread backend lookup seals its declarations."
            )
        super().__init_subclass__(**options)

    @classmethod
    @abstractmethod
    def for_worker(cls, runner: TurnRunner, session_id: AcpSessionId) -> Self:
        """An instance holding this runtime for one thread session in this worker."""

    @classmethod
    @abstractmethod
    def new_location(cls, root, worktree) -> RuntimeLocation: ...

    @classmethod
    def seal(cls) -> None:
        """Bind concrete locations after validating all declaration relationships."""
        NewThreadBackend.selected()
        owners: dict[type[RuntimeLocation], type[AgentBackend]] = {}
        for member in cls.members_with(cls):
            location = member.location_type
            if not issubclass(location, RuntimeLocation):
                raise BackendDeclarationError(f"{member.__name__} declares no RuntimeLocation type")
            if previous := owners.get(location):
                raise BackendDeclarationError(
                    f"location type {location.__name__} belongs to several backends "
                    f"{previous.__name__}, {member.__name__}")
            owners[location] = member
        for location, owner in owners.items():
            location._backend = owner
        AgentBackend.__registry__ = MappingProxyType(dict(AgentBackend.__registry__))  # type: ignore[assignment]
        AgentBackend._sealed = True

    def run_turn(self, thread: Thread, content: InputContent, delivery: TurnDelivery):
        raise BackendDeclarationError(f"{type(self).__name__} does not run turns")

    @classmethod
    def require_event_family(cls, family: type[DeclaredFamily]) -> None:
        """Fail unless ``family`` converts exactly the event kinds this backend's runtime emits."""
        problems = _event_family_problems(cls, family)
        if problems:
            raise BackendDeclarationError(f"{cls.__name__}: " + "; ".join(problems))


def _event_family_problems(backend: type, family: type[DeclaredFamily]) -> list[str]:
    declared = {kind for member in family.members_with(family) for kind in member.known_kinds()}
    expected = backend.event_kinds
    problems = []
    if missing := sorted(expected - declared):
        problems.append(f"{family.__name__} has no converter for event kinds {missing}")
    if extra := sorted(declared - expected):
        problems.append(f"{family.__name__} converts event kinds the runtime never emits {extra}")
    return problems


class ThreadServingBackend(Steers, Compacts, AgentBackend, declared_name=None):
    """A thread backend implements steering, turn lifecycle and compaction together.

    The capability bases precede AgentBackend so its non-thread turn refusal
    cannot satisfy the abstract turn contract.
    """


class NewThreadBackend(ThreadServingBackend, declared_name=None):
    """The complete thread backend selected for newly registered threads."""

    @classmethod
    def selected(cls) -> type[Self]:
        members = cls.members_with(cls)
        if len(members) != 1:
            raise BackendDeclarationError(
                f"exactly one backend must serve new threads, found "
                f"{[member.__name__ for member in members]}")
        return members[0]
