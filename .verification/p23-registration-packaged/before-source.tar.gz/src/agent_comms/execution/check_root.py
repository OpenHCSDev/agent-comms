"""A selected, disposable comms root; source readers never grant execution."""

from __future__ import annotations

import os
import subprocess
from collections.abc import Iterator, Sequence
from contextlib import closing, contextmanager
from dataclasses import dataclass, replace
from itertools import islice
from pathlib import Path
from typing import ClassVar

from agent_comms.cli_verbs.cli_result import CliResult
from agent_comms.comms import Comms, wire
from agent_comms.coordination.attempt_recovery import RecoveryMonitorCapability
from agent_comms.coordination.cohort_schema import AcceptanceFrontier
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.database import CoordinationStore
from agent_comms.execution.fresh_private_session import create_fresh_private_session
from agent_comms.execution.launch_root import LaunchRoot
from agent_comms.execution.launch_runtime import ThreadLaunch
from agent_comms.execution.native_entries import ImportedSessionWriter, NativeEntry
from agent_comms.execution.native_session_files import CheckSession
from agent_comms.execution.session_file import RegistrySessionLocation
from agent_comms.execution.transcript_routes import TranscriptRoutes
from agent_comms.execution.turn_lease import NoTurnRecord
from agent_comms.messaging.bus import Bus
from agent_comms.messaging.read_basis import MemberActivityDisplayScope
from agent_comms.planning.goals import NoGoal
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.roster_visibility import RosterVisibility
from agent_comms.registry.thread_text import NoThreadText
from agent_comms.registry.threads import Thread


@dataclass(frozen=True)
class CheckRootResult(CliResult):
    return_code: int

    def exit_code(self) -> int:
        return self.return_code


@dataclass(frozen=True)
class CheckRoot:
    """Own one check's selected history, workers and directory through its exit.

    The command receives the directory through an explicit ``{root}`` argument,
    never an environment setting. It must not exist before entry. Old turns,
    goals, deliveries and process identities do not travel with the history.
    """

    source: Comms
    threads: tuple[str, ...]
    into: Path
    max_bytes: ClassVar[int] = 1024 * 1024
    max_records: ClassVar[int] = 200

    def create(self) -> Comms:
        """Create selected stopped history; its caller owns retention and retirement.

        Physical acceptance retains failed/UNKNOWN evidence. Disposable command
        checks use ``open`` below; both acquire history through this same owner.
        """
        root = self.into.expanduser().absolute()
        if not self.threads:
            raise ValueError("A check root needs at least one named thread")
        scratch = self.source.registry.storage_rule.scratch_base.resolve()
        if (
            not root.resolve().is_relative_to(scratch)
            or len(root.resolve().relative_to(scratch).parts) < 2
        ):
            raise ValueError("A check root belongs under the caller's agent-scratch directory")
        if root.resolve().is_relative_to(self.source.root.resolve()):
            raise ValueError("A check root cannot be inside its source")
        root.mkdir(mode=0o700, parents=True)  # Refuse an existing directory, including a symlink.
        try:
            self.source.registry.storage_rule.prepare_isolated(root)
            copied = wire(root)
            self._populate(copied)
        except BaseException:
            RecoveryMonitorCapability.retire_check_root(root)
            raise
        return copied

    @contextmanager
    def open(self) -> Iterator[Comms]:
        copied = self.create()
        try:
            try:
                yield copied
            finally:
                for thread in copied.registry.snapshot().visible_threads(
                    RosterVisibility(archived=True)
                ):
                    copied.owners.stop(thread.name)
        finally:
            RecoveryMonitorCapability.retire_check_root(copied.root)

    def _populate(self, copied: Comms) -> None:
        snapshot = self.source.registry.snapshot()
        names = tuple(dict.fromkeys(snapshot.require(name).name for name in self.threads))
        selected = frozenset(names)
        catalog = self.source.channels.catalog.read()
        aliases = frozenset(alias for alias, name in snapshot.aliases.items() if name in selected)
        targets = frozenset(
            target for name in names for target in catalog.targets_for(snapshot.require(name).tags)
        )
        scope = MemberActivityDisplayScope("#check", targets, participant_names=selected | aliases)
        with self.source.bus.bus.reading() as source:
            messages = scope.history(source, limit=self.max_records)
        copied.registry.store.prepare_native_root()
        storage = copied.registry.storage_rule
        Bus.install(Bus.path_in(copied.root), history=messages)
        copied.channels.catalog.replace(catalog)
        declarations = {}
        for name in names:
            original = snapshot.require(name)
            slot = original.incarnation.require_recorded().lookup
            project = copied.root / "projects" / slot
            project.mkdir(parents=True, mode=0o700)
            session = self._session(original, copied.root, slot, project)
            declarations[name] = replace(
                original.without_process(),
                worktree=Checkout(project),
                parent=original.parent.kept_in(selected),
                task=NoThreadText(),
                goal=NoGoal(),
                session_file=RegistrySessionLocation.from_path(session, copied.root),
                earlier_projects=(),
                project_resume_due=False,
                storage_roots=storage.initial_roots(slot),
                # A fresh turn history: a finished turn refuses generation 0.
                turn_record=NoTurnRecord(),
                turn_generation=0,
            )
        with copied.registry.store.editing() as edit:
            edit.restore_stopped(snapshot, names)
            edit.document.threads.update(declarations)
            # Old messages can name people outside the selected workers. Keep
            # only their deleted-name record, never their sessions or authority.
            for name in snapshot.known_names:
                if not edit.document.taken(name):
                    edit.document.advance_claim(name)
                    edit.document.owners.advance(name)
            edit.commit()
        if messages:
            # Imported history is displayable, not fresh input for this root.
            # Position acceptance itself; human read markers own a different fact.
            privacy = copied.registry.store.privacy()
            with Coordination(str(CoordinationStore.path_in(copied.root))) as store:
                with store.session.writing() as db:
                    for thread in declarations.values():
                        AcceptanceFrontier(
                            wire_root_id=privacy.namespace,
                            recipient_lookup=thread.incarnation.require_recorded().lookup,
                            through_seq=messages[-1].seq,
                        ).advance(db)

    def _session(self, original: Thread, root: Path, slot: str, project: Path) -> str:
        session = create_fresh_private_session(root, worktree=project, location=CheckSession, slot=slot)
        source = original.runtime.history_source(self.source.root, original.incarnation)
        with source.reading() as reader, session.path.open("r+") as output:
            writer = ImportedSessionWriter(output, NativeEntry.read(output.readline().encode()))
            output.seek(0, os.SEEK_END)
            cut = reader.cut()
            if reader.has_records(cut.offset):
                selected, used = [], 0
                with closing(reader.reverse(cut.offset)) as records:
                    for record in islice(records, self.max_records):
                        if used + record.size > self.max_bytes:
                            break
                        selected.append(record)
                        used += record.size
                with source.projection(
                    source, TranscriptRoutes(self.source.root)
                ) as project_records:
                    for _record, events in project_records(
                        iter(reversed(selected)),
                        max_records=self.max_records,
                        max_bytes=self.max_bytes,
                    ):
                        for event in events:
                            writer.append_recorded(event)
        return session.session_file

    def run(self, command: Sequence[str]) -> CheckRootResult:
        command = tuple(command)
        if command[:1] == ("--",):
            command = command[1:]
        if not command or "{root}" not in command:
            raise ValueError("check-root needs -- COMMAND with an explicit {root} argument")
        environment = ThreadLaunch.strip(dict(os.environ))
        environment = LaunchRoot.environment(environment)
        with self.open() as copied:
            arguments = tuple(argument.replace("{root}", str(copied.root)) for argument in command)
            return CheckRootResult(
                subprocess.run(arguments, cwd=copied.root, env=environment).returncode
            )
