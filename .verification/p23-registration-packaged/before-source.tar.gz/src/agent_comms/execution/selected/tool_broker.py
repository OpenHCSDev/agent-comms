"""Default-off, one-slot owner boundary for a selected Pi tool request.

The model supplies only a relative existing-file resource and UTF-8 replacement
text. The owner supplies the identities and permission checks; neither a prompt nor
a socket message can authorize a wake. Consumption is durable before any
claim append or file mutation, and UNKNOWN is never retried automatically.
"""

from __future__ import annotations

import logging
import sqlite3
import stat
from collections.abc import Callable
from dataclasses import (
    dataclass,
    field,
)
from functools import partial
from pathlib import Path
from typing import ClassVar

from agent_comms.comms import Comms
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.errors import (
    CoordinationBeginUnavailable,
    CoordinationReadUnavailable,
)
from agent_comms.coordination.session import ReadNativeCoordinationSession
from agent_comms.coordination.tables.participants import OwnerGenerations
from agent_comms.execution.native_input_record import (
    FullNativeExecution,
    NativeInputIdentity,
)
from agent_comms.execution.native_runtime_input import (
    NativeRuntimeInput,
    NativeRuntimeTable,
    SelectedToolSlot,
)
from agent_comms.execution.selected.actions import SelectedAction
from agent_comms.execution.selected.claim import (
    publish_selected_resource_claim,
    write_selected_claimed_file,
)
from agent_comms.execution.turn_context import InstructionFile
from agent_comms.messaging.envelope_claim_transitions import (
    ExistingFileClaim,
    WakeClaim,
)
from agent_comms.nominal.field_codec import (
    FieldCodec,
    InputId,
    MalformedRecord,
    SlotId,
    ToolCallId,
)
from agent_comms.team.pi_rule_gate import PiRuleGate
from agent_comms.transport.native_tool_call import (
    NativeToolCall,
    SelectedToolBusy,
)
from agent_comms.transport.native_tool_transport import (
    GatedToolTransport,
    NativeToolMode,
    NativeToolRound,
    ToolListener,
    UnboundToolTransport,
)
from agent_comms.transport.tool_denial import SelectedToolDenied

# Stay well below the existing native RPC record cap (1 MiB, including JSON).
_MAX_CONTENT = 128 * 1024


_MAX_REQUEST = _MAX_CONTENT + 8192


_TOOL_SOURCE = Path(__file__).with_name("selected_claimed_write.mjs")


_LOG = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class SelectedToolIntent(SelectedAction):
    """Trusted, explicit pre-turn opt-in; no tool call or write authority.

    The owner must create a distinct bound SelectedToolMode only after reserving
    the exact FULL input. Do not construct this from injected/model text. It is
    the nominal owner intent itself, so no declaration may refine it.
    """

    def __init_subclass__(cls, **kwargs: object) -> None:
        raise TypeError("SelectedToolIntent is the nominal owner intent; it has no subclasses")

    @property
    def instruction_files(self) -> tuple[InstructionFile, ...]:
        return (InstructionFile.read("selected-claimed-write.md"),)

    def mode(self, owner):
        return selected_tool_mode_for_owner(
            owner.comms,
            owner.store,
            owner.resource_scope,
            owner.owner_name,
            owner.input_id,
        )


@dataclass(frozen=True, slots=True)
class SelectedToolMode(NativeToolMode):
    """Trusted owner callback, never parsed from a model call or injected text."""

    action: Callable[[int, SelectedToolRequest], None]
    gate: PiRuleGate

    def __post_init__(self) -> None:
        if not callable(self.action):
            raise TypeError("Selected tool mode requires an owner callback")

    def launch_arguments(self, package: Path) -> tuple[str, ...]:
        return (
            "--no-builtin-tools",
            "--tools",
            SelectedToolRequest.declared_name,
            "-e",
            str(selected_extension(package)),
        )

    async def open_transport(self, turn, ownership) -> UnboundToolTransport:
        return await SelectedToolSocket.open(turn, ownership, self.action, self.gate)


@dataclass(frozen=True)
class SelectedWriteArguments:
    """Model-supplied text and relative resource, validated once at ingress."""

    resource: str
    contents: str
    claim: ExistingFileClaim = field(init=False, compare=False)

    def __post_init__(self) -> None:
        if not self.resource or len(self.resource.encode("utf-8")) > 4096:
            raise SelectedToolDenied("Selected tool resource is not bounded")
        path = Path(self.resource)
        if (
            not path.parts
            or path.is_absolute()
            or ".." in path.parts
            or self.resource.startswith(("@", "./"))
        ):
            raise SelectedToolDenied("Selected tool resource must be relative without aliases")
        object.__setattr__(self, "claim", ExistingFileClaim(path))
        if len(self.contents.encode("utf-8", errors="strict")) > _MAX_CONTENT:
            raise SelectedToolDenied("Selected tool contents exceed 128 KiB")


@dataclass(frozen=True)
class SelectedToolRequest(NativeToolCall):
    arguments: SelectedWriteArguments

    declared_name: ClassVar[str] = "selected_claimed_write"

    def commit_terminal(
        self, is_error: bool, coordination_path: Path, input_id: InputId, round_number: int
    ) -> None:
        if is_error:
            raise SelectedToolDenied("Native Pi selected tool did not finish successfully")
        verify_selected_terminal(coordination_path, self.slot(input_id, round_number), self.call_id)

    def claim_failed(self) -> None:
        raise SelectedToolDenied("Native Pi selected tool claim_scope failed; outcome UNKNOWN")


@dataclass(frozen=True)
class SelectedToolEnvelope:
    token: str
    request: SelectedToolRequest

    def authenticate(self, expected_token: str) -> SelectedToolRequest:
        if self.token != expected_token:
            raise SelectedToolDenied("Selected tool transport is not authenticated")
        return self.request


def selected_extension(package: Path) -> Path:
    """Select the tool shipped inside the already verified native package.

    The native deployment manifest allows this exact module. A private session
    directory is state storage, not an extension installation root.
    """
    source = Path(package) / "dist/selected_claimed_write.mjs"
    info = source.lstat()
    if (
        not stat.S_ISREG(info.st_mode)
        or source.read_bytes() != _TOOL_SOURCE.read_bytes()
    ):
        raise SelectedToolDenied("Selected native extension differs from reviewed source")
    return source


def consume_selected_slot(store: Coordination, slot_id: SlotId, call_id: ToolCallId) -> None:
    """Commit consumption BEFORE any action; a failed commit is UNKNOWN, never retried."""
    try:
        with store.session.writing() as db:
            SelectedToolSlot.consume(db, slot_id, call_id)
    except CoordinationBeginUnavailable as error:
        raise SelectedToolBusy() from error
    except sqlite3.Error as error:
        raise SelectedToolDenied("Selected tool consumption UNKNOWN; do not retry") from error


def record_selected_terminal(
    coordination_path: Path, slot_id: SlotId, call_id: ToolCallId,
) -> None:
    """Only a committed terminal acknowledgement lets the tool return success."""
    try:
        with Coordination(str(coordination_path)) as store, store.session.writing() as db:
            SelectedToolSlot.require(db, slot_id=slot_id).acknowledge(db, call_id)
    except CoordinationBeginUnavailable:
        raise  # Nothing was written, so the acknowledgement is not UNKNOWN.
    except sqlite3.Error as error:
        raise SelectedToolDenied("Selected tool terminal acknowledgement UNKNOWN; no retry") from error


def selected_tool_mode_for_owner(
    comms: Comms,
    store: Coordination,
    claim_scope: WakeClaim,
    owner_name: str,
    input_id: InputId,
) -> SelectedToolMode:
    """Capture only owner-derived typed fields for this one FULL selected input.

    Construct after the owner has engaged the selected attempt and reserved its
    tracked input. Never derive this mode from user/model/wake-injected text.
    """
    try:
        FieldCodec.decode(str, owner_name)
    except MalformedRecord as error:
        raise SelectedToolDenied("Selected mode has no typed owner attempt") from error

    path = store.session.path

    def owner_action(round_number: int, request: SelectedToolRequest) -> None:
        # The prompt-send boundary commits this epoch to the exact reserved
        # FULL input before Pi can receive it. A socket token, PID, model text,
        # or context journal alone does not establish this source binding.
        with Coordination(path) as worker_store:
            verify_sent_full_input(worker_store, claim_scope, owner_name, input_id)
            perform_selected_write(
                comms, worker_store, claim_scope, owner_name, input_id, round_number, request
            )

    return SelectedToolMode(owner_action, PiRuleGate.of(comms, comms.registry.require(owner_name)))


def verify_sent_full_input(
    store: Coordination, claim_scope: WakeClaim, owner_name: str, input_id: InputId
) -> None:
    """Only the exact FULL input authorized by the owner may call native tools.

    This is the first check of a tool call and it only reads. Other owners
    write the same database, so the read waits the coordinator's bounded
    time; a database still busy after that is reported as busy, not as a
    refusal of the call and not as an unknown outcome.
    """
    try:
        with CoordinationReadUnavailable.checking(), Coordination(str(store.session.path)) as scoped, scoped.session.read():
            _require_sent_full_input(scoped, claim_scope, owner_name, input_id)
    except CoordinationReadUnavailable as unavailable:
        raise SelectedToolBusy() from unavailable


def _require_sent_full_input(
    scoped: Coordination, claim_scope: WakeClaim, owner_name: str, input_id: InputId
) -> None:
    NativeRuntimeTable.require_installed(scoped.session._connection)
    row = NativeRuntimeInput.one(scoped.session._connection, input_id=input_id)
    if row is None:
        raise SelectedToolDenied("Selected tool has no reserved FULL input")
    if claim_scope.wake_assignment_id not in row.execution.source_assignment_ids(
        scoped.session._connection, input_id
    ):
        raise SelectedToolDenied("Selected tool source was not included in this native input")
    expected = NativeInputIdentity(
        input_id, FullNativeExecution(claim_scope.execution_id, claim_scope.attempt_ordinal),
        OwnerGenerations(
            owner_lookup=claim_scope.recipient_lookup,
            generation=claim_scope.participant_generation,
        ),
    )
    if row.identity != expected:
        raise SelectedToolDenied("Selected tool does not match the exact sent FULL input")
    if not row.sent_owner_claimed_generation.matches(claim_scope.owner_claimed_generation):
        raise SelectedToolDenied("Selected tool names another sending claim_scope")


def verify_selected_terminal(
    coordination_path: Path, slot_id: SlotId, call_id: ToolCallId,
) -> None:
    """Corroborate a live owner result; a persisted acknowledgement alone grants nothing."""
    with Coordination(str(coordination_path), session_type=ReadNativeCoordinationSession) as store, store.session.read():
        SelectedToolSlot.require(store.session._connection, slot_id=slot_id).verify(call_id)


def perform_selected_write(
    comms: Comms,
    store: Coordination,
    claim_scope: WakeClaim,
    owner_name: str,
    input_id: InputId,
    round_number: int,
    request: SelectedToolRequest,
) -> None:
    """Only the owner calls the existing selected claim and writer boundaries."""
    slot = request.slot(input_id, round_number)
    consume_selected_slot(store, slot, request.call_id)
    # Any exception from here leaves the slot consumed. The caller reports
    # UNKNOWN and never automatically reissues the claim or mutation.
    claimed = publish_selected_resource_claim(
        comms, store, claim_scope, owner_name, request.arguments.claim
    )
    write_selected_claimed_file(
        comms, store, claim_scope, owner_name, claimed, request.arguments.contents.encode("utf-8")
    )
    record_selected_terminal(store.session.path, slot, request.call_id)


class SelectedToolSocket(GatedToolTransport[SelectedToolRequest]):
    max_request = _MAX_REQUEST
    """One selected replacement, preserving the existing one-slot authority."""

    def __init__(
        self, listener: ToolListener, action: Callable[[int, SelectedToolRequest], None],
        gate: PiRuleGate, *, pid: int
    ) -> None:
        super().__init__(listener, gate, pid=pid)
        self.action = action

    def validate_round(self, round: NativeToolRound[SelectedToolRequest]) -> None:
        if len(round.declared) != 1 or self.calls.rounds:
            raise SelectedToolDenied("Native Pi returned more than one selected call")

    def decode_call(self, call_id: object, name: object, arguments: object) -> SelectedToolRequest:
        if name != SelectedToolRequest.declared_name:
            raise SelectedToolDenied("Native Pi returned an unapproved selected call")
        try:
            return FieldCodec.decode(
                SelectedToolRequest, {"call_id": call_id, "arguments": arguments}
            )
        except MalformedRecord as error:
            raise SelectedToolDenied("Invalid selected tool call") from error

    def decode_request(self, raw: bytes) -> SelectedToolRequest:
        if len(raw) > self.max_request or not raw.endswith(b"\n"):
            raise SelectedToolDenied("Selected tool request is incomplete or oversized")
        try:
            envelope = FieldCodec.decode(
                SelectedToolEnvelope,
                FieldCodec.parse(raw),
            )
        except MalformedRecord as error:
            raise SelectedToolDenied("Invalid selected tool request") from error
        return envelope.authenticate(self.listener.token)

    async def allow(self, round_number: int, call: SelectedToolRequest) -> None:
        await Coordination.run_worker(partial(self.action, round_number, call))
