"""Verify a selected N/K wake and bind a durable resource claim to it.

Neither verification nor a committed claim grants a native file write. The
write boundary must repeat current authority checks before touching the file.
"""

from __future__ import annotations

import os
import stat
from collections.abc import (
    Callable,
    Iterator,
)
from contextlib import (
    AbstractContextManager,
    ExitStack,
    contextmanager,
)
from pathlib import Path

from agent_comms.comms import Comms
from agent_comms.coordination.cohort import _claim_record
from agent_comms.coordination.cohort_schema import CohortTable
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.database import CoordinationStore
from agent_comms.coordination.errors import (
    IdentityConflict,
    StaleFence,
)
from agent_comms.coordination.tables.participants import OwnerGenerations
from agent_comms.errors import RelationViolationError
from agent_comms.execution.native_input_owner import RegistryOwner
from agent_comms.messaging.bus import (
    BusReader,
    BusSnapshot,
)
from agent_comms.messaging.bus_publication import Delivered
from agent_comms.messaging.envelope_claim_transitions import (
    ClaimOwner,
    ExistingFileClaim,
    FileClaimPath,
    WakeClaim,
)
from agent_comms.registry.private_registry_guard import RegistryPrivacy
from agent_comms.registry.registry_document import RegistrySnapshot
from agent_comms.registry.threads import (
    NativeThread,
    Thread,
)


def verify_selected_wake(
    comms: Comms, store: Coordination, claim_scope: WakeClaim, owner_name: str
) -> None:
    """Reject any unselected, stale, stopped, or unrelated N/K execution."""
    try:
        with _selected_claim_boundary(comms, store, claim_scope, owner_name,
                                      store.session.read):
            pass
    except (RelationViolationError, ValueError) as error:
        raise IdentityConflict("Wake bus or live owner authority changed") from error


def _verify_selected_wake_state(
    initial: Delivered,
    owner: NativeThread,
    generation: int,
    store: Coordination,
    claim_scope: WakeClaim,
    privacy: RegistryPrivacy,
) -> None:
    """Check an already locked bus/owner snapshot against one SQL state."""
    registry_owner = RegistryOwner(thread=owner, claimed_generation=generation)
    try:
        turn = registry_owner.require_active_turn()
    except StaleFence as error:
        raise IdentityConflict("Wake source or owner turn does not match") from error
    if owner.incarnation.lookup != claim_scope.recipient_lookup:
        raise IdentityConflict("Wake recipient incarnation changed")
    if generation != claim_scope.owner_claimed_generation or turn.id != claim_scope.turn_id:
        raise IdentityConflict("Wake source or owner turn does not match")
    with store.session.read():
        CohortTable.require_installed(store.session._connection)
        acknowledgement = _claim_record(store.session._connection, initial, privacy)
        if not any(
            assignment.assignment_id == claim_scope.wake_assignment_id
            for assignment in acknowledgement.assignments
        ):
            raise IdentityConflict("Wake claim is not in the sealed selected cohort")
        assignment = store.assignments.get(claim_scope.wake_assignment_id)
        participant = store.participants.get(claim_scope.recipient_lookup)
        snapshot = store.get(claim_scope.execution_id)
        if assignment.require_engaged_binding() != claim_scope.binding:
            raise IdentityConflict("Wake assignment binding changed")
        expected_owner = OwnerGenerations(
            owner_lookup=claim_scope.recipient_lookup,
            generation=claim_scope.participant_generation,
        )
        if not participant.committed or participant.owner_identity != expected_owner:
            raise IdentityConflict("Wake participant generation changed")
        try:
            attempt = snapshot.require_current_attempt()
        except StaleFence as error:
            raise IdentityConflict("Wake execution is not the current selected attempt") from error
        if (
            attempt.owner_identity != expected_owner
            or attempt.attempt_ordinal != claim_scope.attempt_ordinal
        ):
            raise IdentityConflict("Wake selected attempt owner changed")
        if snapshot.execution.owner_lookup != expected_owner.owner_lookup:
            raise IdentityConflict("Wake execution owner changed")
        if not attempt.lifecycle.tool_claim_open:
            raise IdentityConflict("Wake execution is not the current selected attempt")
        if assignment not in snapshot.assignments or assignment.recipient_lookup != expected_owner.owner_lookup:
            raise IdentityConflict("Wake assignment is not a member of this owner's execution")


def _committed_source(
    source: BusReader, claim_scope: WakeClaim, absent: str
) -> Delivered:
    """Require the original reference and its delivery capability in one bus snapshot."""
    try:
        initial, = source.deliveries_for_references((claim_scope.source,))
        return initial
    except (RelationViolationError, ValueError) as error:
        raise IdentityConflict(absent) from error


@contextmanager
def _selected_claim_boundary(
    comms: Comms, store: Coordination, claim_scope: WakeClaim, owner_name: str,
    checking: Callable[[], AbstractContextManager[object]],
) -> Iterator[tuple[RegistrySnapshot, Thread]]:
    """Keep the registry and coordinator's own authority checks through the effect.

    Native settlement already orders the coordinator before Bus publication. A
    coordinator read holds its rollback-journal read lock; a mediated file write
    uses its existing write transaction. Neither is a replacement bus lock.
    """
    if store.session.path.resolve() != (CoordinationStore.path_in(comms.root)).resolve():
        raise IdentityConflict("Wake coordinator does not belong to this wire root")
    with comms.registry.store.current_snapshot() as cut:
        registry = cut.snapshot
        canonical = registry.canonical_name(owner_name)
        try:
            captured = RegistryOwner.capture(
                registry, canonical, "Selected wake owner stopped or changed"
            )
            captured.require_active_turn()
        except StaleFence as error:
            raise IdentityConflict("Selected wake owner stopped or changed") from error
        owner, generation = captured.thread, captured.claimed_generation
        privacy = cut.privacy
        privacy.require_root(
            claim_scope.wire_root_id, IdentityConflict("Selected wake belongs to another namespace"))
        with checking(), comms.bus.bus.reading() as source:
            initial = _committed_source(
                source, claim_scope, "Selected wake has no committed initial row")
            _verify_selected_wake_state(initial, owner, generation, store, claim_scope, privacy)
            yield registry, owner


def publish_selected_resource_claim(
    comms: Comms,
    store: Coordination,
    claim_scope: WakeClaim,
    owner_name: str,
    resource_path: FileClaimPath,
) -> ClaimOwner:
    """Bind one existing file claim to a live selected wake in a durable bus row.

    The common lock order keeps stop and coordinator settlement behind the
    pre-append check. A lost append result is UNKNOWN; this call never retries it.
    The returned claim is an ownership acknowledgement, not file-write authorization.
    """
    with (
        comms.bus.opened_activity() as activity,
        _selected_claim_boundary(comms, store, claim_scope, owner_name, store.session.read) as (
            registry, owner,
        ),
    ):
        resource = resource_path.normalized(owner.worktree.path)
        return comms.bus.publisher._publish_acquisition_unlocked(
            registry,
            owner,
            resource,
            claim_scope,
            activity=activity,
        )


@contextmanager
def _opened_selected_file(
    worktree: Path, normalized: str
) -> Iterator[tuple[int, Callable[[], None]]]:
    """Anchor every parent component to physical worktree directory FDs.

    Path normalization alone is not enough: a parent can be replaced by a
    symlink before a final-component O_NOFOLLOW open. Preflight stability is
    required before truncation; post-fsync drift is UNKNOWN, not success.
    This does not promise hostile same-UID rename exclusion during a write.
    """
    relative = Path(normalized).relative_to(worktree)
    refusal = IdentityConflict("Selected write needs a physical directory chain")
    if not relative.parts:
        raise refusal
    directory_flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
    with ExitStack() as opened:
        try:
            root_fd = os.open(worktree, directory_flags)
            opened.callback(os.close, root_fd)
            chain: list[tuple[int | None, str | Path, int]] = [(None, worktree, root_fd)]
            parent_fd = root_fd
            for part in relative.parts[:-1]:
                next_fd = os.open(part, directory_flags, dir_fd=parent_fd)
                opened.callback(os.close, next_fd)
                chain.append((parent_fd, part, next_fd))
                parent_fd = next_fd
            leaf = relative.parts[-1]
            before = os.stat(leaf, dir_fd=parent_fd, follow_symlinks=False)
            fd = os.open(leaf, os.O_WRONLY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent_fd)
            opened.callback(os.close, fd)
            actual = os.fstat(fd)
            if (
                not stat.S_ISREG(actual.st_mode)
                or actual.st_nlink != 1
                or (actual.st_dev, actual.st_ino) != (before.st_dev, before.st_ino)
            ):
                raise IdentityConflict("Selected write file changed before opening")

            def stable() -> None:
                for parent, name, directory_fd in chain:
                    visible = os.stat(name, dir_fd=parent, follow_symlinks=False)
                    held = os.fstat(directory_fd)
                    if not stat.S_ISDIR(visible.st_mode) or (visible.st_dev, visible.st_ino) != (
                        held.st_dev,
                        held.st_ino,
                    ):
                        raise IdentityConflict("Selected write parent directory changed")
                visible_file = os.stat(leaf, dir_fd=parent_fd, follow_symlinks=False)
                held_file = os.fstat(fd)
                if (
                    not stat.S_ISREG(visible_file.st_mode)
                    or held_file.st_nlink != 1
                    or (visible_file.st_dev, visible_file.st_ino)
                    != (held_file.st_dev, held_file.st_ino)
                ):
                    raise IdentityConflict("Selected write opened file changed")

            stable()
        except OSError as error:
            raise IdentityConflict("Selected write directory or file changed") from error
        yield fd, stable


def write_selected_claimed_file(
    comms: Comms,
    store: Coordination,
    claim_scope: WakeClaim,
    owner_name: str,
    claimed: ClaimOwner,
    contents: bytes,
) -> None:
    """Mediate one bounded existing-file replacement under *current* authority.

    This explicitly invoked API is not an interceptor for Pi shell/edit tools,
    subprocesses, or human edits. Failure after truncation/write is UNKNOWN;
    callers must inspect, never automatically retry this operation.
    """
    if len(contents) > 1024 * 1024:
        raise IdentityConflict("Selected write requires bounded bytes")
    with Coordination(str(store.session.path)) as scoped:
        # Native settlement's existing coordinator -> Bus order also protects the
        # exact resource claim through fsync, without any root or file-bus gate.
        with (
            _selected_claim_boundary(comms, scoped, claim_scope, owner_name,
                                     scoped.session.writing) as (_, owner),
            comms.bus.bus.writing() as db,
        ):
            normalized = ExistingFileClaim(Path(claimed.resource)).normalized(owner.worktree.path)
            if not claimed.resource_scope.reuses(claim_scope) or BusSnapshot.from_connection(db).resource_owner(normalized) != claimed:
                raise IdentityConflict("Selected write has no current exact resource claim")
            with _opened_selected_file(owner.worktree.path, normalized) as (fd, stable):
                os.ftruncate(fd, 0)
                view = memoryview(contents)
                while view:
                    written = os.write(fd, view)
                    if written <= 0:
                        raise OSError("Selected write made no progress; file outcome UNKNOWN")
                    view = view[written:]
                os.fsync(fd)
                try:
                    stable()
                except (IdentityConflict, OSError) as error:
                    raise OSError(
                        "Selected write parent/file drift after fsync; outcome UNKNOWN"
                    ) from error
