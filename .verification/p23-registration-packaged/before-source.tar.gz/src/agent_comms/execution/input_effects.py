"""Turn and private-runtime effects consumed by the input owner."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from agent_comms.nominal.field_codec import AcpSessionId, RootId

if TYPE_CHECKING:
    from agent_comms.execution.cursor_publication import CursorPublication
    from agent_comms.execution.turn_runner import TurnRunner


class InputEffects(ABC):
    cursors: CursorPublication
    turns: TurnRunner

    @abstractmethod
    def _debug_log(self, message: str) -> None: ...

    @abstractmethod
    async def _drain_private_nk(self, session_id: AcpSessionId, wire_root_id: RootId) -> int: ...
