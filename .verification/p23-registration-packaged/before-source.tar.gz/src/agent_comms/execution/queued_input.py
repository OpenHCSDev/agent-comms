"""Live accepted input and the registry context that permits its handoff.

These values never recover prompts from disk. A renamed thread retains the same
birth identity and input generation; the registry resolves its name before comparison.
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator
from contextlib import AsyncExitStack, ExitStack, asynccontextmanager
from dataclasses import dataclass, field, replace
from functools import partial
from typing import TYPE_CHECKING, Generic, Self, TypeVar

from agent_comms.acp_extension import InputStartedUpdate, QueueItem
from agent_comms.context_segments.wake import MessageDelivery
from agent_comms.coordination.assignment_states import DeferredAssignment, DeliveredAssignment
from agent_comms.coordination.cohort import pending_sealed_assignments
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.database import CoordinationStore
from agent_comms.coordination.errors import IdentityConflict, Refused, StaleRevision
from agent_comms.coordination.session import ReadNativeCoordinationSession
from agent_comms.coordination.tables.assignments import WakeAssignment
from agent_comms.errors import RelationViolationError
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.execution.controller import NO_CONTROLLER, Controller
from agent_comms.execution.image_input import ImageInput
from agent_comms.execution.input_key import AcpInputKey, InputKey
from agent_comms.execution.input_origin import InputOrigin, UnattributedInputOrigin, WireInputOrigin
from agent_comms.execution.ordinary_turn_rules import MissingAcceptedInputCheck
from agent_comms.execution.reservation_rules import ReservationRule, RuleCheck
from agent_comms.execution.turn_context import TurnContext
from agent_comms.execution.turn_goal_permission import AcceptedGoalPermission, TurnGoalPermission
from agent_comms.execution.turn_inbox import InputContent, InputRequest
from agent_comms.execution.turn_input_source import (
    AcceptedFollowingInput,
    DeliveredFollowingInput,
    TurnAcceptance,
)
from agent_comms.input_attempt import InputAttempt, ReservedInput
from agent_comms.input_disposition import InputDispositions
from agent_comms.messaging.messages import Message
from agent_comms.messaging.routing import ScheduledTurn
from agent_comms.nominal.field_codec import AcpSessionId, GoalId, InputId, RootId
from agent_comms.planning.goals import GoalDeclaration, NoGoal
from agent_comms.registry.thread_identity import ClaimedIdentity, ClaimScoped
from agent_comms.registry.threads import Thread

if TYPE_CHECKING:
    from agent_comms.acp_extension import QueueScope
    from agent_comms.comms import Comms
    from agent_comms.execution.input_drain import DrainedSession, InputDrain
    from agent_comms.execution.turn_inbox import TurnInbox
    from agent_comms.execution.turn_input_source import TurnInputSource
    from agent_comms.execution.turn_runner import TurnRunner
    from agent_comms.messaging.bus_publication import Delivered
    from agent_comms.messaging.message_bus import MessageBus
    from agent_comms.registry.registry_document import RegistryEntry, RegistrySnapshot
    from agent_comms.transport.runtime_server import RuntimeServer


@dataclass(frozen=True, kw_only=True)
class AcceptedInputCheck(RuleCheck):
    acknowledgement: QueuedInput
    current: Thread
    claim_generation: int
    input_id: InputId
    keys: tuple[InputKey, ...]
    source_live: bool


class AcceptedInputAuthorityRule(ReservationRule):
    check_type = AcceptedInputCheck
    explanation = "The live input's accepted owner or goal authority changed."

    def violated(self, check: AcceptedInputCheck) -> bool:
        return not check.acknowledgement.current(check.current, check.claim_generation)


class AcceptedInputKeyRule(ReservationRule):
    check_type = AcceptedInputCheck
    explanation = "The input does not name its exact accepted ACP acknowledgement."

    def violated(self, check: AcceptedInputCheck) -> bool:
        return (check.input_id, check.keys) != (check.acknowledgement.input_id, (check.acknowledgement.key,))


class AcceptedInputSourceRule(ReservationRule):
    check_type = AcceptedInputCheck
    explanation = "The captured accepted input source is no longer live."

    def violated(self, check: AcceptedInputCheck) -> bool:
        return not check.source_live


@dataclass(frozen=True)
class AcceptedTurn(TurnAcceptance):
    input_id: InputId

    def controller(self, state: DrainedSession, runtime: RuntimeServer) -> Controller:
        return state.queued[self.input_id].controller

    def require_current(
        self, inputs: InputDrain, session_id: AcpSessionId, source: TurnInputSource,
        current: Thread, claim_generation: int,
    ) -> None:
        try:
            accepted = inputs.state(session_id).queued[self.input_id]
        except KeyError:
            for row in inputs.dispositions.read(source.keys).rows.values():
                row.require_not_cleared()
            MissingAcceptedInputCheck().require_valid()
            raise
        AcceptedInputCheck(
            acknowledgement=accepted, current=current, claim_generation=claim_generation,
            input_id=self.input_id, keys=source.keys,
            source_live=accepted.is_live(inputs, session_id),
        ).require_valid()

    async def accepted_start(
        self, update: InputStartedUpdate, inputs: InputDrain, session_id: AcpSessionId,
    ) -> InputStartedUpdate:
        queued = inputs.state(session_id).queued
        if self.input_id in queued:
            update = replace(update, text=await queued[self.input_id].started(inputs))
        return update.identified(self.input_id)

    def require_following_source(
        self, inputs: InputDrain, session_id: AcpSessionId, source: TurnInputSource,
    ) -> None:
        if inputs.state(session_id).following.get(self.input_id) is not source:
            raise RelationViolationError("Following context outlived its actual accepted input")

    def release(self, inputs: InputDrain, session_id: AcpSessionId) -> None:
        inputs.state(session_id).queued.pop(self.input_id, None)


class InputHandoffRefused(RelationViolationError):
    """Captured acceptance was refused before any native turn was dispatched."""


@dataclass(frozen=True, slots=True)
class QueuedInputContext(ClaimScoped):
    goal: GoalDeclaration = field(default_factory=NoGoal)

    @classmethod
    def capture(cls, owner: Thread, claim_scope: ClaimedIdentity):
        return cls(claim_scope, owner.goal)

    def named(self, name: str) -> QueuedInputContext:
        """Use the caller's canonical registry name without changing authority."""
        return replace(
            self,
            claimed_identity=replace(
                self.claimed_identity,
                incarnation=replace(self.claimed_identity.incarnation, name=name),
            ),
        )

    def owns(self, claim_scope: ClaimedIdentity) -> bool:
        return self.named(claim_scope.incarnation.name).claimed_identity == claim_scope

    @property
    def active_goal_id(self) -> GoalId | None:
        return self.goal.active().reported_id()


@dataclass(frozen=True, slots=True)
class QueuedInput:
    text: str
    echo: bool
    context: QueuedInputContext
    input_id: InputId
    prompt: str
    images: tuple[ImageInput, ...] = ()
    controller: Controller = NO_CONTROLLER

    @property
    def key(self) -> InputKey:
        return AcpInputKey(self.input_id)

    def queue_items(self, scope: QueueScope) -> tuple[QueueItem, ...]:
        """Show the item only when its recorded input generation matches the queue."""
        return (QueueItem.from_input(self.input_id, self.text),) if self.context.owns(scope.claimed_identity) else ()

    def source(self) -> AcceptedFollowingInput:
        return AcceptedFollowingInput(
            keys=(self.key,),
            acceptance=AcceptedTurn(self.input_id),
            goal_permission=TurnGoalPermission(AcceptedGoalPermission(self.context.active_goal_id)),
        )

    @classmethod
    def capture(
        cls,
        inputs: InputDrain,
        name: str,
        *,
        snapshot: RegistrySnapshot,
        text: str,
        prompt: str,
        echo: bool,
        images: tuple[ImageInput, ...],
        controller: Controller,
        ownership: ExitStack,
        input_id: InputId,
        origin: InputOrigin = UnattributedInputOrigin(),
    ) -> tuple[Self, InputAttempt]:
        """The current registry selection permits this durable input reservation."""
        canonical = snapshot.canonical_name(name)
        owner = snapshot.threads[canonical]
        context = QueuedInputContext.capture(
            owner,
            snapshot.claimed_identity(canonical),
        )
        origin.require_ingress(inputs.comms, snapshot, context.claimed_identity, controller)
        item = cls(
            text or prompt or "[image prompt]",
            echo,
            context,
            input_id,
            prompt,
            images,
            controller,
        )
        row = ReservedInput(
            item.key, None, canonical, context.claimed_identity.claimed_generation,
            canonical, item.text, origin=origin,
        )
        document = inputs.dispositions.reserve_originals(row, ownership=ownership)
        return item, document.lookup(item.key)

    @staticmethod
    def remaining_capacity(inputs: InputDrain, sources: tuple[TurnInputSource, ...]) -> int:
        """Read capacity for the loop owner's captured following sources."""
        document = inputs.dispositions.read(tuple(key for source in sources for key in source.keys))
        return 32 - sum(not document.all_started(source.keys) for source in sources)

    @classmethod
    def require_capacity(cls, inputs: InputDrain, sources: tuple[TurnInputSource, ...]) -> None:
        """Follow-ups cannot exceed the original live awaiting-start allowance."""
        if cls.remaining_capacity(inputs, sources) <= 0:
            raise Refused.invalid_params(
                {"reason": "Too many follow-up inputs awaiting their own user start."}
            )

    @classmethod
    @asynccontextmanager
    async def reserve(
        cls, inputs: InputDrain, session_id: AcpSessionId, name: str, *, text: str, prompt: str,
        echo: bool, images: tuple[ImageInput, ...], controller: Controller,
        input_id: InputId,
        origin: InputOrigin = UnattributedInputOrigin(),
    ) -> AsyncIterator[InputReservation[Self]]:
        """Serialize local queue placement; reserve durable input in a worker."""
        async with AsyncExitStack() as rollback:
            ownership = ExitStack()
            rollback.push_async_callback(Coordination.run_worker, ownership.close)
            async with inputs.queue_lock:
                sources = tuple(inputs.state(session_id).following.values())

                def capture():
                    with inputs.comms.registry.store.current_snapshot() as cut:
                        cls.require_capacity(inputs, sources)
                        return cls.capture(
                            inputs, name, snapshot=cut.snapshot, text=text, prompt=prompt, echo=echo,
                            images=images, controller=controller, input_id=input_id,
                            origin=origin, ownership=ownership,
                        )

                item, row = await Coordination.run_worker(capture)
                yield InputReservation(item, row, rollback)

    def place(
        self, inputs: InputDrain, session_id: AcpSessionId,
        inbox: TurnInbox, content: InputContent,
    ) -> None:
        """The accepted input owns transfer into this turn's existing native queue."""
        inputs.require_inbox(session_id, inbox)
        source = self.source()
        inputs.state(session_id).following[self.input_id] = source
        inputs.state(session_id).queued[self.input_id] = self
        inbox.put_nowait(InputRequest(
            input_id=self.input_id, content=content, when_busy=source.when_busy,
        ))

    async def dispatch(self, turns: TurnRunner, session_id: AcpSessionId, name: str) -> None:
        """Transfer this live acceptance under current authority; never recover disk work."""
        inputs = turns.inputs
        try:
            async with inputs.queue_lock:
                self.require_live_source(inputs, session_id)

                def verify():
                    snapshot = inputs.comms.registry.snapshot()
                    canonical = snapshot.canonical_name(name)
                    self.require_handoff(
                        snapshot, canonical, inputs.dispositions.lookup(self.key), self.input_id,
                    )
                    return canonical

                canonical = await Coordination.run_worker(verify)
                self.require_live_source(inputs, session_id)
        except RelationViolationError as error:
            raise InputHandoffRefused(str(error)) from error
        await turns.run_agent_turn(
            session_id,
            canonical,
            self.prompt,
            images=self.images,
            original_keys=(self.key,),
            initial_display_text=self.text if self.echo else None,
            original_owner_input=True,
            original_goal_id=self.context.active_goal_id,
            acceptance=AcceptedTurn(self.input_id),
        )

    def is_live(self, inputs: InputDrain, session_id: AcpSessionId) -> bool:
        return inputs.state(session_id).following.get(self.input_id) == self.source()

    def require_live_source(self, inputs: InputDrain, session_id: AcpSessionId) -> None:
        if not self.is_live(inputs, session_id):
            raise RelationViolationError("Accepted input source changed")

    def current(self, owner: Thread, claim_scope: int) -> bool:
        return self.context.named(owner.name) == QueuedInputContext.capture(
            owner, ClaimedIdentity(owner.incarnation, claim_scope)
        )

    def require_handoff(
        self,
        snapshot: RegistrySnapshot,
        name: str,
        row: InputAttempt,
        input_id: InputId,
    ) -> None:
        owner = snapshot.require_active(name)
        snapshot.status(owner.name).require_running()
        owner.require_local_process(ProcessIdentity.capture(os.getpid()))
        owner.turn_record.read().require_idle()
        claim_scope = snapshot.claim_generation(owner.name)
        if not self.current(owner, claim_scope):
            raise RelationViolationError("Queued input acceptance context changed")
        if not row.queued_for(owner.incarnation, claim_scope, self.text):
            raise RelationViolationError("Queued input reservation changed")
        if row.key != AcpInputKey(input_id):
            raise RelationViolationError("Queued input ID changed")

    def after_clear(self) -> QueuedInput | None:
        return None

    def restore_after_turn(self) -> tuple[QueuedInput, ...]:
        return (self,) if self.echo else ()

    async def started(self, inputs: InputDrain) -> str | None:
        """The running turn proved this input's start; the text the client shows as the user's."""
        return self.text

    async def not_started(self, inputs: InputDrain) -> None:
        """The turn refused this input or ended before its user start."""


ReservedQueuedInput = TypeVar("ReservedQueuedInput", bound=QueuedInput)


@dataclass(frozen=True, slots=True)
class InputReservation(Generic[ReservedQueuedInput]):
    """A captured input and its rollback until placement takes ownership."""

    item: ReservedQueuedInput
    source: InputAttempt
    _rollback: AsyncExitStack

    def release(self) -> AsyncExitStack:
        """Transfer rollback actions; a new scope may adopt them or discard them."""
        return self._rollback.pop_all()


@dataclass(frozen=True, slots=True, kw_only=True)
class DeliveredInput(QueuedInput):
    """A pending bus message handed to its recipient's running turn.

    Its assignment is paused while the turn holds it. A proved start settles it
    as delivered; an input never written returns it to pending for an ordinary
    wake. One written without a proved start stays paused and is never resent.
    """

    bus_key: InputKey
    message: Message
    assignment: WakeAssignment

    @property
    def key(self) -> InputKey:
        return self.bus_key

    def queue_items(self, scope: QueueScope) -> tuple[QueueItem, ...]:
        return ()  # The user's queue lists only what the user typed.

    def source(self) -> DeliveredFollowingInput:
        return DeliveredFollowingInput(
            keys=(self.key,),
            acceptance=AcceptedTurn(self.input_id),
            goal_permission=TurnGoalPermission(AcceptedGoalPermission(self.context.active_goal_id)),
            origins=(self.message,),
        )

    @classmethod
    def reserve_pending(
        cls, inputs: InputDrain, name: str, root_id: RootId,
        pending: tuple[tuple[Delivered, WakeAssignment], ...],
        sources: tuple[TurnInputSource, ...],
        reserved: list[tuple[Self, InputContent]],
    ) -> None:
        """Fill the original reservation scope under its current registry owner.

        The caller owns ``reserved`` and its AsyncExitStack before work starts,
        so cancellation cannot lose a successfully paused but unplaced input.
        The worker opens/closes SQLite and never reads or mutates live queues.
        """
        with inputs.comms.registry.store.current_snapshot() as cut:
            accepted = pending[:max(cls.remaining_capacity(inputs, sources), 0)]
            if not accepted:
                return
            snapshot = cut.snapshot
            canonical = snapshot.canonical_name(name)
            owner = snapshot.threads[canonical]
            context = QueuedInputContext.capture(owner, snapshot.claimed_identity(canonical))
            document = inputs.dispositions.read(tuple(
                source.message.bus_key(owner) for source, _ in accepted
            ))
            with Coordination(str(CoordinationStore.path_in(inputs.comms.root))) as store:
                for source, assignment in accepted:
                    message = source.message
                    key = message.bus_key(owner)
                    if document.lookup(key).exists:
                        continue
                    rendered = TurnContext.render_segments(
                        (MessageDelivery(source, assignment, owner).segment(),)
                    )
                    row = ReservedInput(
                        key, message.seq, canonical, context.claimed_identity.claimed_generation,
                        message.target,
                        ScheduledTurn.incoming(message, aliases=snapshot.aliases).prompt,
                        origin=WireInputOrigin(root_id, message.reference),
                    )
                    with ExitStack() as ownership:
                        inputs.dispositions.reserve_originals(row, ownership=ownership)
                        paused = store.assignments.transition_preengagement(
                            assignment.assignment_id, DeferredAssignment,
                            expected_revision=assignment.revision,
                        ).value
                        ownership.callback(store.assignments.restore_unbound_delivery, paused)
                        reserved.append((
                            cls(
                                text=row.source_text, echo=False, context=context,
                                input_id=InputId.mint(), prompt=rendered.text,
                                bus_key=key, message=message, assignment=paused,
                            ),
                            InputContent(text=rendered.text, contributions=rendered.contributions),
                        ))
                        ownership.pop_all()

    @staticmethod
    async def _restore_unplaced(
        inputs: InputDrain, session_id: AcpSessionId,
        reserved: list[tuple[DeliveredInput, InputContent]],
    ) -> None:
        # Capture the loop-owned transfer before the first await; a turn may
        # retire its placed inputs while an unplaced input is being restored.
        placed = inputs.state(session_id).queued
        unplaced = tuple(
            item for item, _content in reserved if placed.get(item.input_id) is not item
        )
        for item in unplaced:
            await item.not_started(inputs)

    @classmethod
    async def recover_interrupted(
        cls, inputs: InputDrain, state: DrainedSession, entry: RegistryEntry, root_id: RootId,
    ) -> int:
        """Requeue only deliveries positively proved absent from native input.

        A killed owner can lose the live ``DeliveredInput`` which normally
        restores its paused assignment. The durable input row and native source
        membership replace that lost object: any send binding or native row
        keeps the assignment deferred and therefore never replayed.
        """
        async with inputs.queue_lock:
            live_keys = frozenset(item.key for item in state.queued.values())
            return await Coordination.run_worker(partial(
                cls._recover_locked, inputs.comms, inputs.dispositions,
                entry.thread.name, root_id, live_keys,
            ))

    @staticmethod
    def _recover_locked(
        comms: Comms, dispositions: InputDispositions,
        name: str, root_id: RootId, live_keys: frozenset[InputKey],
    ) -> int:
        """Acquire, recover and release entirely inside the joined worker."""
        entry = comms.registry.entry(name).entry
        document = dispositions.stored_unresolved((entry,))
        if not any(row.key not in live_keys
                   for row in document.unbound_wire_inputs(root_id).values()):
            return 0
        with comms.registry.store.current_entry(name) as cut:
            entry = cut.entry
            owner = entry.thread
            document = dispositions.stored_unresolved((entry,))
            rows = {
                reference: row
                for reference, row in document.unbound_wire_inputs(root_id).items()
                if row.key not in live_keys
            }
            if not rows:
                return 0  # Without work, no SQLite connection is needed, let alone a writer.
            path = str(CoordinationStore.path_in(comms.root))
            with Coordination(path, session_type=ReadNativeCoordinationSession) as store:
                assignments = store.assignments.recoverable_unbound_deliveries(
                    owner.incarnation.lookup, frozenset(rows),
                )
            if not assignments:
                return 0
            with Coordination(path) as store:
                dispositions.settle_unbound(tuple(rows[row.source].key for row in assignments))
                restored = 0
                for assignment in assignments:
                    try:
                        store.assignments.restore_unbound_delivery(assignment)
                    except StaleRevision:
                        continue
                    restored += 1
                return restored

    @classmethod
    async def deliver_pending(
        cls, inputs: InputDrain, session_id: AcpSessionId, owner: Thread, bus: MessageBus,
        root_id: RootId, after_seq: int,
    ) -> None:
        """Hand this owner's pending bus messages to its running turn.

        Pi takes each sealed pending assignment after its current tool batch,
        regardless of its audience. Only a turn without following capacity leaves
        the original pending for the ordinary wake after it ends.
        """
        turn = await inputs.effects.turns.active_backend_turn(session_id)
        # Only the started member owns both the inbox and its original input.
        if not turn.has_source:
            return
        inbox = turn.require_inbox()
        store_path = CoordinationStore.path_in(inputs.comms.root)
        lookup = owner.incarnation.lookup

        def read(store: Coordination):
            with store.session.read():
                assignments = pending_sealed_assignments(store, lookup, after_seq=after_seq)
            with store.session.capture(bus) as boundary, bus.bus.reading() as source:
                boundary.privacy.require_root(root_id, IdentityConflict("delivered native namespace changed"))
                originals = source.deliveries_for_references(tuple(
                    assignment.source for assignment in assignments
                ))
            return tuple(zip(originals, assignments, strict=True))

        pending = await Coordination.run_read_async(store_path, read)
        if not pending:
            return
        reserved: list[tuple[Self, InputContent]] = []
        async with AsyncExitStack() as rollback:
            rollback.push_async_callback(cls._restore_unplaced, inputs, session_id, reserved)
            async with inputs.queue_lock:
                sources = tuple(inputs.state(session_id).following.values())
                await Coordination.run_worker(partial(
                    cls.reserve_pending, inputs, owner.name, root_id, pending, sources, reserved,
                ))
                for item, content in reserved:
                    try:
                        item.place(inputs, session_id, inbox, content)
                    except InputHandoffRefused:
                        break

    async def dispatch(self, turns: TurnRunner, session_id: AcpSessionId, name: str) -> None:
        raise InputHandoffRefused("A bus message its turn never took wakes its owner instead")

    def after_clear(self) -> DeliveredInput:
        return self  # Clearing the user's queue cannot withdraw a bus message.

    def restore_after_turn(self) -> tuple[QueuedInput, ...]:
        return ()

    async def settle(self, inputs: InputDrain, state) -> None:
        await Coordination.run_async(
            CoordinationStore.path_in(inputs.comms.root),
            lambda store: store.assignments.transition_preengagement(
                self.assignment.assignment_id, state,
                expected_revision=self.assignment.revision,
            ),
        )

    async def started(self, inputs: InputDrain) -> None:
        # Its transcript row is the bus message, not typed user text.
        await self.settle(inputs, DeliveredAssignment)

    async def not_started(self, inputs: InputDrain) -> None:
        document = await Coordination.run_worker(
            partial(inputs.finish_original_inputs, (self.key,))
        )
        if document.lookup(self.key).has_native_binding:
            return  # Written without a proved start: it stays paused, never resent.
        await self.settle(inputs, self.assignment.lifecycle.mode.initial_state())


class InitialInput(QueuedInput):
    @classmethod
    def require_capacity(cls, inputs: InputDrain, sources: tuple[TurnInputSource, ...]) -> None:
        """A new original is not a following input in the live native queue."""

    @classmethod
    async def run(
        cls, inputs: InputDrain, session_id: AcpSessionId, thread_name: str, task: str, *,
        images: tuple[ImageInput, ...] = (), display_text: str | None = None,
        input_id: InputId,
        origin: InputOrigin = UnattributedInputOrigin(),
    ) -> None:
        """Own original reservation, dispatch and unbound retirement as one lifetime."""
        from agent_comms.execution.turn_context import TurnContext, UserRequestSegment

        request = UserRequestSegment.capture(task)
        async with AsyncExitStack() as resources:
            async with cls.reserve(
                inputs, session_id, thread_name, text=display_text or task,
                prompt=TurnContext.render_segments((request,), images=images).text,
                echo=display_text is not None, images=images,
                controller=inputs.runtime.controller.get(), input_id=input_id, origin=origin,
            ) as reservation:
                item = reservation.item
                inputs.state(session_id).queued[item.input_id] = item
                resources.push_async_callback(item.finish, inputs, session_id)
                reservation.release()
            await inputs.emit_input_delivery_changed(session_id)
            await inputs.emit_queue_state(session_id)
            await item.dispatch(inputs.effects.turns, session_id, thread_name)

    async def finish(self, inputs: InputDrain, session_id: AcpSessionId) -> None:
        """Retire only this captured original after its dispatch resources join."""
        queued = inputs.state(session_id).queued
        if queued.get(self.input_id) is self:
            try:
                await Coordination.run_worker(partial(
                    inputs.finish_original_inputs, (self.key,),
                ))
            finally:
                # The joined original write finishes before cancellation is
                # propagated. Burn only this live grant; durable UNKNOWN stays.
                queued.pop(self.input_id)
            await inputs.emit_queue_state(session_id)

    def is_live(self, inputs: InputDrain, session_id: AcpSessionId) -> bool:
        return inputs.state(session_id).queued.get(self.input_id) is self

    def after_clear(self) -> InitialInput:
        return self  # Clearing follow-ups cannot withdraw the original dispatch.

    def restore_after_turn(self) -> tuple[QueuedInput, ...]:
        return ()  # Its original terminal disposition owns cancellation/UNKNOWN.
