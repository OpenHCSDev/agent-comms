"""Private send refusals discovered through the shared reservation rule family."""

from __future__ import annotations

from dataclasses import dataclass

from agent_comms.coordination.tables.assignments import WakeAssignment
from agent_comms.execution.child_process import ProcessIdentity
from agent_comms.execution.native_input_record import NativeInputIdentity, NativeInputRecord
from agent_comms.execution.native_runtime_input import NativeRuntimeInput
from agent_comms.execution.reservation_rules import ReservationRule, RuleCheck
from agent_comms.execution.turn_goal_permission import GoalPermission
from agent_comms.registry.threads import Thread


@dataclass(frozen=True, kw_only=True)
class RegistryIdentityCheck(RuleCheck):
    expected: Thread
    actual: Thread
    expected_claim: int
    claim_generation: int | None
    process: ProcessIdentity
    goal_permission: GoalPermission

    def name_matches(self) -> bool:
        return self.actual.name == self.expected.name

    def worktree_matches(self) -> bool:
        return self.actual.worktree == self.expected.worktree

    def model_matches(self) -> bool:
        return self.actual.model == self.expected.model

    def thinking_matches(self) -> bool:
        return self.actual.thinking_level == self.expected.thinking_level


class RegistryClaimCheck(RegistryIdentityCheck):
    """A claimed turn uses its captured settings, not the next-turn selection.

    Before a claim, configuration must still match. After a claim, the exact
    lease/process/session checks retain this operation's original authority;
    native launch and compaction use the captured Thread and observed model.
    """

    def model_matches(self) -> bool:
        return self.expected.turn_lease.leased or super().model_matches()

    def thinking_matches(self) -> bool:
        return self.expected.turn_lease.leased or super().thinking_matches()


class RunningTurnRegistryCheck(RegistryClaimCheck):
    """A turn that already started finishes in the project it started in.

    The registry's project selects the next turn, so changing it during a
    turn does not stop that turn from recording its result and replies. The
    same lease, process and session must remain, and the turn's directory
    must be one this conversation ran in. This accepts no new input.
    """

    def name_matches(self) -> bool:
        # RegistryOwner resolved the captured name through the registry's
        # retained alias. Recording this turn accepts no input under a new name.
        return True

    def worktree_matches(self) -> bool:
        return self.actual.continues_running_project(self.expected)


class GoalRegistryIdentityCheck(RegistryIdentityCheck):
    """Fresh turn claims capture the goal, not the earlier turn state."""


class GoalRegistryClaimCheck(GoalRegistryIdentityCheck, RegistryClaimCheck):
    """Selected input/awareness also captures the goal; reply settlement does not."""


class RegistryIncarnationRule(ReservationRule):
    check_type = RegistryIdentityCheck
    explanation = "The registered thread incarnation changed before native send."

    def violated(self, check: RegistryIdentityCheck) -> bool:
        return check.actual.incarnation != check.expected.incarnation


class RegistryNameRule(ReservationRule):
    check_type = RegistryIdentityCheck
    explanation = "The captured owner name changed."

    def violated(self, check: RegistryIdentityCheck) -> bool:
        return not check.name_matches()


class RegistryProcessRule(ReservationRule):
    check_type = RegistryIdentityCheck
    explanation = "The registered process is not the captured current owner process."

    def violated(self, check: RegistryIdentityCheck) -> bool:
        return (
            check.actual.process_identity != check.expected.process_identity
            or check.actual.process_identity != check.process
        )


class RegistryClaimRule(ReservationRule):
    check_type = RegistryIdentityCheck
    explanation = "The registry claim_scope generation changed."

    def violated(self, check: RegistryIdentityCheck) -> bool:
        return check.claim_generation != check.expected_claim


class RegistryRoleRule(ReservationRule):
    check_type = RegistryIdentityCheck
    explanation = "The captured owner role changed."

    def violated(self, check: RegistryIdentityCheck) -> bool:
        return check.actual.role != check.expected.role


class RegistryWorktreeRule(ReservationRule):
    check_type = RegistryIdentityCheck
    explanation = "The captured owner worktree changed."

    def violated(self, check: RegistryIdentityCheck) -> bool:
        return not check.worktree_matches()


class RegistryModelRule(ReservationRule):
    check_type = RegistryIdentityCheck
    explanation = "The captured owner's selected model changed."

    def violated(self, check: RegistryIdentityCheck) -> bool:
        return not check.model_matches()


class RegistryThinkingRule(ReservationRule):
    check_type = RegistryIdentityCheck
    explanation = "The captured owner's thinking level changed."

    def violated(self, check: RegistryIdentityCheck) -> bool:
        return not check.thinking_matches()


class RegistrySessionRule(ReservationRule):
    check_type = RegistryIdentityCheck
    explanation = "The captured owner's native session changed."

    def violated(self, check: RegistryIdentityCheck) -> bool:
        return check.actual.session_file != check.expected.session_file


class RegistryTurnRule(ReservationRule):
    check_type = RegistryClaimCheck
    explanation = "The exact captured active turn changed."

    def violated(self, check: RegistryClaimCheck) -> bool:
        return not check.actual.same_turn(check.expected)


class RegistryGoalRule(ReservationRule):
    check_type = GoalRegistryIdentityCheck
    explanation = "The captured goal changed."

    def violated(self, check: GoalRegistryIdentityCheck) -> bool:
        return not check.goal_permission.allows(check.actual.goal)


@dataclass(frozen=True, kw_only=True)
class NativeIdentityCheck(RuleCheck):
    row: NativeInputRecord
    expected: NativeInputIdentity


@dataclass(frozen=True, kw_only=True)
class NativeReservationCheck(NativeIdentityCheck):
    row: NativeRuntimeInput
    token_digest: str


class NativeInputIdentityRule(ReservationRule):
    check_type = NativeIdentityCheck
    explanation = "The original native input assignment, stage, attempt or owner changed."

    def violated(self, check: NativeIdentityCheck) -> bool:
        return check.row.identity != check.expected


class NativeTokenRule(ReservationRule):
    check_type = NativeReservationCheck
    explanation = "The reserved native input token changed."

    def violated(self, check: NativeReservationCheck) -> bool:
        return check.row.owner_token_digest != check.token_digest


class NativeAlreadyBoundRule(ReservationRule):
    check_type = NativeReservationCheck
    explanation = "The native input was already bound to a sending claim_scope."

    def violated(self, check: NativeReservationCheck) -> bool:
        return check.row.sent_owner_claimed_generation.reservation_violation()


class NativeAlreadyProvenRule(ReservationRule):
    check_type = NativeReservationCheck
    explanation = "The native input already has a proven session result."

    def violated(self, check: NativeReservationCheck) -> bool:
        return check.row.reference.recorded


class NativeAlreadyDecidedRule(ReservationRule):
    check_type = NativeReservationCheck
    explanation = "The native triage input already has a verdict."

    def violated(self, check: NativeReservationCheck) -> bool:
        return check.row.verdict.decided


@dataclass(frozen=True, kw_only=True)
class NativeClaimCheck(RuleCheck):
    captured: WakeAssignment
    current: WakeAssignment


class NativeClaimRecipientRule(ReservationRule):
    check_type = NativeClaimCheck
    explanation = "The selected claim recipient changed."

    def violated(self, check: NativeClaimCheck) -> bool:
        return check.current.recipient != check.captured.recipient


class NativeClaimLookupRule(ReservationRule):
    check_type = NativeClaimCheck
    explanation = "The selected claim recipient lookup changed."

    def violated(self, check: NativeClaimCheck) -> bool:
        return check.current.recipient_lookup != check.captured.recipient_lookup


class NativeClaimSequenceRule(ReservationRule):
    check_type = NativeClaimCheck
    explanation = "The selected claim source sequence changed."

    def violated(self, check: NativeClaimCheck) -> bool:
        return check.current.wire_seq != check.captured.wire_seq


class NativeClaimMessageRule(ReservationRule):
    check_type = NativeClaimCheck
    explanation = "The selected claim committed message changed."

    def violated(self, check: NativeClaimCheck) -> bool:
        return check.current.message_id != check.captured.message_id


class NativeClaimModeRule(ReservationRule):
    check_type = NativeClaimCheck
    explanation = "The selected claim wake mode changed."

    def violated(self, check: NativeClaimCheck) -> bool:
        return check.current.lifecycle.mode != check.captured.lifecycle.mode
