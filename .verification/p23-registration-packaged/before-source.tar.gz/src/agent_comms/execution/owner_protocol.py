"""Owner and frontend change in lockstep: the built Core commit is the protocol.

Every socket line is a declared family member, encoded and decoded once by
FieldCodec. Each member answers what its reader does with it.
"""

from __future__ import annotations

import json
from abc import abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Annotated, Self, cast

from pydantic import BaseModel

from agent_comms import package_stamp
from agent_comms.coordination.errors import Refused
from agent_comms.nominal.declared_family import DeclaredFamily
from agent_comms.nominal.field_codec import (
    FieldCodec,
    MalformedRecord,
    NullMember,
    RecordMember,
    SubclassUnion,
    Token256Text,
    WireName,
)

if TYPE_CHECKING:
    from agent_comms.execution.runtime import RuntimeProxy
    from agent_comms.transport.runtime_server import SocketClient


@dataclass(frozen=True, kw_only=True)
class SocketLine(DeclaredFamily, affix=""):
    """One JSON line on an owner socket; each direction reads only its own members."""

    @classmethod
    def read(cls, line: bytes) -> Self:
        return FieldCodec.decode(cls, FieldCodec.parse(line))

    def wire(self) -> bytes:
        return (json.dumps(FieldCodec.encode(self)) + "\n").encode()


@dataclass(frozen=True, kw_only=True)
class OwnerLine(SocketLine):
    """A line the owner writes to an attached client."""

    declared_name = None  # a direction, not a line

    def announced(self, thread: str) -> None:
        """The first subscription line; only this Core's announcement passes."""
        raise IncompatibleOwnerError(UnannouncedOwner(thread=thread))

    async def attach(self, proxy: RuntimeProxy) -> OwnerReady | None:
        """A line before ready; only ready completes the attachment."""
        await self.deliver(proxy)
        return None

    async def deliver(self, proxy: RuntimeProxy) -> None:
        raise MalformedRecord(f"The owner sent {self.declared_name} to an attached client.")

    def reply(self) -> object:
        raise MalformedRecord(f"The owner answered a request with {self.declared_name}.")


@dataclass(frozen=True, kw_only=True)
class OwnerAnnouncement(OwnerLine):
    """The first line of every owner subscription, compared before any update."""

    core_commit: str = field(default_factory=lambda: package_stamp.STAMP.commit())

    def announced(self, thread: str) -> None:
        if self != OwnerAnnouncement():
            raise IncompatibleOwnerError(
                OtherCoreOwner(thread=thread, core_commit=self.core_commit)
            )


class ControllerTokenText(Token256Text):
    """The owner issues each attachment a 32-byte hex controller token."""


@dataclass(frozen=True, kw_only=True)
class OwnerReady(OwnerLine):
    """The subscription line that completes attachment: session metadata and its controller."""

    ready: dict[str, object]
    controller_token: Annotated[str, ControllerTokenText, WireName("controllerToken")]

    async def attach(self, proxy: RuntimeProxy) -> OwnerReady:
        return self


@dataclass(frozen=True, kw_only=True)
class OwnerUpdate(OwnerLine):
    """An ACP session update; its metadata is presented again for the attached session."""

    update: dict[str, object]
    meta: Annotated[dict[str, object], WireName("_meta")] = field(
        default_factory=dict
    )

    @classmethod
    def of(cls, update: BaseModel) -> Self:
        body = update.model_dump(by_alias=True, exclude_none=True)
        return cls(update=body, meta=cast(dict[str, object], body.pop("_meta", {})))

    async def deliver(self, proxy: RuntimeProxy) -> None:
        await proxy.present(self)


@dataclass(frozen=True, kw_only=True)
class OwnerPermissionRequest(OwnerLine):
    """A permission dialog for the attached controller, answered by its id."""

    id: str
    tool_call: Annotated[dict[str, object], WireName("toolCall")]
    options: list[dict[str, object]]

    async def deliver(self, proxy: RuntimeProxy) -> None:
        proxy.ask(self)


@dataclass(frozen=True, kw_only=True)
class OwnerResult(OwnerLine):
    """The single reply to a request that is not a subscription."""

    result: object

    def reply(self) -> object:
        return self.result


class RpcFailure(SubclassUnion, affix=""):
    """How a failed request raises again on the client: as its JSON-RPC error, or as text."""

    @abstractmethod
    def raised(self, error: str) -> Exception: ...


@dataclass(frozen=True)
class OwnerRpcError(RecordMember, RpcFailure):
    code: int
    message: str
    data: object = None

    def raised(self, error: str) -> Exception:
        return Refused(self.code, self.message, self.data)


@dataclass(frozen=True, slots=True)
class NoRpcError(NullMember, RpcFailure):
    """The failure was not a JSON-RPC error; the client raises its text."""

    def raised(self, error: str) -> Exception:
        return RuntimeError(error)


@dataclass(frozen=True, kw_only=True)
class OwnerFailure(OwnerLine):
    """A failed request. A JSON-RPC error raises again as itself on the client."""

    error: str
    rpc_error: Annotated[RpcFailure, WireName("rpcError")] = NoRpcError()

    @classmethod
    def of(cls, error: Exception) -> Self:
        return cls(error=str(error) or type(error).__name__)

    @classmethod
    def refused(cls, error: Refused) -> Self:
        data = error.data if isinstance(error.data, dict) else {}
        reason = data.get("details") or data.get("reason")
        # The pi project extension shows the text; Core clients raise the RPC error.
        return cls(
            error=reason if isinstance(reason, str) and reason else str(error),
            rpc_error=OwnerRpcError(error.code, str(error), error.data),
        )

    def raised(self) -> Exception:
        return self.rpc_error.raised(self.error)

    def announced(self, thread: str) -> None:
        raise self.raised()

    async def deliver(self, proxy: RuntimeProxy) -> None:
        raise self.raised()

    def reply(self) -> object:
        raise self.raised()


@dataclass(frozen=True, kw_only=True)
class ClientLine(SocketLine):
    """A line an attached client writes back to the owner."""

    declared_name = None  # a direction, not a line

    def answer(self, client: SocketClient) -> None:
        raise MalformedRecord(f"The client sent {self.declared_name} to the owner.")


@dataclass(frozen=True, kw_only=True)
class IncompatibleOwner(DeclaredFamily, affix="Owner"):
    thread: str
    FAILURE = "agentCommsIncompatibleOwner"

    @classmethod
    def from_failure(cls, data: object) -> IncompatibleOwner | None:
        if not isinstance(data, dict) or cls.FAILURE not in data:
            return None
        return FieldCodec.decode(cls, data.get(cls.FAILURE))

    def failure_metadata(self) -> dict:
        return {"reason": self.line(), self.FAILURE: FieldCodec.encode(self)}

    def line(self) -> str:
        return (f"The {self.thread} owner runs {self.owner_core()}, not this app's Core "
                f"{OwnerAnnouncement().core_commit[:9]}. Its history is shown read-only; sending opens after "
                f"the owner restarts while idle.")

    async def request(self, action: str, **_: object) -> dict:
        """The history-only attachment refuses every owner request with this owner's line."""
        raise Refused.invalid_params(self.failure_metadata())

    async def close(self) -> None:
        pass

    @abstractmethod
    def owner_core(self) -> str: ...


@dataclass(frozen=True, kw_only=True)
class UnannouncedOwner(IncompatibleOwner):
    def owner_core(self) -> str:
        return "an older Core"


@dataclass(frozen=True, kw_only=True)
class OtherCoreOwner(IncompatibleOwner):
    core_commit: str

    def owner_core(self) -> str:
        return f"Core {self.core_commit[:9]}"


class IncompatibleOwnerError(Exception):  # not a RuntimeError: reconnect loops do not retry it
    def __init__(self, owner: IncompatibleOwner) -> None:
        super().__init__(owner.line())
        self.owner = owner
