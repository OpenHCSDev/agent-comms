"""Native context observations own their presentation without nullable readings."""

from abc import abstractmethod
from dataclasses import dataclass

from agent_comms.nominal.declared_family import DeclaredFamily


class ContextReading(DeclaredFamily):
    @abstractmethod
    def label_parts(self) -> tuple[str, ...]: ...

    @abstractmethod
    def status_text(self) -> str: ...


@dataclass(frozen=True)
class ContextUsage(ContextReading):
    used: int
    size: int

    @property
    def context_percent(self) -> float:
        return self.used / self.size * 100

    @property
    def label(self) -> str:
        return f"{self.used:,}/{self.size:,} tokens ({self.context_percent:.1f}%)"

    def label_parts(self) -> tuple[str, ...]:
        return (self.label,)

    def status_text(self) -> str:
        return self.label


class UnsizedContext(ContextReading):
    """No share of the context window is known, so no usage update can carry it."""


@dataclass(frozen=True)
class UnmeasuredContext(UnsizedContext):
    def label_parts(self) -> tuple[str, ...]:
        return ()

    def status_text(self) -> str:
        return "Native owner has not reported context usage"


@dataclass(frozen=True)
class UnsizedContextUsage(UnsizedContext):
    """Usage a runtime reports without its context window, so no share of it is known."""

    used: int

    def label_parts(self) -> tuple[str, ...]:
        return (f"{self.used:,} tokens",)

    def status_text(self) -> str:
        return f"{self.used:,} tokens"
