"""State-owning ACP attachment lifecycle; turn and delivery effects stay external."""

from __future__ import annotations

import asyncio
import os
from collections.abc import Iterator
from dataclasses import dataclass
from functools import partial
from pathlib import Path
from typing import cast

from acp.schema import (
    AgentCapabilities,
    ClientCapabilities,
    CloseSessionResponse,
    Implementation,
    InitializeResponse,
    LoadSessionRequest,
    LoadSessionResponse,
    NewSessionRequest,
    NewSessionResponse,
    PromptCapabilities,
    SessionCapabilities,
    SessionCloseCapabilities,
    SessionInfoUpdate,
    TerminalAuthMethod,
)
from pydantic import JsonValue

from agent_comms import agent_events as events
from agent_comms.acp_extension import CoordinationChangedUpdate, GoalChangedUpdate, encode_updates
from agent_comms.comms import Comms
from agent_comms.config_options import ConfigOptions
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.errors import Refused
from agent_comms.errors import RelationViolationError
from agent_comms.execution.child_process import ProcessIdentity, join_retirement
from agent_comms.execution.controller import NO_CONTROLLER, NoController
from agent_comms.execution.input_key import InputKey, InputKeyText
from agent_comms.execution.launch_runtime import ThreadLaunch
from agent_comms.execution.owner_protocol import IncompatibleOwner, IncompatibleOwnerError
from agent_comms.execution.runtime import RuntimeProxy
from agent_comms.execution.session_config_options import SessionConfigOptions
from agent_comms.execution.session_effects import SessionEffects
from agent_comms.execution.session_owner_reads import OwnedSessionLifetime
from agent_comms.execution.session_reads import SessionClient, SessionConfigurationSource
from agent_comms.execution.turn_input_source import NoTurnAcceptance
from agent_comms.nominal.field_codec import (
    AcpSessionId,
    FieldCodec,
    MalformedRecord,
    boundary_decoder,
)
from agent_comms.projects.checkouts import Checkout
from agent_comms.registry.registry_document import RegistryEntry
from agent_comms.registry.thread_identity import (
    AcpThreadRole,
    ClaimedIdentity,
    OwnerIdentity,
    ThreadIncarnation,
)
from agent_comms.registry.thread_model import ThreadModel
from agent_comms.registry.thread_presentation import (
    ExistingSessionLoadPlan,
    FailedSessionLoadPlan,
    SessionLoadPlan,
)
from agent_comms.registry.thread_status import ActiveThreadPresence
from agent_comms.registry.thread_text import NoThreadText, ThreadText
from agent_comms.registry.threads import NativeThread, Thread
from agent_comms.team.pi_rule_gate import PiRedeal
from agent_comms.transcript.transcript_updates import TranscriptReplay
from agent_comms.transport.owner_requests import RetainedOwnerLaunch
from agent_comms.transport.runtime_requests import (
    FreshSubscribeRuntimeRequest,
    SubscribeRuntimeRequest,
)
from agent_comms.transport.runtime_server import RuntimeServer


@dataclass(frozen=True)
class PublishedSession:
    """The thread metadata a session last published, derived from its Thread."""

    name: str
    title: ThreadText
    worktree: Checkout

    @classmethod
    def of(cls, thread: Thread) -> PublishedSession:
        return cls(thread.name, thread.title, thread.worktree)


class SessionLifecycle(SessionConfigurationSource[RuntimeProxy | IncompatibleOwner]):
    def __init__(
        self,
        comms: Comms,
        runtime: RuntimeServer,
        effects: SessionEffects,
    ):
        self.comms = comms
        self.runtime, self.effects = runtime, effects
        self.published: dict[AcpSessionId, PublishedSession] = {}
        self.client: SessionClient | NoController = NO_CONTROLLER
        self.proxies: dict[AcpSessionId, RuntimeProxy | IncompatibleOwner] = {}
        self._attachment_lock = asyncio.Lock()
        self._identity_lock = asyncio.Lock()
        self.transcript = TranscriptReplay(comms)
        self.config = SessionConfigOptions(comms, runtime, self, effects)

    async def initialize(
        self,
        protocol_version: int,
        client_capabilities: ClientCapabilities | None = None,
        client_info: Implementation | None = None,
    ) -> InitializeResponse:
        methods: list[TerminalAuthMethod] = []
        if (
            client_capabilities is not None
            and client_capabilities.auth is not None
            and client_capabilities.auth.terminal
        ):
            methods = [
                TerminalAuthMethod(
                    type="terminal",
                    id="pi-login",
                    name="Connect a provider",
                    description="Choose a provider and sign in using Pi's native UI",
                    args=["--login"],
                )
            ]
        return InitializeResponse(
            protocol_version=protocol_version,
            agent_capabilities=AgentCapabilities(
                load_session=True,
                prompt_capabilities=PromptCapabilities(image=True),
                session_capabilities=self.session_capabilities(),
            ),
            agent_info=Implementation(name="agent-comms", title="Agent Comms", version="0.1.0"),
            auth_methods=methods,
        )

    def session_capabilities(self) -> SessionCapabilities:
        return SessionCapabilities()

    async def close_session(self, session_id: AcpSessionId) -> CloseSessionResponse:
        # An executing owner is not an attachment. Its turn/input retirement
        # remains with shutdown, rather than treating tab close as owner stop.
        raise Refused.method_not_found("session/close")

    def require(self, session_id: AcpSessionId) -> str:
        if session_id not in self.published:
            raise Refused.invalid_params({"reason": f"Unknown sessionId: {session_id!r}"})
        return self.published[session_id].name

    def publish(self, session_id: AcpSessionId, thread: Thread) -> None:
        """This session is now the thread's published ACP session."""
        self.published[session_id] = PublishedSession.of(thread)

    def binds(self, session_id: AcpSessionId, name: object) -> bool:
        """Whether this session is published as the named thread."""
        return session_id in self.published and self.published[session_id].name == name

    def require_owned_session(self, entry: RegistryEntry) -> AcpSessionId:
        """Resolve an original loaded resource; registration grants no attachment."""
        return self._require_session(self.owned_sessions(entry), entry)

    def require_fenced_session(self, entry: RegistryEntry) -> AcpSessionId:
        """The loaded resource a stop fenced; the fence already advanced its lease."""
        return self._require_session(self.fenced_sessions(entry.thread.incarnation), entry)

    @staticmethod
    def _require_session(sessions: Iterator[AcpSessionId], entry: RegistryEntry) -> AcpSessionId:
        for session_id in sessions:
            return session_id
        raise Refused.invalid_params({
            "reason": f"Registered owner {entry.thread.name!r} has no loaded ACP session. "
                      "PID registration does not attach a session.",
            "owner": entry.thread.name,
        })

    def owned_sessions(self, entry: RegistryEntry) -> Iterator[AcpSessionId]:
        """Published sessions whose retained owner lease is this entry's allocation, birth
        and generation, under any of the thread's names. A same-name replacement, or the same
        birth under a later lease, owns none of them."""
        return (owner.identifier for owner in self._retained() if owner.owner == entry.owner_identity)

    def fenced_sessions(self, incarnation: ThreadIncarnation) -> Iterator[AcpSessionId]:
        """A stop advances the lease when it fences a birth; the sessions that birth retained
        are its to retire, under the lease they were bound with."""
        return (owner.identifier for owner in self._retained() if owner.owner.incarnation == incarnation)

    def _retained(self) -> Iterator[OwnedSessionLifetime]:
        """The published sessions holding local execution, with the owner lease each bound."""
        return (owner for state in self.effects.inputs.drained.values() for owner in state.executors()
                if owner.identifier in self.published)

    @staticmethod
    def reject_foreign_mcp(request: NewSessionRequest | LoadSessionRequest) -> None:
        if request.mcp_servers:
            raise Refused.invalid_params(
                {
                    "reason": (
                        "ACP mcpServers are unsupported; use Pi's native MCP package configuration."
                    )
                }
            )

    @boundary_decoder
    def declare_thread(self, cwd: str) -> Thread:
        """Decode the ACP directory and register before choosing its executor."""
        checkout = FieldCodec.decode(Checkout, cwd)
        thread = self.comms.threads.claim_thread(
            checkout.path.name,
            tags=frozenset({"acp"}),
            worktree=checkout,
            model=ThreadModel.selected_by(self.effects.inputs.configuration.agent_args),
            thinking_level=self.effects.inputs.configuration.agent_args.thinking,
            auto_title_pending=True,
            role=AcpThreadRole,
        )
        self.comms.registry.restore_stopped(self.comms.registry.snapshot(), (thread.name,))
        return self.acquire_declared_thread(thread)

    def acquire_declared_thread(self, thread: Thread) -> Thread:
        """An owning ACP lifecycle acquires its calling process after publication."""
        return self.comms.owners.acquire_thread(thread.name)

    def validated_thread(self, cwd: Checkout, session_id: AcpSessionId) -> Thread:
        thread = self.comms.registry.require_member(session_id, NativeThread)
        if not thread.contains_worktree(cwd, self.comms.registry.storage_rule):
            raise Refused.invalid_params(
                {"reason": "The saved thread belongs to a different working directory."}
            )
        return thread

    async def bind_owned(self, thread: Thread, session_id: AcpSessionId) -> None:
        owner = (await Coordination.run_worker(partial(
            self.comms.registry.entry, thread.name,
        ))).entry.owner_identity
        await self.bind_owner(thread, session_id, self.effects.inputs.configuration, owner)

    async def bind_owner(
        self, thread: Thread, session_id: AcpSessionId,
        configuration: ConfigOptions, owner: OwnerIdentity,
    ) -> OwnedSessionLifetime:
        async with self._attachment_lock:
            await self.retire_proxy(session_id)
        await Coordination.run_worker(PiRedeal.of(self.comms, thread).start)
        # Acquisition starts the authentication producer. Publish its session
        # in the same loop turn, before any await can let that producer read it.
        state = self.effects.inputs.acquire_owner(session_id, configuration, owner)
        self.publish(session_id, thread)
        await self.runtime.start()
        return state

    async def new_session(self, request: NewSessionRequest) -> NewSessionResponse:
        self.reject_foreign_mcp(request)
        await Coordination.run_worker(self.comms.owners.require_private_launch)
        thread = await Coordination.run_worker(partial(self.declare_thread, request.cwd))
        session_id = AcpSessionId(thread.name)
        await self.bind_owned(thread, session_id)
        self.effects.inputs.ensure_live_drain(session_id)
        response = NewSessionResponse(
            session_id=session_id,
            field_meta=await self.metadata(thread.name, session_id=session_id),
        )
        self.config.start_menu(session_id, self.runtime)
        return response

    async def load_session(self, request: LoadSessionRequest) -> LoadSessionResponse:
        self.reject_foreign_mcp(request)
        session_id = FieldCodec.decode(AcpSessionId, request.session_id)
        thread = await self._acquire_loaded(FieldCodec.decode(Checkout, request.cwd), session_id)
        if not thread.process_identity.runs_here():
            return await self.attach_owner(thread, session_id)
        await self._bind_loaded(thread, session_id)
        await self.transcript.replay(
            thread.name, session_id=session_id, client=self.runtime,
        )
        self.effects.inputs.ensure_live_drain(session_id)
        response = LoadSessionResponse(
            field_meta=await self.metadata(thread.name, session_id=session_id),
        )
        self.config.start_menu(session_id, self.runtime)
        return response

    async def start_owner(self, launch: RetainedOwnerLaunch, owner: OwnerIdentity) -> None:
        """Attach the reserved lease using that owner's original launch, not the host ingress."""
        if not launch.process.runs_here():
            raise RelationViolationError("The launch does not name this worker host")
        selected = ThreadLaunch.current(launch.environment)
        entry = (await Coordination.run_worker(partial(
            self.comms.registry.entry, owner.incarnation.name,
        ))).entry
        thread = entry.require_owner_process(owner, launch.process)
        if not entry.matches_name(selected.name):
            raise RelationViolationError("Owner environment names another thread")
        session_id = AcpSessionId(thread.name)
        state = await self.bind_owner(
            thread, session_id, ConfigOptions(launch, self.comms.route), owner)
        self.effects.inputs.ensure_live_drain(session_id)
        key = selected.take_startup_input(launch.environment)
        if key:
            self.runtime.background(self.run_startup_input(state, InputKeyText.decode(key)))

    async def run_startup_input(self, state: OwnedSessionLifetime, key: InputKey) -> None:
        """Consume only the explicitly authorized first input; never scan or replay."""
        session_id = state.identifier
        async with state.turn_lock:
            async with state.own_turn_task():
                def capture() -> str:
                    snapshot = self.comms.registry.snapshot()
                    thread = snapshot.require(state.owner.incarnation.name)
                    return self.effects.inputs.dispositions.lookup(key).queued_text(
                        thread.incarnation, snapshot.claim_generation(thread.name))
                text = await Coordination.run_worker(capture)
                await self.effects.inputs.emit_input_delivery_changed(session_id)
                await self.effects.turns.run_agent_turn(
                    session_id, session_id, text, acceptance=NoTurnAcceptance(),
                    original_keys=(key,), original_owner_input=True,
                )

    async def complete_unheld(self, expected: OwnerIdentity, claim: ClaimedIdentity) -> None:
        """A fenced owner whose session this host never held (an aborted start) completes
        here, the process its row is bound to."""
        await Coordination.run_worker(partial(
            self.comms.owners.complete_session, expected, expected,
            ProcessIdentity.capture(os.getpid()), claim.claimed_generation,
        ))

    async def retire_owner(self, state: OwnedSessionLifetime, expected: OwnerIdentity, claim: ClaimedIdentity) -> None:
        """Only a completed retirement is remembered: a failed attempt (a busy store lock)
        fails its own stop request and leaves the next stop to retry every idempotent step."""
        async with state.retirement_lock:
            if state.retired.done():
                return
            state.request_stop()
            self.runtime.retire_session(state.identifier)
            await self.effects.inputs.close_sessions((state,))
            await state.join_observations()
            await self.effects.turns.close_sessions((state,))
            await Coordination.run_worker(partial(
                self.comms.owners.complete_session, state.owner, expected,
                state.configuration.launch.process, claim.claimed_generation,
            ))
            self.config.stop_observing_configuration(state.identifier)
            del self.published[state.identifier]
            self.effects.inputs.end_session(state.identifier)
            state.retired.set_result(None)

    async def _acquire_loaded(self, cwd: Checkout, session_id: AcpSessionId) -> Thread:
        await Coordination.run_worker(self.comms.owners.require_private_launch)
        thread = await Coordination.run_worker(partial(self.validated_thread, cwd, session_id))
        if not (
            self.binds(session_id, thread.name)
            and thread.process_identity.runs_here()
            and (await Coordination.run_worker(partial(self.comms.registry.status, thread.name)))
                .items_with(ActiveThreadPresence, thread)
        ):
            thread = await Coordination.run_worker(partial(
                self.comms.owners.acquire_thread, thread.name,
            ))
        return thread

    async def _bind_loaded(self, thread: Thread, session_id: AcpSessionId) -> None:
        await self.bind_owned(thread, session_id)
        await self.effects.inputs.emit_input_delivery_changed(session_id)

    async def attach_owner(
        self, thread: Thread, session_id: AcpSessionId,
        subscription: type[SubscribeRuntimeRequest] = SubscribeRuntimeRequest,
    ) -> LoadSessionResponse:
        async with self._attachment_lock:
            await self.retire_proxy(session_id)
            snapshot = await Coordination.run_worker(self.comms.registry.snapshot)
            binding = snapshot.owner_binding(thread.name)
            failed_command = FailedSessionLoadPlan(binding)
            proxy = await Coordination.run_worker(partial(self.effects._create_runtime_proxy, thread, session_id))
            try:
                snapshot.require_owner_process(snapshot.owner_identity(thread.name), thread.require_process())
                metadata = await proxy.subscribe(subscription)
                self.proxies[session_id] = proxy
            except IncompatibleOwnerError as error:
                # History is Core's own store; only owner requests need the owner's Core.
                await self.transcript.replay(
                    thread.name, session_id=session_id, client=self.runtime,
                )
                self.proxies[session_id] = error.owner
                return LoadSessionResponse(field_meta={
                    **await self.metadata(thread.name, session_id=session_id),
                    **error.owner.failure_metadata(), **ExistingSessionLoadPlan(binding).metadata(),
                })
            except (OSError, RuntimeError, RelationViolationError, MalformedRecord) as error:
                raise Refused.invalid_params(
                    {"reason": (
                        f"Unable to attach to {thread.name!r} owner {thread.process_identity}: {error}"
                     ), **failed_command.failure_metadata()}
                ) from error
            finally:
                if self.proxies.get(session_id) is not proxy:
                    await proxy.close()
            return LoadSessionResponse(
                field_meta={**metadata, **ExistingSessionLoadPlan(binding).metadata()},
            )

    async def sync_identity(self, session_id: AcpSessionId) -> str:
        """Publish each observed identity generation once across concurrent consumers."""
        async with self._identity_lock:
            cached_name = self.require(session_id)
            entry = (await Coordination.run_worker(partial(
                self.comms.registry.entry, cached_name,
            ))).entry
            thread = entry.thread
            if any(owner.owner.incarnation != thread.incarnation
                   for owner in self.effects.inputs.state(session_id).executors()):
                await self.effects.turns.close_idle_backend(session_id)
                raise RelationViolationError(
                    f"{cached_name!r} now names another thread; this session stays its original's")
            name = thread.name
            if (
                name != cached_name
                or not thread.process_identity.runs_here()
                or not entry.status.running
            ):
                await self.effects.turns.close_idle_backend(session_id)
            current = PublishedSession.of(thread)
            if self.published[session_id] != current:
                await self.publish_metadata(session_id, title=thread.title)
                self.published[session_id] = current
            return name

    @boundary_decoder
    async def publish_metadata(
        self, session_id: AcpSessionId, *, title: ThreadText = NoThreadText(),
    ) -> None:
        """Encode the thread's title once for the ACP metadata boundary."""
        await self.runtime.publish_update(
            session_id=session_id,
            update=SessionInfoUpdate(
                session_update="session_info_update",
                title=cast(str | None, FieldCodec.encode(title)),
                field_meta=await self.metadata(self.require(session_id), session_id=session_id),
            ),
        )

    async def observe_native_configuration(
        self, session_id: AcpSessionId, thread_name: str, event: events.NativeMetadataObservation
    ) -> None:
        """Initialize only unset configuration from its actual native producer."""
        await Coordination.run_worker(partial(
            self.comms.threads.initialize_native_configuration,
            thread_name, model=event.model, thinking_level=event.thinking_level,
        ))

    def configuration_updates(
        self, thread_name: str,
    ) -> tuple[CoordinationChangedUpdate, GoalChangedUpdate]:
        """Capture original store projections before loop/client effects consume them."""
        snapshot = GoalChangedUpdate.from_snapshot(self.comms.goals.goal_snapshot(thread_name))
        return self.comms.configuration.answer(thread_name), snapshot

    async def metadata(self, thread_name: str, *, session_id: AcpSessionId) -> dict[str, JsonValue]:
        configuration = await Coordination.run_worker(partial(
            self.configuration_updates, thread_name,
        ))
        return encode_updates(
            *configuration,
            await self.effects.inputs.queue_state(session_id),
            *await self.effects.cursors.trusted_metadata(thread_name, session_id),
        )

    async def retire_proxy(self, session_id: AcpSessionId) -> None:
        """Keep the proxy registered until its reader is closed and awaited."""
        proxy = self.proxies.get(session_id)
        if proxy is not None:
            retirement = asyncio.create_task(proxy.close())
            try:
                await join_retirement(retirement)
            finally:
                if retirement.done() and not retirement.cancelled() and retirement.exception() is None:
                    del self.proxies[session_id]
                    self.effects.inputs.end_session(session_id)

    async def close_proxies(self) -> None:
        async with self._attachment_lock:
            for session_id in tuple(self.proxies):
                await self.retire_proxy(session_id)

    async def release_owned(self) -> None:
        """Release every owned thread, then report each release that failed.

        This includes a thread this process was launched to own but failed to
        bind: otherwise a startup failure leaves it registered as running with
        a dead process. One failed stop must not keep the others registered as
        running, and it must not disappear either: the failures surface
        together after the runtime has closed.
        """
        failures: list[Exception] = []
        try:
            names = {
                owner.owner.incarnation.name
                for state in self.effects.inputs.drained.values()
                for owner in state.executors()
            }
            owners = await Coordination.run_worker(partial(self.comms.owners.fence_stop, *names))
            requests = await Coordination.run_worker(partial(self.comms.owners.stop_requests, owners))
            for request in requests:
                try:
                    entry = (await Coordination.run_worker(partial(
                        self.comms.registry.entry, request.thread))).entry
                    state = self.effects.inputs.state(self.require_fenced_session(entry)).owned()
                    await request.retire(self, state)
                except (OSError, ValueError) as error:
                    failures.append(error)
        finally:
            await self.config.close()
            await self.runtime.close()
        if failures:
            raise ExceptionGroup("Owned threads were not released at shutdown", failures)


class AttachedSessionLifecycle(SessionLifecycle):
    """A stdio attachment requests a separate executor; it never claims ownership."""

    def session_capabilities(self) -> SessionCapabilities:
        return SessionCapabilities(close=SessionCloseCapabilities()) if (
            self.effects.use_unstable_protocol
        ) else super().session_capabilities()

    async def close_session(self, session_id: AcpSessionId) -> CloseSessionResponse:
        if not self.effects.use_unstable_protocol:
            raise Refused.method_not_found("session/close")
        async with self._attachment_lock:
            if session_id not in self.proxies:
                raise Refused.invalid_params({"reason": "Unknown attached session"})
            await self.retire_proxy(session_id)
        return CloseSessionResponse()

    def acquire_declared_thread(self, thread: Thread) -> Thread:
        """Leave the registered declaration for the load operation to check."""
        return thread

    async def new_session(self, request: NewSessionRequest) -> NewSessionResponse:
        self.reject_foreign_mcp(request)
        thread = await Coordination.run_worker(partial(self.declare_thread, request.cwd))
        session_id = AcpSessionId(thread.name)
        loaded = await self._attach_requested_session(
            thread,
            session_id,
            (request.field_meta or {}).get("agentCommsLoad"),
            FreshSubscribeRuntimeRequest,
        )
        return NewSessionResponse(
            session_id=session_id,
            field_meta=loaded.field_meta,
        )

    async def load_session(self, request: LoadSessionRequest) -> LoadSessionResponse:
        self.reject_foreign_mcp(request)
        session_id = FieldCodec.decode(AcpSessionId, request.session_id)
        thread = await Coordination.run_worker(
            partial(self.validated_thread, FieldCodec.decode(Checkout, request.cwd), session_id)
        )
        return await self._attach_requested_session(
            thread,
            session_id,
            (request.field_meta or {}).get("agentCommsLoad"),
            SubscribeRuntimeRequest,
        )

    async def _attach_requested_session(
        self, thread: Thread, session_id: AcpSessionId, load_metadata: object,
        subscription: type[SubscribeRuntimeRequest],
    ) -> LoadSessionResponse:
        try:
            plan = SessionLoadPlan.at_ingress(load_metadata)
            owner = await plan.resolve(self, thread)
        except (OSError, RuntimeError, RelationViolationError, MalformedRecord) as error:
            raise Refused.invalid_params(
                {"reason": f"Session load not authorized for {thread.name!r}: {error}"}
            ) from error
        return await self.attach_owner(owner, session_id, subscription)
