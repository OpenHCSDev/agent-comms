"""Selected stage declarations own claim, reservation and prelaunch-binding identity."""

from __future__ import annotations

import asyncio
import sqlite3
from abc import ABC, abstractmethod
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass

from agent_comms.coordination.assignment_states import (
    DeferredAssignment,
    FailedAssignment,
    TriagePendingAssignment,
)
from agent_comms.coordination.coordinator import Coordination
from agent_comms.coordination.durable_turn import DurableTurn
from agent_comms.coordination.errors import IdentityConflict, RetryScheduled, StaleFence
from agent_comms.coordination.tables.assignments import WakeAssignment
from agent_comms.execution.native_entries import NativeEvidenceScope
from agent_comms.execution.native_input_owner import ParticipantOwner
from agent_comms.execution.native_input_proof import NativeContextProof
from agent_comms.execution.native_input_record import (
    FullNativeExecution,
    NativeInputExecution,
    NativeInputIdentity,
    TriageNativeExecution,
)
from agent_comms.execution.native_prompt_binding import (
    PromptBinding,
    expected_prompt_bindings,
    expected_prompt_matches_journal,
)
from agent_comms.execution.native_runtime_input import NativeRuntimeInput, NativeRuntimeTable
from agent_comms.execution.native_session_files import NativeSessionFiles
from agent_comms.execution.private_send_rules import (
    NativeClaimCheck,
    NativeIdentityCheck,
    NativeReservationCheck,
)
from agent_comms.execution.private_sidecar import native_request_digest
from agent_comms.execution.reservation_rules import ReservationRule, ReservationViolationError
from agent_comms.execution.selected.triage import DecidedTriageRecord, SelectedTriage
from agent_comms.execution.turn_failure import TurnFailure
from agent_comms.nominal.field_codec import InputId, RootId, ThreadLookup
from agent_comms.nominal.lifecycle_capability import Active
from agent_comms.nominal.text_digest import TextDigest
from agent_comms.storage.typed_table import SqlValue


@dataclass(frozen=True, kw_only=True)
class NativeBindingCheck(NativeIdentityCheck):
    row: PromptBinding
    wire_root_id: RootId
    prompt_digest: TextDigest


class NativeBindingRootRule(ReservationRule):
    check_type = NativeBindingCheck
    explanation = "The prelaunch binding belongs to a different wire root."

    def violated(self, check: NativeBindingCheck) -> bool:
        return check.row.wire_root_id != check.wire_root_id


class NativeBindingContentRule(ReservationRule):
    check_type = NativeBindingCheck
    explanation = "The native request digest differs from its durable prelaunch binding."

    def violated(self, check: NativeBindingCheck) -> bool:
        return TextDigest(check.row.expected_prompt_digest) != check.prompt_digest


@dataclass(frozen=True)
class NativeSendStage(ABC):
    assignments: tuple[WakeAssignment, ...]

    @property
    def recipient_lookup(self) -> ThreadLookup:
        """Require every assignment to name the same permitted recipient."""
        lookups = {row.recipient_lookup for row in self.assignments}
        if len(lookups) != 1:
            raise IdentityConflict("Native batch requires one original participant")
        return next(iter(lookups))

    @property
    @abstractmethod
    def execution(self) -> NativeInputExecution: ...

    @abstractmethod
    def require_phase(self, store: Coordination, current: WakeAssignment) -> None: ...

    @abstractmethod
    def reserve_claim(self, store: Coordination, db: sqlite3.Connection) -> None:
        """Fence this stage and reject any previous dispatch before inserting an ID."""

    @abstractmethod
    def fail_terminal(
        self,
        store: Coordination,
        owner: ParticipantOwner,
        input_id: InputId,
        token_digest: str,
        context: NativeContextProof,
        failure: TurnFailure,
    ):
        """Record the failed input's verified model context and fail its claims.

        The native child is reaped and ``context`` was verified against the
        session file. Recording it states which model context the input entered,
        as a successful input records it. A failed input is never sent again.
        """

    async def continue_after_failure(self, settlement, failure: TurnFailure) -> None:
        """Triage and terminal full failures have no subsequent attempt."""

    async def fail_unknown(self, bus, owner, witness) -> None:
        await Coordination.run_worker(lambda: owner.require_registry(bus._registry))

    def reserve(self, store: Coordination, owner: ParticipantOwner, token_digest: str,
                *, attempt: int = 0) -> str:
        input_id = InputId.mint()
        with store.session.writing() as db:
            NativeRuntimeTable.require_installed(db)
            owner.require(store, self.recipient_lookup)
            self.reserve_claim(store, db, attempt=attempt)
            NativeRuntimeInput(
                input_id=input_id,
                stage=type(self.execution),
                **self.execution.binding_fields(),
                owner_lookup=self.recipient_lookup,
                owner_generation=owner.generation,
                owner_token_digest=token_digest,
            ).insert(db)
            self.execution.record_sources(db, input_id, self.assignments, attempt=attempt)
        return input_id

    def identity(self, input_id: InputId, owner) -> NativeInputIdentity:
        return NativeInputIdentity(
            input_id, self.execution, owner,
        )

    def pending_input(
        self, store: Coordination, input_id: InputId, owner: ParticipantOwner, token_digest: str
    ) -> NativeRuntimeInput:
        """Read current durable ownership inside the caller's read/write transaction."""
        db = store.session._connection
        NativeRuntimeTable.require_installed(db)
        owner.require(store, self.recipient_lookup)
        row = NativeRuntimeInput.one(db, input_id=input_id)
        if row is None:
            raise StaleFence("native input reservation is missing")
        self.require_sources(db, input_id)
        try:
            NativeIdentityCheck(
                row=row,
                expected=self.identity(
                    row.input_id, owner.coordinator_identity(self.recipient_lookup),
                ),
            ).require_valid()
        except ReservationViolationError as error:
            raise StaleFence(f"native dispatch identity changed: {error}") from error
        row.require_dispatch(token_digest)
        return row

    def require_acknowledgement(self, store: Coordination) -> None:
        self.require_claim(store)

    def acknowledge_context(
        self, store: Coordination, owner: ParticipantOwner, input_id: InputId,
        token_digest: str, context: NativeContextProof,
    ) -> None:
        with store.session.writing() as db:
            row = self.pending_input(store, input_id, owner, token_digest)
            self.require_acknowledgement(store)
            row.commit_context(db, context)

    def verify(
        self,
        store: Coordination,
        owner: ParticipantOwner,
        input_id: InputId,
        token_digest: str,
        context: NativeContextProof,
        *,
        wire_root_id: RootId,
        prompt: str,
        source_reads: NativeEvidenceScope,
    ) -> None:
        # The native boundary validated the live RPC events before returning.
        # Disk evidence corroborates those events, never authorizes recovery.
        with source_reads.borrow():
            evidence = source_reads.for_source(context.session_file)
            if not evidence.corroborates_context(
                context, input_id=input_id,
                files=NativeSessionFiles.for_identity(context.session_identity(),
                                         root=store.session.path.parent,
                                         owner=owner.thread.incarnation.require_recorded()),
            ):
                raise IdentityConflict(
                    "Pi live assembled context differs from its reserved input proof"
                )
            # Binding writers acquire sidecar before SQL. Keep that order here,
            # and finish journal I/O before acquiring the coordinator snapshot.
            with self.bound_prompt(store, input_id, owner, wire_root_id, prompt) as binding:
                if not expected_prompt_matches_journal(context.session_file, binding, evidence=evidence):
                    raise IdentityConflict("live native input lacks exact bound source prompt equality")
                with store.session.read():
                    original = self.pending_input(store, input_id, owner, token_digest)
                    original.require_session_identity().require_context(context)

    def require_claim(self, store: Coordination) -> None:
        for captured in self.assignments:
            current = store.assignments.get(captured.assignment_id)
            try:
                NativeClaimCheck(captured=captured, current=current).require_valid()
            except ReservationViolationError as error:
                raise StaleFence(
                    f"selected claim identity changed before native send: {error}"
                ) from error
            self.require_phase(store, current)

    def require_reservation(
        self, db: sqlite3.Connection, input_id: InputId, owner: ParticipantOwner, token_digest: str
    ) -> NativeRuntimeInput:
        reserved = NativeRuntimeInput.one(db, input_id=input_id)
        if reserved is None:
            raise StaleFence("native reservation missing before send")
        self.require_sources(db, input_id)
        try:
            NativeReservationCheck(
                row=reserved,
                expected=self.identity(
                    reserved.input_id, owner.coordinator_identity(self.recipient_lookup),
                ),
                token_digest=token_digest,
            ).require_valid()
        except ReservationViolationError as error:
            raise StaleFence(f"native reservation changed before send: {error}") from error
        return reserved

    def require_sources(self, db, input_id) -> None:
        if self.execution.source_assignment_ids(db, input_id) != tuple(
            row.assignment_id for row in self.assignments
        ):
            raise IdentityConflict("Native input changed its original source membership")

    @contextmanager
    def bound_prompt(
        self, store: Coordination, input_id: InputId, owner: ParticipantOwner,
        wire_root_id: RootId, prompt: str,
    ) -> Iterator[PromptBinding]:
        with expected_prompt_bindings(store, (input_id,)) as bindings:
            binding = bindings.get(input_id)
            self.require_bound_prompt(binding, owner, wire_root_id, prompt)
            yield binding

    def require_bound_prompt(
        self, binding: PromptBinding | None, owner: ParticipantOwner,
        wire_root_id: RootId, prompt: str,
    ) -> None:
        if binding is None:
            raise IdentityConflict("native send has no durable prompt binding")
        try:
            NativeBindingCheck(
                row=binding,
                expected=self.identity(
                    binding.input_id, owner.coordinator_identity(self.recipient_lookup),
                ),
                wire_root_id=wire_root_id,
                prompt_digest=TextDigest(native_request_digest(prompt)),
            ).require_valid()
        except ReservationViolationError as error:
            raise IdentityConflict(
                f"native send differs from its durable prompt binding: {error}"
            ) from error


class TriageNativeSend(NativeSendStage):
    def fail_terminal(
        self, store, owner, input_id, token_digest, context, failure
    ) -> tuple[WakeAssignment, ...]:
        return self.fail_decision(store, owner, input_id, token_digest, context)

    def fail_decision(
        self, store, owner, input_id, token_digest, context
    ) -> tuple[WakeAssignment, ...]:
        """A provider failure and an unparseable decision both end the triage here.

        The context and the failed claims commit in one transaction; no
        replacement triage input is reserved.
        """
        with store.session.writing() as db:
            row = self.pending_input(store, input_id, owner, token_digest)
            self.require_claim(store)
            row.commit_context(db, context)
            return self.fail_claims(store, db)

    def refreshed(self, store: Coordination) -> TriageNativeSend:
        """The same claims at their current revision, for a reservation after one turn."""
        return TriageNativeSend(tuple(
            store.assignments.get(captured.assignment_id) for captured in self.assignments
        ))

    def burn_turn(
        self, store, owner, input_id, token_digest, context
    ) -> None:
        """Close the answer that failed and leave the claim owing a decision.

        The reader gets one more ask because the decision was unreadable, not because
        the provider failed: the claim returns to triage-pending so a replacement input
        may be reserved for it.
        """
        with store.session.writing() as db:
            row = self.pending_input(store, input_id, owner, token_digest)
            self.require_claim(store)
            row.commit_context(db, context)
            for captured in self.assignments:
                current = store.assignments.get(captured.assignment_id)
                WakeAssignment.update(
                    db,
                    where="assignment_id=? AND revision=?",
                    parameters=(current.assignment_id, current.revision),
                    lifecycle=TriagePendingAssignment.build(current.lifecycle.mode, None, None),
                    revision=current.revision + 1,
                    updated_at_ms=store.session.now(current.updated_at_ms),
                )

    def fail_claims(self, store: Coordination, db: sqlite3.Connection) -> tuple[WakeAssignment, ...]:
        """Move this triage's deferred claims to Failed inside the caller's transaction."""
        for captured in self.assignments:
            current = store.assignments.get(captured.assignment_id)
            if current.lifecycle != DeferredAssignment.build(current.lifecycle.mode, None, None):
                raise StaleFence("failed triage claim is no longer deferred")
            updated = WakeAssignment.update(
                db,
                where="assignment_id=? AND revision=?",
                parameters=(current.assignment_id, current.revision),
                lifecycle=current.lifecycle.preengagement(FailedAssignment),
                revision=current.revision + 1,
                updated_at_ms=store.session.now(current.updated_at_ms),
            )
            if updated.rowcount != 1:
                raise StaleFence("failed triage lost an original batch claim")
        return tuple(store.assignments.get(captured.assignment_id)
                     for captured in self.assignments)

    @property
    def execution(self) -> TriageNativeExecution:
        return TriageNativeExecution()

    def reserve_claim(self, store: Coordination, db: sqlite3.Connection,
                      *, attempt: int = 0) -> None:
        """Reserve the original ask, or the one replacement an unparseable decision earns."""
        if attempt not in (0, 1):
            raise IdentityConflict("A triage claim has one original ask and one replacement")
        for captured in self.assignments:
            current = store.assignments.get(captured.assignment_id)
            if current != captured or not current.lifecycle.requires_selected_triage():
                raise IdentityConflict("triage claim changed before native batch reservation")
            if SqlValue.for_annotation(int).read(db.execute(
                f"SELECT 1 FROM ({self.execution.source_membership_sql()}) members "
                "WHERE members.assignment_id=? AND members.attempt>=? LIMIT 1",
                (captured.assignment_id, attempt),
            )):
                raise IdentityConflict("triage source was previously reserved; no second replacement")
            # All original CASes and the one reserved input commit before Pi.
            update = WakeAssignment.update(
                db,
                where="assignment_id=? AND revision=? AND disposition='triage_pending'",
                parameters=(current.assignment_id, current.revision),
                lifecycle=DeferredAssignment.build(current.lifecycle.mode, None, None),
                revision=current.revision + 1,
                updated_at_ms=store.session.now(current.updated_at_ms),
            )
            if update.rowcount != 1:
                raise IdentityConflict("triage batch reservation lost an original claim CAS")

    def commit(
        self,
        store: Coordination,
        owner: ParticipantOwner,
        input_id: InputId,
        token_digest: str,
        context: NativeContextProof,
        decision: SelectedTriage,
    ) -> tuple[WakeAssignment, ...]:
        with store.session.writing() as db:
            row = self.pending_input(store, input_id, owner, token_digest)
            self.require_claim(store)
            row.commit_context(db, context)
            row.settle_verdict(db, DecidedTriageRecord(type(decision)))
            for captured in self.assignments:
                decision.settle(store, db, store.assignments.get(captured.assignment_id))
            # This is the settlement transaction's witness, not a replacement
            # source cache. Engagement must fence this exact proved transition.
            return tuple(store.assignments.get(captured.assignment_id)
                         for captured in self.assignments)

    def require_phase(self, store: Coordination, current: WakeAssignment) -> None:
        if (
            current.lifecycle
            != DeferredAssignment.build(current.lifecycle.mode, None, None)
            or current.revision != next(
                row.revision for row in self.assignments if row.assignment_id == current.assignment_id
            ) + 1
        ):
            raise StaleFence("triage claim changed before native send")


@dataclass(frozen=True)
class FullNativeSend(NativeSendStage):
    progress: DurableTurn

    @property
    def fence(self):
        # Native observations advance the existing durable attempt owner. Never
        # capture a second fence which goes stale while tools/model events run.
        return self.progress.fence

    @property
    def execution(self) -> FullNativeExecution:
        return FullNativeExecution(self.fence.execution_id, self.fence.attempt_ordinal)

    def fail_terminal(self, store, owner, input_id, token_digest, context, failure):
        # Same order as success: record the context under the live attempt,
        # then settle the attempt.
        with store.session.writing() as db:
            row = self.pending_input(store, input_id, owner, token_digest)
            store.require_fence(self.fence)
            row.commit_context(db, context)
        with self.progress.using_attempts(store):
            return self.progress.fail_terminal(failure)

    async def continue_after_failure(self, settlement, failure: TurnFailure) -> None:
        if settlement.can_retry:
            await asyncio.sleep(failure.retry_delay(self.execution.attempt_ordinal))
            raise RetryScheduled

    async def fail_unknown(self, bus, owner, witness) -> None:
        def settle(store):
            with self.progress.using_attempts(store), store.session.capture(bus) as boundary:
                witness.require_live(boundary.registry, self.fence)
                self.progress.fail_unknown(boundary)

        await Coordination.run_async(self.progress.attempts.session.path, settle)

    def reserve_claim(self, store: Coordination, db: sqlite3.Connection,
                      *, attempt: int = 0) -> None:
        if attempt:
            raise IdentityConflict("Only a triage input has a replacement attempt")
        snapshot, _ = store.require_fence(self.fence)
        self.require_claim(store)
        if snapshot.pointer_revision < 1 or self.assignments != snapshot.assignments:
            raise StaleFence("full input cannot bind to the current attempt")
        if NativeRuntimeInput.select(
            db,
            where="execution_id=? AND attempt_ordinal=?",
            parameters=(
                self.execution.execution_id, self.execution.attempt_ordinal,
            ),
        ):
            raise IdentityConflict("this execution attempt already has a native input")

    def require_acknowledgement(self, store: Coordination) -> None:
        snapshot, _ = store.require_fence(self.fence)
        for assignment in self.assignments:
            engagement = assignment.lifecycle.require_engagement()
            snapshot.require_wire_response(engagement.exact_target)

    def require_phase(self, store: Coordination, current: WakeAssignment) -> None:
        snapshot, attempt = store.require_fence(self.fence)
        current.lifecycle.require_engagement()
        if (
            not snapshot.execution.lifecycle.items_with(Active, snapshot.execution)
            or not attempt.lifecycle.starting
            or attempt.lifecycle.backend_done
            or attempt.lifecycle.process_dead
        ):
            raise StaleFence("full execution is not running before native send")
