"""Original refused-send outcomes in the delivery coordination database."""

from __future__ import annotations

import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Annotated

from agent_comms.coordination.database import CoordinationStore
from agent_comms.coordination.schema import CoordinatorRow
from agent_comms.coordination.session import CoordinationSession
from agent_comms.errors import RelationViolationError
from agent_comms.storage.locked_store import RegistryFile
from agent_comms.storage.maintenance_barrier import MaintenanceBarrier
from agent_comms.storage.typed_table import Column, Index
from agent_comms_hooks import ToolRefusedError

if TYPE_CHECKING:
    from agent_comms.coordination.coordinator import Coordination


@dataclass(frozen=True)
class SendRefusal(CoordinatorRow):
    """One attempted send, with no fabricated message, audience or delivery identity."""

    id: Annotated[int, Column(primary_key=True)]
    sender: str
    target: str
    reason: str
    refused_at_ms: int
    indexes = (Index(("sender", "id")), Index(("target", "id")))

    @classmethod
    def install(cls, store: Coordination) -> None:
        """Explicit upgrade operation; ordinary reads and writes never repair schema."""
        with store.session.writing() as db:
            if cls.stored_schema(db):
                cls.require_schema(db)
            else:
                cls.create(db)

    @classmethod
    def record(cls, root: Path, sender: str, target: str, error: ToolRefusedError) -> None:
        with (
            MaintenanceBarrier(RegistryFile.path_in(root)).allow_input(),
            CoordinationSession(str(CoordinationStore.path_in(root))) as store,
            store.writing() as db,
        ):
            cls.require_schema(db)
            # SQLite allocates this attempt's identity. The text is exactly
            # the refusal returned to the caller, not a page's summary.
            cls.insert_values(
                db,
                sender=sender,
                target=target,
                reason=str(error),
                refused_at_ms=time.time_ns() // 1_000_000,
            )

    @classmethod
    def recent(
        cls, root: Path, *, sender: str = "", target: str = "", limit: int = 50
    ) -> tuple[SendRefusal, ...]:
        if not 1 <= limit <= 200:
            raise ToolRefusedError("Refusal reads require a limit between 1 and 200")
        source = CoordinationStore.observed(CoordinationStore.path_in(root))
        with source.observing(cls, sender, target, limit) as rows:
            return rows

    @classmethod
    def capture(cls, db: sqlite3.Connection, sender: str, target: str, limit: int):
        cls.require_schema(db)
        filters = {name: value for name, value in (("sender", sender), ("target", target)) if value}
        return tuple(cls.select(db, order_by=("id",), descending=True, limit=limit, **filters))

    @classmethod
    def missing_store(cls, store, *arguments):
        return ()

    @classmethod
    def invalid_store(cls, store, *arguments):
        raise RelationViolationError(f"Send refusal outcomes unavailable: {store.failure_reason}")
