"""Response lifecycle owns acknowledgement data and its public recovery projection."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, ClassVar

from agent_comms.coordination.errors import IdentityConflict, IntegrityViolationError
from agent_comms.coordination.reason_codes import NoReasonCode
from agent_comms.coordination.vocabulary import CoordinatorVocabulary
from agent_comms.messaging.message_reference import MessageReference
from agent_comms.nominal.field_codec import MessageId, NullMember
from agent_comms.nominal.lifecycle import LifecycleState
from agent_comms.nominal.lifecycle_capability import Deferred, Failed, Pending, Successful, Terminal

if TYPE_CHECKING:
    from agent_comms.coordination.session import CoordinationSession
    from agent_comms.coordination.tables.responses import ResponseObligation


@dataclass(frozen=True, slots=True)
class Unpublished(NullMember):
    """An obligation has no publication acknowledgement until it is published."""


@dataclass(frozen=True)
class ResponseState(CoordinatorVocabulary, LifecycleState, affix="Response"):
    retryable: ClassVar[bool] = False
    allows_intent: ClassVar[bool] = False
    requires_intent: ClassVar[bool] = False
    published: ClassVar[bool] = False
    publishing: ClassVar[bool] = False

    @classmethod
    def sql_vocabulary(cls) -> dict[str, str]:
        members = cls.members_with(cls)
        return dict(
            response_names=cls.sql_values(cls.names()),
            successful_response_names=cls.sql_members(cls.members_with(Successful)),
            retryable_response_names=cls.sql_members(
                member for member in members if member.retryable
            ),
            intent_response_names=cls.sql_members(
                member for member in members if member.allows_intent
            ),
            required_intent_response_names=cls.sql_members(
                member for member in members if member.requires_intent
            ),
        )

    @property
    def published_message_id(self) -> MessageId | Unpublished:
        return Unpublished()

    @property
    def publication_seq(self) -> int | Unpublished:
        return Unpublished()

    def published_reference(self) -> MessageReference:
        raise IntegrityViolationError("only published obligations have an acknowledgement")

    def require_preparation(self) -> None:
        raise IdentityConflict("response obligation cannot prepare a new intent")

    def require_existing_preparation(self) -> None:
        raise IdentityConflict("prepared response envelope conflicts")

    def require_publishing(self) -> None:
        raise IdentityConflict("no frozen publishing intent for current owner")

    @classmethod
    def resume_response(
        cls, session: CoordinationSession, obligation: ResponseObligation, execution_id: str
    ) -> None:
        """Only a deferred response needs to reengage."""

    def require_nonpublication(self) -> None:
        if not self.retryable:
            raise IdentityConflict("wire completion requires nonpublication obligation")

    def validate_publication(self, intent, acknowledgement) -> None:
        if intent is not None and not self.allows_intent:
            raise IntegrityViolationError("publication intent is invalid for obligation state")
        if intent is None and self.requires_intent:
            raise IntegrityViolationError("publishing and published obligations require intent")
        self.validate_acknowledgement(acknowledgement)
        if acknowledgement is not None:
            intent.validate_acknowledgement(acknowledgement)

    def validate_acknowledgement(self, acknowledgement) -> None:
        if acknowledgement is not None:
            raise IntegrityViolationError("publication acknowledgement exists iff published")


class PendingResponse(Pending, ResponseState):
    retryable = True

    def require_preparation(self) -> None:
        pass

    @classmethod
    def successors(cls):
        return PublishingResponse, DeferredResponse, SilentResponse, FailedResponse


class PublishingResponse(ResponseState):
    publishing = True
    allows_intent = True
    requires_intent = True

    def require_publishing(self) -> None:
        pass

    def require_existing_preparation(self) -> None:
        pass

    @classmethod
    def successors(cls):
        return PublishedResponse, FailedResponse


class DeferredResponse(Deferred, ResponseState):
    retryable = True

    @classmethod
    def resume_response(
        cls, session: CoordinationSession, obligation: ResponseObligation, execution_id: str
    ) -> None:
        obligation.update(
            session._connection,
            where="execution_id=? AND exact_target=?",
            parameters=(execution_id, obligation.exact_target),
            lifecycle=PendingResponse(),
            revision=obligation.revision + 1,
            reason_code=NoReasonCode(),
            updated_at_ms=session.now(obligation.updated_at_ms),
        )

    @classmethod
    def successors(cls):
        return PendingResponse, SilentResponse, FailedResponse


@dataclass(frozen=True)
class PublishedResponse(Successful, ResponseState):
    message_id: MessageId
    seq: int
    allows_intent = True
    requires_intent = True
    published = True

    def __post_init__(self):
        if type(self.seq) is not int or self.seq <= 0:
            raise ValueError("receipt_seq must be positive")

    @property
    def published_message_id(self):
        return self.message_id

    @property
    def publication_seq(self):
        return self.seq

    def published_reference(self) -> MessageReference:
        return MessageReference(self.seq, self.message_id)

    def validate_acknowledgement(self, acknowledgement) -> None:
        if acknowledgement is None:
            raise IntegrityViolationError("publication acknowledgement exists iff published")
        if (acknowledgement.message_id, acknowledgement.seq) != (self.message_id, self.seq):
            raise IntegrityViolationError("obligation acknowledgement does not match publication")


class SilentResponse(Successful, ResponseState):
    pass


class FailedResponse(Failed, Terminal, ResponseState):
    allows_intent = True
