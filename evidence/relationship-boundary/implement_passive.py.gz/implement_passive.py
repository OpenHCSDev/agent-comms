from pathlib import Path
p=Path('src/agent_comms/passive_channel_awareness.py');s=p.read_text()
s=s.replace('from dataclasses import dataclass, fields, replace','from dataclasses import dataclass, field, replace').replace('from typing import Any','from typing import Any, Literal')
s=s.replace('from .field_codec import FieldCodec\n','')
a=s.index('    @classmethod\n    def from_payload');b=s.index('    def scoped(',a)
s=s[:a]+'''    @staticmethod
    def key(created_at: float) -> str:
        return sha256(repr(created_at).encode()).hexdigest()

    def current(self, owner: Thread, snapshot: RegistrySnapshot, channels: frozenset[str]) -> bool:
        return (
            self.created_at == owner.created_at
            and self.admission == snapshot.admission_generations.get(owner.name)
            and self.scope_generation == owner.channel_scope_generation
            and self.channels == tuple(sorted(channels))
            and snapshot.aliases.get(self.name, self.name) == owner.name
        )

'''+s[b:]
a=s.index('class PassiveAwarenessStore(');b=s.index('\n\nclass PassiveChannelAwareness:',a)
s=s[:a]+'''@dataclass(frozen=True, slots=True)
class PassiveAwarenessDocument:
    rows: dict[str, PassiveAwarenessRecord] = field(default_factory=dict)
    version: Literal[1] = 1

    def __post_init__(self):
        if any(key != row.key(row.created_at) for key, row in self.rows.items()):
            raise ValueError("Passive awareness key differs from its saved incarnation")

    def for_owner(self, owner: Thread) -> PassiveAwarenessRecord | None:
        return self.rows.get(PassiveAwarenessRecord.key(owner.created_at))

    def updated(self, row: PassiveAwarenessRecord) -> PassiveAwarenessDocument:
        return replace(self, rows={**self.rows, row.key(row.created_at): row})


class PassiveAwarenessStore(LockedStore[PassiveAwarenessDocument | None]):
    """One optional typed document; invalid data is left untouched, never repaired."""

    filename = "acp_passive_channel_awareness.json"
    json_sort_keys = True

    @property
    def record_type(self) -> type[PassiveAwarenessDocument]:
        return PassiveAwarenessDocument

    def empty(self) -> PassiveAwarenessDocument:
        return PassiveAwarenessDocument()

    def _unreadable(self, error: Exception) -> None:
        return None
'''+s[b:]
a=s.index('    @staticmethod\n    def _key(');b=s.index('    def initialize(',a)
s=s[:a]+s[b:]
s=s.replace('document: dict[str, Any] | None','document: PassiveAwarenessDocument | None').replace('-> dict[str, Any] | None:', '-> PassiveAwarenessDocument | None:')
s=s.replace('            rows = dict(document["rows"])\n            key = self._key(owner)\n            saved = rows.get(key)\n            row = PassiveAwarenessRecord.from_payload(saved) if saved is not None else None', '            row = document.for_owner(owner)')
s=s.replace('                rows[key] = FieldCodec.encode(\n                    PassiveAwarenessRecord(', '                return document.updated(\n                    PassiveAwarenessRecord(')
s=s.replace('                return {**document, "rows": rows}\n','')
s=s.replace('''                rows[key] = {
                    **rows[key],
                    **FieldCodec.encode(row.scoped(owner, high_water, channels)),
                }''', '''                return document.updated(row.scoped(owner, high_water, channels))''')
s=s.replace('''            rows = dict(document["rows"])
            saved = rows.get(self._key(owner))
            row = PassiveAwarenessRecord.from_payload(saved) if saved is not None else None''', '''            row = document.for_owner(owner)''')
s=s.replace('''            rows[self._key(owner)] = {
                **rows[self._key(owner)],
                **FieldCodec.encode(row.scoped(owner, high_water, channels)),
            }
            return {**document, "rows": rows}''', '''            return document.updated(row.scoped(owner, high_water, channels))''')
s=s.replace('''            rows = document["rows"] if document is not None else None
            saved = rows.get(self._key(owner)) if rows is not None else None
            row = PassiveAwarenessRecord.from_payload(saved) if saved is not None else None''', '''            row = document.for_owner(owner) if document is not None else None''')
s=s.replace('''                or row.created_at != owner.created_at
                or row.admission != snapshot.admission_generations.get(owner.name)
                or row.scope_generation != owner.channel_scope_generation
                or row.channels != tuple(sorted(channels))
                or snapshot.aliases.get(row.name, row.name) != owner.name''', '''                or not row.current(owner, snapshot, channels)''')
s=s.replace('''            rows = document["rows"]
            key = self._key(owner)
            saved = rows.get(key)
            row = PassiveAwarenessRecord.from_payload(saved) if saved is not None else None''','''            row = document.for_owner(owner)''')
s=s.replace('''                or row.created_at != owner.created_at
                or row.admission != admission
                or row.scope_generation != owner.channel_scope_generation
                or row.channels != tuple(sorted(channels))
                or snapshot.aliases.get(row.name, row.name) != owner.name''','''                or not row.current(owner, snapshot, channels)''')
s=s.replace('        admission = snapshot.admission_generations.get(owner.name)\n','')
s=s.replace('''                            changed = {
                                **document,
                                "rows": {
                                    **rows,
                                    key: {
                                        **rows[key],
                                        **FieldCodec.encode(replace(row, known=latest)),
                                    },
                                },
                            }''','''                            changed = document.updated(replace(row, known=latest))''')
p.write_text(s)
# Actual consumer of removed path proxy.
p=Path('src/agent_comms/operations.py');s=p.read_text().replace('awareness.path.exists()', 'awareness.store.path.exists()');p.write_text(s)
