from pathlib import Path
for p in Path('tests').glob('*.py'):
 s=p.read_text();n=s.replace('.relationships.path','.relationships.store.path').replace('awareness.path','awareness.store.path')
 if p.name=='test_relationship_awareness_store.py':
  n=n.replace('service.path','service.store.path').replace('    store.path.write_text(', '    store.store.path.write_text(').replace('json.loads(store.path.read_text())','json.loads(store.store.path.read_text())')
  n=n.replace('PassiveAwarenessStore, PassiveChannelAwareness', 'PassiveAwarenessDocument, PassiveAwarenessRecord, PassiveAwarenessStore, PassiveChannelAwareness').replace('from agent_comms.relationships import RelationshipStore','from agent_comms.relationships import RelationshipDocument, RelationshipStore')
  n=n.replace('assert service.store.read() == {"version": 1, "collaborations": [], "orders": []}', 'assert service.store.read() == RelationshipDocument()')
  n=n.replace('        "version": 1,\n        "collaborations":', '        "collaborations":',1)
  n=n.replace('                "updated_at": 123.0,','                "updated_at": 123.0,\n                "history": [],',1)
  n=n.replace('    assert service.store.path.read_text() == json.dumps(expected, indent=2) + "\\n"','    expected["version"] = 2\n    assert service.store.path.read_text() == json.dumps(expected, indent=2) + "\\n"')
  n=n.replace('test_golden_passive_scope_and_unknown_fields','test_golden_passive_scope_and_typed_records').replace('    row["extension"] = {"keep": [1, 2]}\n','')
  n=n.replace('awareness._key(owner())','PassiveAwarenessRecord.key(owner().created_at)')
  n=n.replace('assert document == {"version": 1, "rows": {}}','assert document == PassiveAwarenessDocument()')
  n=n.replace('{row["name"] for row in data["rows"].values()}','{row.name for row in data.rows.values()}')
  a=n.index('\ndef test_relationship_extension_keys_survive_mutations(')
  n=n[:a]+'\n'
 if p.name=='test_relationships.py':
  a=n.index('\ndef test_legacy_opposite_declarations_project_once_without_losing_notes');b=n.index('\ndef test_bounded_window',a)
  n=n[:a]+n[b:];n=n.replace('from dataclasses import asdict, replace\n','')
 if p.name=='test_passive_channel_awareness.py':
  n=n.replace('def observed(path, *, shared=False):','def observed(path, *, shared=False, blocking=True):').replace('with _store_lock(path, shared=shared):','with _store_lock(path, shared=shared, blocking=blocking):')
 if p.name=='test_goal_mentions.py':
  n=n.replace('def fail_save() -> None:','def fail_save(_self, _text) -> None:').replace('monkeypatch.setattr(comms.registry, "_save_unlocked", fail_save)', 'monkeypatch.setattr(type(comms.registry.store), "_write_unlocked", fail_save)')
 if n!=s:p.write_text(n)
p=Path('src/agent_comms/relationships.py');s=p.read_text().replace('from dataclasses import dataclass, fields, replace','from dataclasses import dataclass, field, fields, replace')
s=s.replace('collaborations: tuple[Collaboration, ...] = ()','collaborations: tuple[Collaboration, ...] = field(default=(), metadata={"wire_required": True})').replace('orders: tuple[RelationshipOrder, ...] = ()','orders: tuple[RelationshipOrder, ...] = field(default=(), metadata={"wire_required": True})').replace('version: Literal[2] = 2','version: Literal[2] = field(default=2, metadata={"wire_required": True})');p.write_text(s)
p=Path('src/agent_comms/passive_channel_awareness.py');s=p.read_text().replace('field(default_factory=dict)','field(default_factory=dict, metadata={"wire_required": True})').replace('version: Literal[1] = 1','version: Literal[1] = field(default=1, metadata={"wire_required": True})');p.write_text(s)
