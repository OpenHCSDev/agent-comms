from pathlib import Path
p=Path('src/agent_comms/relationships.py');s=p.read_text()
s=s.replace('from dataclasses import dataclass, replace','from dataclasses import dataclass, fields, replace').replace('from typing import TYPE_CHECKING, Any','from typing import TYPE_CHECKING, Literal')
s=s.replace('class Collaboration:\n','class CollaborationRevision:\n',1)
pos=s.index('\n\n@dataclass(frozen=True, slots=True)\nclass GoalDerivedContact:')
s=s[:pos]+'''

    def incident(self, thread: Thread) -> bool:
        return (self.owner, self.owner_created) == (thread.name, thread.created_at) or (
            self.peer, self.peer_created
        ) == (thread.name, thread.created_at)

    def counterpart(self, thread: Thread) -> tuple[str, float]:
        if (self.owner, self.owner_created) == (thread.name, thread.created_at):
            return self.peer, self.peer_created
        return self.owner, self.owner_created

    def oriented(self, thread: Thread):
        if (self.owner, self.owner_created) == (thread.name, thread.created_at):
            return self
        return replace(self, owner=self.peer, peer=self.owner,
                       owner_created=self.peer_created, peer_created=self.owner_created)

    @property
    def pair_identity(self) -> frozenset[tuple[str, float]]:
        return frozenset(((self.owner, self.owner_created), (self.peer, self.peer_created)))

    def resolved(self, registry: RegistrySnapshot):
        def current_name(name: str, created: float) -> str:
            canonical = registry.aliases.get(name, name)
            thread = registry.threads.get(canonical)
            return canonical if thread and thread.created_at == created else name

        return replace(self, owner=current_name(self.owner, self.owner_created),
                       peer=current_name(self.peer, self.peer_created))


@dataclass(frozen=True, slots=True)
class Collaboration(CollaborationRevision):
    # Previous records are immutable provenance, never active parallel edges.
    history: tuple[CollaborationRevision, ...] = ()

    def revision(self) -> CollaborationRevision:
        return CollaborationRevision(**{
            field.name: getattr(self, field.name) for field in fields(CollaborationRevision)
        })

    def updated(self, note: str, now: float) -> Collaboration:
        return replace(self, note=note, updated_at=now, history=(*self.history, self.revision()))
'''+s[pos:]
a=s.index('class RelationshipStore(');b=s.index('\n\nclass ThreadRelationships:',a)
s=s[:a]+'''@dataclass(frozen=True, slots=True)
class RelationshipDocument:
    collaborations: tuple[Collaboration, ...] = ()
    orders: tuple[RelationshipOrder, ...] = ()
    version: Literal[2] = 2

    def __post_init__(self):
        pairs = [edge.pair_identity for edge in self.collaborations]
        if len(pairs) != len(set(pairs)):
            raise ValueError("Duplicate collaboration pairs require explicit migration")
        order_keys = [(row.owner, row.owner_created, row.group) for row in self.orders]
        if len(order_keys) != len(set(order_keys)):
            raise ValueError("Duplicate relationship sort preferences")

    def resolved(self, registry: RegistrySnapshot) -> RelationshipDocument:
        # Rename aliases are current domain data; deleted/rebound names stay historical.
        def resolve_order(row: RelationshipOrder) -> RelationshipOrder:
            name = registry.aliases.get(row.owner, row.owner)
            owner = registry.threads.get(name)
            return replace(row, owner=name) if owner and owner.created_at == row.owner_created else row

        return replace(self, collaborations=tuple(edge.resolved(registry) for edge in self.collaborations),
                       orders=tuple(resolve_order(row) for row in self.orders))

    def edit(self, first: Thread, peer: str, second: Thread | None,
             action: str, note: str) -> tuple[RelationshipDocument, Collaboration | None]:
        pairs = tuple(edge for edge in self.collaborations
                      if {edge.owner, edge.peer} == {first.name, peer} and edge.incident(first))
        active = next((edge for edge in pairs if second is not None
                       and edge.counterpart(first) == (second.name, second.created_at)), None)
        unavailable = next((edge for edge in pairs if edge is not active), None)
        existing = active or unavailable
        if action == "remove":
            if existing is None:
                return self, None
            return replace(self, collaborations=tuple(edge for edge in self.collaborations
                            if edge.pair_identity != existing.pair_identity)), None
        if second is None:
            raise ValueError(f"Unknown collaboration peer: {peer}")
        if not second.role.executable:
            raise ValueError("Collaborations relate agent threads")
        if first.name == second.name:
            raise ValueError("A thread cannot collaborate with itself")
        if unavailable and active is None:
            raise ValueError("Peer identity was replaced; explicitly remove the unavailable "
                             "collaboration before adding a new one")
        if action == "update" and active is None:
            raise ValueError("Collaboration does not exist")
        if action == "add" and active is not None:
            return self, active.oriented(first)
        now = time.time()
        changed = active.updated(note, now) if active else Collaboration(
            first.name, second.name, first.created_at, second.created_at, note, now, now
        )
        return replace(self, collaborations=tuple(edge for edge in self.collaborations
                            if edge is not active) + (changed,)), changed.oriented(first)

    def ordered(self, owner: Thread, group: str, order: ThreadSort) -> RelationshipDocument:
        row = RelationshipOrder(owner.name, owner.created_at, group, order)
        rows = tuple(saved for saved in self.orders if (saved.owner, saved.owner_created, saved.group)
                     != (owner.name, owner.created_at, group))
        return replace(self, orders=(*rows, row))


class RelationshipStore(LockedStore[RelationshipDocument]):
    """One current typed schema. Version1 conversion is an explicit offline operation."""

    filename = "relationships.json"
    json_indent = 2
    json_suffix = "\\n"

    @property
    def record_type(self) -> type[RelationshipDocument]:
        return RelationshipDocument

    def empty(self) -> RelationshipDocument:
        return RelationshipDocument()
'''+s[b:]
# Delete all service projection/identity helper implementations; move behavior to records.
a=s.index('    @property\n    def path(self)');b=s.index('    def collaborations(',a)
s=s[:a]+s[b:]
s=s.replace('file_revision(self.path)','file_revision(self.store.path)')
s=s.replace('edges = self._unique_edges(self._canonical_edges(self.store.read(), registry))','edges = self.store.read().resolved(registry).collaborations')
s=s.replace('self._orient(edge, thread)','edge.oriented(thread)').replace('self._incident(edge, thread)','edge.incident(thread)').replace('self._counterpart(edge, thread)','edge.counterpart(thread)')
a=s.index('    def edit(self, owner:');b=s.index('    def _recent_messages(',a)
s=s[:a]+'''    def edit(self, owner: str, action: str, peer: str, note: str = "") -> Collaboration | None:
        if action not in {"add", "update", "remove"}:
            raise ValueError("Expected add, update or remove")
        if len(note) > 2000:
            raise ValueError("Collaboration notes are limited to 2000 characters")
        with _store_lock(self.comms._wire_lock_path):
            first = self.comms.registry.require(owner)
            if not first.role.executable:
                raise ValueError("Collaborations relate agent threads")
            registry = self.comms.registry.snapshot()
            peer = registry.aliases.get(peer, peer)
            result = None

            def change(document: RelationshipDocument) -> RelationshipDocument:
                nonlocal result
                resolved = document.resolved(registry)
                changed, result = resolved.edit(first, peer, registry.threads.get(peer), action, note)
                return document if changed == document else changed

            self.store.update(change)
            return result

    def set_order(self, owner: str, group: str, order: ThreadSort) -> ThreadSort:
        if group not in {"children", "collaborating"}:
            raise ValueError("This relationship group has no selectable sort")
        with _store_lock(self.comms._wire_lock_path):
            thread = self.comms.registry.require(owner)
            registry = self.comms.registry.snapshot()
            self.store.update(lambda document: document.resolved(registry).ordered(thread, group, order))
        return order

'''+s[b:]
s=s.replace('state = self.store.read()\n            edges = self._canonical_edges(state, registry)','state = self.store.read().resolved(registry)\n            edges = state.collaborations')
s=s.replace('for row in state["orders"]:', 'for row in state.orders:').replace('canonical(row["owner"])','canonical(row.owner)').replace('row["owner_created"]','row.owner_created').replace('row["group"]','row.group').replace('ThreadSort(row["order"])','row.order')
s=s.replace('for edge in self._unique_edges(edges):','for edge in edges:')
p.write_text(s)
