from pathlib import Path
import ast,re
families={
'WakeMode':('wake_policy','WakePolicy','Wake'),
'ClaimDisposition':('claim_states','ClaimState','Claim'),
'ExecutionStatus':('execution_states','ExecutionState','Execution'),
'AttemptPhase':('attempt_states','AttemptState','Attempt'),
'ObligationState':('obligation_states','ResponseState','Response'),
'RecoveryKind':('recovery_states','RecoveryCondition','Recovery'),
}
classes={}
for old,(module,root,suffix) in families.items():
 for n in ast.parse(Path(f'src/agent_comms/{module}.py').read_text()).body:
  if isinstance(n,ast.ClassDef):
   stem=n.name.removesuffix(suffix)
   snake=re.sub(r'([a-z0-9])([A-Z])',r'\1_\2',re.sub(r'([A-Z]+)([A-Z][a-z])',r'\1_\2',stem)).upper()
   classes[old,snake]=(module,n.name)
for p in [*Path('src/agent_comms').glob('*.py'),*Path('tests').glob('*.py')]:
 s=p.read_text()
 if not any(re.search(r'\b'+name+r'\b',s) for name in families):continue
 imports={}
 # Remove stale imports before introducing names; keep executable child scripts.
 s=re.sub(r'(?m)^([ \t]*)from ([.\w]*coordination) import (\([^)]*\)|[^\n]+)',
          lambda m: m[1]+'from '+m[2]+' import '+', '.join(x.strip() for x in m[3].strip().strip('()').split(',') if x.strip() and x.strip() not in families),s)
 s=re.sub(r'(?m)^\s*from [\w.]+ import\s*$', '',s)
 for old,(module,root,suffix) in families.items():
  def member(m):
   mod,cls=classes[old,m[1]];imports.setdefault(mod,set()).add(cls)
   return cls+'()' if old=='WakeMode' else cls
  s=re.sub(r'\b'+old+r'\.([A-Z][A-Z_]+)\b',member,s)
  if re.search(r'\b'+old+r'\b',s):
   imports.setdefault(module,set()).add(root)
   # Remaining references are family-root decoding, types or tests of discovery.
   s=re.sub(r'\b'+old+r'\(',root+'.decode(',s)
   s=re.sub(r'\b'+old+r'\b',root,s)
 # Need wake construction after decoding. Static constants are already instances.
 s=re.sub(r'WakePolicy.decode\(([^()]*)\)',r'WakePolicy.decode(\1)()',s)
 # New class names have a name owned by their declaration, not enum.value.
 for pair,(module,cls) in classes.items():
  s=s.replace(cls+'.value',cls+'.declared_name')
 if imports:
  prefix='.' if p.parts[0]=='src' else 'agent_comms.'
  lines=s.splitlines(keepends=True);tree=ast.parse(s)
  insert=0
  for n in tree.body:
   if isinstance(n,ast.Expr) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str) or isinstance(n,ast.ImportFrom) and n.module=='__future__':insert=n.end_lineno
   else:break
  lines[insert:insert]=['\n']+[f'from {prefix}{mod} import {", ".join(sorted(names))}\n' for mod,names in sorted(imports.items())]
  s=''.join(lines)
 p.write_text(s)
