exec(__import__('pathlib').Path('.artifacts/s3-deletion/migrate_record_callers.py').read_text().split('for p in [')[0])
class Constructors(Migration):
 def visit_Attribute(self,n):self.generic_visit(n)
 def visit_Call(self,n):
  typ=self.infer(n)
  name=n.func.id if isinstance(n.func,ast.Name) else ''
  if typ not in fields or name not in {*fields,'replace'}:
   self.generic_visit(n);return
  kw={k.arg:ast.get_source_segment(self.s,k.value) for k in n.keywords}
  if None in kw:self.generic_visit(n);return
  args=[ast.get_source_segment(self.s,x) for x in n.args]
  replacing=name=='replace'
  base=args[0]+'.lifecycle' if replacing else None
  if not replacing and typ=='WakeClaim' and args:
   old=['claim_id','recipient','recipient_lookup','wire_seq','message_id','exact_target','audience','wake_mode','triage_verdict','disposition','accepted_at_ms','updated_at_ms','revision','resolver_version','policy_version','execution_id']
   kw=dict(zip(old,args))|kw;args=[]
  keys=set(fields[typ])
  if not keys.intersection(kw):self.generic_visit(n);return
  def take(key,attr=None,default='None'):
   return kw.pop(key, f'{base}.{attr or key}' if base else default)
  family=take({'WakeClaim':'disposition','ExecutionRecord':'status','AttemptRecord':'phase','ResponseObligation':'state'}[typ],default='None')
  if family=='None' and 'lifecycle' in kw:family='type('+kw.pop('lifecycle')+')'
  elif base and family==base+'.'+{'WakeClaim':'disposition','ExecutionRecord':'status','AttemptRecord':'phase','ResponseObligation':'state'}[typ]:family='type('+base+')'
  if typ=='WakeClaim':parts=[take('wake_mode','mode'),take('triage_verdict','verdict'),take('execution_id'),take('exact_target')]
  elif typ=='ExecutionRecord':parts=[take('current_attempt_ordinal')]
  elif typ=='AttemptRecord':parts=[take('lease_expires_at_ms'),take('backend_done',default='False'),take('process_dead',default='False')]
  else:parts=[take('receipt_message_id'),take('receipt_seq')]
  kw['lifecycle']=family+'.load('+', '.join(parts)+')'
  text=name+'('+', '.join([*args,*(k+'='+v for k,v in kw.items())])+')'
  self.edits.append((self.offsets[n.lineno-1]+n.col_offset,self.offsets[n.end_lineno-1]+n.end_col_offset,text))
for p in [*Path('src/agent_comms').glob('*.py'),*Path('tests').glob('*.py')]:
 s=p.read_text()
 if not any(x in s for x in ['.coordination','class WakeClaim']):continue
 m=Constructors(s);m.visit(ast.parse(s))
 for a,b,v in sorted(set(m.edits),reverse=True):s=s[:a]+v+s[b:]
 p.write_text(s)
