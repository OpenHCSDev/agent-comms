from pathlib import Path
import ast,re
p=Path('src/agent_comms/coordination.py');s=p.read_text()
s=s.replace('from .state_tags import state_tags, transition_tags\n','')
# Remove compatibility declarations and redundant materialized collections.
t=ast.parse(s);lines=s.splitlines(keepends=True);delete=[]
names={'WakeMode','ClaimDisposition','ExecutionStatus','AttemptPhase','ObligationState','RecoveryKind','CLAIM_DISPOSITION_TRANSITIONS','EXECUTION_STATUS_TRANSITIONS','ATTEMPT_PHASE_TRANSITIONS','OBLIGATION_STATE_TRANSITIONS','ACTIVE_ATTEMPT_PHASES','TERMINAL_ATTEMPT_PHASES','TERMINAL_EXECUTION_STATUSES'}
for node in t.body:
 targets=node.targets if isinstance(node,ast.Assign) else [node.target] if isinstance(node,ast.AnnAssign) else []
 if any(isinstance(x,ast.Name) and x.id in names for x in targets):delete.append((node.lineno-1,node.end_lineno))
for a,b in reversed(delete):lines[a:b]=[]
s=''.join(lines)
# Plain constructors accept only their actual typed determining lifecycle.
t=ast.parse(s);lines=s.splitlines(keepends=True);delete=[]
records={'WakeClaim','ExecutionRecord','AttemptRecord','ResponseObligation'}
for cls in t.body:
 if isinstance(cls,ast.ClassDef) and cls.name in records:
  for n in cls.body:
   if isinstance(n,ast.FunctionDef) and n.name=='__init__':delete.append((n.lineno-1,n.end_lineno))
for a,b in reversed(sorted(delete)):lines[a:b]=[]
s=''.join(lines).replace('@dataclass(frozen=True, slots=True, init=False)','@dataclass(frozen=True, slots=True)')
# The snapshot codec keeps the external field names. These explicit wire
# getters are not the internal record API and return no compatibility enum.
for name in ['disposition','wake_mode','triage_verdict','status','current_attempt_ordinal','phase','lease_expires_at_ms','backend_done','process_dead','state','receipt_message_id','receipt_seq']:
 s=s.replace(f'@projected(view="snapshot")\n    def {name}(',f'@projected(view="snapshot", name="{name}")\n    def snapshot_{name}(')
# Only WakeClaim's execution/target projections; other records own real fields.
a=s.index('class WakeClaim:');b=s.index('\ndef claim_transition_allowed',a);chunk=s[a:b]
for name in ['execution_id','exact_target']:
 chunk=chunk.replace(f'@projected(view="snapshot")\n    def {name}(',f'@projected(view="snapshot", name="{name}")\n    def snapshot_{name}(')
s=s[:a]+chunk+s[b:]
s=s.replace('ClaimDisposition(self.lifecycle.declared_name)','self.lifecycle.declared_name').replace('WakeMode(self.lifecycle.mode.declared_name)','self.lifecycle.mode.declared_name').replace('ExecutionStatus(self.lifecycle.declared_name)','self.lifecycle.declared_name').replace('AttemptPhase(self.lifecycle.declared_name)','self.lifecycle.declared_name').replace('ObligationState(self.lifecycle.declared_name)','self.lifecycle.declared_name')
s=s.replace('return TriageVerdict(verdict) if verdict is not None else None','return verdict')
s=s.replace('kind: RecoveryKind','kind: type[RecoveryCondition]').replace('        object.__setattr__(self, "kind", RecoveryKind(self.kind))\n','')
s=s.replace('or attempt.phase not in ACTIVE_ATTEMPT_PHASES','or attempt.lifecycle.terminal')
p.write_text(s)
Path('src/agent_comms/state_tags.py').unlink()
# Encode/decode nominal declaration classes at actual scalar wire boundaries.
p=Path('src/agent_comms/field_codec.py');s=p.read_text()
s=s.replace('        if isinstance(value, Enum):','        if isinstance(value, type) and issubclass(value, DeclaredFamily):\n            return value.declared_name\n        if isinstance(value, Enum):',1)
s=s.replace('        if origin is Literal:', '''        if origin is type and args and issubclass(args[0], DeclaredFamily):
            if type(data) is not str:
                raise ValueError("Expected a declared family name.")
            return args[0].decode(data)
        if origin is Literal:''',1);p.write_text(s)
