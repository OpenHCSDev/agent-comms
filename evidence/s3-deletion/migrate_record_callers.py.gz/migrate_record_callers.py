import ast
from pathlib import Path
# One-time source migration information, never installed or imported by runtime.
fields={
 'WakeClaim':{'disposition':'type','wake_mode':'mode','triage_verdict':'verdict','execution_id':'execution_id','exact_target':'exact_target'},
 'ExecutionRecord':{'status':'type','current_attempt_ordinal':'current_attempt_ordinal'},
 'AttemptRecord':{'phase':'type','lease_expires_at_ms':'lease_expires_at_ms','backend_done':'backend_done','process_dead':'process_dead'},
 'ResponseObligation':{'state':'type','receipt_message_id':'receipt_message_id','receipt_seq':'receipt_seq'},
}
fieldtypes={'RecoverySnapshot':{'execution':'ExecutionRecord','attempt':'AttemptRecord','claims':'WakeClaim','obligation':'ResponseObligation','last_recovery':'RecoveryAudit'},'StartResult':{'snapshot':'RecoverySnapshot'},'WakeClaim':{'lifecycle':'ClaimState'},'ExecutionRecord':{'lifecycle':'ExecutionState'},'AttemptRecord':{'lifecycle':'AttemptState'},'ResponseObligation':{'lifecycle':'ResponseState'}}
returns={'_claim':'WakeClaim','_execution':'ExecutionRecord','_attempt':'AttemptRecord','claim':'WakeClaim','execution':'ExecutionRecord','attempt':'AttemptRecord','obligation':'ResponseObligation','snapshot':'RecoverySnapshot',**{x:x for x in fields}}
def annotation(n):
 if isinstance(n,ast.Name):return n.id
 if isinstance(n,ast.BinOp):return annotation(n.left)
 if isinstance(n,ast.Subscript):return annotation(n.slice)
 return None
fallback={'claim':'WakeClaim','execution':'ExecutionRecord','attempt':'AttemptRecord','obligation':'ResponseObligation','snapshot':'RecoverySnapshot','execution_record':'ExecutionRecord','attempt_record':'AttemptRecord'}
class Migration(ast.NodeVisitor):
 def __init__(self,s):self.s=s;self.env={};self.owner=None;self.edits=[];self.lines=s.splitlines(keepends=True);self.offsets=[0];[self.offsets.append(self.offsets[-1]+len(x)) for x in self.lines]
 def infer(self,n):
  if isinstance(n,ast.Name):return self.env.get(n.id,fallback.get(n.id))
  if isinstance(n,ast.Attribute):
   typ=self.infer(n.value)
   return fieldtypes.get(typ,{}).get(n.attr)
  if isinstance(n,ast.Subscript):return self.infer(n.value)
  if isinstance(n,ast.Call):
   if isinstance(n.func,ast.Name):
    if n.func.id=='replace' and n.args:return self.infer(n.args[0])
    return returns.get(n.func.id)
   if isinstance(n.func,ast.Attribute):return returns.get(n.func.attr)
  return None
 def visit_ClassDef(self,n):
  old=self.owner;self.owner=n.name;self.generic_visit(n);self.owner=old
 def visit_FunctionDef(self,n):
  old=self.env;self.env=dict(old)
  if self.owner:self.env['self']=self.owner
  for a in n.args.args+n.args.kwonlyargs:
   if a.annotation:self.env[a.arg]=annotation(a.annotation)
  self.generic_visit(n);self.env=old
 visit_AsyncFunctionDef=visit_FunctionDef
 def visit_Assign(self,n):
  typ=self.infer(n.value)
  for target in n.targets:
   if isinstance(target,ast.Name) and typ:self.env[target.id]=typ
  self.generic_visit(n)
 def visit_For(self,n):
  if isinstance(n.target,ast.Name) and (typ:=self.infer(n.iter)):self.env[n.target.id]=typ
  self.generic_visit(n)
 def visit_Attribute(self,n):
  typ=self.infer(n.value)
  if n.attr in fields.get(typ,{}):
   base=ast.get_source_segment(self.s,n.value);target=fields[typ][n.attr]
   value=f'type({base}.lifecycle)' if target=='type' else f'{base}.lifecycle.{target}'
   self.edits.append((self.offsets[n.lineno-1]+n.col_offset,self.offsets[n.end_lineno-1]+n.end_col_offset,value))
  else:self.generic_visit(n)
for p in [*Path('src/agent_comms').glob('*.py'),*Path('tests').glob('*.py')]:
 # Migrate S3 record consumers only; no heuristic rewriting of unrelated domains.
 s=p.read_text()
 if not any(x in s for x in ['.coordination','class WakeClaim','class RecoverySnapshot']):continue
 m=Migration(s);m.visit(ast.parse(s))
 for a,b,v in sorted(set(m.edits),reverse=True):s=s[:a]+v+s[b:]
 p.write_text(s)
